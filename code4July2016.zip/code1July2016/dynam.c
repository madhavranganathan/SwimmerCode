#include	"includes.h"






void new_val(int triang_site[NTRIANG][3], int triang_site2[NTRIANG2][3], double* dtime,
                 struct point3D r_mem[], struct point3D r_mem2[], struct point3D dr_mem[],
                 double zeta[], double zeta2[], double colors[], double dzeta[], double dzeta2[], double dcolors[],
                 struct point3D v_mem[],  struct point3D f_mem[], struct point3D *v_mem_cm, struct point3D *r_mem_cm,
                 struct point3D n_mem[], double curv[], double gauss[],
                 double lap_curv[], double darea[], double eta, double pp, double kappa,
                 double grav, double *area, double *vol, int step, struct point3D dv_mem[NMEM], double* target_area,
					  int Nneighbours[NMEM],int neighbours[NMEM][6],int neighbour_sites[NMEM][6][2],
					  int Nneighbours2[NMEM2],int neighbours2[NMEM2][6],int neighbour_sites2[NMEM2][6][2], int slaves[NMEM][NSLA], int slaves2[NMEM][NSLA2], int Nslaves2[NMEM], double ref_state[NTRIANG][4],double* time0,int istep,struct point3D r_ref[NMEM])
{
	int i,j,k;
	double curv0[NMEM];
	double Axi[NMEM],Axi0[NMEM],beta1,beta2,areatemp,epsilon,epsilon1,alpha,Z0,dZ0,beta3,epmax,xi[NMEM],xi0[NMEM],res[NMEM],res0[NMEM];
	double GxndA[NMEM][3][3], drmin[NMEM];
	struct point3D vxi[NMEM],vxi0[NMEM],vcurv[NMEM],vcurv2[NMEM],v_mem2[NMEM2],vpk[NMEM],vpk1[NMEM],vtemp,rtemp;
	struct point3D fdA[NMEM][4], fdA2[NMEM2][4], f_mem0[NMEM2][4], v_mem0[NMEM][4],r_mem0[NMEM],RxV[3],Omega0,V0[3];
	double r_max[NMEM],vy1,vy2,dtime2,areas[NMEM],area0, vn0,Dij[6],tempx,tempy,tempz,kk,temp0,Z0test,beta_test;
	double dV0,dA0,dV1,dA1,dV2,dA2;
	double drx,drz;
	FILE* fp;
	gsl_matrix *M;
	gsl_vector *V;
	char suf[100];
        //printf("Made it up to first geom of new_val\n");
	geom(triang_site,r_mem,v_mem,n_mem,v_mem_cm,r_mem_cm,area,vol,darea);
        //printf("Made it through first geom of new_val\n");
	if(*target_area!=0.0) *target_area-=*area;
	areatemp=4.0*PI*pow(3.0*(*vol/TAU)/4.0/PI,2.0/3.0)-*area;
	if(areatemp>MAX_AREA_CHANGE) areatemp=MAX_AREA_CHANGE;
	else if(areatemp<-MAX_AREA_CHANGE) areatemp=-MAX_AREA_CHANGE;
	areatemp+=*target_area;
	if(areatemp>MAX_AREA_CHANGE2) areatemp=MAX_AREA_CHANGE2;
	else if(areatemp<-MAX_AREA_CHANGE2) areatemp=-MAX_AREA_CHANGE2;
	#ifdef	CAPSULE
		areatemp+=*area;
	#else
		areatemp/=*dtime;
	#endif

	#ifdef PRINTSTUFF
		printf("area=%f volume=%f tau=%f areatemp=%f target area=%f\n",*area,*vol,*vol*pow(*area/(4.0*PI),-1.5)/PI*0.75,areatemp,*target_area);
	#endif

	#ifdef VISCOSITY_CONTRAST

		#ifdef DEFLATION

			for(i=0;i<NMEM;i++) areas[i]=0.0;
			for(i=0;i<NTRIANG;i++) for(j=0;j<3;j++) areas[triang_site[i][j]]+=darea[i]/3.0;
			for(j=0;j<6;j++)Dij[j]=0.0;
			RxV[0].x=RxV[0].y=RxV[0].z=0.0;

			for(i=0;i<NMEM;i++){

				tempx=r_mem[i].x-r_mem_cm->x;
				tempy=r_mem[i].y-r_mem_cm->y;
				tempz=r_mem[i].z-r_mem_cm->z;
				RxV[0].x+=(tempy*v_mem[i].z-tempz*v_mem[i].y)*areas[i];
				RxV[0].y+=(tempz*v_mem[i].x-tempx*v_mem[i].z)*areas[i];
				RxV[0].z+=(tempx*v_mem[i].y-tempy*v_mem[i].x)*areas[i];
				Dij[0]-=tempx*tempx*areas[i];
				Dij[1]-=tempy*tempy*areas[i];
				Dij[2]-=tempz*tempz*areas[i];
				Dij[3]-=tempx*tempy*areas[i];
				Dij[4]-=tempy*tempz*areas[i];
				Dij[5]-=tempz*tempx*areas[i];
			}

			M=gsl_matrix_alloc(3,3);
			V=gsl_vector_alloc(3);
			temp0=Dij[0]+Dij[1]+Dij[2];
			gsl_matrix_set(M,0,0,temp0-Dij[0]);
			gsl_matrix_set(M,1,1,temp0-Dij[1]);
			gsl_matrix_set(M,2,2,temp0-Dij[2]);
			gsl_matrix_set(M,0,1,-Dij[3]);
			gsl_matrix_set(M,1,2,-Dij[4]);
			gsl_matrix_set(M,2,0,-Dij[5]);
			gsl_matrix_set(M,1,0,-Dij[3]);
			gsl_matrix_set(M,2,1,-Dij[4]);
			gsl_matrix_set(M,0,2,-Dij[5]);
			gsl_vector_set(V,0,RxV[0].x);
			gsl_vector_set(V,1,RxV[0].y);
			gsl_vector_set(V,2,RxV[0].z);
			gsl_linalg_HH_svx(M,V);
			Omega0.x=gsl_vector_get(V,0);
			Omega0.y=gsl_vector_get(V,1);
			Omega0.z=gsl_vector_get(V,2);
			for(i=0;i<NMEM;i++){
				tempx=r_mem[i].x-r_mem_cm->x;
				tempy=r_mem[i].y-r_mem_cm->y;
				tempz=r_mem[i].z-r_mem_cm->z;
				v_mem[i].x-=v_mem_cm->x+tempy*Omega0.z-tempz*Omega0.y;
				v_mem[i].y-=v_mem_cm->y+tempz*Omega0.x-tempx*Omega0.z;
				v_mem[i].z-=v_mem_cm->z+tempx*Omega0.y-tempy*Omega0.x;
			}

			#ifdef PRINTSTUFF
				printf("%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n",r_mem_cm->x,r_mem_cm->y,r_mem_cm->z,v_mem_cm->x,v_mem_cm->y,v_mem_cm->z,Omega0.x,Omega0.y,Omega0.z);
			#endif
		#else
			#ifdef PRINTSTUFF
				printf("%f\t%f\t%f\t%f\t%f\t%f\n",r_mem_cm->x,r_mem_cm->y,r_mem_cm->z,v_mem_cm->x,v_mem_cm->y,v_mem_cm->z);
			#endif
		#endif

	#else

		#ifdef PRINTSTUFF
				printf("%f\t%f\t%f\t%f\t%f\t%f\n",r_mem_cm->x,r_mem_cm->y,r_mem_cm->z,v_mem_cm->x,v_mem_cm->y,v_mem_cm->z);
		#endif

	#endif

	put_points16(r_mem, r_mem2, slaves, Nneighbours);
	test_get_force16(triang_site,triang_site2,r_mem,r_mem2,r_mem0,n_mem,kappa,curv,gauss,lap_curv,zeta,zeta2,dzeta,dzeta2,f_mem,f_mem0,fdA,fdA2,Nneighbours,neighbours,slaves,r_max,v_mem,v_mem2,ref_state,areas,colors,*time0,r_ref);	
	free_space_green16(triang_site,slaves,Nneighbours,r_mem,r_mem2,v_mem0,f_mem0,fdA,fdA2,eta,pp,GxndA,v_mem2,slaves2,Nslaves2,*time0);

	#ifdef INTERACTION
		interaction_green16(triang_site,slaves,Nneighbours,r_mem,r_mem2,v_mem0,f_mem0,fdA,fdA2,eta,pp,v_mem2,slaves2,Nslaves2,drmin);
	#endif

	#ifdef WALL
		wall_green16(triang_site,slaves,Nneighbours,r_mem,r_mem2,v_mem0,f_mem0,fdA,fdA2,eta,pp,v_mem2,slaves2,Nslaves2);
	#endif

	#ifdef VISCOSITY_CONTRAST
		#ifdef DEFLATION
			for(j=0;j<3;j++)RxV[j].x=RxV[j].y=RxV[j].z=V0[j].x=V0[j].y=V0[j].z=0.0;
			for(i=0;i<NMEM;i++){
				tempx=r_mem[i].x-r_mem_cm->x;
				tempy=r_mem[i].y-r_mem_cm->y;
				tempz=r_mem[i].z-r_mem_cm->z;
				for(j=0;j<3;j++){
					RxV[j].x+=(tempy*v_mem0[i][j+1].z-tempz*v_mem0[i][j+1].y)*areas[i];
					RxV[j].y+=(tempz*v_mem0[i][j+1].x-tempx*v_mem0[i][j+1].z)*areas[i];
					RxV[j].z+=(tempx*v_mem0[i][j+1].y-tempy*v_mem0[i][j+1].x)*areas[i];
					V0[j].x+=v_mem0[i][j+1].x*areas[i];
					V0[j].y+=v_mem0[i][j+1].y*areas[i];
					V0[j].z+=v_mem0[i][j+1].z*areas[i];
				}
			}
			kk=(pp-1.0)*0.5;
			for(j=0;j<3;j++){
				temp0=Dij[0]+Dij[1]+Dij[2];
				gsl_matrix_set(M,0,0,temp0-Dij[0]);
				gsl_matrix_set(M,1,1,temp0-Dij[1]);
				gsl_matrix_set(M,2,2,temp0-Dij[2]);
				gsl_matrix_set(M,0,1,-Dij[3]);
				gsl_matrix_set(M,1,2,-Dij[4]);
				gsl_matrix_set(M,2,0,-Dij[5]);
				gsl_matrix_set(M,1,0,-Dij[3]);
				gsl_matrix_set(M,2,1,-Dij[4]);
				gsl_matrix_set(M,0,2,-Dij[5]);
				gsl_vector_set(V,0,RxV[j].x);
				gsl_vector_set(V,1,RxV[j].y);
				gsl_vector_set(V,2,RxV[j].z);
				gsl_linalg_HH_svx(M,V);
				Omega0.x=gsl_vector_get(V,0);
				Omega0.y=gsl_vector_get(V,1);
				Omega0.z=gsl_vector_get(V,2);
				V0[j].x/=(*area);
				V0[j].y/=(*area);
				V0[j].z/=(*area);
				for(i=0;i<NMEM;i++){
					tempx=r_mem[i].x-r_mem_cm->x;
					tempy=r_mem[i].y-r_mem_cm->y;
					tempz=r_mem[i].z-r_mem_cm->z;
					v_mem0[i][j+1].x+=kk*(V0[j].x+tempy*Omega0.z-tempz*Omega0.y);
					v_mem0[i][j+1].y+=kk*(V0[j].y+tempz*Omega0.x-tempx*Omega0.z);
					v_mem0[i][j+1].z+=kk*(V0[j].z+tempx*Omega0.y-tempy*Omega0.x);
				}
			}

			gsl_matrix_free(M);
			gsl_vector_free(V);	
		#endif
	#endif

	temp0=0.0;
	for(i=0;i<NMEM;i++)temp0+=(f_mem0[i][0].x*fdA[i][0].x+f_mem0[i][0].y*fdA[i][0].y+f_mem0[i][0].z*fdA[i][0].z);
	for(j=0;j<3;j++){
		vn0=0.0;
		for(i=0;i<NMEM;i++)vn0+=(v_mem0[i][j+1].x*fdA[i][0].x+v_mem0[i][j+1].y*fdA[i][0].y+v_mem0[i][j+1].z*fdA[i][0].z);
		vn0/=temp0;
		for(i=0;i<NMEM;i++){
			v_mem0[i][j+1].x-=vn0*f_mem0[i][0].x;
			v_mem0[i][j+1].y-=vn0*f_mem0[i][0].y;
			v_mem0[i][j+1].z-=vn0*f_mem0[i][0].z;
		}
	}

	for(i=0;i<NMEM;i++){
		v_mem[i].x=v_mem0[i][1].x;
		v_mem[i].y=v_mem0[i][1].y;
		v_mem[i].z=v_mem0[i][1].z;
		vxi[i].x=v_mem0[i][2].x;
		vxi[i].y=v_mem0[i][2].y;
		vxi[i].z=v_mem0[i][2].z;
		vcurv[i].x=v_mem0[i][3].x;
		vcurv[i].y=v_mem0[i][3].y;
		vcurv[i].z=v_mem0[i][3].z;
	}

//	VTKdump("test0",r_mem,triang_site,zeta,curv,gauss,lap_curv,dzeta,colors,v_mem,f_mem);
//	return;

	#ifdef CAPSULE
		get_zeta21(triang_site,r_mem,v_mem,v_mem_cm,darea,res,curv,n_mem,areatemp,&beta1,ref_state,(*dtime));
	#else
		get_zeta2(triang_site,r_mem,v_mem,v_mem_cm,darea,res,curv,n_mem,0.0,&beta_test);
		get_zeta2(triang_site,r_mem,v_mem,v_mem_cm,darea,res,curv,n_mem,-areatemp/(*area),&beta1);
	#endif

	get_zeta2(triang_site,r_mem,vxi,v_mem_cm,darea,Axi,curv,n_mem,0.0,&beta2);
	get_zeta2(triang_site,r_mem,vcurv,v_mem_cm,darea,curv0,curv,n_mem,0.0,&beta3);
	Z0=-beta1/beta3;
	Z0test=(beta1-beta_test)/beta3;
	dZ0=-beta2/beta3;

	for(i=0;i<NMEM;i++) {
		Axi0[i]=Axi[i];
		v_mem[i].x+=Z0*vcurv[i].x;
		v_mem[i].y+=Z0*vcurv[i].y;
		v_mem[i].z+=Z0*vcurv[i].z;
		vxi0[i].x=vxi[i].x;
		vxi0[i].y=vxi[i].y;
		vxi0[i].z=vxi[i].z;
		vxi[i].x+=dZ0*vcurv[i].x;
		vxi[i].y+=dZ0*vcurv[i].y;
		vxi[i].z+=dZ0*vcurv[i].z;
//		vxi0[i].x=vxi0[i].y=vxi0[i].z=0.0;
		zeta[i]+=Z0;
		res[i]+=Z0*curv0[i];
		xi0[i]=xi[i]=dzeta[i]+dZ0;
		Axi[i]+=dZ0*curv0[i];
	}

	beta1=beta2=0.0;
	epsilon=0.0;

	for(i=0;i<NMEM;i++){
		beta1+=Axi[i]*res[i];
		beta2+=Axi[i]*Axi[i];
		epsilon+=res[i]*res[i];
	}

	if(beta2<1.e-12) alpha=0.0;
	else alpha=-beta1/beta2;
/*	for(i=0;i<(NMEM-2)/4+2;i++){
		beta1+=Axi[i]*xi[i];
		beta2+=res[i]*res[i];
		epsilon+=res[i]*res[i];
	}
	if(beta1<1.e-12) alpha=0.0;
	else alpha=-beta2/beta1;*/
	epsilon1=0.0;
	for(i=0;i<NMEM;i++) {
		v_mem[i].x+=alpha*vxi[i].x;
		v_mem[i].y+=alpha*vxi[i].y;
		v_mem[i].z+=alpha*vxi[i].z;
		zeta[i]+=xi[i]*alpha;
		res[i]+=Axi[i]*alpha;
		epsilon1+=res[i]*res[i];
		xi0[i]=dzeta[i];
	}
	epmax=0.0;
	for(i=0;i<NMEM;i++) if(fabs(res[i])>epmax) epmax=fabs(res[i]);

	#ifdef PRINTSTUFF
		printf("Z0=%f dZ0=%f beta1=%f beta2=%f epmax=%f alpha=%e epsilon=%e epsilon1=%e Z0test=%e\n",Z0,dZ0,beta1,beta2,epmax,alpha,epsilon,epsilon1,Z0test);
	#endif

	for(i=0;i<NMEM;i++) dzeta[i]=res[i];

	#if defined INTERACTION	
		for (i=0;i<NMEM;i++) if(drmin[i]<0.05) drmin[i]=0.05;
		for (i=0;i<NMEM;i++) curv0[i]=1.0+pow(fabs(2.0*curv[i]*curv[i]-gauss[i]),0.5)+0.0*pow(drmin[i],-1);
	#else
		for (i=0;i<NMEM;i++) curv0[i]=1.0+pow(fabs(2.0*curv[i]*curv[i]-gauss[i]),0.5);
	#endif

//advection

	#ifdef CAPSULE

		for(i=0;i<NMEM;i++){
			r_mem[i].x+=(*dtime)*v_mem[i].x;
			r_mem[i].y+=(*dtime)*v_mem[i].y;
			r_mem[i].z+=(*dtime)*v_mem[i].z;
		}
	*target_area=areatemp;

	#else
		*target_area=areatemp*(*dtime)+*area;
/*	for(i=0;i<NMEM;i++){
		vn0=(v_mem[i].x-v_mem_cm->x)*n_mem[i].x+(v_mem[i].y-v_mem_cm->y)*n_mem[i].y+(v_mem[i].z-v_mem_cm->z)*n_mem[i].z;
		v_mem[i].x=n_mem[i].x*vn0;
		v_mem[i].y=n_mem[i].y*vn0;
		v_mem[i].z=n_mem[i].z*vn0;
	}*/
		new_dynamique(r_mem,triang_site,n_mem,colors,v_mem,curv0,*v_mem_cm,dr_mem,dcolors,dv_mem,dtime,darea);
		for(i=0;i<NMEM;i++){
	//		vn0=(v_mem[i].x-v_mem_cm->x)*n_mem[i].x+(v_mem[i].y-v_mem_cm->y)*n_mem[i].y+(v_mem[i].z-v_mem_cm->z)*n_mem[i].z;
		/*	r_mem[i].x+=dr_mem[i].x+(vn0*n_mem[i].x+v_mem_cm->x)*(*dtime);
			r_mem[i].y+=dr_mem[i].y+(vn0*n_mem[i].y+v_mem_cm->y)*(*dtime);
			r_mem[i].z+=dr_mem[i].z+(vn0*n_mem[i].z+v_mem_cm->z)*(*dtime);*/
			r_mem[i].x+=dr_mem[i].x+v_mem[i].x*(*dtime);
			r_mem[i].y+=dr_mem[i].y+v_mem[i].y*(*dtime);
			r_mem[i].z+=dr_mem[i].z+v_mem[i].z*(*dtime);
			v_mem[i].x+=dv_mem[i].x;
			v_mem[i].y+=dv_mem[i].y;
			v_mem[i].z+=dv_mem[i].z;
		}
	//	beta1=beta2=0.0;
	/*	dV0=dV1=dV2=dA0=dA1=dA2=0.0;
		for(i=0;i<NMEM;i++){
	#ifndef MESHTT
		dr_mem[i].x-=(*dtime)*(v_mem[i].x-v_mem_cm->x);
		dr_mem[i].y-=(*dtime)*(v_mem[i].y-v_mem_cm->y);
		dr_mem[i].z-=(*dtime)*(v_mem[i].z-v_mem_cm->z);
	#endif
		alpha=DotProduct3D(dr_mem[i],n_mem[i]);
		dr_mem[i].x-=n_mem[i].x*alpha;
		dr_mem[i].y-=n_mem[i].y*alpha;
		dr_mem[i].z-=n_mem[i].z*alpha;
		dA0+=DotProduct3D(dr_mem[i],fdA[i][3]);
		dV0+=DotProduct3D(dr_mem[i],fdA[i][0]);
		dA1+=DotProduct3D(n_mem[i],fdA[i][3]);
		dV1+=DotProduct3D(n_mem[i],fdA[i][0]);
		dA2+=curv[i]*DotProduct3D(n_mem[i],fdA[i][3]);
		dV2+=curv[i]*DotProduct3D(n_mem[i],fdA[i][0]);
	}
	beta1=(dA0*dV2-dV0*dA2)/(dA1*dV2-dA2*dV1);
	beta2=(dA1*dV0-dV1*dA0)/(dA1*dV2-dA2*dV1);
//	printf("mu1=%e mu2=%e ",beta1,beta2);
//	dA0=dV0=0.0;
	for(i=0;i<NMEM;i++){
		dr_mem[i].x-=(beta1+beta2*curv[i])*n_mem[i].x;
		dr_mem[i].y-=(beta1+beta2*curv[i])*n_mem[i].y;
		dr_mem[i].z-=(beta1+beta2*curv[i])*n_mem[i].z;
		r_mem[i].x+=((*dtime)*v_mem[i].x+dr_mem[i].x);
		r_mem[i].y+=((*dtime)*v_mem[i].y+dr_mem[i].y);
		r_mem[i].z+=((*dtime)*v_mem[i].z+dr_mem[i].z);
		v_mem[i].x+=dv_mem[i].x;
		v_mem[i].y+=dv_mem[i].y;
		v_mem[i].z+=dv_mem[i].z;
//		dA0+=DotProduct3D(dr_mem[i],fdA[i][3]);
//		dV0+=DotProduct3D(dr_mem[i],fdA[i][0]);
	}*/
//	printf("dA=%e dV=%e\n",dA0,dV0);

	#endif

	(*time0)+=*dtime;
/*	j=0;
	tempx=-1.e10;
	for(i=0;i<NMEM;i++){
		tempy=r_mem[i].x+r_mem[i].y+r_mem[i].z-r_mem_cm->x-r_mem_cm->y-r_mem_cm->z;
		if(tempy>tempx){
			j=i;
			tempx=tempy;
		}
	}
	fp=fopen("test.dat","a+");
	fprintf(fp,"%f %f %f\n",v_mem[j].x,v_mem[j].y,v_mem[j].z);
	fclose(fp);*/

#define DX 0.2
#define DZ 0.2
#define NXst 20
#define NZst 20

	drx=floor(r_mem_cm->x/DX)*DX;
	drz=floor(r_mem_cm->z/DZ)*DZ;
	if(istep%NSTREAM==0){
		sprintf(suf,"stream%06d.vtk",istep);
		fp=fopen(suf,"w+");
		fprintf(fp,"# vtk DataFile Version 3.0\n");
		fprintf(fp,"vtk output\n");
		fprintf(fp,"ASCII\n");
		fprintf(fp,"DATASET POLYDATA\n");
		fprintf(fp,"POINTS %d float\n",(2*NXst+1)*(2*NZst+1));
		for(i=-NXst;i<=NXst;i++){
			for(j=-NZst;j<=NZst;j++){
				fprintf(fp,"%f 0.0 %f\n",i*DX+drx,j*DZ+drz);
			}
		}
		fprintf(fp,"POINT_DATA %d\n",(2*NXst+1)*(2*NZst+1));
		fprintf(fp,"VECTORS velocity float\n");
		rtemp.y=0.0;
		for(i=-NXst;i<=NXst;i++){
			rtemp.x=DX*i+drx;
			for(j=-NZst;j<=NZst;j++){
				rtemp.z=DZ*j+drz;
				probe_green16(rtemp,&vtemp,r_mem,r_mem2,fdA,fdA2,eta,pp,v_mem2,time0);
				fprintf(fp,"%f %f %f\n",vtemp.x,vtemp.y,vtemp.z);
			}
		}
		fclose(fp);
	}
}
/*END new_val */


void rescale(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D v_mem[], struct point3D r_mem_cm, double zeta[], double vol0, double vol)
{
    int 		i;
    double 		scale, lnscale2;

    scale = pow(vol0/vol,1.0/3.0);
    lnscale2 = 2.0*log(scale);

    for (i=0;i<NMEM;i++) {

        r_mem[i].x = r_mem_cm.x + scale*(r_mem[i].x-r_mem_cm.x);
        r_mem[i].y = r_mem_cm.y + scale*(r_mem[i].y-r_mem_cm.y);
        r_mem[i].z = r_mem_cm.z + scale*(r_mem[i].z-r_mem_cm.z);

    }


}

/*END rescale */

