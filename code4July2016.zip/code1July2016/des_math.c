#include <math.h>

#include "des_math.h"

double dotprod(struct point u , struct point v)
{
    double prod;
    prod = u.x*v.x + u.y*v.y + u.z*v.z;
    return prod;
}


struct point vecprod(struct point u , struct point v)
{
    struct point prod;
    prod.x = u.y*v.z - u.z*v.y;
    prod.y = u.z*v.x - u.x*v.z;
    prod.z = u.x*v.y - u.y*v.x;
    return prod;
}

void azero(struct point *u)
{
    u->x = u->y = u->z = 0.0;
}


struct point normalize(struct point u)
{
    double norm;
    norm = sqrt(dotprod(u,u));
    u.x = u.x / norm;
    u.y = u.y / norm;
    u.z = u.z / norm;
    return u;
}


double efrandom()
{
	return ((random() % 32768) - 16384) / 16384.0;
}


void rotate	(struct point *u, struct point rotvec, struct point rotcentre,
		 double theta)
{
    double a[3][3];
    double unmcost, cost, sint;
    double xx,yy,zz;

    cost = cos(theta);
    unmcost = 1.-cost;
    sint = sin(theta);

    a[0][0] = cost + rotvec.x*rotvec.x*unmcost;
    a[0][1] =        rotvec.y*rotvec.x*unmcost - rotvec.z*sint;
    a[0][2] =        rotvec.z*rotvec.x*unmcost + rotvec.y*sint;

    a[1][0] =        rotvec.x*rotvec.y*unmcost + rotvec.z*sint;
    a[1][1] = cost + rotvec.y*rotvec.y*unmcost;
    a[1][2] =        rotvec.z*rotvec.y*unmcost - rotvec.x*sint;

    a[2][0] =        rotvec.x*rotvec.z*unmcost - rotvec.y*sint;
    a[2][1] =        rotvec.y*rotvec.z*unmcost + rotvec.x*sint;
    a[2][2] = cost + rotvec.z*rotvec.z*unmcost;


    xx = u->x - rotcentre.x;
    yy = u->y - rotcentre.y;
    zz = u->z - rotcentre.z;

    u->x = rotcentre.x + a[0][0]*xx + a[0][1]*yy + a[0][2]*zz;
    u->y = rotcentre.y + a[1][0]*xx + a[1][1]*yy + a[1][2]*zz;
    u->z = rotcentre.z + a[2][0]*xx + a[2][1]*yy + a[2][2]*zz;
	

}


struct point    normalized_rand_vec()
{
    double              cstet, sntet, phi, pi;
    struct point        tmp;

    pi = 4.0*atan(1.0);

    cstet = efrandom();
    sntet = sin( acos( cstet ) );
    phi = 2.0*pi * 0.5*(1.0+efrandom());
    tmp.x = sntet * cos(phi);
    tmp.y = sntet * sin(phi);
    tmp.z = cstet;

    return tmp;
}
