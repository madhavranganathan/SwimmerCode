#include "includes.h"

void VTKflow(char suf[], int n, double y0, double dy, double x0, double time0){
	FILE* fp;
	char file[100];
	int i;
	struct point3D r0;
	sprintf(file,"flow_%s.vtk",suf);
	fp=fopen(file,"w");
	
	fprintf(fp,"# vtk DataFile Version 3.0\n");
	fprintf(fp,"vtk output\n");
	fprintf(fp,"ASCII\n");
	fprintf(fp,"DATASET POLYDATA\n");
	fprintf(fp,"POINTS %d float\n",2*n+1);
	for(i=-n;i<=n;i++){
		r0.y=y0+dy*i;
		fprintf(fp,"%f %f 0.0\n",10.0-fmod(x0+10.0,20.0),r0.y);
	}
	fprintf(fp,"POINT_DATA %d\n",2*n+1);
	fprintf(fp,"VECTORS velocity float\n");
	r0.z=0.0;
	for(i=-n;i<=n;i++){
		r0.y=y0+i*dy;
		r0.x=10.0-fmod(x0+10.0,20.0);
		fprintf(fp,"%f %f %f\n",xflow(r0,time0),yflow(r0,time0),zflow(r0,time0));
	}
	fclose(fp);
}

void VTKdump(char suf[], struct point3D Vertices[], int Facets[NTRIANG][3], double Scalar_Field[], double Scalar_Field2[], double Scalar_Field3[], double Scalar_Field4[], double Scalar_Field5[], double Scalar_Field6[], struct point3D Vector_Field[], struct point3D Vector_Field2[])
{
    FILE        	*fp,*fp1;
    char		file[100];
    int			i, j, l0, l1, l2;
    double		dsurf, area, t0, e01,e02,e12,e0,fn0,x0,y0,phi0;
	 double     Vmwall1,Vmwall2,darea[NTRIANG];
    struct point3D	v_cm, r_cm, r01, r02, r12, r, norml[NTRIANG], Vertices1[NMEM];
	double S1xx,S1xy,S1xz,S1yx,S1yy,S1yz,S1zx,S1zy,S1zz,S2xx,S2xy,S2xz,S2yx,S2yy,S2yz,S2zx,S2zy,S2zz,VR;

    area = v_cm.x = v_cm.y = v_cm.z = r_cm.x = r_cm.y = r_cm.z = Vmwall1 = Vmwall2 = 0.0;

	 fp=fopen("areas.dat","w");
	 fp1=fopen("edges.dat","w");
	 e0=0.0;
	 for (i=0;i<NMEM;i++) norml[i].x=norml[i].y=norml[i].z=0.0;
    for (i=0;i<NTRIANG;i++) {

        l0 = Facets[i][0];
        l1 = Facets[i][1];
        l2 = Facets[i][2];

        r01.x = Vertices[l1].x - Vertices[l0].x;
        r01.y = Vertices[l1].y - Vertices[l0].y;
        r01.z = Vertices[l1].z - Vertices[l0].z;
		  e01=sqrt(r01.x*r01.x+r01.y*r01.y+r01.z*r01.z);
		  e0+=e01;

        r02.x = Vertices[l2].x - Vertices[l0].x;
        r02.y = Vertices[l2].y - Vertices[l0].y;
        r02.z = Vertices[l2].z - Vertices[l0].z;
		  e02=sqrt(r02.x*r02.x+r02.y*r02.y+r02.z*r02.z);
		  e0+=e02;

        r12.x = Vertices[l2].x - Vertices[l1].x;
        r12.y = Vertices[l2].y - Vertices[l1].y;
        r12.z = Vertices[l2].z - Vertices[l1].z;
		  e12=sqrt(r12.x*r12.x+r12.y*r12.y+r12.z*r12.z);
		  e0+=e12;

        r.x = r01.y*r02.z - r01.z*r02.y;
        r.y = r01.z*r02.x - r01.x*r02.z;
        r.z = r01.x*r02.y - r01.y*r02.x;

        dsurf = sqrt(r.x*r.x + r.y*r.y + r.z*r.z);


        area   += dsurf;

        v_cm.x += dsurf*( Vector_Field[l0].x + Vector_Field[l1].x + Vector_Field[l2].x )/3.0;
        v_cm.y += dsurf*( Vector_Field[l0].y + Vector_Field[l1].y + Vector_Field[l2].y )/3.0;
        v_cm.z += dsurf*( Vector_Field[l0].z + Vector_Field[l1].z + Vector_Field[l2].z )/3.0;

        r_cm.x += dsurf*( Vertices[l0].x + Vertices[l1].x + Vertices[l2].x )/3.0;
        r_cm.y += dsurf*( Vertices[l0].y + Vertices[l1].y + Vertices[l2].y )/3.0;
        r_cm.z += dsurf*( Vertices[l0].z + Vertices[l1].z + Vertices[l2].z )/3.0;


/*		  fn0+=(Vector_Field2[l0].x*r.x+Vector_Field2[l0].y*r.y+Vector_Field2[l0].z*r.z);
		  fn0+=(Vector_Field2[l1].x*r.x+Vector_Field2[l1].y*r.y+Vector_Field2[l1].z*r.z);
		  fn0+=(Vector_Field2[l2].x*r.x+Vector_Field2[l2].y*r.y+Vector_Field2[l2].z*r.z);*/

		  fprintf(fp,"%f\n",dsurf);
		  fprintf(fp1,"%f\n",e01);
		  fprintf(fp1,"%f\n",e02);
		  fprintf(fp1,"%f\n",e12);
		  norml[l0].x+=r.x/dsurf;
		  norml[l0].y+=r.y/dsurf;
		  norml[l0].z+=r.z/dsurf;
		  norml[l1].x+=r.x/dsurf;
		  norml[l1].y+=r.y/dsurf;
		  norml[l1].z+=r.z/dsurf;
		  norml[l2].x+=r.x/dsurf;
		  norml[l2].y+=r.y/dsurf;
		  norml[l2].z+=r.z/dsurf;
		  darea[i]=dsurf*0.5;
    }



	 for(i=0;i<NMEM;i++){
		  dsurf=pow(norml[i].x*norml[i].x+norml[i].y*norml[i].y+norml[i].z*norml[i].z,-0.5);
		  norml[i].x*=dsurf;
		  norml[i].y*=dsurf;
		  norml[i].z*=dsurf;
	 }
	 fclose(fp);
	 fclose(fp1);

    v_cm.x = v_cm.x / area;
    v_cm.y = v_cm.y / area;
    v_cm.z = v_cm.z / area;

    r_cm.x = r_cm.x / area;
    r_cm.y = r_cm.y / area;
    r_cm.z = r_cm.z / area;

	 fn0/=(area*3.0);
	fn0=0.0;

/*    printf("%f\t%f\t%f\t%f\t%f\t%f\n",v_cm.x,v_cm.y,v_cm.z,r_cm.x,r_cm.y,r_cm.z);
    fp=fopen("vm.dat","a");
    fprintf(fp,"%f\t%f\t%f\t%f\t%f\t%f\n",v_cm.x,v_cm.y,v_cm.z,r_cm.x,r_cm.y,r_cm.z);
    fclose(fp);
    fp=fopen("wall.dat","a");
    fprintf(fp,"%f\t%f\n",Vmwall1,Vmwall2);
    fclose(fp);
	 fp=fopen("area0.dat","a");
	 fprintf(fp,"%f\n",area);
	 fclose(fp);
	 fp=fopen("edge0.dat","a");
	 e0/=(3.0*NTRIANG);
	 fprintf(fp,"%f\n",e0);
	 fclose(fp);*/
    sprintf(file,"shape_%s.vtk",suf);
    fp = fopen(file,"w");
    fprintf(fp,"# vtk DataFile Version 3.0\n");
    fprintf(fp,"vtk output\n");
	 fprintf(fp,"ASCII\n");
	 fprintf(fp,"DATASET POLYDATA\n");
	 fprintf(fp,"POINTS %d float\n",NMEM);
    for (i=0;i<NMEM;i++) 
            fprintf(fp,"%18.12e %18.12e %18.12e\n",Vertices[i].x,Vertices[i].y,Vertices[i].z);
    fprintf(fp,"POLYGONS %d %d\n",NTRIANG,4*NTRIANG);
    for (i=0;i<NTRIANG;i++)
            fprintf(fp,"3 %d %d %d\n",Facets[i][0],Facets[i][1],Facets[i][2]);
	 fprintf(fp,"POINT_DATA %d\n",NMEM);
	 fprintf(fp,"SCALARS tension float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NMEM;i++)
		  fprintf(fp,"%f\n",Scalar_Field[i]);
	 fprintf(fp,"SCALARS mean_curvature float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NMEM;i++)
		  fprintf(fp,"%f\n",Scalar_Field2[i]);
	 fprintf(fp,"SCALARS gaussian_curvature float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NMEM;i++)
		  fprintf(fp,"%f\n",Scalar_Field3[i]);
	 fprintf(fp,"SCALARS curvature_laplacian float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NMEM;i++)
		  fprintf(fp,"%f\n",Scalar_Field4[i]);
	 fprintf(fp,"SCALARS colors float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NMEM;i++)
		  fprintf(fp,"%f\n",Scalar_Field5[i]);
	 fprintf(fp,"SCALARS stretch float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NMEM;i++)
		  fprintf(fp,"%f\n",Scalar_Field6[i]);
	 fprintf(fp,"VECTORS velocity float\n");
	 for (i=0;i<NMEM;i++)
	 	  fprintf(fp,"%f %f %f\n",Vector_Field[i].x,Vector_Field[i].y,Vector_Field[i].z);
	 fprintf(fp,"VECTORS force float\n");
	 for (i=0;i<NMEM;i++)
	 	  fprintf(fp,"%f %f %f\n",Vector_Field2[i].x,Vector_Field2[i].y,Vector_Field2[i].z);
	 fprintf(fp,"CELL_DATA %d\n",NTRIANG);
	 fprintf(fp,"SCALARS areas float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NTRIANG;i++)
		  fprintf(fp,"%f\n",darea[i]);
	 fprintf(fp,"SCALARS tensions float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NTRIANG;i++)
		  fprintf(fp,"%f\n",Scalar_Field[Facets[i][0]]+Scalar_Field[Facets[i][1]]+Scalar_Field[Facets[i][2]]);
	 fclose(fp);
    for (i=0;i<NMEM;i++) {
		  Vertices1[i].x = Vertices[i].x-r_cm.x;
		  Vertices1[i].y = Vertices[i].y-r_cm.y;
		  Vertices1[i].z = Vertices[i].z-r_cm.z;
	 }
	 sprintf(file,"csxy_%s.dat",suf);
	 fp=fopen(file,"w");
	 for (i=0;i<NTRIANG;i++){
        l0 = Facets[i][0];
        l1 = Facets[i][1];
        l2 = Facets[i][2];
		  if (Vertices1[l0].z*Vertices1[l1].z<0.0){
			   t0 = Vertices1[l1].z/(Vertices1[l1].z-Vertices1[l0].z);
				fprintf(fp,"%f\t%f\n",Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l1].x,Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l1].y);
		  }
		  if (Vertices1[l0].z*Vertices1[l2].z<0.0){
			   t0 = Vertices1[l2].z/(Vertices1[l2].z-Vertices1[l0].z);
				fprintf(fp,"%f\t%f\n",Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l2].x,Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l2].y);
		  }
		  if (Vertices1[l2].z*Vertices1[l1].z<0.0){
			   t0 = Vertices1[l1].z/(Vertices1[l1].z-Vertices1[l2].z);
				fprintf(fp,"%f\t%f\n",Vertices1[l2].x*t0+(1.0-t0)*Vertices1[l1].x,Vertices1[l2].y*t0+(1.0-t0)*Vertices1[l1].y);
		  }
	 }
	 fclose(fp);
	 sprintf(file,"curv_%s.dat",suf);
	 fp=fopen(file,"w");
	 for (i=0;i<NTRIANG;i++){
        l0 = Facets[i][0];
        l1 = Facets[i][1];
        l2 = Facets[i][2];
		  if (Vertices1[l0].z*Vertices1[l1].z<0.0){
			   t0 = Vertices1[l1].z/(Vertices1[l1].z-Vertices1[l0].z);
				x0=Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l1].x;
				y0=Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l1].y;
				phi0=acos(x0/sqrt(x0*x0+y0*y0));
				if(y0<0) phi0=2.0*PI-phi0;
				fprintf(fp,"%f\t%f\n",phi0,Scalar_Field2[l0]*t0+(1.0-t0)*Scalar_Field2[l1]);
		  }
		  if (Vertices1[l0].z*Vertices1[l2].z<0.0){
			   t0 = Vertices1[l2].z/(Vertices1[l2].z-Vertices1[l0].z);
				x0=Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l2].x;
				y0=Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l2].y;
				phi0=acos(x0/sqrt(x0*x0+y0*y0));
				if(y0<0) phi0=2.0*PI-phi0;
				fprintf(fp,"%f\t%f\n",phi0,Scalar_Field2[l0]*t0+(1.0-t0)*Scalar_Field2[l2]);
		  }
		  if (Vertices1[l2].z*Vertices1[l1].z<0.0){
			   t0 = Vertices1[l1].z/(Vertices1[l1].z-Vertices1[l2].z);
				x0=Vertices1[l2].x*t0+(1.0-t0)*Vertices1[l1].x;
				y0=Vertices1[l2].y*t0+(1.0-t0)*Vertices1[l1].y;
				phi0=acos(x0/sqrt(x0*x0+y0*y0));
				if(y0<0) phi0=2.0*PI-phi0;
				fprintf(fp,"%f\t%f\n",phi0,Scalar_Field2[l2]*t0+(1.0-t0)*Scalar_Field2[l1]);
		  }
	 }
	 fclose(fp);
	 sprintf(file,"tension_%s.dat",suf);
	 fp=fopen(file,"w");
	 for (i=0;i<NTRIANG;i++){
        l0 = Facets[i][0];
        l1 = Facets[i][1];
        l2 = Facets[i][2];
		  if (Vertices1[l0].z*Vertices1[l1].z<0.0){
			   t0 = Vertices1[l1].z/(Vertices1[l1].z-Vertices1[l0].z);
				x0=Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l1].x;
				y0=Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l1].y;
				phi0=acos(x0/sqrt(x0*x0+y0*y0));
				if(y0<0) phi0=2.0*PI-phi0;
				fprintf(fp,"%f\t%f\n",phi0,Scalar_Field[l0]*t0+(1.0-t0)*Scalar_Field[l1]);
		  }
		  if (Vertices1[l0].z*Vertices1[l2].z<0.0){
			   t0 = Vertices1[l2].z/(Vertices1[l2].z-Vertices1[l0].z);
				x0=Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l2].x;
				y0=Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l2].y;
				phi0=acos(x0/sqrt(x0*x0+y0*y0));
				if(y0<0) phi0=2.0*PI-phi0;
				fprintf(fp,"%f\t%f\n",phi0,Scalar_Field[l0]*t0+(1.0-t0)*Scalar_Field[l2]);
		  }
		  if (Vertices1[l2].z*Vertices1[l1].z<0.0){
			   t0 = Vertices1[l1].z/(Vertices1[l1].z-Vertices1[l2].z);
				x0=Vertices1[l2].x*t0+(1.0-t0)*Vertices1[l1].x;
				y0=Vertices1[l2].y*t0+(1.0-t0)*Vertices1[l1].y;
				phi0=acos(x0/sqrt(x0*x0+y0*y0));
				if(y0<0) phi0=2.0*PI-phi0;
				fprintf(fp,"%f\t%f\n",phi0,Scalar_Field[l2]*t0+(1.0-t0)*Scalar_Field[l1]);
		  }
	 }
	 fclose(fp);
	 sprintf(file,"gauss_%s.dat",suf);
	 fp=fopen(file,"w");
	 for (i=0;i<NTRIANG;i++){
        l0 = Facets[i][0];
        l1 = Facets[i][1];
        l2 = Facets[i][2];
		  if (Vertices1[l0].z*Vertices1[l1].z<0.0){
			   t0 = Vertices1[l1].z/(Vertices1[l1].z-Vertices1[l0].z);
				x0=Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l1].x;
				y0=Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l1].y;
				phi0=acos(x0/sqrt(x0*x0+y0*y0));
				if(y0<0) phi0=2.0*PI-phi0;
				fprintf(fp,"%f\t%f\n",phi0,Scalar_Field3[l0]*t0+(1.0-t0)*Scalar_Field3[l1]);
		  }
		  if (Vertices1[l0].z*Vertices1[l2].z<0.0){
			   t0 = Vertices1[l2].z/(Vertices1[l2].z-Vertices1[l0].z);
				x0=Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l2].x;
				y0=Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l2].y;
				phi0=acos(x0/sqrt(x0*x0+y0*y0));
				if(y0<0) phi0=2.0*PI-phi0;
				fprintf(fp,"%f\t%f\n",phi0,Scalar_Field3[l0]*t0+(1.0-t0)*Scalar_Field3[l2]);
		  }
		  if (Vertices1[l2].z*Vertices1[l1].z<0.0){
			   t0 = Vertices1[l1].z/(Vertices1[l1].z-Vertices1[l2].z);
				x0=Vertices1[l2].x*t0+(1.0-t0)*Vertices1[l1].x;
				y0=Vertices1[l2].y*t0+(1.0-t0)*Vertices1[l1].y;
				phi0=acos(x0/sqrt(x0*x0+y0*y0));
				if(y0<0) phi0=2.0*PI-phi0;
				fprintf(fp,"%f\t%f\n",phi0,Scalar_Field3[l2]*t0+(1.0-t0)*Scalar_Field3[l1]);
		  }
	 }
	 fclose(fp);
	 sprintf(file,"lap_%s.dat",suf);
	 fp=fopen(file,"w");
	 for (i=0;i<NTRIANG;i++){
        l0 = Facets[i][0];
        l1 = Facets[i][1];
        l2 = Facets[i][2];
		  if (Vertices1[l0].z*Vertices1[l1].z<0.0){
			   t0 = Vertices1[l1].z/(Vertices1[l1].z-Vertices1[l0].z);
				x0=Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l1].x;
				y0=Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l1].y;
				phi0=acos(x0/sqrt(x0*x0+y0*y0));
				if(y0<0) phi0=2.0*PI-phi0;
				fprintf(fp,"%f\t%f\n",phi0,Scalar_Field4[l0]*t0+(1.0-t0)*Scalar_Field4[l1]);
		  }
		  if (Vertices1[l0].z*Vertices1[l2].z<0.0){
			   t0 = Vertices1[l2].z/(Vertices1[l2].z-Vertices1[l0].z);
				x0=Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l2].x;
				y0=Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l2].y;
				phi0=acos(x0/sqrt(x0*x0+y0*y0));
				if(y0<0) phi0=2.0*PI-phi0;
				fprintf(fp,"%f\t%f\n",phi0,Scalar_Field4[l0]*t0+(1.0-t0)*Scalar_Field4[l2]);
		  }
		  if (Vertices1[l2].z*Vertices1[l1].z<0.0){
			   t0 = Vertices1[l1].z/(Vertices1[l1].z-Vertices1[l2].z);
				x0=Vertices1[l2].x*t0+(1.0-t0)*Vertices1[l1].x;
				y0=Vertices1[l2].y*t0+(1.0-t0)*Vertices1[l1].y;
				phi0=acos(x0/sqrt(x0*x0+y0*y0));
				if(y0<0) phi0=2.0*PI-phi0;
				fprintf(fp,"%f\t%f\n",phi0,Scalar_Field4[l2]*t0+(1.0-t0)*Scalar_Field4[l1]);
		  }
	 }
	 fclose(fp);
	 sprintf(file,"fx_%s.dat",suf);
	 fp=fopen(file,"w");
	 for (i=0;i<NTRIANG;i++){
        l0 = Facets[i][0];
        l1 = Facets[i][1];
        l2 = Facets[i][2];
		  if (Vertices1[l0].z*Vertices1[l1].z<0.0){
			   t0 = Vertices1[l1].z/(Vertices1[l1].z-Vertices1[l0].z);
				x0=Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l1].x;
				y0=Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l1].y;
				phi0=acos(x0/sqrt(x0*x0+y0*y0));
				if(y0<0) phi0=2.0*PI-phi0;
				fprintf(fp,"%f\t%f\n",phi0,Vector_Field2[l0].x*t0+(1.0-t0)*Vector_Field2[l1].x);
		  }
		  if (Vertices1[l0].z*Vertices1[l2].z<0.0){
			   t0 = Vertices1[l2].z/(Vertices1[l2].z-Vertices1[l0].z);
				x0=Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l2].x;
				y0=Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l2].y;
				phi0=acos(x0/sqrt(x0*x0+y0*y0));
				if(y0<0) phi0=2.0*PI-phi0;
				fprintf(fp,"%f\t%f\n",phi0,Vector_Field2[l0].x*t0+(1.0-t0)*Vector_Field2[l2].x);
		  }
		  if (Vertices1[l2].z*Vertices1[l1].z<0.0){
			   t0 = Vertices1[l1].z/(Vertices1[l1].z-Vertices1[l2].z);
				x0=Vertices1[l2].x*t0+(1.0-t0)*Vertices1[l1].x;
				y0=Vertices1[l2].y*t0+(1.0-t0)*Vertices1[l1].y;
				phi0=acos(x0/sqrt(x0*x0+y0*y0));
				if(y0<0) phi0=2.0*PI-phi0;
				fprintf(fp,"%f\t%f\n",phi0,Vector_Field2[l2].x*t0+(1.0-t0)*Vector_Field2[l1].x);
		  }
	 }
	 fclose(fp);
	 sprintf(file,"fy_%s.dat",suf);
	 fp=fopen(file,"w");
	 for (i=0;i<NTRIANG;i++){
        l0 = Facets[i][0];
        l1 = Facets[i][1];
        l2 = Facets[i][2];
		  if (Vertices1[l0].z*Vertices1[l1].z<0.0){
			   t0 = Vertices1[l1].z/(Vertices1[l1].z-Vertices1[l0].z);
				x0=Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l1].x;
				y0=Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l1].y;
				phi0=acos(x0/sqrt(x0*x0+y0*y0));
				if(y0<0) phi0=2.0*PI-phi0;
				fprintf(fp,"%f\t%f\n",phi0,Vector_Field2[l0].y*t0+(1.0-t0)*Vector_Field2[l1].y);
		  }
		  if (Vertices1[l0].z*Vertices1[l2].z<0.0){
			   t0 = Vertices1[l2].z/(Vertices1[l2].z-Vertices1[l0].z);
				x0=Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l2].x;
				y0=Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l2].y;
				phi0=acos(x0/sqrt(x0*x0+y0*y0));
				if(y0<0) phi0=2.0*PI-phi0;
				fprintf(fp,"%f\t%f\n",phi0,Vector_Field2[l0].y*t0+(1.0-t0)*Vector_Field2[l2].y);
		  }
		  if (Vertices1[l2].z*Vertices1[l1].z<0.0){
			   t0 = Vertices1[l1].z/(Vertices1[l1].z-Vertices1[l2].z);
				x0=Vertices1[l2].x*t0+(1.0-t0)*Vertices1[l1].x;
				y0=Vertices1[l2].y*t0+(1.0-t0)*Vertices1[l1].y;
				phi0=acos(x0/sqrt(x0*x0+y0*y0));
				if(y0<0) phi0=2.0*PI-phi0;
				fprintf(fp,"%f\t%f\n",phi0,Vector_Field2[l2].y*t0+(1.0-t0)*Vector_Field2[l1].y);
		  }
	 }
	 fclose(fp);
	 sprintf(file,"csyz_%s.dat",suf);
	 fp=fopen(file,"w");
	 for (i=0;i<NTRIANG;i++){
        l0 = Facets[i][0];
        l1 = Facets[i][1];
        l2 = Facets[i][2];
		  if (Vertices1[l0].x*Vertices1[l1].x<0.0){
			   t0 = Vertices1[l1].x/(Vertices1[l1].x-Vertices1[l0].x);
				fprintf(fp,"%f\t%f\n",Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l1].y,Vertices1[l0].z*t0+(1.0-t0)*Vertices1[l1].z);
		  }
		  if (Vertices1[l0].x*Vertices1[l2].x<0.0){
			   t0 = Vertices1[l2].x/(Vertices1[l2].x-Vertices1[l0].x);
				fprintf(fp,"%f\t%f\n",Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l2].y,Vertices1[l0].z*t0+(1.0-t0)*Vertices1[l2].z);
		  }
		  if (Vertices1[l2].x*Vertices1[l1].x<0.0){
			   t0 = Vertices1[l1].x/(Vertices1[l1].x-Vertices1[l2].x);
				fprintf(fp,"%f\t%f\n",Vertices1[l2].y*t0+(1.0-t0)*Vertices1[l1].y,Vertices1[l2].z*t0+(1.0-t0)*Vertices1[l1].z);
		  }
	 }
	 fclose(fp);
	 sprintf(file,"cszx_%s.dat",suf);
	 fp=fopen(file,"w");
	 for (i=0;i<NTRIANG;i++){
        l0 = Facets[i][0];
        l1 = Facets[i][1];
        l2 = Facets[i][2];
		  if (Vertices1[l0].y*Vertices1[l1].y<0.0){
			   t0 = Vertices1[l1].y/(Vertices1[l1].y-Vertices1[l0].y);
				fprintf(fp,"%f\t%f\n",Vertices1[l0].z*t0+(1.0-t0)*Vertices1[l1].z,Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l1].x);
		  }
		  if (Vertices1[l0].y*Vertices1[l2].y<0.0){
			   t0 = Vertices1[l2].y/(Vertices1[l2].y-Vertices1[l0].y);
				fprintf(fp,"%f\t%f\n",Vertices1[l0].z*t0+(1.0-t0)*Vertices1[l2].z,Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l2].x);
		  }
		  if (Vertices1[l2].y*Vertices1[l1].y<0.0){
			   t0 = Vertices1[l1].y/(Vertices1[l1].y-Vertices1[l2].y);
				fprintf(fp,"%f\t%f\n",Vertices1[l2].z*t0+(1.0-t0)*Vertices1[l1].z,Vertices1[l2].x*t0+(1.0-t0)*Vertices1[l1].x);
		  }
	 }
	 fclose(fp);
	 sprintf(file,"areas_%s.dat",suf);
	 
}

void VTKdump_ref(char suf[], struct point3D Vertices[], int Facets[NTRIANG][3], double Scalar_Field[])
{
	FILE        	*fp,*fp1;
	char		file[100];
	int			i, j, l0, l1, l2;
	double		dsurf, area, t0, e01,e02,e12,e0,fn0;
	double     darea[NTRIANG2];
	struct point3D	v_cm, r_cm, r01, r02, r12, r, norml[NTRIANG2], Vertices1[NMEM2];

	area = v_cm.x = v_cm.y = v_cm.z = r_cm.x = r_cm.y = r_cm.z = 0.0;

	 for (i=0;i<NMEM2;i++) norml[i].x=norml[i].y=norml[i].z=0.0;
    for (i=0;i<NTRIANG2;i++) {

        l0 = Facets[i][0];
        l1 = Facets[i][1];
        l2 = Facets[i][2];

        r01.x = Vertices[l1].x - Vertices[l0].x;
        r01.y = Vertices[l1].y - Vertices[l0].y;
        r01.z = Vertices[l1].z - Vertices[l0].z;

        r02.x = Vertices[l2].x - Vertices[l0].x;
        r02.y = Vertices[l2].y - Vertices[l0].y;
        r02.z = Vertices[l2].z - Vertices[l0].z;

        r12.x = Vertices[l2].x - Vertices[l1].x;
        r12.y = Vertices[l2].y - Vertices[l1].y;
        r12.z = Vertices[l2].z - Vertices[l1].z;

        r.x = r01.y*r02.z - r01.z*r02.y;
        r.y = r01.z*r02.x - r01.x*r02.z;
        r.z = r01.x*r02.y - r01.y*r02.x;

        dsurf = sqrt(r.x*r.x + r.y*r.y + r.z*r.z);


        area   += dsurf;

        r_cm.x += dsurf*( Vertices[l0].x + Vertices[l1].x + Vertices[l2].x )/3.0;
        r_cm.y += dsurf*( Vertices[l0].y + Vertices[l1].y + Vertices[l2].y )/3.0;
        r_cm.z += dsurf*( Vertices[l0].z + Vertices[l1].z + Vertices[l2].z )/3.0;


/*		  fn0+=(Vector_Field2[l0].x*r.x+Vector_Field2[l0].y*r.y+Vector_Field2[l0].z*r.z);
		  fn0+=(Vector_Field2[l1].x*r.x+Vector_Field2[l1].y*r.y+Vector_Field2[l1].z*r.z);
		  fn0+=(Vector_Field2[l2].x*r.x+Vector_Field2[l2].y*r.y+Vector_Field2[l2].z*r.z);*/

		  norml[l0].x+=r.x/dsurf;
		  norml[l0].y+=r.y/dsurf;
		  norml[l0].z+=r.z/dsurf;
		  norml[l1].x+=r.x/dsurf;
		  norml[l1].y+=r.y/dsurf;
		  norml[l1].z+=r.z/dsurf;
		  norml[l2].x+=r.x/dsurf;
		  norml[l2].y+=r.y/dsurf;
		  norml[l2].z+=r.z/dsurf;
		  darea[i]=dsurf*0.5;
    }



	 for(i=0;i<NMEM2;i++){
		  dsurf=pow(norml[i].x*norml[i].x+norml[i].y*norml[i].y+norml[i].z*norml[i].z,-0.5);
		  norml[i].x*=dsurf;
		  norml[i].y*=dsurf;
		  norml[i].z*=dsurf;
	 }


    r_cm.x = r_cm.x / area;
    r_cm.y = r_cm.y / area;
    r_cm.z = r_cm.z / area;

	 fn0/=(area*3.0);
	fn0=0.0;

/*    printf("%f\t%f\t%f\t%f\t%f\t%f\n",v_cm.x,v_cm.y,v_cm.z,r_cm.x,r_cm.y,r_cm.z);
    fp=fopen("vm.dat","a");
    fprintf(fp,"%f\t%f\t%f\t%f\t%f\t%f\n",v_cm.x,v_cm.y,v_cm.z,r_cm.x,r_cm.y,r_cm.z);
    fclose(fp);
    fp=fopen("wall.dat","a");
    fprintf(fp,"%f\t%f\n",Vmwall1,Vmwall2);
    fclose(fp);
	 fp=fopen("area0.dat","a");
	 fprintf(fp,"%f\n",area);
	 fclose(fp);
	 fp=fopen("edge0.dat","a");
	 e0/=(3.0*NTRIANG);
	 fprintf(fp,"%f\n",e0);
	 fclose(fp);*/
    sprintf(file,"shape_ref_%s.vtk",suf);
    fp = fopen(file,"w");
    fprintf(fp,"# vtk DataFile Version 3.0\n");
    fprintf(fp,"vtk output\n");
	 fprintf(fp,"ASCII\n");
	 fprintf(fp,"DATASET POLYDATA\n");
	 fprintf(fp,"POINTS %d float\n",NMEM2);
    for (i=0;i<NMEM2;i++) 
            fprintf(fp,"%18.12e %18.12e %18.12e\n",Vertices[i].x,Vertices[i].y,Vertices[i].z);
    fprintf(fp,"POLYGONS %d %d\n",NTRIANG2,4*NTRIANG2);
    for (i=0;i<NTRIANG2;i++)
            fprintf(fp,"3 %d %d %d\n",Facets[i][0],Facets[i][1],Facets[i][2]);
	 fprintf(fp,"POINT_DATA %d\n",NMEM2);
	 fprintf(fp,"SCALARS tension float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NMEM2;i++)
		  fprintf(fp,"%f\n",Scalar_Field[i]);
	 fprintf(fp,"CELL_DATA %d\n",NTRIANG2);
	 fprintf(fp,"SCALARS areas float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NTRIANG2;i++)
		  fprintf(fp,"%f\n",darea[i]);
	 fprintf(fp,"SCALARS tensions float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NTRIANG2;i++)
		  fprintf(fp,"%f\n",Scalar_Field[Facets[i][0]]+Scalar_Field[Facets[i][1]]+Scalar_Field[Facets[i][2]]);
	 fclose(fp);
    for (i=0;i<NMEM2;i++) {
		  Vertices1[i].x = Vertices[i].x-r_cm.x;
		  Vertices1[i].y = Vertices[i].y-r_cm.y;
		  Vertices1[i].z = Vertices[i].z-r_cm.z;
	 }
	 sprintf(file,"csxy_ref_%s.dat",suf);
	 fp=fopen(file,"w");
	 for (i=0;i<NTRIANG2;i++){
	l0 = Facets[i][0];
        l1 = Facets[i][1];
        l2 = Facets[i][2];
		  if (Vertices1[l0].z*Vertices1[l1].z<0.0){
			   t0 = Vertices1[l1].z/(Vertices1[l1].z-Vertices1[l0].z);
				fprintf(fp,"%f\t%f\n",Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l1].x,Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l1].y);
		  }
		  if (Vertices1[l0].z*Vertices1[l2].z<0.0){
			   t0 = Vertices1[l2].z/(Vertices1[l2].z-Vertices1[l0].z);
				fprintf(fp,"%f\t%f\n",Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l2].x,Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l2].y);
		  }
		  if (Vertices1[l2].z*Vertices1[l1].z<0.0){
			   t0 = Vertices1[l1].z/(Vertices1[l1].z-Vertices1[l2].z);
				fprintf(fp,"%f\t%f\n",Vertices1[l2].x*t0+(1.0-t0)*Vertices1[l1].x,Vertices1[l2].y*t0+(1.0-t0)*Vertices1[l1].y);
		  }
	 }
	 fclose(fp);
	 sprintf(file,"csyz_ref_%s.dat",suf);
	 fp=fopen(file,"w");
	 for (i=0;i<NTRIANG2;i++){
        l0 = Facets[i][0];
        l1 = Facets[i][1];
        l2 = Facets[i][2];
		  if (Vertices1[l0].x*Vertices1[l1].x<0.0){
			   t0 = Vertices1[l1].x/(Vertices1[l1].x-Vertices1[l0].x);
				fprintf(fp,"%f\t%f\n",Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l1].y,Vertices1[l0].z*t0+(1.0-t0)*Vertices1[l1].z);
		  }
		  if (Vertices1[l0].x*Vertices1[l2].x<0.0){
			   t0 = Vertices1[l2].x/(Vertices1[l2].x-Vertices1[l0].x);
				fprintf(fp,"%f\t%f\n",Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l2].y,Vertices1[l0].z*t0+(1.0-t0)*Vertices1[l2].z);
		  }
		  if (Vertices1[l2].x*Vertices1[l1].x<0.0){
			   t0 = Vertices1[l1].x/(Vertices1[l1].x-Vertices1[l2].x);
				fprintf(fp,"%f\t%f\n",Vertices1[l2].y*t0+(1.0-t0)*Vertices1[l1].y,Vertices1[l2].z*t0+(1.0-t0)*Vertices1[l1].z);
		  }
	 }
	 fclose(fp);
	 sprintf(file,"cszx_ref_%s.dat",suf);
	 fp=fopen(file,"w");
	 for (i=0;i<NTRIANG2;i++){
        l0 = Facets[i][0];
        l1 = Facets[i][1];
        l2 = Facets[i][2];
		  if (Vertices1[l0].y*Vertices1[l1].y<0.0){
			   t0 = Vertices1[l1].y/(Vertices1[l1].y-Vertices1[l0].y);
				fprintf(fp,"%f\t%f\n",Vertices1[l0].z*t0+(1.0-t0)*Vertices1[l1].z,Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l1].x);
		  }
		  if (Vertices1[l0].y*Vertices1[l2].y<0.0){
			   t0 = Vertices1[l2].y/(Vertices1[l2].y-Vertices1[l0].y);
				fprintf(fp,"%f\t%f\n",Vertices1[l0].z*t0+(1.0-t0)*Vertices1[l2].z,Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l2].x);
		  }
		  if (Vertices1[l2].y*Vertices1[l1].y<0.0){
			   t0 = Vertices1[l1].y/(Vertices1[l1].y-Vertices1[l2].y);
				fprintf(fp,"%f\t%f\n",Vertices1[l2].z*t0+(1.0-t0)*Vertices1[l1].z,Vertices1[l2].x*t0+(1.0-t0)*Vertices1[l1].x);
		  }
	 }
	 fclose(fp);
	 
}


void VTKdump_2vesicles(char suf[], struct point3D Vertices[], int Facets[NTRIANG][3], double Scalar_Field[], double Scalar_Field2[], double Scalar_Field3[], double Scalar_Field4[], double Scalar_Field5[], double Scalar_Field6[], struct point3D Vector_Field[], struct point3D Vector_Field2[])
{
    FILE        	*fp,*fp1;
    char		file[100];
    int			i, j, l0, l1, l2;
    double		dsurf, area, t0, e01,e02,e12,e0,fn0;
	 double     Vmwall1,Vmwall2,darea[NTRIANG];
    struct point3D	v_cm, r_cm, r01, r02, r12, r, norml[NTRIANG], Vertices1[NMEM];
	double S1xx,S1xy,S1xz,S1yx,S1yy,S1yz,S1zx,S1zy,S1zz,S2xx,S2xy,S2xz,S2yx,S2yy,S2yz,S2zx,S2zy,S2zz,VR;

    area = v_cm.x = v_cm.y = v_cm.z = r_cm.x = r_cm.y = r_cm.z = Vmwall1 = Vmwall2 = 0.0;

	 fp=fopen("areas.dat","w");
	 fp1=fopen("edges.dat","w");
	 e0=0.0;
	 for (i=0;i<NMEM;i++) norml[i].x=norml[i].y=norml[i].z=0.0;
    for (i=0;i<NTRIANG;i++) {

        l0 = Facets[i][0];
        l1 = Facets[i][1];
        l2 = Facets[i][2];

        r01.x = Vertices[l1].x - Vertices[l0].x;
        r01.y = Vertices[l1].y - Vertices[l0].y;
        r01.z = Vertices[l1].z - Vertices[l0].z;
		  e01=sqrt(r01.x*r01.x+r01.y*r01.y+r01.z*r01.z);
		  e0+=e01;

        r02.x = Vertices[l2].x - Vertices[l0].x;
        r02.y = Vertices[l2].y - Vertices[l0].y;
        r02.z = Vertices[l2].z - Vertices[l0].z;
		  e02=sqrt(r02.x*r02.x+r02.y*r02.y+r02.z*r02.z);
		  e0+=e02;

        r12.x = Vertices[l2].x - Vertices[l1].x;
        r12.y = Vertices[l2].y - Vertices[l1].y;
        r12.z = Vertices[l2].z - Vertices[l1].z;
		  e12=sqrt(r12.x*r12.x+r12.y*r12.y+r12.z*r12.z);
		  e0+=e12;

        r.x = r01.y*r02.z - r01.z*r02.y;
        r.y = r01.z*r02.x - r01.x*r02.z;
        r.z = r01.x*r02.y - r01.y*r02.x;

        dsurf = sqrt(r.x*r.x + r.y*r.y + r.z*r.z);


        area   += dsurf;

        v_cm.x += dsurf*( Vector_Field[l0].x + Vector_Field[l1].x + Vector_Field[l2].x )/3.0;
        v_cm.y += dsurf*( Vector_Field[l0].y + Vector_Field[l1].y + Vector_Field[l2].y )/3.0;
        v_cm.z += dsurf*( Vector_Field[l0].z + Vector_Field[l1].z + Vector_Field[l2].z )/3.0;

        r_cm.x += dsurf*( Vertices[l0].x + Vertices[l1].x + Vertices[l2].x )/3.0;
        r_cm.y += dsurf*( Vertices[l0].y + Vertices[l1].y + Vertices[l2].y )/3.0;
        r_cm.z += dsurf*( Vertices[l0].z + Vertices[l1].z + Vertices[l2].z )/3.0;


/*		  fn0+=(Vector_Field2[l0].x*r.x+Vector_Field2[l0].y*r.y+Vector_Field2[l0].z*r.z);
		  fn0+=(Vector_Field2[l1].x*r.x+Vector_Field2[l1].y*r.y+Vector_Field2[l1].z*r.z);
		  fn0+=(Vector_Field2[l2].x*r.x+Vector_Field2[l2].y*r.y+Vector_Field2[l2].z*r.z);*/

		  fprintf(fp,"%f\n",dsurf);
		  fprintf(fp1,"%f\n",e01);
		  fprintf(fp1,"%f\n",e02);
		  fprintf(fp1,"%f\n",e12);
		  norml[l0].x+=r.x/dsurf;
		  norml[l0].y+=r.y/dsurf;
		  norml[l0].z+=r.z/dsurf;
		  norml[l1].x+=r.x/dsurf;
		  norml[l1].y+=r.y/dsurf;
		  norml[l1].z+=r.z/dsurf;
		  norml[l2].x+=r.x/dsurf;
		  norml[l2].y+=r.y/dsurf;
		  norml[l2].z+=r.z/dsurf;
		  darea[i]=dsurf*0.5;
    }



	 for(i=0;i<NMEM;i++){
		  dsurf=pow(norml[i].x*norml[i].x+norml[i].y*norml[i].y+norml[i].z*norml[i].z,-0.5);
		  norml[i].x*=dsurf;
		  norml[i].y*=dsurf;
		  norml[i].z*=dsurf;
	 }
	 fclose(fp);
	 fclose(fp1);

    v_cm.x = v_cm.x / area;
    v_cm.y = v_cm.y / area;
    v_cm.z = v_cm.z / area;

    r_cm.x = r_cm.x / area;
    r_cm.y = r_cm.y / area;
    r_cm.z = r_cm.z / area;

	 fn0/=(area*3.0);
	fn0=0.0;

/*    printf("%f\t%f\t%f\t%f\t%f\t%f\n",v_cm.x,v_cm.y,v_cm.z,r_cm.x,r_cm.y,r_cm.z);
    fp=fopen("vm.dat","a");
    fprintf(fp,"%f\t%f\t%f\t%f\t%f\t%f\n",v_cm.x,v_cm.y,v_cm.z,r_cm.x,r_cm.y,r_cm.z);
    fclose(fp);
    fp=fopen("wall.dat","a");
    fprintf(fp,"%f\t%f\n",Vmwall1,Vmwall2);
    fclose(fp);
	 fp=fopen("area0.dat","a");
	 fprintf(fp,"%f\n",area);
	 fclose(fp);
	 fp=fopen("edge0.dat","a");
	 e0/=(3.0*NTRIANG);
	 fprintf(fp,"%f\n",e0);
	 fclose(fp);*/
    sprintf(file,"shape_%s.vtk",suf);
    fp = fopen(file,"w");
    fprintf(fp,"# vtk DataFile Version 3.0\n");
    fprintf(fp,"vtk output\n");
	 fprintf(fp,"ASCII\n");
	 fprintf(fp,"DATASET POLYDATA\n");
	 fprintf(fp,"POINTS %d float\n",2*NMEM);
    for (i=0;i<NMEM;i++) 
            fprintf(fp,"%18.12e %18.12e %18.12e\n",Vertices[i].x,Vertices[i].y,Vertices[i].z);
    for (i=0;i<NMEM;i++) 
            fprintf(fp,"%18.12e %18.12e %18.12e\n",-Vertices[i].x,-Vertices[i].y,-Vertices[i].z);
    fprintf(fp,"POLYGONS %d %d\n",2*NTRIANG,8*NTRIANG);
    for (i=0;i<NTRIANG;i++)
            fprintf(fp,"3 %d %d %d\n",Facets[i][0],Facets[i][1],Facets[i][2]);
    for (i=0;i<NTRIANG;i++)
            fprintf(fp,"3 %d %d %d\n",Facets[i][0]+NMEM,Facets[i][1]+NMEM,Facets[i][2]+NMEM);
	 fprintf(fp,"POINT_DATA %d\n",2*NMEM);
	 fprintf(fp,"SCALARS tension float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NMEM;i++)
		  fprintf(fp,"%f\n",Scalar_Field[i]);
	 for (i=0;i<NMEM;i++)
		  fprintf(fp,"%f\n",Scalar_Field[i]);
	 fprintf(fp,"SCALARS mean_curvature float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NMEM;i++)
		  fprintf(fp,"%f\n",Scalar_Field2[i]);
	 for (i=0;i<NMEM;i++)
		  fprintf(fp,"%f\n",Scalar_Field2[i]);
	 fprintf(fp,"SCALARS gaussian_curvature float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NMEM;i++)
		  fprintf(fp,"%f\n",Scalar_Field3[i]);
	 for (i=0;i<NMEM;i++)
		  fprintf(fp,"%f\n",Scalar_Field3[i]);
	 fprintf(fp,"SCALARS curvature_laplacian float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NMEM;i++)
		  fprintf(fp,"%f\n",Scalar_Field4[i]);
	 for (i=0;i<NMEM;i++)
		  fprintf(fp,"%f\n",Scalar_Field4[i]);
	 fprintf(fp,"SCALARS colors float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NMEM;i++)
		  fprintf(fp,"%f\n",Scalar_Field5[i]);
	 for (i=0;i<NMEM;i++)
		  fprintf(fp,"%f\n",Scalar_Field5[i]);
	 fprintf(fp,"SCALARS stretch float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NMEM;i++)
		  fprintf(fp,"%f\n",Scalar_Field6[i]);
	 for (i=0;i<NMEM;i++)
		  fprintf(fp,"%f\n",Scalar_Field6[i]);
	 fprintf(fp,"VECTORS velocity float\n");
	 for (i=0;i<NMEM;i++)
	 	  fprintf(fp,"%f %f %f\n",Vector_Field[i].x-v_cm.x,Vector_Field[i].y-v_cm.y,Vector_Field[i].z-v_cm.z);
	 for (i=0;i<NMEM;i++)
	 	  fprintf(fp,"%f %f %f\n",-Vector_Field[i].x+v_cm.x,-Vector_Field[i].y+v_cm.y,-Vector_Field[i].z+v_cm.z);
	 fprintf(fp,"VECTORS force float\n");
	 for (i=0;i<NMEM;i++)
	 	  fprintf(fp,"%f %f %f\n",Vector_Field2[i].x-fn0*norml[i].x,Vector_Field2[i].y-fn0*norml[i].y,Vector_Field2[i].z-fn0*norml[i].z);
	 for (i=0;i<NMEM;i++)
	 	  fprintf(fp,"%f %f %f\n",-Vector_Field2[i].x+fn0*norml[i].x,-Vector_Field2[i].y+fn0*norml[i].y,-Vector_Field2[i].z+fn0*norml[i].z);
	 fprintf(fp,"CELL_DATA %d\n",2*NTRIANG);
	 fprintf(fp,"SCALARS areas float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NTRIANG;i++)
		  fprintf(fp,"%f\n",darea[i]);
	 for (i=0;i<NTRIANG;i++)
		  fprintf(fp,"%f\n",darea[i]);
	 fprintf(fp,"SCALARS tensions float\n");
	 fprintf(fp,"LOOKUP_TABLE default\n");
	 for (i=0;i<NTRIANG;i++)
		  fprintf(fp,"%f\n",Scalar_Field[Facets[i][0]]+Scalar_Field[Facets[i][1]]+Scalar_Field[Facets[i][2]]);
	 for (i=0;i<NTRIANG;i++)
		  fprintf(fp,"%f\n",Scalar_Field[Facets[i][0]]+Scalar_Field[Facets[i][1]]+Scalar_Field[Facets[i][2]]);
	 fclose(fp);
    for (i=0;i<NMEM;i++) {
		  Vertices1[i].x = Vertices[i].x-r_cm.x*0.0;
		  Vertices1[i].y = Vertices[i].y-r_cm.y*0.0;
		  Vertices1[i].z = Vertices[i].z-r_cm.z*0.0;
	 }
	 sprintf(file,"csxy_%s.dat",suf);
	 fp=fopen(file,"w");
	 for (i=0;i<NTRIANG;i++){
        l0 = Facets[i][0];
        l1 = Facets[i][1];
        l2 = Facets[i][2];
		  if (Vertices1[l0].z*Vertices1[l1].z<0.0){
			   t0 = Vertices1[l1].z/(Vertices1[l1].z-Vertices1[l0].z);
				fprintf(fp,"%f\t%f\n",Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l1].x,Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l1].y);
				fprintf(fp,"%f\t%f\n",-Vertices1[l0].x*t0-(1.0-t0)*Vertices1[l1].x,-Vertices1[l0].y*t0-(1.0-t0)*Vertices1[l1].y);
		  }
		  if (Vertices1[l0].z*Vertices1[l2].z<0.0){
			   t0 = Vertices1[l2].z/(Vertices1[l2].z-Vertices1[l0].z);
				fprintf(fp,"%f\t%f\n",Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l2].x,Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l2].y);
				fprintf(fp,"%f\t%f\n",-Vertices1[l0].x*t0-(1.0-t0)*Vertices1[l2].x,-Vertices1[l0].y*t0-(1.0-t0)*Vertices1[l2].y);
		  }
		  if (Vertices1[l2].z*Vertices1[l1].z<0.0){
			   t0 = Vertices1[l1].z/(Vertices1[l1].z-Vertices1[l2].z);
				fprintf(fp,"%f\t%f\n",Vertices1[l2].x*t0+(1.0-t0)*Vertices1[l1].x,Vertices1[l2].y*t0+(1.0-t0)*Vertices1[l1].y);
				fprintf(fp,"%f\t%f\n",-Vertices1[l2].x*t0-(1.0-t0)*Vertices1[l1].x,-Vertices1[l2].y*t0-(1.0-t0)*Vertices1[l1].y);
		  }
	 }
	 fclose(fp);
	 sprintf(file,"csyz_%s.dat",suf);
	 fp=fopen(file,"w");
	 for (i=0;i<NTRIANG;i++){
        l0 = Facets[i][0];
        l1 = Facets[i][1];
        l2 = Facets[i][2];
		  if (Vertices1[l0].x*Vertices1[l1].x<0.0){
			   t0 = Vertices1[l1].x/(Vertices1[l1].x-Vertices1[l0].x);
				fprintf(fp,"%f\t%f\n",Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l1].y,Vertices1[l0].z*t0+(1.0-t0)*Vertices1[l1].z);
				fprintf(fp,"%f\t%f\n",-Vertices1[l0].y*t0-(1.0-t0)*Vertices1[l1].y,-Vertices1[l0].z*t0-(1.0-t0)*Vertices1[l1].z);
		  }
		  if (Vertices1[l0].x*Vertices1[l2].x<0.0){
			   t0 = Vertices1[l2].x/(Vertices1[l2].x-Vertices1[l0].x);
				fprintf(fp,"%f\t%f\n",Vertices1[l0].y*t0+(1.0-t0)*Vertices1[l2].y,Vertices1[l0].z*t0+(1.0-t0)*Vertices1[l2].z);
				fprintf(fp,"%f\t%f\n",-Vertices1[l0].y*t0-(1.0-t0)*Vertices1[l2].y,-Vertices1[l0].z*t0-(1.0-t0)*Vertices1[l2].z);
		  }
		  if (Vertices1[l2].x*Vertices1[l1].x<0.0){
			   t0 = Vertices1[l1].x/(Vertices1[l1].x-Vertices1[l2].x);
				fprintf(fp,"%f\t%f\n",Vertices1[l2].y*t0+(1.0-t0)*Vertices1[l1].y,Vertices1[l2].z*t0+(1.0-t0)*Vertices1[l1].z);
				fprintf(fp,"%f\t%f\n",-Vertices1[l2].y*t0-(1.0-t0)*Vertices1[l1].y,-Vertices1[l2].z*t0-(1.0-t0)*Vertices1[l1].z);
		  }
	 }
	 fclose(fp);
	 sprintf(file,"cszx_%s.dat",suf);
	 fp=fopen(file,"w");
	 for (i=0;i<NTRIANG;i++){
        l0 = Facets[i][0];
        l1 = Facets[i][1];
        l2 = Facets[i][2];
		  if (Vertices1[l0].y*Vertices1[l1].y<0.0){
			   t0 = Vertices1[l1].y/(Vertices1[l1].y-Vertices1[l0].y);
				fprintf(fp,"%f\t%f\n",Vertices1[l0].z*t0+(1.0-t0)*Vertices1[l1].z,Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l1].x);
				fprintf(fp,"%f\t%f\n",-Vertices1[l0].z*t0-(1.0-t0)*Vertices1[l1].z,-Vertices1[l0].x*t0-(1.0-t0)*Vertices1[l1].x);
		  }
		  if (Vertices1[l0].y*Vertices1[l2].y<0.0){
			   t0 = Vertices1[l2].y/(Vertices1[l2].y-Vertices1[l0].y);
				fprintf(fp,"%f\t%f\n",Vertices1[l0].z*t0+(1.0-t0)*Vertices1[l2].z,Vertices1[l0].x*t0+(1.0-t0)*Vertices1[l2].x);
				fprintf(fp,"%f\t%f\n",-Vertices1[l0].z*t0-(1.0-t0)*Vertices1[l2].z,-Vertices1[l0].x*t0-(1.0-t0)*Vertices1[l2].x);
		  }
		  if (Vertices1[l2].y*Vertices1[l1].y<0.0){
			   t0 = Vertices1[l1].y/(Vertices1[l1].y-Vertices1[l2].y);
				fprintf(fp,"%f\t%f\n",Vertices1[l2].z*t0+(1.0-t0)*Vertices1[l1].z,Vertices1[l2].x*t0+(1.0-t0)*Vertices1[l1].x);
				fprintf(fp,"%f\t%f\n",-Vertices1[l2].z*t0-(1.0-t0)*Vertices1[l1].z,-Vertices1[l2].x*t0-(1.0-t0)*Vertices1[l1].x);
		  }
	 }
	 fclose(fp);
	 sprintf(file,"areas_%s.dat",suf);
	 
}

