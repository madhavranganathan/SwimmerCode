void green_2_walls_ (double gw[3][3],double *xts, double *yts, double *zt, double *zs, double *hh);

void green_wall_contribution(int triang_site[NTRIANG][3], struct point3D new_v1[NMEM], struct point3D new_v2[NMEM], struct point3D new_v3[NMEM], struct point3D r_mem[NMEM], double darea[NTRIANG], double eta, struct point3D f_mem[NMEM], struct point3D f_mem2[NMEM], struct point3D f_mem3[NMEM]);
