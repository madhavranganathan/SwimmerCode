

struct	point {
	double x,y,z;
	};




double 		dotprod(struct point u , struct point v);

struct point 	vecprod(struct point u , struct point v);

void 		azero(struct point *u);

struct point 	normalize(struct point u);

struct point	normalized_rand_vec();

double 		efrandom();

void rotate	(struct point *u, struct point rotvec, struct point rotcentre,
		 double theta);

struct point    normalized_rand_vec();
