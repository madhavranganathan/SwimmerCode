/*
about:
A function to calculate the non-singular part of the Green function for flow bounded by two plane walls.

how to use:

to define the position of the lower wall #define WALL1 some value 
to define the position of the upper wall #define WALL2 some other value

the walls are z=WALL1, z=WALL2

The velocity fields new_v1, new_v2, new_v3 should already contain the result of the integration of the free space Green function.
The present function updates new_v1, new_v2, new_v3 by adding the non-singular contribution

limitations:
Only the case of no viscosity contrast is handled

features:
The Green function is calculated only once for each pair of points


*/





void green_wall_contribution(int triang_site[NTRIANG][3], struct point3D new_v1[NMEM], struct point3D new_v2[NMEM], struct point3D new_v3[NMEM], struct point3D r_mem[NMEM], double darea[NTRIANG], double eta, struct point3D f_mem[NMEM], struct point3D f_mem2[NMEM], struct point3D f_mem3[NMEM]){

	int i,j,k;
	double areas[NMEM];
	double fn,fGndA,dr1,drn,eta0,temp0;
	double gw[3][3];
	double xts, yts, zt, zs, hh;

	struct point3D fdA[NMEM],fdA2[NMEM],fdA3[NMEM];
	struct point3D dr,vtemp;
	int l1,l2,l3;

	eta0=1.0/(24.0*PI*eta);
	hh=WALL2-WALL1;
	for(i=0;i<NMEM;i++) areas[i]=0.0;
	for(i=0;i<NTRIANG;i++) for(j=0;j<3;j++) areas[triang_site[i][j]]+=darea[i];
	for(i=0;i<NMEM;i++) areas[i]*=eta0;
	for(i=0;i<NMEM;i++){
		fdA[i].x=areas[i]*f_mem[i].x;
		fdA[i].y=areas[i]*f_mem[i].y;
		fdA[i].z=areas[i]*f_mem[i].z;
		fdA2[i].x=areas[i]*f_mem2[i].x;
		fdA2[i].y=areas[i]*f_mem2[i].y;
		fdA2[i].z=areas[i]*f_mem2[i].z;
		fdA3[i].x=areas[i]*f_mem3[i].x;
		fdA3[i].y=areas[i]*f_mem3[i].y;
		fdA3[i].z=areas[i]*f_mem3[i].z;
	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<i;j++){
			dr.x=r_mem[i].x-r_mem[j].x;
			dr.y=r_mem[i].y-r_mem[j].y;

			xts=r_mem[j].x-r_mem[i].x;
			yts=r_mem[j].y-r_mem[i].y;
			zs=r_mem[i].z-WALL1;
			zt=r_mem[j].z-WALL1;
			green_2_walls_ (gw,&xts,&yts,&zt,&zs,&hh);

//calculating contribution of f[i] to v[j]
			new_v1[j].x+=gw[0][0]*fdA[i].x+gw[1][0]*fdA[i].y+gw[1][0]*fdA[i].z;
			new_v1[j].y+=gw[0][1]*fdA[i].x+gw[1][1]*fdA[i].y+gw[1][1]*fdA[i].z;
			new_v1[j].z+=gw[0][2]*fdA[i].x+gw[1][2]*fdA[i].y+gw[1][2]*fdA[i].z;
			new_v2[j].x+=gw[0][0]*fdA2[i].x+gw[1][0]*fdA2[i].y+gw[1][0]*fdA2[i].z;
			new_v2[j].y+=gw[0][1]*fdA2[i].x+gw[1][1]*fdA2[i].y+gw[1][1]*fdA2[i].z;
			new_v2[j].z+=gw[0][2]*fdA2[i].x+gw[1][2]*fdA2[i].y+gw[1][2]*fdA2[i].z;
			new_v3[j].x+=gw[0][0]*fdA3[i].x+gw[1][0]*fdA3[i].y+gw[1][0]*fdA3[i].z;
			new_v3[j].y+=gw[0][1]*fdA3[i].x+gw[1][1]*fdA3[i].y+gw[1][1]*fdA3[i].z;
			new_v3[j].z+=gw[0][2]*fdA3[i].x+gw[1][2]*fdA3[i].y+gw[1][2]*fdA3[i].z;

//calculating contribution of f[j] to v[i]
			new_v1[i].x+=gw[0][0]*fdA[j].x+gw[0][1]*fdA[j].y+gw[0][2]*fdA[j].z;
			new_v1[i].y+=gw[1][0]*fdA[j].x+gw[1][1]*fdA[j].y+gw[1][2]*fdA[j].z;
			new_v1[i].z+=gw[2][0]*fdA[j].x+gw[2][1]*fdA[j].y+gw[2][2]*fdA[j].z;
			new_v2[i].x+=gw[0][0]*fdA2[j].x+gw[0][1]*fdA2[j].y+gw[0][2]*fdA2[j].z;
			new_v2[i].y+=gw[1][0]*fdA2[j].x+gw[1][1]*fdA2[j].y+gw[1][2]*fdA2[j].z;
			new_v2[i].z+=gw[2][0]*fdA2[j].x+gw[2][1]*fdA2[j].y+gw[2][2]*fdA2[j].z;
			new_v3[i].x+=gw[0][0]*fdA3[j].x+gw[0][1]*fdA3[j].y+gw[0][2]*fdA3[j].z;
			new_v3[i].y+=gw[1][0]*fdA3[j].x+gw[1][1]*fdA3[j].y+gw[1][2]*fdA3[j].z;
			new_v3[i].z+=gw[2][0]*fdA3[j].x+gw[2][1]*fdA3[j].y+gw[2][2]*fdA3[j].z;
		}
//calculating contribution of f[i] to v[i]
		xts=0.0;
		yts=0.0;
		zt=r_mem[i].z-WALL1;
		zs=r_mem[i].z-WALL1;
		green_2_walls_(gw,&xts,&yts,&zt,&zs,&hh);
		new_v1[i].x+=(gw[0][0]*fdA[i].x+gw[0][1]*fdA[i].y+gw[0][2]*fdA[i].z);
		new_v1[i].y+=(gw[1][0]*fdA[i].x+gw[1][1]*fdA[i].y+gw[1][2]*fdA[i].z);
		new_v1[i].z+=(gw[2][0]*fdA[i].x+gw[2][1]*fdA[i].y+gw[2][2]*fdA[i].z);
		new_v2[i].x+=(gw[0][0]*fdA2[i].x+gw[0][1]*fdA2[i].y+gw[0][2]*fdA2[i].z);
		new_v2[i].y+=(gw[1][0]*fdA2[i].x+gw[1][1]*fdA2[i].y+gw[1][2]*fdA2[i].z);
		new_v2[i].z+=(gw[2][0]*fdA2[i].x+gw[2][1]*fdA2[i].y+gw[2][2]*fdA2[i].z);
		new_v3[i].x+=(gw[0][0]*fdA3[i].x+gw[0][1]*fdA3[i].y+gw[0][2]*fdA3[i].z);
		new_v3[i].y+=(gw[1][0]*fdA3[i].x+gw[1][1]*fdA3[i].y+gw[1][2]*fdA3[i].z);
		new_v3[i].z+=(gw[2][0]*fdA3[i].x+gw[2][1]*fdA3[i].y+gw[2][2]*fdA3[i].z);	
	}

}
