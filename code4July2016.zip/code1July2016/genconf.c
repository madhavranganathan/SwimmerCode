#include        "includes.h"

void refine7(int triang_site[NTRIANG2][3], int triang_site0[NTRIANG][3], struct point3D r_sphere[], int ntriang, int nvertex, int slaves[NMEM][NSLA])
{
	int		i, j, k, i1, j1, i2, j2, n, m, v, w, l0, l1, l2, a, b, c, d, Nslaves0[NMEM][3];
	double		norm;
	struct point3D	rmid;

	n = m = ntriang;

	w = v = nvertex;
	for(i=0;i<w;i++){
		slaves[i][0]=i;
		for(j=0;j<3;j++) Nslaves0[i][j]=1;
	}
	for(i=0;i<m;i++){
		for(j=0;j<3;j++){
			l0 = triang_site0[i][j];
			l1 = triang_site0[i][(j+1)%3];
			l2 = triang_site0[i][(j+2)%3];
			slaves[l0][Nslaves0[l0][0]]=v;
			slaves[l1][Nslaves0[l1][1]+6]=v;
			slaves[l2][Nslaves0[l2][2]+12]=v;
			Nslaves0[l0][0]++;
			Nslaves0[l1][1]++;
			Nslaves0[l2][2]++;
			r_sphere[v].x=r_sphere[l2].x+2.0*r_sphere[l1].x+4.0*r_sphere[l0].x;
			r_sphere[v].y=r_sphere[l2].y+2.0*r_sphere[l1].y+4.0*r_sphere[l0].y;
			r_sphere[v].z=r_sphere[l2].z+2.0*r_sphere[l1].z+4.0*r_sphere[l0].z;
			norm=1.0/sqrt(r_sphere[v].x*r_sphere[v].x+r_sphere[v].y*r_sphere[v].y+r_sphere[v].z*r_sphere[v].z);
			r_sphere[v].x*=norm;
			r_sphere[v].y*=norm;
			r_sphere[v].z*=norm;
			triang_site[i][j]=v;
			v++;
		}	
	}
	for(i=0;i<m;i++){
		for(j=0;j<i;j++){
			for(i1=0;i1<3;i1++){
				for(j1=0;j1<3;j1++){
					if((triang_site0[i][i1]==triang_site0[j][j1]) && (triang_site0[i][(i1+2)%3]==triang_site0[j][(j1+1)%3])){
						l0=triang_site0[i][(i1+2)%3];
						l1=triang_site0[i][i1];
						a=w+3*i+(i1+2)%3;
						b=w+3*j+(j1+1)%3;
						c=w+3*j+j1;
						d=w+3*i+i1;
						triang_site[n][0]=l0;
						triang_site[n][1]=b;
						triang_site[n++][2]=a;
						triang_site[n][0]=a;
						triang_site[n][1]=b;
						triang_site[n++][2]=c;
						triang_site[n][0]=a;
						triang_site[n][1]=c;
						triang_site[n++][2]=d;
						triang_site[n][0]=l1;
						triang_site[n][1]=d;
						triang_site[n++][2]=c;
						
					}
				}
			}
		}
	}
	printf("%d\t%d\n",n,v);

}



void settau(int triang_site[NTRIANG][3], struct point3D r_mem[], double tau, double radius){
	int	i, j, k, l0, l1, l2;
	double	vol0, area0, tautemp, norm, alpha, beta, gamma, gamma0;
	struct point3D	r01,r02, r, temp_sqrt2;
	int	ntriang, nvertex;
	vol0=area0=0.0;
	for(i=0;i<NTRIANG;i++){
		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];

		r01.x = r_mem[l1].x - r_mem[l0].x;
		r01.y = r_mem[l1].y - r_mem[l0].y;
		r01.z = r_mem[l1].z - r_mem[l0].z;

		r02.x = r_mem[l2].x - r_mem[l0].x;
		r02.y = r_mem[l2].y - r_mem[l0].y;
		r02.z = r_mem[l2].z - r_mem[l0].z;

		r.x = r01.y*r02.z - r01.z*r02.y;
		r.y = r01.z*r02.x - r01.x*r02.z;
		r.z = r01.x*r02.y - r01.y*r02.x;

		norm = sqrt(r.x*r.x + r.y*r.y + r.z*r.z);
		area0 += norm;
		vol0+=(r_mem[l0].x+r_mem[l1].x+r_mem[l2].x)*r.x;
		vol0+=(r_mem[l0].y+r_mem[l1].y+r_mem[l2].y)*r.y;
		vol0+=(r_mem[l0].z+r_mem[l1].z+r_mem[l2].z)*r.z;
	}
	area0*=0.5;
	vol0*=(0.5/9.0);
	tautemp=vol0/4.0/PI*3.0*pow(area0/4.0/PI,-1.5);
	printf("%f\t%f\t%f\n",area0,vol0,tautemp);
        printf("Made it here\n");
	alpha=1.e-6;
	gamma=1.0+alpha;
	k=0;
	while(tautemp>tau){
		for(i=0;i<NMEM;i++){
#if defined OBLATE
			r_mem[i].z/=gamma;
#else
			r_mem[i].z*=gamma;
#endif
		}
		vol0=area0=0.0;
		for(i=0;i<NTRIANG;i++){
			l0 = triang_site[i][0];
			l1 = triang_site[i][1];
			l2 = triang_site[i][2];

			r01.x = r_mem[l1].x - r_mem[l0].x;
			r01.y = r_mem[l1].y - r_mem[l0].y;
			r01.z = r_mem[l1].z - r_mem[l0].z;

			r02.x = r_mem[l2].x - r_mem[l0].x;
			r02.y = r_mem[l2].y - r_mem[l0].y;
			r02.z = r_mem[l2].z - r_mem[l0].z;

			r.x = r01.y*r02.z - r01.z*r02.y;
			r.y = r01.z*r02.x - r01.x*r02.z;
			r.z = r01.x*r02.y - r01.y*r02.x;

			norm = sqrt(r.x*r.x + r.y*r.y + r.z*r.z);
			area0 += norm;
			vol0+=(r_mem[l0].x+r_mem[l1].x+r_mem[l2].x)*r.x;
			vol0+=(r_mem[l0].y+r_mem[l1].y+r_mem[l2].y)*r.y;
			vol0+=(r_mem[l0].z+r_mem[l1].z+r_mem[l2].z)*r.z;
		}
		area0*=0.5;
		vol0*=(0.5/9.0);
		tautemp=vol0/4.0/PI*3.0*pow(area0/4.0/PI,-1.5);
		printf("%f\t%f\t%f\n",area0,vol0,tautemp);
               
		beta=alpha;
		alpha*=2.0;
		gamma=(1.0+alpha)/(1.0+beta);
		k++;
	}
	gamma=1.0+beta;
	alpha*=0.5;
	beta*=0.5;
	for(j=0;j<k-1;j++){
		gamma0=(1.0+0.5*(alpha+beta))/gamma;			
		for(i=0;i<NMEM;i++){
#if defined OBLATE
			r_mem[i].z/=gamma0;
#else
			r_mem[i].z*=gamma0;
#endif
		}
		vol0=area0=0.0;
		for(i=0;i<NTRIANG;i++){
			l0 = triang_site[i][0];
			l1 = triang_site[i][1];
			l2 = triang_site[i][2];

			r01.x = r_mem[l1].x - r_mem[l0].x;
			r01.y = r_mem[l1].y - r_mem[l0].y;
			r01.z = r_mem[l1].z - r_mem[l0].z;

			r02.x = r_mem[l2].x - r_mem[l0].x;
			r02.y = r_mem[l2].y - r_mem[l0].y;
			r02.z = r_mem[l2].z - r_mem[l0].z;

			r.x = r01.y*r02.z - r01.z*r02.y;
			r.y = r01.z*r02.x - r01.x*r02.z;
			r.z = r01.x*r02.y - r01.y*r02.x;

			norm = sqrt(r.x*r.x + r.y*r.y + r.z*r.z);
			area0 += norm;
			vol0+=(r_mem[l0].x+r_mem[l1].x+r_mem[l2].x)*r.x;
			vol0+=(r_mem[l0].y+r_mem[l1].y+r_mem[l2].y)*r.y;
			vol0+=(r_mem[l0].z+r_mem[l1].z+r_mem[l2].z)*r.z;			
		}
		area0*=0.5;
		vol0*=(0.5/9.0);
		tautemp=vol0/4.0/PI*3.0*pow(area0/4.0/PI,-1.5);
		printf("%f\t%f\t%f\n",area0,vol0,tautemp);
		gamma=(1.0+0.5*(alpha+beta));
                
		if(tautemp>tau) beta=0.5*(alpha+beta);
		else alpha=0.5*(alpha+beta);

	}
       
	gamma=radius*pow(vol0/4.0/PI*3.0,-1.0/3.0);
	for(i=0;i<NMEM;i++){
		r_mem[i].x*=gamma;
		r_mem[i].y*=gamma;
		r_mem[i].z*=gamma;
	}
}

void init_conf(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D v_mem[], double zeta[], double angle, double tau, double radius){
	int	i, j, k, l0, l1, l2;
	double	vol0, area0, tautemp, norm, alpha, beta, gamma, gamma0;
	struct point3D	r01,r02, r, temp_sqrt2;
	int	ntriang, nvertex;

#ifdef	CAPSULE
	icosaedre2(triang_site,r_mem,&ntriang,&nvertex);
#else
	icosaedre2(triang_site,r_mem,&ntriang,&nvertex);
#endif
	for (i=0;i<NELL;i++) refine  (triang_site,r_mem,&ntriang,&nvertex);

//  make some noise

	for (i=0;i<NMEM;i++) {

/*set noise to zero, Alexander
		r_mem[i].x += 0.01*efrandom();
		r_mem[i].y += 0.01*efrandom();
		r_mem[i].z += 0.01*efrandom();
*/
		norm = 1.0/sqrt(r_mem[i].x*r_mem[i].x+r_mem[i].y*r_mem[i].y+r_mem[i].z*r_mem[i].z);

		r_mem[i].x = r_mem[i].x*norm;
		r_mem[i].y = r_mem[i].y*norm;
		r_mem[i].z = r_mem[i].z*norm;

	}


	vol0=area0=0.0;
	for(i=0;i<NTRIANG;i++){
		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];

		r01.x = r_mem[l1].x - r_mem[l0].x;
		r01.y = r_mem[l1].y - r_mem[l0].y;
		r01.z = r_mem[l1].z - r_mem[l0].z;

		r02.x = r_mem[l2].x - r_mem[l0].x;
		r02.y = r_mem[l2].y - r_mem[l0].y;
		r02.z = r_mem[l2].z - r_mem[l0].z;

		r.x = r01.y*r02.z - r01.z*r02.y;
		r.y = r01.z*r02.x - r01.x*r02.z;
		r.z = r01.x*r02.y - r01.y*r02.x;

		norm = sqrt(r.x*r.x + r.y*r.y + r.z*r.z);
		area0 += norm;
		vol0+=(r_mem[l0].x+r_mem[l1].x+r_mem[l2].x)*r.x;
		vol0+=(r_mem[l0].y+r_mem[l1].y+r_mem[l2].y)*r.y;
		vol0+=(r_mem[l0].z+r_mem[l1].z+r_mem[l2].z)*r.z;
	}
	area0*=0.5;
	vol0*=(0.5/9.0);
	tautemp=vol0/4.0/PI*3.0*pow(area0/4.0/PI,-1.5);
	printf("%f\t%f\t%f\n",area0,vol0,tautemp);
	alpha=1.e-6;
	gamma=1.0+alpha;
	k=0;
	while(tautemp>tau){
		for(i=0;i<NMEM;i++){
#if defined OBLATE
			r_mem[i].z/=gamma;
#else
			r_mem[i].z*=gamma;
#endif
		}
		vol0=area0=0.0;
		for(i=0;i<NTRIANG;i++){
			l0 = triang_site[i][0];
			l1 = triang_site[i][1];
			l2 = triang_site[i][2];

			r01.x = r_mem[l1].x - r_mem[l0].x;
			r01.y = r_mem[l1].y - r_mem[l0].y;
			r01.z = r_mem[l1].z - r_mem[l0].z;

			r02.x = r_mem[l2].x - r_mem[l0].x;
			r02.y = r_mem[l2].y - r_mem[l0].y;
			r02.z = r_mem[l2].z - r_mem[l0].z;

			r.x = r01.y*r02.z - r01.z*r02.y;
			r.y = r01.z*r02.x - r01.x*r02.z;
			r.z = r01.x*r02.y - r01.y*r02.x;

			norm = sqrt(r.x*r.x + r.y*r.y + r.z*r.z);
			area0 += norm;
			vol0+=(r_mem[l0].x+r_mem[l1].x+r_mem[l2].x)*r.x;
			vol0+=(r_mem[l0].y+r_mem[l1].y+r_mem[l2].y)*r.y;
			vol0+=(r_mem[l0].z+r_mem[l1].z+r_mem[l2].z)*r.z;
		}
		area0*=0.5;
		vol0*=(0.5/9.0);
		tautemp=vol0/4.0/PI*3.0*pow(area0/4.0/PI,-1.5);
		printf("%f\t%f\t%f\n",area0,vol0,tautemp);
                
		beta=alpha;
		alpha*=2.0;
		gamma=(1.0+alpha)/(1.0+beta);
		k++;
	}
	gamma=1.0+beta;
	alpha*=0.5;
	beta*=0.5;
	for(j=0;j<k-1;j++){
		gamma0=(1.0+0.5*(alpha+beta))/gamma;			
		for(i=0;i<NMEM;i++){
#if defined OBLATE
			r_mem[i].z/=gamma0;
#else
			r_mem[i].z*=gamma0;
#endif
		}
		vol0=area0=0.0;
		for(i=0;i<NTRIANG;i++){
			l0 = triang_site[i][0];
			l1 = triang_site[i][1];
			l2 = triang_site[i][2];

			r01.x = r_mem[l1].x - r_mem[l0].x;
			r01.y = r_mem[l1].y - r_mem[l0].y;
			r01.z = r_mem[l1].z - r_mem[l0].z;

			r02.x = r_mem[l2].x - r_mem[l0].x;
			r02.y = r_mem[l2].y - r_mem[l0].y;
			r02.z = r_mem[l2].z - r_mem[l0].z;

			r.x = r01.y*r02.z - r01.z*r02.y;
			r.y = r01.z*r02.x - r01.x*r02.z;
			r.z = r01.x*r02.y - r01.y*r02.x;

			norm = sqrt(r.x*r.x + r.y*r.y + r.z*r.z);
			area0 += norm;
			vol0+=(r_mem[l0].x+r_mem[l1].x+r_mem[l2].x)*r.x;
			vol0+=(r_mem[l0].y+r_mem[l1].y+r_mem[l2].y)*r.y;
			vol0+=(r_mem[l0].z+r_mem[l1].z+r_mem[l2].z)*r.z;			
		}
		area0*=0.5;
		vol0*=(0.5/9.0);
		tautemp=vol0/4.0/PI*3.0*pow(area0/4.0/PI,-1.5);
		printf("%f\t%f\t%f\n",area0,vol0,tautemp);
               
		gamma=(1.0+0.5*(alpha+beta));
		if(tautemp>tau) beta=0.5*(alpha+beta);
		else alpha=0.5*(alpha+beta);

	}
	gamma=radius*pow(vol0/4.0/PI*3.0,-1.0/3.0);
	for(i=0;i<NMEM;i++){
		r_mem[i].x*=gamma;
		r_mem[i].y*=gamma;
		r_mem[i].z*=gamma;
	}

//  other fields
	for (i=0;i<NMEM;i++) {
		v_mem[i].x=v_mem[i].y=v_mem[i].z=0.0;
	}
	for(i=0;i<NMEM;i++) zeta[i]=0.0;
        
 
} //END OF init_conf


/*
double excentricite_prolate()
{
    double dum, tmin, tmax, ttest, fmin, fmax, ftest;

    dum = 1.0/pow(TAU,2.0/3.0);

    tmin = 0.0;
    tmax = 1.0 - 1.e-12;

    fmin = func_ell_prolate(dum,tmin);
    fmax = func_ell_prolate(dum,tmax);

    if (fmin>fmax) {
        ttest = tmin;
        tmin  = tmax;
        tmax  = ttest;
        ftest = fmin;
        fmin  = fmax;
        fmax  = ftest;
    }

    while ( fabs(tmax-tmin) > 1.e-12 ) {

        ttest = 0.5 * (tmax+tmin);
        ftest = func_ell_prolate(dum,ttest);

        if (ftest>=0.0) {
            tmax = ttest;
            fmax = ftest;
        }
        else {
            tmin = ttest;
            fmin = ftest;
        }

    }

    return 0.5 * (tmax+tmin);
}
*/
/*void init_wall(struct point3D r_wall[], struct point3D r0_wall[], struct point3D v_wall[])
{
    int		i, j, label;


    for (i=0;i<NX;i++) {
    for (j=0;j<NY;j++) {

        label = site_label_wall(i,j);

        r_wall[label].x = XWALL + (i-NX/2+0.5)*LX/(NX-1.0) ;
        r_wall[label].y = YWALL + (j-NY/2+0.5)*LY/(NY-1.0) ;
        r_wall[label].z = ZWALL;

    }
    }

//  other fields

    for (label=0;label<NWALL;label++) {

        r0_wall[label] = r_wall[label];

        v_wall[label].x = xflow(r_wall[label]);
        v_wall[label].y = yflow(r_wall[label]);
        v_wall[label].z = zflow(r_wall[label]);

    }


    for (i=0;i<NX;i++) {
    for (j=0;j<NY;j++) {

        label = site_label_wall(i,j);

 //       r_wall[label].x += 0.1*i/(NX-1.0) ;
          r_wall[label].y += 0.1*j/(NY-1.0) ;
 //       r_wall[label].z += 0.0 ;
    }
    }

}*/

void icosaedre(int triang_site[NTRIANG][3], struct point3D r_sphere[], int *ntriang, int *nvertex)
{
    int		i;
    double	rad, zz;

    *ntriang = 20;
    *nvertex = 12;

    rad = 0.894427191; /*TAU = 0.8 */
    zz  = 0.4472135954;

    r_sphere[0].x = 0.0;
    r_sphere[0].y = 0.0;
    r_sphere[0].z = 1.0;

    for (i=1;i<6;i++) {

        r_sphere[i].x = rad*cos(2.0*PI*i/5.0);
        r_sphere[i].y = rad*sin(2.0*PI*i/5.0);
        r_sphere[i].z = zz;

    }
    for (i=6;i<11;i++) {

        r_sphere[i].x = - rad*cos(2.0*PI*i/5.0);
        r_sphere[i].y = - rad*sin(2.0*PI*i/5.0);
        r_sphere[i].z = - zz;

    }

    r_sphere[11].x = 0.0;
    r_sphere[11].y = 0.0;
    r_sphere[11].z = -1.0;

    triang_site[0][0] = 0;
    triang_site[0][1] = 1;
    triang_site[0][2] = 2;

    triang_site[1][0] = 0;
    triang_site[1][1] = 2;
    triang_site[1][2] = 3;

    triang_site[2][0] = 0;
    triang_site[2][1] = 3;
    triang_site[2][2] = 4;

    triang_site[3][0] = 0;
    triang_site[3][1] = 4;
    triang_site[3][2] = 5;

    triang_site[4][0] = 0;
    triang_site[4][1] = 5;
    triang_site[4][2] = 1;

    triang_site[5][0] = 1;
    triang_site[5][1] = 8;
    triang_site[5][2] = 9;

    triang_site[6][0] = 1;
    triang_site[6][1] = 9;
    triang_site[6][2] = 2;

    triang_site[7][0] = 2;
    triang_site[7][1] = 9;
    triang_site[7][2] = 10;

    triang_site[8][0] = 2;
    triang_site[8][1] = 10;
    triang_site[8][2] = 3;

    triang_site[9][0] = 3;
    triang_site[9][1] = 10;
    triang_site[9][2] = 6;

    triang_site[10][0] = 3;
    triang_site[10][1] = 6;
    triang_site[10][2] = 4;

    triang_site[11][0] = 4;
    triang_site[11][1] = 6;
    triang_site[11][2] = 7;

    triang_site[12][0] = 4;
    triang_site[12][1] = 7;
    triang_site[12][2] = 5;

    triang_site[13][0] = 5;
    triang_site[13][1] = 7;
    triang_site[13][2] = 8;

    triang_site[14][0] = 5;
    triang_site[14][1] = 8;
    triang_site[14][2] = 1;

    triang_site[15][0] = 11;
    triang_site[15][1] = 7;
    triang_site[15][2] = 6;

    triang_site[16][0] = 11;
    triang_site[16][1] = 8;
    triang_site[16][2] = 7;

    triang_site[17][0] = 11;
    triang_site[17][1] = 9;
    triang_site[17][2] = 8;

    triang_site[18][0] = 11;
    triang_site[18][1] = 10;
    triang_site[18][2] = 9;

    triang_site[19][0] = 11;
    triang_site[19][1] = 6;
    triang_site[19][2] = 10;

}

void icosaedre2(int triang_site[NTRIANG][3], struct point3D r_sphere[], int *ntriang, int *nvertex)
{
	int	i,j,rows,site;
	double	rad, zz, norm;

	rows = NROWS;
	*nvertex = 5*rows+2;
	*ntriang=0;

	rad = 1.0;
	zz  = 2.0/(rows+2.0);
	rad = 0.894427191;
	zz  = 0.4472135954;
	

	r_sphere[0].x = 0.0;
	r_sphere[0].y = 0.0;
	r_sphere[0].z = zz*(-1-(rows-1.0)/2.0);

	for (i=0;i<rows;i++) {
		for(j=1;j<6;j++) {
			r_sphere[5*i+j].z=zz*(i-(rows-1.0)/2.0);	
			r_sphere[5*i+j].x=rad*cos(PI*(2*j+i)/5.0);
			r_sphere[5*i+j].y=rad*sin(PI*(2*j+i)/5.0);
		}
	}
	r_sphere[5*rows+1].x = 0.0;
	r_sphere[5*rows+1].y = 0.0;
	r_sphere[5*rows+1].z = zz*(rows-(rows-1.0)/2.0);
	for(i=0;i<*nvertex;i++){
		norm=1.0/sqrt(r_sphere[i].x*r_sphere[i].x+r_sphere[i].y*r_sphere[i].y+r_sphere[i].z*r_sphere[i].z);
		r_sphere[i].x*=norm;
		r_sphere[i].y*=norm;
		r_sphere[i].z*=norm;
	}
	for(i=1;i<6;i++){
		triang_site[*ntriang][2]=0;
		triang_site[*ntriang][1]=i;
		triang_site[*ntriang][0]=i%5+1;
		(*ntriang)++;
	}
	for(i=0;i<rows-1;i++){
		for(j=1;j<6;j++){
			triang_site[*ntriang][0]=i*5+j;
			triang_site[*ntriang][1]=i*5+j%5+1;
			triang_site[*ntriang][2]=(i+1)*5+j;
			(*ntriang)++;
			triang_site[*ntriang][2]=i*5+j;
			triang_site[*ntriang][1]=(i+1)*5+(j+3)%5+1;
			triang_site[*ntriang][0]=(i+1)*5+j;
			(*ntriang)++;
		}
	}
	for(i=1;i<6;i++){
		triang_site[*ntriang][2]=5*rows+1;
		triang_site[*ntriang][1]=5*(rows-1)+i%5+1;
		triang_site[*ntriang][0]=5*(rows-1)+i;
		(*ntriang)++;
	}
	for(i=0;i<*ntriang;i++) for(j=0;j<3;j++) {
		if(j<2) printf("%d ",triang_site[i][j]);
		else printf("%d\n",triang_site[i][j]);
	}
		printf("%d %d\n",i,*ntriang);
}

void refine(int triang_site[NTRIANG][3], struct point3D r_sphere[], int *ntriang, int *nvertex)
{
	int			i, j, k,l, n, m, v, l0, l1, l2, v0, v1, v2,triang_site0[NTRIANG][3],midpoint[NTRIANG][3];
	double		norm;
	struct point3D	rmid;

	n =  *ntriang;
	m=0;
	v = *nvertex;

	for(i=0;i<n;i++) for(j=0;j<3;j++)triang_site0[i][j]=triang_site[i][j];
	for (i=0;i<n;i++) {
		for(k=0;k<3;k++){
			for(j=0;j<i;j++) {
				for(l=0;l<3;l++) if((triang_site0[i][k]==triang_site0[j][l]) && (triang_site0[i][(k+1)%3]==triang_site0[j][(l+2)%3])) break;
				if(l<3) break;
			}
			if(j==i){
				l0=triang_site0[i][k];
				l1=triang_site0[i][(k+1)%3];
				r_sphere[v].x=r_sphere[l0].x+r_sphere[l1].x;
				r_sphere[v].y=r_sphere[l0].y+r_sphere[l1].y;
				r_sphere[v].z=r_sphere[l0].z+r_sphere[l1].z;
				norm=1.0/sqrt(r_sphere[v].x*r_sphere[v].x+r_sphere[v].y*r_sphere[v].y+r_sphere[v].z*r_sphere[v].z);
				r_sphere[v].x*=norm;
				r_sphere[v].y*=norm;
				r_sphere[v].z*=norm;
				midpoint[i][k]=v;
				v++;
			}
			else midpoint[i][k]=midpoint[j][(l+2)%3];			
		}
		triang_site[m][0]=triang_site0[i][0];
		triang_site[m][1]=midpoint[i][0];
		triang_site[m][2]=midpoint[i][2];
		m++;
		triang_site[m][0]=triang_site0[i][1];
		triang_site[m][1]=midpoint[i][1];
		triang_site[m][2]=midpoint[i][0];
		m++;
		triang_site[m][0]=triang_site0[i][2];
		triang_site[m][1]=midpoint[i][2];
		triang_site[m][2]=midpoint[i][1];
		m++;
		triang_site[m][0]=midpoint[i][0];
		triang_site[m][1]=midpoint[i][1];
		triang_site[m][2]=midpoint[i][2];
		m++;		
	}
	*ntriang = m;
	*nvertex = v;

}

void refine16(int triang_site[NTRIANG2][3], int triang_site2[NTRIANG][3], struct point3D r_sphere[], struct point3D r_sphere2[], int slaves[NMEM][NSLA], int slaves2[NMEM][NSLA2], int Nslaves2[NMEM])
{
	int			a,i, j, k,l, n, m, v, l0, l1, l2, v0, v1, v2,midpoint[NTRIANG2][3][3],triang_site0[NTRIANG2][3];
	int Nslaves[NMEM][3];
	double		norm;
	struct point3D	rmid;

	n = NTRIANG;
	m=0;
	v = NMEM;

	for(i=0;i<NMEM;i++){
		Nslaves[i][0]=1;
		Nslaves[i][1]=7;
		Nslaves[i][2]=19;
		slaves[i][0]=i;
		Nslaves2[i]=1;
		slaves2[i][0]=i;
	}
	for(i=0;i<n;i++) {
		r_sphere2[i].x=r_sphere[i].x;
		r_sphere2[i].y=r_sphere[i].y;
		r_sphere2[i].z=r_sphere[i].z;
	}
	for(i=0;i<n;i++)for(j=0;j<3;j++)triang_site0[i][j]=triang_site[i][j];
	for (i=0;i<n;i++) {
		for(k=0;k<3;k++){
			for(j=0;j<i;j++) {
				for(l=0;l<3;l++) if((triang_site0[i][k]==triang_site0[j][l]) && (triang_site0[i][(k+1)%3]==triang_site0[j][(l+2)%3])) break;
				if(l<3) break;
			}
			if(j==i){
				l0=triang_site0[i][k];
				l1=triang_site0[i][(k+1)%3];
				r_sphere2[v].x=3.0*r_sphere2[l0].x+r_sphere2[l1].x;
				r_sphere2[v].y=3.0*r_sphere2[l0].y+r_sphere2[l1].y;
				r_sphere2[v].z=3.0*r_sphere2[l0].z+r_sphere2[l1].z;
				norm=1.0/sqrt(r_sphere2[v].x*r_sphere2[v].x+r_sphere2[v].y*r_sphere2[v].y+r_sphere2[v].z*r_sphere2[v].z);
				r_sphere2[v].x*=norm;
				r_sphere2[v].y*=norm;
				r_sphere2[v].z*=norm;
				midpoint[i][k][0]=v;
				slaves[l0][Nslaves[l0][0]]=v;
				Nslaves[l0][0]++;
				slaves[l1][Nslaves[l1][2]]=v;
				Nslaves[l1][2]++;
				slaves2[l0][Nslaves2[l0]++]=v;
				v++;
				r_sphere2[v].x=r_sphere2[l0].x+r_sphere2[l1].x;
				r_sphere2[v].y=r_sphere2[l0].y+r_sphere2[l1].y;
				r_sphere2[v].z=r_sphere2[l0].z+r_sphere2[l1].z;
				norm=1.0/sqrt(r_sphere2[v].x*r_sphere2[v].x+r_sphere2[v].y*r_sphere2[v].y+r_sphere2[v].z*r_sphere2[v].z);
				r_sphere2[v].x*=norm;
				r_sphere2[v].y*=norm;
				r_sphere2[v].z*=norm;
				midpoint[i][k][1]=v;
				slaves[l0][Nslaves[l0][1]]=v;
				Nslaves[l0][1]++;
				slaves[l1][Nslaves[l1][1]]=v;
				Nslaves[l1][1]++;
				if(l0<l1) slaves2[l0][Nslaves2[l0]++]=v;
				else slaves2[l1][Nslaves2[l1]++]=v;
				v++;
				r_sphere2[v].x=r_sphere2[l0].x+3.0*r_sphere2[l1].x;
				r_sphere2[v].y=r_sphere2[l0].y+3.0*r_sphere2[l1].y;
				r_sphere2[v].z=r_sphere2[l0].z+3.0*r_sphere2[l1].z;
				norm=1.0/sqrt(r_sphere2[v].x*r_sphere2[v].x+r_sphere2[v].y*r_sphere2[v].y+r_sphere2[v].z*r_sphere2[v].z);
				r_sphere2[v].x*=norm;
				r_sphere2[v].y*=norm;
				r_sphere2[v].z*=norm;
				midpoint[i][k][2]=v;
				slaves[l0][Nslaves[l0][2]]=v;
				Nslaves[l0][2]++;
				slaves[l1][Nslaves[l1][0]]=v;
				Nslaves[l1][0]++;
				slaves2[l1][Nslaves2[l1]++]=v;
				v++;
			}
			else for(a=0;a<3;a++)midpoint[i][k][a]=midpoint[j][(l+2)%3][2-a];
		}
		for(j=0;j<3;j++){
			l0=triang_site0[i][j];
			l1=triang_site0[i][(j+1)%3];
			l2=triang_site0[i][(j+2)%3];
			r_sphere2[v].x=r_sphere2[l0].x+r_sphere2[l1].x+2.0*r_sphere2[l2].x;
			r_sphere2[v].y=r_sphere2[l0].y+r_sphere2[l1].y+2.0*r_sphere2[l2].y;
			r_sphere2[v].z=r_sphere2[l0].z+r_sphere2[l1].z+2.0*r_sphere2[l2].z;
			norm=1.0/sqrt(r_sphere2[v].x*r_sphere2[v].x+r_sphere2[v].y*r_sphere2[v].y+r_sphere2[v].z*r_sphere2[v].z);
			r_sphere2[v].x*=norm;
			r_sphere2[v].y*=norm;
			r_sphere2[v].z*=norm;
			slaves[l0][Nslaves[l0][2]]=v;
			Nslaves[l0][2]++;
			slaves[l1][Nslaves[l1][2]]=v;
			Nslaves[l1][2]++;
			slaves[l2][Nslaves[l2][1]]=v;
			Nslaves[l2][1]++;
			slaves2[l2][Nslaves2[l2]++]=v;
			v++;
		}
		triang_site2[m][0]=v-3;
		triang_site2[m][1]=v-2;
		triang_site2[m][2]=v-1;
		m++;
		for(j=0;j<3;j++){
			triang_site2[m][0]=triang_site0[i][j];
			triang_site2[m][1]=midpoint[i][j][0];
			triang_site2[m][2]=midpoint[i][(j+2)%3][2];
			m++;
			triang_site2[m][0]=v-3+(j+1)%3;
			triang_site2[m][1]=midpoint[i][j][0];
			triang_site2[m][2]=midpoint[i][j][1];
			m++;
			triang_site2[m][0]=v-3+(j+2)%3;
			triang_site2[m][1]=midpoint[i][j][1];
			triang_site2[m][2]=midpoint[i][j][2];
			m++;
			triang_site2[m][0]=v-3+(j+2)%3;
			triang_site2[m][1]=midpoint[i][j][2];
			triang_site2[m][2]=midpoint[i][(j+1)%3][0];
			m++;
			triang_site2[m][0]=midpoint[i][j][1];
			triang_site2[m][1]=v-3+(j+2)%3;
			triang_site2[m][2]=v-3+(j+1)%3;
			m++;
		}
	}
}
