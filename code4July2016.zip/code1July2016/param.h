#include "script.h"

#define		GENCONF		0 // Genconf 1 implies automatically generated input, Genconf 0 implies input from file
#define		RUNPREV		0  //25400 Takes triang_0 mem_0

#define		PI		 3.141592653589793115997963468544

// units

#define		RAD		1.0
#define		T_CURV		1.0
#define		GRAV		1.0

// parameters

#define		TAU		0.80 //reduced volume

//#define VISCOSITY_CONTRAST // use this option if lambda!=1
//#define DEFLATION

#ifdef VISCOSITY_CONTRAST
#define		VISC_RATIO	0.1 //viscosity ratio
#else
#define		VISC_RATIO	1.0 //1.0
#endif

#define		C_CURV		1.0
#define		T_TENS		1.e-3
#define		C_WALL		1.e-3
#define		C_GRAV		1.0

#define		KAPPA		0.01
#define		CAPSULE
//#define		STRESSFREE_SPHERE //use sphere of surface area 4\pi\tau^{-2/3} as the stress-free configuration for the shear elasticity
#define		SHEAR_MU	0.75

//#define		EXTENSIBLE
//#define		SKALAK
#define		SKALAK_C	0.5
#define		SHEAR_E2	0.45 //inverse for maximum distortion

#define		CAPSULE_SWIMMER

#define		T_REMESH	100         // in units 1/gamma_dot
#define		T_STRESS	100	//number of timesteps between writing the stress to stress.dat
#define         NSTEP           500000
#define         NSAVE           1000 //number of timesteps between saves
#define         NPRINT          1000 //number of timesteps between writing the position and velocity to vm.dat
#define         NSHOW           10000 /* Only used to test zero force and zero torque */
#define         NSTREAM         1000  //number of timesteps between writing to stream.dat 

#define		UNSTIFFENER	1.0
#define         DT		1.256637e-3 //(2.e-3/C_CURV) //time step set to 1.256637e-3 so that after 100 steps on vm.dat or 1000 steps on stress.dat, we will have exactly 1 period

// geometry

#define			REF16

//#define NELL_3   //if you want spherical mesh, use Nell_3


#define		NMEM		1282 //number of points (2+5*(NROWS<<(2*NELL)))
#define		NTRIANG		2560 //number of triangles (10*(NROWS<<(2*NELL)))
#define		NELL		3  //number of refinements
#define		NROWS		4  //sets the number of points in cylindrical part of the initial configuration NROWS>1*/ //NMEM=5*NROWS<<(2*NELL)+2// Np=(NROWS-2)<<NELL
//#define		OBLATE	//start with oblate shape
#define		NLONG		24 //60
#define		NLAT		31 //31

#ifdef NELL_0
#define		NELL		0
#define		NROWS		2
#define		NMEM		12
#define		NTRIANG		20
#endif

#ifdef NELL_1
#define		NELL		1
#define		NROWS		2
#define		NMEM		42
#define		NTRIANG		80
#endif

#ifdef NELL_2
#define		NELL		2
#define		NROWS		2
#define		NMEM		162
#define		NTRIANG	320
#endif

#ifdef NELL_3
#define		NELL		3
#define		NROWS		2
#define		NMEM		642
#define		NTRIANG	1280
#endif

#ifdef NELL_4
#define		NELL		4
#define		NROWS		2
#define		NMEM		2562
#define		NTRIANG	5120
#endif

#ifdef NELL_5
#define		NELL		5
#define		NROWS		2
#define		NMEM		10242
#define		NTRIANG	20480
#endif

#ifdef		REF7
#define		NSLA	19
#define		NMEM2		(NMEM-2)*7+2
#define		NTRIANG2	NTRIANG*7
#endif

#ifdef		REF16
#define		NSLA	37
#define		NSLA2	19
#define		NMEM2		(NMEM-2)*16+2
#define		NTRIANG2	NTRIANG*16
#define		NSLA_T 16
#endif

// eventual wall

#define		NX		10
#define		NY		10
#define		XWALL		0.0
#define		YWALL		0.0
#define		ZWALL		-2.0
#define		LX		2.0
#define		LY		2.0
#define		NWALL		(NX*NY)

#define		DX0		(0.05*RAD)
#define		AA		0.34//0.36

#define		XPOS		0.0
#define		YPOS		0.0//(2.0*RAD)
#define		ZPOS		0.0


#define 	NFIXED		8 //(NWALL/2)
#define	DOPIL
//#define  NO_MIGRATION
//#define  MESHTT
//#define	truett2
//#define	TTAREA 1000.0
//#define	TTAREA2 0.0
#define TIMESTEP2
#define DRMAX 1000.01 //limits displacement per time step
#define ADVECT_MUL 0.1 //multiplier for mesh advection
//limits of area changes per time step
#define MAX_AREA_CHANGE 1.0e-3
#define MAX_AREA_CHANGE2 1.0e-1
#define EPMAX 1.0e3
#define INFO_STRING "Shear flow, Ca=10\n" // a string to add to the !info.txt file
#define MIGRATION_MULTIPLIER 1.0
//#define PRINTSTUFF //print information to stdout

//modified Green's functions
//#define INTERACTION // modified Green function for two vesicles in shear flow
//#define WALL //modified Green function for a wall


//move the vesicle after generating the configuration
#define INITIAL_X0 0.0
#define INITIAL_Y0 0.0
#define INITIAL_Z0 0.0

//move the vesicle after reading the configuration
#define SHIFT_X0 0.0
#define SHIFT_Y0 0.0
#define SHIFT_Z0 0.0

//imposed flow
#define XFLOW 0.0
//#define XFLOW 4.0*r.y
#define YFLOW 0.0
#define ZFLOW 0.0

/*#define F20 (-0.26924635515704884222)
#define F30 (0.25364902239229188366)
#define F40 (0.068003244329969622672)*/
/*
#define F20 0.0
#define F40 0.0
#define F30 0.0 

*/

#define F20 8.00*cos(0.05*time0)
#define F40 0.0
#define F30 8.00*sin(-0.05*time0)


//#define F30 0.0
//#define F20 2.0
//#define F32 0.0
//#define F22 2.0
#define Fx22 0.0
//#define F20 1.0
//#define F30 0.0

//imposed flow
/*#define XFLOW 10.0*cos(10.0*time0)*(2.0*r.x*r.x+r.y*r.y+r.z*r.z)/(sqrt(r.x*r.x+r.y*r.y+r.z*r.z)*(r.x*r.x+r.y*r.y+r.z*r.z))
#define YFLOW 10.0*cos(10.0*time0)*r.x*r.y/(sqrt(r.x*r.x+r.y*r.y+r.z*r.z)*(r.x*r.x+r.y*r.y+r.z*r.z))
#define ZFLOW 10.0*cos(10.0*time0)*r.x*r.z/(sqrt(r.x*r.x+r.y*r.y+r.z*r.z)*(r.x*r.x+r.y*r.y+r.z*r.z))
*/

//integration settings
#define SINGULARITY_TREATMENT
#define MU1	0.5
#define MU2	0.5
//cut off distance
#define r_co 0.5

#define W_DEF (4.0-3.0*rho)*rho*rho*rho
#define W1_DEF 12.0*rho*rho*(1.0-rho)*r_co1

#define NEW_ADVECT
//#define W_DEF 0.0
//#define W1_DEF 0.0
//#define W_DEF (3.0-2.0*rho)*rho*rho
//#define W1_DEF 6.0*rho*(1.0-rho)*r_co1
//#define W_DEF (2.0-rho)*rho
//#define W1_DEF 2.0*(1.0-rho)*r_co1

//#define STRETCH_EXPERIMENT
//#define ZMAX 23
//#define ZMIN 29
//#define PULL_FORCE SCRIPT_PULL
//#define PULL_AREA 0.5
