#include <includes.h>

void free_space_green16(int triang_site[NTRIANG][3], int slaves[NMEM][NSLA], int Nslaves[NMEM], struct point3D r_mem[NMEM], struct point3D r_mem2[NMEM2], struct point3D v_mem[NMEM][4], struct point3D f_mem[NMEM2][4], struct point3D fdA[NMEM][4], struct point3D fdA2[NMEM2][4], double eta, double pp, double GxndA[NMEM][3][3], struct point3D v_mem_prev[NMEM2], int slaves2[NMEM][NSLA2], int Nslaves2[NMEM],double time0){

	int i,j,k,j1,i1,i0,j0;
	double fn,fGndA,dr1,drn,eta0,temp0,w,w1,drn1,r_maxtemp;
	struct point3D new_v5[NMEM], new_v6[NMEM], dr, fGxndA, fxn, vtemp, dr1ndA;

	double r_max[NMEM],rho,r_co1,r_co2;
#ifdef VISCOSITY_CONTRAST
	struct point3D new_v4[NMEM];
	double cst,eta1,eta2,dvdr;
	eta1=0.75*(pp-1.0)/PI;
	eta2=0.5*(pp-1.0);
	cst=2.0/(1.0+pp);
#endif
	eta0=1.0/(8.0*PI*eta);
	r_co1=1.0/r_co;
	r_co2=r_co*r_co;
	for(i=0;i<NMEM;i++){
		for(j=0;j<4;j++)v_mem[i][j].x=v_mem[i][j].y=v_mem[i][j].z=0.0;
		new_v5[i].x=new_v5[i].y=new_v5[i].z=0.0;
		new_v6[i].x=new_v6[i].y=new_v6[i].z=0.0;
		for(j=0;j<3;j++) for(k=0;k<3;k++) GxndA[i][j][k]=0.0;
#ifdef VISCOSITY_CONTRAST
		new_v4[i].x=new_v4[i].y=new_v4[i].z=0.0;
#endif
	}
	for(i=0;i<NMEM;i++){
		r_max[i]=0.0;
		for(j=0;j<Nslaves2[i];j++){
			vtemp.x=r_mem2[i].x-r_mem2[slaves2[i][j]].x;
			vtemp.y=r_mem2[i].y-r_mem2[slaves2[i][j]].y;
			vtemp.z=r_mem2[i].z-r_mem2[slaves2[i][j]].z;
			temp0=vtemp.x*vtemp.x+vtemp.y*vtemp.y+vtemp.z*vtemp.z;
			if(r_max[i]<temp0) r_max[i]=temp0;
		}
		r_max[i]=0.5*sqrt(r_max[i]);
	}
	for(i=0;i<NMEM;i++){
		r_maxtemp=r_max[i]+r_co;
		for(j=0;j<i;j++){
			dr.x=r_mem[i].x-r_mem[j].x;
			dr.y=r_mem[i].y-r_mem[j].y;
			dr.z=r_mem[i].z-r_mem[j].z;
			dr1=sqrt(dr.x*dr.x+dr.y*dr.y+dr.z*dr.z);
			if(dr1>r_maxtemp+r_max[j]+fabs(r_max[i]-r_max[j])){
				dr1=1.0/dr1;
				dr.x*=dr1;
				dr.y*=dr1;
				dr.z*=dr1;

#ifdef VISCOSITY_CONTRAST
				dvdr=((v_mem_prev[i].x-v_mem_prev[j].x)*dr.x+(v_mem_prev[i].y-v_mem_prev[j].y)*dr.y+(v_mem_prev[i].z-v_mem_prev[j].z)*dr.z)*dr1*dr1;
#endif
//calculating contribution of f[i] to v[j]
				temp0=fdA[i][1].x*dr.x+fdA[i][1].y*dr.y+fdA[i][1].z*dr.z;
				v_mem[j][1].x+=dr1*(fdA[i][1].x+dr.x*temp0);
				v_mem[j][1].y+=dr1*(fdA[i][1].y+dr.y*temp0);
				v_mem[j][1].z+=dr1*(fdA[i][1].z+dr.z*temp0);
				temp0=fdA[i][2].x*dr.x+fdA[i][2].y*dr.y+fdA[i][2].z*dr.z;
				v_mem[j][2].x+=dr1*(fdA[i][2].x+dr.x*temp0);
				v_mem[j][2].y+=dr1*(fdA[i][2].y+dr.y*temp0);
				v_mem[j][2].z+=dr1*(fdA[i][2].z+dr.z*temp0);
				temp0=fdA[i][3].x*dr.x+fdA[i][3].y*dr.y+fdA[i][3].z*dr.z;
				v_mem[j][3].x+=dr1*(fdA[i][3].x+dr.x*temp0);
				v_mem[j][3].y+=dr1*(fdA[i][3].y+dr.y*temp0);
				v_mem[j][3].z+=dr1*(fdA[i][3].z+dr.z*temp0);
/*				dr1ndA.x=dr1*fdA[i][0].x;
				dr1ndA.y=dr1*fdA[i][0].y;
				dr1ndA.z=dr1*fdA[i][0].z;
				new_v5[j].x+=dr1ndA.x;
				new_v5[j].y+=dr1ndA.y;
				new_v5[j].z+=dr1ndA.z;
				drn=dr.x*dr1ndA.x+dr.y*dr1ndA.y+dr.z*dr1ndA.z;
				v_mem[j][0].x+=dr.x*drn;
				v_mem[j][0].y+=dr.y*drn;
				v_mem[j][0].z+=dr.z*drn;
				vtemp.x=dr.y*dr1ndA.z-dr.z*dr1ndA.y;
				vtemp.y=dr.z*dr1ndA.x-dr.x*dr1ndA.z;
				vtemp.z=dr.x*dr1ndA.y-dr.y*dr1ndA.x;
				GxndA[j][0][0]+=dr.x*vtemp.x;
				GxndA[j][0][1]+=dr.x*vtemp.y;
				GxndA[j][0][2]+=dr.x*vtemp.z;
				GxndA[j][1][0]+=dr.y*vtemp.x;
				GxndA[j][1][1]+=dr.y*vtemp.y;
				GxndA[j][1][2]+=dr.y*vtemp.z;
				GxndA[j][2][0]+=dr.z*vtemp.x;
				GxndA[j][2][1]+=dr.z*vtemp.y;
				GxndA[j][2][2]+=dr.z*vtemp.z;*/
//calculating contribution of v[i] to v[j]
#ifdef VISCOSITY_CONTRAST
				drn=fdA[i][0].x*dr.x+fdA[i][0].y*dr.y+fdA[i][0].z*dr.z;
				drn*=dvdr;
				new_v4[j].x+=dr.x*drn;
				new_v4[j].y+=dr.y*drn;
				new_v4[j].z+=dr.z*drn;
#endif

//calculating contribution of f[j] to v[i]
				temp0=fdA[j][1].x*dr.x+fdA[j][1].y*dr.y+fdA[j][1].z*dr.z;
				v_mem[i][1].x+=dr1*(fdA[j][1].x+dr.x*temp0);
				v_mem[i][1].y+=dr1*(fdA[j][1].y+dr.y*temp0);
				v_mem[i][1].z+=dr1*(fdA[j][1].z+dr.z*temp0);
				temp0=fdA[j][2].x*dr.x+fdA[j][2].y*dr.y+fdA[j][2].z*dr.z;
				v_mem[i][2].x+=dr1*(fdA[j][2].x+dr.x*temp0);
				v_mem[i][2].y+=dr1*(fdA[j][2].y+dr.y*temp0);
				v_mem[i][2].z+=dr1*(fdA[j][2].z+dr.z*temp0);
				temp0=fdA[j][3].x*dr.x+fdA[j][3].y*dr.y+fdA[j][3].z*dr.z;
				v_mem[i][3].x+=dr1*(fdA[j][3].x+dr.x*temp0);
				v_mem[i][3].y+=dr1*(fdA[j][3].y+dr.y*temp0);
				v_mem[i][3].z+=dr1*(fdA[j][3].z+dr.z*temp0);
/*				dr1ndA.x=dr1*fdA[j][0].x;
				dr1ndA.y=dr1*fdA[j][0].y;
				dr1ndA.z=dr1*fdA[j][0].z;
				new_v5[i].x+=dr1ndA.x;
				new_v5[i].y+=dr1ndA.y;
				new_v5[i].z+=dr1ndA.z;
				drn=dr.x*dr1ndA.x+dr.y*dr1ndA.y+dr.z*dr1ndA.z;
				v_mem[i][0].x+=dr.x*drn;
				v_mem[i][0].y+=dr.y*drn;
				v_mem[i][0].z+=dr.z*drn;
				vtemp.x=dr.y*dr1ndA.z-dr.z*dr1ndA.y;
				vtemp.y=dr.z*dr1ndA.x-dr.x*dr1ndA.z;
				vtemp.z=dr.x*dr1ndA.y-dr.y*dr1ndA.x;
				GxndA[i][0][0]+=dr.x*vtemp.x;
				GxndA[i][0][1]+=dr.x*vtemp.y;
				GxndA[i][0][2]+=dr.x*vtemp.z;
				GxndA[i][1][0]+=dr.y*vtemp.x;
				GxndA[i][1][1]+=dr.y*vtemp.y;
				GxndA[i][1][2]+=dr.y*vtemp.z;
				GxndA[i][2][0]+=dr.z*vtemp.x;
				GxndA[i][2][1]+=dr.z*vtemp.y;
				GxndA[i][2][2]+=dr.z*vtemp.z;*/
//calculating contribution of v[j] to v[i]
#ifdef VISCOSITY_CONTRAST
				drn=fdA[j][0].x*dr.x+fdA[j][0].y*dr.y+fdA[j][0].z*dr.z;
				drn*=dvdr;
				new_v4[i].x+=dr.x*drn;
				new_v4[i].y+=dr.y*drn;
				new_v4[i].z+=dr.z*drn;
#endif
			}
			else {
				rho=dr1*r_co1;
				dr1=1.0/dr1;
				dr.x*=dr1;
				dr.y*=dr1;
				dr.z*=dr1;

#ifdef VISCOSITY_CONTRAST
				dvdr=((v_mem_prev[i].x-v_mem_prev[j].x)*dr.x+(v_mem_prev[i].y-v_mem_prev[j].y)*dr.y+(v_mem_prev[i].z-v_mem_prev[j].z)*dr.z)*dr1;
#endif
				if(rho<1.0){
					w=W_DEF;
					dr1*=w;
				}
#ifdef VISCOSITY_CONTRAST
				dvdr*=dr1;
#endif
//calculating contribution of f[i] to v[j]
				temp0=fdA[i][1].x*dr.x+fdA[i][1].y*dr.y+fdA[i][1].z*dr.z;
				v_mem[j][1].x+=dr1*(fdA[i][1].x+dr.x*temp0);
				v_mem[j][1].y+=dr1*(fdA[i][1].y+dr.y*temp0);
				v_mem[j][1].z+=dr1*(fdA[i][1].z+dr.z*temp0);
				temp0=fdA[i][2].x*dr.x+fdA[i][2].y*dr.y+fdA[i][2].z*dr.z;
				v_mem[j][2].x+=dr1*(fdA[i][2].x+dr.x*temp0);
				v_mem[j][2].y+=dr1*(fdA[i][2].y+dr.y*temp0);
				v_mem[j][2].z+=dr1*(fdA[i][2].z+dr.z*temp0);
				temp0=fdA[i][3].x*dr.x+fdA[i][3].y*dr.y+fdA[i][3].z*dr.z;
				v_mem[j][3].x+=dr1*(fdA[i][3].x+dr.x*temp0);
				v_mem[j][3].y+=dr1*(fdA[i][3].y+dr.y*temp0);
				v_mem[j][3].z+=dr1*(fdA[i][3].z+dr.z*temp0);
/*			dr1ndA.x=dr1*fdA[i][0].x;
			dr1ndA.y=dr1*fdA[i][0].y;
			dr1ndA.z=dr1*fdA[i][0].z;
			new_v5[j].x+=dr1ndA.x;
			new_v5[j].y+=dr1ndA.y;
			new_v5[j].z+=dr1ndA.z;
			drn=dr.x*dr1ndA.x+dr.y*dr1ndA.y+dr.z*dr1ndA.z;
			v_mem[j][0].x+=dr.x*drn;
			v_mem[j][0].y+=dr.y*drn;
			v_mem[j][0].z+=dr.z*drn;
			vtemp.x=dr.y*dr1ndA.z-dr.z*dr1ndA.y;
			vtemp.y=dr.z*dr1ndA.x-dr.x*dr1ndA.z;
			vtemp.z=dr.x*dr1ndA.y-dr.y*dr1ndA.x;
			GxndA[j][0][0]+=dr.x*vtemp.x;
			GxndA[j][0][1]+=dr.x*vtemp.y;
			GxndA[j][0][2]+=dr.x*vtemp.z;
			GxndA[j][1][0]+=dr.y*vtemp.x;
			GxndA[j][1][1]+=dr.y*vtemp.y;
			GxndA[j][1][2]+=dr.y*vtemp.z;
			GxndA[j][2][0]+=dr.z*vtemp.x;
			GxndA[j][2][1]+=dr.z*vtemp.y;
			GxndA[j][2][2]+=dr.z*vtemp.z;*/
//calculating contribution of v[i] to v[j]
#ifdef VISCOSITY_CONTRAST
				drn=fdA[i][0].x*dr.x+fdA[i][0].y*dr.y+fdA[i][0].z*dr.z;
				drn*=dvdr;
				new_v4[j].x+=dr.x*drn;
				new_v4[j].y+=dr.y*drn;
				new_v4[j].z+=dr.z*drn;
#endif

//calculating contribution of f[j] to v[i]
				temp0=fdA[j][1].x*dr.x+fdA[j][1].y*dr.y+fdA[j][1].z*dr.z;
				v_mem[i][1].x+=dr1*(fdA[j][1].x+dr.x*temp0);
				v_mem[i][1].y+=dr1*(fdA[j][1].y+dr.y*temp0);
				v_mem[i][1].z+=dr1*(fdA[j][1].z+dr.z*temp0);
				temp0=fdA[j][2].x*dr.x+fdA[j][2].y*dr.y+fdA[j][2].z*dr.z;
				v_mem[i][2].x+=dr1*(fdA[j][2].x+dr.x*temp0);
				v_mem[i][2].y+=dr1*(fdA[j][2].y+dr.y*temp0);
				v_mem[i][2].z+=dr1*(fdA[j][2].z+dr.z*temp0);
				temp0=fdA[j][3].x*dr.x+fdA[j][3].y*dr.y+fdA[j][3].z*dr.z;
				v_mem[i][3].x+=dr1*(fdA[j][3].x+dr.x*temp0);
				v_mem[i][3].y+=dr1*(fdA[j][3].y+dr.y*temp0);
				v_mem[i][3].z+=dr1*(fdA[j][3].z+dr.z*temp0);
/*			dr1ndA.x=dr1*fdA[j][0].x;
			dr1ndA.y=dr1*fdA[j][0].y;
			dr1ndA.z=dr1*fdA[j][0].z;
			new_v5[i].x+=dr1ndA.x;
			new_v5[i].y+=dr1ndA.y;
			new_v5[i].z+=dr1ndA.z;
			drn=dr.x*dr1ndA.x+dr.y*dr1ndA.y+dr.z*dr1ndA.z;
			v_mem[i][0].x+=dr.x*drn;
			v_mem[i][0].y+=dr.y*drn;
			v_mem[i][0].z+=dr.z*drn;
			vtemp.x=dr.y*dr1ndA.z-dr.z*dr1ndA.y;
			vtemp.y=dr.z*dr1ndA.x-dr.x*dr1ndA.z;
			vtemp.z=dr.x*dr1ndA.y-dr.y*dr1ndA.x;
			GxndA[i][0][0]+=dr.x*vtemp.x;
			GxndA[i][0][1]+=dr.x*vtemp.y;
			GxndA[i][0][2]+=dr.x*vtemp.z;
			GxndA[i][1][0]+=dr.y*vtemp.x;
			GxndA[i][1][1]+=dr.y*vtemp.y;
			GxndA[i][1][2]+=dr.y*vtemp.z;
			GxndA[i][2][0]+=dr.z*vtemp.x;
			GxndA[i][2][1]+=dr.z*vtemp.y;
			GxndA[i][2][2]+=dr.z*vtemp.z;*/
//calculating contribution of v[j] to v[i]
#ifdef VISCOSITY_CONTRAST
				drn=fdA[j][0].x*dr.x+fdA[j][0].y*dr.y+fdA[j][0].z*dr.z;
				drn*=dvdr;
				new_v4[i].x+=dr.x*drn;
				new_v4[i].y+=dr.y*drn;
				new_v4[i].z+=dr.z*drn;
#endif
				for(i1=0;i1<Nslaves2[i];i1++){
					i0=slaves2[i][i1];
					dr.x=r_mem[j].x-r_mem2[i0].x;
					dr.y=r_mem[j].y-r_mem2[i0].y;
					dr.z=r_mem[j].z-r_mem2[i0].z;
					dr1=dr.x*dr.x+dr.y*dr.y+dr.z*dr.z;
					if(dr1>r_co2) continue;
					dr1=sqrt(dr1);
					rho=dr1*r_co1;
					dr1=1.0/dr1;
					dr.x*=dr1;
					dr.y*=dr1;
					dr.z*=dr1;

#ifdef VISCOSITY_CONTRAST
					dvdr=((v_mem_prev[j].x-v_mem_prev[i0].x)*dr.x+(v_mem_prev[j].y-v_mem_prev[i0].y)*dr.y+(v_mem_prev[j].z-v_mem_prev[i0].z)*dr.z)*dr1;
#endif
					w=1.0-W_DEF;
					w1=W1_DEF;
					dr1*=w;
#ifdef VISCOSITY_CONTRAST
					dvdr*=dr1;
#endif
//calculating contribution of f2[i] to v[j]
					temp0=fdA2[i0][1].x*dr.x+fdA2[i0][1].y*dr.y+fdA2[i0][1].z*dr.z;
					v_mem[j][1].x+=dr1*(fdA2[i0][1].x+dr.x*temp0);
					v_mem[j][1].y+=dr1*(fdA2[i0][1].y+dr.y*temp0);
					v_mem[j][1].z+=dr1*(fdA2[i0][1].z+dr.z*temp0);
					temp0=fdA2[i0][2].x*dr.x+fdA2[i0][2].y*dr.y+fdA2[i0][2].z*dr.z;
					v_mem[j][2].x+=dr1*(fdA2[i0][2].x+dr.x*temp0);
					v_mem[j][2].y+=dr1*(fdA2[i0][2].y+dr.y*temp0);
					v_mem[j][2].z+=dr1*(fdA2[i0][2].z+dr.z*temp0);
					temp0=fdA2[i0][3].x*dr.x+fdA2[i0][3].y*dr.y+fdA2[i0][3].z*dr.z;
					v_mem[j][3].x+=dr1*(fdA2[i0][3].x+dr.x*temp0);
					v_mem[j][3].y+=dr1*(fdA2[i0][3].y+dr.y*temp0);
					v_mem[j][3].z+=dr1*(fdA2[i0][3].z+dr.z*temp0);
					dr1ndA.x=dr1*fdA2[i0][0].x;
					dr1ndA.y=dr1*fdA2[i0][0].y;
					dr1ndA.z=dr1*fdA2[i0][0].z;
					new_v5[j].x+=dr1ndA.x;
					new_v5[j].y+=dr1ndA.y;
					new_v5[j].z+=dr1ndA.z;
					new_v6[j].x+=w1*fdA2[i0][0].x;
					new_v6[j].y+=w1*fdA2[i0][0].y;
					new_v6[j].z+=w1*fdA2[i0][0].z;
					temp0=dr1+w1;
/*					drn=(dr.x*fdA2[i0][0].x+dr.y*fdA2[i0][0].y+dr.z*fdA2[i0][0].z)*temp0;
					v_mem[j][0].x+=dr.x*drn;
					v_mem[j][0].y+=dr.y*drn;
					v_mem[j][0].z+=dr.z*drn;*/
					vtemp.x=(dr.y*fdA2[i0][0].z-dr.z*fdA2[i0][0].y)*temp0;
					vtemp.y=(dr.z*fdA2[i0][0].x-dr.x*fdA2[i0][0].z)*temp0;
					vtemp.z=(dr.x*fdA2[i0][0].y-dr.y*fdA2[i0][0].x)*temp0;
					GxndA[j][0][0]+=dr.x*vtemp.x;
					GxndA[j][0][1]+=dr.x*vtemp.y;
					GxndA[j][0][2]+=dr.x*vtemp.z;
					GxndA[j][1][0]+=dr.y*vtemp.x;
					GxndA[j][1][1]+=dr.y*vtemp.y;
					GxndA[j][1][2]+=dr.y*vtemp.z;
					GxndA[j][2][0]+=dr.z*vtemp.x;
					GxndA[j][2][1]+=dr.z*vtemp.y;
//					GxndA[j][2][2]+=dr.z*vtemp.z;
//calculating contribution of v[i] to v[j]
#ifdef VISCOSITY_CONTRAST
					drn=fdA2[i0][0].x*dr.x+fdA2[i0][0].y*dr.y+fdA2[i0][0].z*dr.z;
					drn*=dvdr;
					new_v4[j].x+=dr.x*drn;
					new_v4[j].y+=dr.y*drn;
					new_v4[j].z+=dr.z*drn;
#endif
				}
				for(j1=0;j1<Nslaves2[j];j1++){
					j0=slaves2[j][j1];
					dr.x=r_mem[i].x-r_mem2[j0].x;
					dr.y=r_mem[i].y-r_mem2[j0].y;
					dr.z=r_mem[i].z-r_mem2[j0].z;
					dr1=dr.x*dr.x+dr.y*dr.y+dr.z*dr.z;
					if(dr1>r_co2) continue;
					dr1=sqrt(dr1);
					rho=dr1*r_co1;
					dr1=1.0/dr1;
					dr.x*=dr1;
					dr.y*=dr1;
					dr.z*=dr1;
	
#ifdef VISCOSITY_CONTRAST
					dvdr=((v_mem_prev[i].x-v_mem_prev[j0].x)*dr.x+(v_mem_prev[i].y-v_mem_prev[j0].y)*dr.y+(v_mem_prev[i].z-v_mem_prev[j0].z)*dr.z)*dr1;
#endif
					w=1.0-W_DEF;
					w1=W1_DEF;
					dr1*=w;
#ifdef VISCOSITY_CONTRAST
					dvdr*=dr1;
#endif
//calculating contribution of f2[j] to v[i]
					temp0=fdA2[j0][1].x*dr.x+fdA2[j0][1].y*dr.y+fdA2[j0][1].z*dr.z;
					v_mem[i][1].x+=dr1*(fdA2[j0][1].x+dr.x*temp0);
					v_mem[i][1].y+=dr1*(fdA2[j0][1].y+dr.y*temp0);
					v_mem[i][1].z+=dr1*(fdA2[j0][1].z+dr.z*temp0);
					temp0=fdA2[j0][2].x*dr.x+fdA2[j0][2].y*dr.y+fdA2[j0][2].z*dr.z;
					v_mem[i][2].x+=dr1*(fdA2[j0][2].x+dr.x*temp0);
					v_mem[i][2].y+=dr1*(fdA2[j0][2].y+dr.y*temp0);
					v_mem[i][2].z+=dr1*(fdA2[j0][2].z+dr.z*temp0);
					temp0=fdA2[j0][3].x*dr.x+fdA2[j0][3].y*dr.y+fdA2[j0][3].z*dr.z;
					v_mem[i][3].x+=dr1*(fdA2[j0][3].x+dr.x*temp0);
					v_mem[i][3].y+=dr1*(fdA2[j0][3].y+dr.y*temp0);
					v_mem[i][3].z+=dr1*(fdA2[j0][3].z+dr.z*temp0);
					dr1ndA.x=dr1*fdA2[j0][0].x;
					dr1ndA.y=dr1*fdA2[j0][0].y;
					dr1ndA.z=dr1*fdA2[j0][0].z;
					new_v5[i].x+=dr1ndA.x;
					new_v5[i].y+=dr1ndA.y;
					new_v5[i].z+=dr1ndA.z;
					new_v6[i].x+=w1*fdA2[j0][0].x;
					new_v6[i].y+=w1*fdA2[j0][0].y;
					new_v6[i].z+=w1*fdA2[j0][0].z;
					temp0=dr1+w1;
/*					drn=(dr.x*fdA2[j0][0].x+dr.y*fdA2[j0][0].y+dr.z*fdA2[j0][0].z)*temp0;
					v_mem[i][0].x+=dr.x*drn;
					v_mem[i][0].y+=dr.y*drn;
					v_mem[i][0].z+=dr.z*drn;*/
					vtemp.x=(dr.y*fdA2[j0][0].z-dr.z*fdA2[j0][0].y)*temp0;
					vtemp.y=(dr.z*fdA2[j0][0].x-dr.x*fdA2[j0][0].z)*temp0;
					vtemp.z=(dr.x*fdA2[j0][0].y-dr.y*fdA2[j0][0].x)*temp0;
					GxndA[i][0][0]+=dr.x*vtemp.x;
					GxndA[i][0][1]+=dr.x*vtemp.y;
					GxndA[i][0][2]+=dr.x*vtemp.z;
					GxndA[i][1][0]+=dr.y*vtemp.x;
					GxndA[i][1][1]+=dr.y*vtemp.y;
					GxndA[i][1][2]+=dr.y*vtemp.z;
					GxndA[i][2][0]+=dr.z*vtemp.x;
					GxndA[i][2][1]+=dr.z*vtemp.y;
//					GxndA[i][2][2]+=dr.z*vtemp.z;
//calculating contribution of v[j] to v[i]
#ifdef VISCOSITY_CONTRAST
					drn=fdA2[j0][0].x*dr.x+fdA2[j0][0].y*dr.y+fdA2[j0][0].z*dr.z;
					drn*=dvdr;
					new_v4[i].x+=dr.x*drn;
					new_v4[i].y+=dr.y*drn;
					new_v4[i].z+=dr.z*drn;
#endif
				}
			}
		}
		for(i1=1;i1<Nslaves2[i];i1++){
			j0=slaves2[i][i1];
			dr.x=r_mem[i].x-r_mem2[j0].x;
			dr.y=r_mem[i].y-r_mem2[j0].y;
			dr.z=r_mem[i].z-r_mem2[j0].z;
			dr1=dr.x*dr.x+dr.y*dr.y+dr.z*dr.z;
			if(dr1>r_co2) continue;
			dr1=sqrt(dr1);
			rho=dr1*r_co1;
			dr1=1.0/dr1;
			dr.x*=dr1;
			dr.y*=dr1;
			dr.z*=dr1;

#ifdef VISCOSITY_CONTRAST
			dvdr=((v_mem_prev[i].x-v_mem_prev[j0].x)*dr.x+(v_mem_prev[i].y-v_mem_prev[j0].y)*dr.y+(v_mem_prev[i].z-v_mem_prev[j0].z)*dr.z)*dr1;
#endif
			w=1.0-W_DEF;
			w1=W1_DEF;
			dr1*=w;
#ifdef VISCOSITY_CONTRAST
			dvdr*=dr1;
#endif
//calculating contribution of f2[i] to v[i]
			temp0=fdA2[j0][1].x*dr.x+fdA2[j0][1].y*dr.y+fdA2[j0][1].z*dr.z;
			v_mem[i][1].x+=dr1*(fdA2[j0][1].x+dr.x*temp0);
			v_mem[i][1].y+=dr1*(fdA2[j0][1].y+dr.y*temp0);
			v_mem[i][1].z+=dr1*(fdA2[j0][1].z+dr.z*temp0);
			temp0=fdA2[j0][2].x*dr.x+fdA2[j0][2].y*dr.y+fdA2[j0][2].z*dr.z;
			v_mem[i][2].x+=dr1*(fdA2[j0][2].x+dr.x*temp0);
			v_mem[i][2].y+=dr1*(fdA2[j0][2].y+dr.y*temp0);
			v_mem[i][2].z+=dr1*(fdA2[j0][2].z+dr.z*temp0);
			temp0=fdA2[j0][3].x*dr.x+fdA2[j0][3].y*dr.y+fdA2[j0][3].z*dr.z;
			v_mem[i][3].x+=dr1*(fdA2[j0][3].x+dr.x*temp0);
			v_mem[i][3].y+=dr1*(fdA2[j0][3].y+dr.y*temp0);
			v_mem[i][3].z+=dr1*(fdA2[j0][3].z+dr.z*temp0);
			dr1ndA.x=dr1*fdA2[j0][0].x;
			dr1ndA.y=dr1*fdA2[j0][0].y;
			dr1ndA.z=dr1*fdA2[j0][0].z;
			new_v5[i].x+=dr1ndA.x;
			new_v5[i].y+=dr1ndA.y;
			new_v5[i].z+=dr1ndA.z;
			new_v6[i].x+=w1*fdA2[j0][0].x;
			new_v6[i].y+=w1*fdA2[j0][0].y;
			new_v6[i].z+=w1*fdA2[j0][0].z;
			temp0=dr1+w1;
/*			drn=(dr.x*fdA2[j0][0].x+dr.y*fdA2[j0][0].y+dr.z*fdA2[j0][0].z)*temp0;
			v_mem[i][0].x+=dr.x*drn;
			v_mem[i][0].y+=dr.y*drn;
			v_mem[i][0].z+=dr.z*drn;*/
			vtemp.x=(dr.y*fdA2[j0][0].z-dr.z*fdA2[j0][0].y)*temp0;
			vtemp.y=(dr.z*fdA2[j0][0].x-dr.x*fdA2[j0][0].z)*temp0;
			vtemp.z=(dr.x*fdA2[j0][0].y-dr.y*fdA2[j0][0].x)*temp0;
			GxndA[i][0][0]+=dr.x*vtemp.x;
			GxndA[i][0][1]+=dr.x*vtemp.y;
			GxndA[i][0][2]+=dr.x*vtemp.z;
			GxndA[i][1][0]+=dr.y*vtemp.x;
			GxndA[i][1][1]+=dr.y*vtemp.y;
			GxndA[i][1][2]+=dr.y*vtemp.z;
			GxndA[i][2][0]+=dr.z*vtemp.x;
			GxndA[i][2][1]+=dr.z*vtemp.y;
//			GxndA[i][2][2]+=dr.z*vtemp.z;
//calculating contribution of v[i] to v[j]
#ifdef VISCOSITY_CONTRAST
			drn=fdA2[j0][0].x*dr.x+fdA2[j0][0].y*dr.y+fdA2[j0][0].z*dr.z;
			drn*=dvdr;
			new_v4[i].x+=dr.x*drn;
			new_v4[i].y+=dr.y*drn;
			new_v4[i].z+=dr.z*drn;
#endif
		}
	}
	for(i=0;i<NMEM;i++){
		v_mem[i][0].x=GxndA[i][1][2]-GxndA[i][2][1]+2.0*new_v5[i].x;
		v_mem[i][0].y=GxndA[i][2][0]-GxndA[i][0][2]+2.0*new_v5[i].y;
		v_mem[i][0].z=GxndA[i][0][1]-GxndA[i][1][0]+2.0*new_v5[i].z;
		GxndA[i][0][1]+=new_v5[i].z-2.0*v_mem[i][0].z;
		GxndA[i][1][2]+=new_v5[i].x-2.0*v_mem[i][0].x;
		GxndA[i][2][0]+=new_v5[i].y-2.0*v_mem[i][0].y;
		GxndA[i][1][0]-=new_v5[i].z-2.0*v_mem[i][0].z;
		GxndA[i][2][1]-=new_v5[i].x-2.0*v_mem[i][0].x;
		GxndA[i][0][2]-=new_v5[i].y-2.0*v_mem[i][0].y;
		GxndA[i][2][2]=-(GxndA[i][0][0]+GxndA[i][1][1]);
	}
	for(i=0;i<NMEM;i++) {
//first velocity
		fn=f_mem[i][1].x*f_mem[i][0].x+f_mem[i][1].y*f_mem[i][0].y+f_mem[i][1].z*f_mem[i][0].z;
		fGndA=f_mem[i][1].x*v_mem[i][0].x+f_mem[i][1].y*v_mem[i][0].y+f_mem[i][1].z*v_mem[i][0].z;
		fGxndA.x=f_mem[i][1].x*GxndA[i][0][0]+f_mem[i][1].y*GxndA[i][1][0]+f_mem[i][1].z*GxndA[i][2][0];
		fGxndA.y=f_mem[i][1].x*GxndA[i][0][1]+f_mem[i][1].y*GxndA[i][1][1]+f_mem[i][1].z*GxndA[i][2][1];
		fGxndA.z=f_mem[i][1].x*GxndA[i][0][2]+f_mem[i][1].y*GxndA[i][1][2]+f_mem[i][1].z*GxndA[i][2][2];
		fxn.x=f_mem[i][1].y*f_mem[i][0].z-f_mem[i][1].z*f_mem[i][0].y;
		fxn.y=f_mem[i][1].z*f_mem[i][0].x-f_mem[i][1].x*f_mem[i][0].z;
		fxn.z=f_mem[i][1].x*f_mem[i][0].y-f_mem[i][1].y*f_mem[i][0].x;
#ifdef VISCOSITY_CONTRAST
		temp0=fxn.x*GxndA[i][0][0]+fxn.y*GxndA[i][0][1]+fxn.z*GxndA[i][0][2];
		v_mem[i][1].x=cst*(eta0*(v_mem[i][1].x-MU1*(fGndA*f_mem[i][0].x+f_mem[i][0].y*fGxndA.z-f_mem[i][0].z*fGxndA.y)-MU2*(fn*v_mem[i][0].x+temp0))+eta1*new_v4[i].x+eta2*v_mem_prev[i].x+xflow(r_mem[i],time0));
		temp0=fxn.x*GxndA[i][1][0]+fxn.y*GxndA[i][1][1]+fxn.z*GxndA[i][1][2];
		v_mem[i][1].y=cst*(eta0*(v_mem[i][1].y-MU1*(fGndA*f_mem[i][0].y+f_mem[i][0].z*fGxndA.x-f_mem[i][0].x*fGxndA.z)-MU2*(fn*v_mem[i][0].y+temp0))+eta1*new_v4[i].y+eta2*v_mem_prev[i].y+yflow(r_mem[i],time0));
		temp0=fxn.x*GxndA[i][2][0]+fxn.y*GxndA[i][2][1]+fxn.z*GxndA[i][2][2];
		v_mem[i][1].z=cst*(eta0*(v_mem[i][1].z-MU1*(fGndA*f_mem[i][0].z+f_mem[i][0].x*fGxndA.y-f_mem[i][0].y*fGxndA.x)-MU2*(fn*v_mem[i][0].z+temp0))+eta1*new_v4[i].z+eta2*v_mem_prev[i].z+zflow(r_mem[i],time0));
#else
		temp0=fxn.x*GxndA[i][0][0]+fxn.y*GxndA[i][0][1]+fxn.z*GxndA[i][0][2];
		v_mem[i][1].x=eta0*(v_mem[i][1].x-MU1*(fGndA*f_mem[i][0].x+f_mem[i][0].y*fGxndA.z-f_mem[i][0].z*fGxndA.y)-MU2*(fn*v_mem[i][0].x+temp0))+xflow(r_mem[i],time0);
		temp0=fxn.x*GxndA[i][1][0]+fxn.y*GxndA[i][1][1]+fxn.z*GxndA[i][1][2];
		v_mem[i][1].y=eta0*(v_mem[i][1].y-MU1*(fGndA*f_mem[i][0].y+f_mem[i][0].z*fGxndA.x-f_mem[i][0].x*fGxndA.z)-MU2*(fn*v_mem[i][0].y+temp0))+yflow(r_mem[i],time0);
		temp0=fxn.x*GxndA[i][2][0]+fxn.y*GxndA[i][2][1]+fxn.z*GxndA[i][2][2];
		v_mem[i][1].z=eta0*(v_mem[i][1].z-MU1*(fGndA*f_mem[i][0].z+f_mem[i][0].x*fGxndA.y-f_mem[i][0].y*fGxndA.x)-MU2*(fn*v_mem[i][0].z+temp0))+zflow(r_mem[i],time0);
#endif
//second velocity
		fn=f_mem[i][2].x*f_mem[i][0].x+f_mem[i][2].y*f_mem[i][0].y+f_mem[i][2].z*f_mem[i][0].z;
		fGndA=f_mem[i][2].x*v_mem[i][0].x+f_mem[i][2].y*v_mem[i][0].y+f_mem[i][2].z*v_mem[i][0].z;
		fGxndA.x=f_mem[i][2].x*GxndA[i][0][0]+f_mem[i][2].y*GxndA[i][1][0]+f_mem[i][2].z*GxndA[i][2][0];
		fGxndA.y=f_mem[i][2].x*GxndA[i][0][1]+f_mem[i][2].y*GxndA[i][1][1]+f_mem[i][2].z*GxndA[i][2][1];
		fGxndA.z=f_mem[i][2].x*GxndA[i][0][2]+f_mem[i][2].y*GxndA[i][1][2]+f_mem[i][2].z*GxndA[i][2][2];
		fxn.x=f_mem[i][2].y*f_mem[i][0].z-f_mem[i][2].z*f_mem[i][0].y;
		fxn.y=f_mem[i][2].z*f_mem[i][0].x-f_mem[i][2].x*f_mem[i][0].z;
		fxn.z=f_mem[i][2].x*f_mem[i][0].y-f_mem[i][2].y*f_mem[i][0].x;
#ifdef VISCOSITY_CONTRAST
		temp0=fxn.x*GxndA[i][0][0]+fxn.y*GxndA[i][0][1]+fxn.z*GxndA[i][0][2];
		v_mem[i][2].x=cst*eta0*(v_mem[i][2].x-MU1*(fGndA*f_mem[i][0].x+f_mem[i][0].y*fGxndA.z-f_mem[i][0].z*fGxndA.y)-MU2*(fn*v_mem[i][0].x+temp0));
		temp0=fxn.x*GxndA[i][1][0]+fxn.y*GxndA[i][1][1]+fxn.z*GxndA[i][1][2];
		v_mem[i][2].y=cst*eta0*(v_mem[i][2].y-MU1*(fGndA*f_mem[i][0].y+f_mem[i][0].z*fGxndA.x-f_mem[i][0].x*fGxndA.z)-MU2*(fn*v_mem[i][0].y+temp0));
		temp0=fxn.x*GxndA[i][2][0]+fxn.y*GxndA[i][2][1]+fxn.z*GxndA[i][2][2];
		v_mem[i][2].z=cst*eta0*(v_mem[i][2].z-MU1*(fGndA*f_mem[i][0].z+f_mem[i][0].x*fGxndA.y-f_mem[i][0].y*fGxndA.x)-MU2*(fn*v_mem[i][0].z+temp0));
#else
		temp0=fxn.x*GxndA[i][0][0]+fxn.y*GxndA[i][0][1]+fxn.z*GxndA[i][0][2];
		v_mem[i][2].x=eta0*(v_mem[i][2].x-MU1*(fGndA*f_mem[i][0].x+f_mem[i][0].y*fGxndA.z-f_mem[i][0].z*fGxndA.y)-MU2*(fn*v_mem[i][0].x+temp0));
		temp0=fxn.x*GxndA[i][1][0]+fxn.y*GxndA[i][1][1]+fxn.z*GxndA[i][1][2];
		v_mem[i][2].y=eta0*(v_mem[i][2].y-MU1*(fGndA*f_mem[i][0].y+f_mem[i][0].z*fGxndA.x-f_mem[i][0].x*fGxndA.z)-MU2*(fn*v_mem[i][0].y+temp0));
		temp0=fxn.x*GxndA[i][2][0]+fxn.y*GxndA[i][2][1]+fxn.z*GxndA[i][2][2];
		v_mem[i][2].z=eta0*(v_mem[i][2].z-MU1*(fGndA*f_mem[i][0].z+f_mem[i][0].x*fGxndA.y-f_mem[i][0].y*fGxndA.x)-MU2*(fn*v_mem[i][0].z+temp0));
#endif
//third velocity
		fn=f_mem[i][3].x*f_mem[i][0].x+f_mem[i][3].y*f_mem[i][0].y+f_mem[i][3].z*f_mem[i][0].z;
		fGndA=f_mem[i][3].x*v_mem[i][0].x+f_mem[i][3].y*v_mem[i][0].y+f_mem[i][3].z*v_mem[i][0].z;
		fGxndA.x=f_mem[i][3].x*GxndA[i][0][0]+f_mem[i][3].y*GxndA[i][1][0]+f_mem[i][3].z*GxndA[i][2][0];
		fGxndA.y=f_mem[i][3].x*GxndA[i][0][1]+f_mem[i][3].y*GxndA[i][1][1]+f_mem[i][3].z*GxndA[i][2][1];
		fGxndA.z=f_mem[i][3].x*GxndA[i][0][2]+f_mem[i][3].y*GxndA[i][1][2]+f_mem[i][3].z*GxndA[i][2][2];
		fxn.x=f_mem[i][3].y*f_mem[i][0].z-f_mem[i][3].z*f_mem[i][0].y;
		fxn.y=f_mem[i][3].z*f_mem[i][0].x-f_mem[i][3].x*f_mem[i][0].z;
		fxn.z=f_mem[i][3].x*f_mem[i][0].y-f_mem[i][3].y*f_mem[i][0].x;
#ifdef VISCOSITY_CONTRAST
		temp0=fxn.x*GxndA[i][0][0]+fxn.y*GxndA[i][0][1]+fxn.z*GxndA[i][0][2];
		v_mem[i][3].x=cst*eta0*(v_mem[i][3].x-MU1*(fGndA*f_mem[i][0].x+f_mem[i][0].y*fGxndA.z-f_mem[i][0].z*fGxndA.y)-MU2*(fn*v_mem[i][0].x+temp0));
		temp0=fxn.x*GxndA[i][1][0]+fxn.y*GxndA[i][1][1]+fxn.z*GxndA[i][1][2];
		v_mem[i][3].y=cst*eta0*(v_mem[i][3].y-MU1*(fGndA*f_mem[i][0].y+f_mem[i][0].z*fGxndA.x-f_mem[i][0].x*fGxndA.z)-MU2*(fn*v_mem[i][0].y+temp0));
		temp0=fxn.x*GxndA[i][2][0]+fxn.y*GxndA[i][2][1]+fxn.z*GxndA[i][2][2];
		v_mem[i][3].z=cst*eta0*(v_mem[i][3].z-MU1*(fGndA*f_mem[i][0].z+f_mem[i][0].x*fGxndA.y-f_mem[i][0].y*fGxndA.x)-MU2*(fn*v_mem[i][0].z+temp0));
#else
		temp0=fxn.x*GxndA[i][0][0]+fxn.y*GxndA[i][0][1]+fxn.z*GxndA[i][0][2];
		v_mem[i][3].x=eta0*(v_mem[i][3].x-MU1*(fGndA*f_mem[i][0].x+f_mem[i][0].y*fGxndA.z-f_mem[i][0].z*fGxndA.y)-MU2*(fn*v_mem[i][0].x+temp0));
		temp0=fxn.x*GxndA[i][1][0]+fxn.y*GxndA[i][1][1]+fxn.z*GxndA[i][1][2];
		v_mem[i][3].y=eta0*(v_mem[i][3].y-MU1*(fGndA*f_mem[i][0].y+f_mem[i][0].z*fGxndA.x-f_mem[i][0].x*fGxndA.z)-MU2*(fn*v_mem[i][0].y+temp0));
		temp0=fxn.x*GxndA[i][2][0]+fxn.y*GxndA[i][2][1]+fxn.z*GxndA[i][2][2];
		v_mem[i][3].z=eta0*(v_mem[i][3].z-MU1*(fGndA*f_mem[i][0].z+f_mem[i][0].x*fGxndA.y-f_mem[i][0].y*fGxndA.x)-MU2*(fn*v_mem[i][0].z+temp0));
#endif


	}
}

void probe_green16(struct point3D r0, struct point3D* v0, struct point3D r_mem[NMEM], struct point3D r_mem2[NMEM2], struct point3D fdA[NMEM][4], struct point3D fdA2[NMEM2][4], double eta, double pp, struct point3D v_mem_prev[NMEM2],double time0){

	int i,j,k,j1,i1,i0,j0;
	double dr1,drn,eta0,temp0,w,w1,drn1;
	struct point3D dr, vtemp;

	double rho,r_co1,r_co2;
#ifdef VISCOSITY_CONTRAST
	struct point3D new_v4;
	double cst,eta1,eta2,dvdr;
	eta1=0.75*(pp-1.0)/PI;
	eta2=0.5*(pp-1.0);
	cst=2.0/(1.0+pp);
#endif
	eta0=1.0/(8.0*PI*eta);
	r_co1=1.0/r_co;
	r_co2=r_co*r_co;
	v0->x=v0->y=v0->z=0.0;
	
	for(i=0;i<NMEM;i++){
		dr.x=r_mem[i].x-r0.x;
		dr.y=r_mem[i].y-r0.y;
		dr.z=r_mem[i].z-r0.z;
		dr1=sqrt(dr.x*dr.x+dr.y*dr.y+dr.z*dr.z);
		if(dr1>r_co){
			dr1=1.0/dr1;
			dr.x*=dr1;
			dr.y*=dr1;
			dr.z*=dr1;

#ifdef VISCOSITY_CONTRAST
			dvdr=(v_mem_prev[i].x*dr.x+v_mem_prev[i].y*dr.y+v_mem_prev[i].z*dr.z)*dr1*dr1;
#endif
//calculating contribution of f[i] to v[j]
			temp0=fdA[i][1].x*dr.x+fdA[i][1].y*dr.y+fdA[i][1].z*dr.z;
			v0->x+=dr1*(fdA[i][1].x+dr.x*temp0);
			v0->y+=dr1*(fdA[i][1].y+dr.y*temp0);
			v0->z+=dr1*(fdA[i][1].z+dr.z*temp0);
//calculating contribution of v[i] to v[j]
#ifdef VISCOSITY_CONTRAST
			drn=fdA[i][0].x*dr.x+fdA[i][0].y*dr.y+fdA[i][0].z*dr.z;
			drn*=dvdr;
			new_v4.x+=dr.x*drn;
			new_v4.y+=dr.y*drn;
			new_v4.z+=dr.z*drn;
#endif
		}
		else {
			rho=dr1*r_co1;
			dr1=1.0/dr1;
			dr.x*=dr1;
			dr.y*=dr1;
			dr.z*=dr1;

#ifdef VISCOSITY_CONTRAST
			dvdr=(v_mem_prev[i].x*dr.x+v_mem_prev[i].y*dr.y+v_mem_prev[i].z*dr.z)*dr1;
#endif
			w=W_DEF;
			dr1*=w;
#ifdef VISCOSITY_CONTRAST
			dvdr*=dr1;
#endif
//calculating contribution of f[i] to v[j]
			temp0=fdA[i][1].x*dr.x+fdA[i][1].y*dr.y+fdA[i][1].z*dr.z;
			v0->x+=dr1*(fdA[i][1].x+dr.x*temp0);
			v0->y+=dr1*(fdA[i][1].y+dr.y*temp0);
			v0->z+=dr1*(fdA[i][1].z+dr.z*temp0);
//calculating contribution of v[i] to v[j]
#ifdef VISCOSITY_CONTRAST
			drn=fdA[i][0].x*dr.x+fdA[i][0].y*dr.y+fdA[i][0].z*dr.z;
			drn*=dvdr;
			new_v4.x+=dr.x*drn;
			new_v4.y+=dr.y*drn;
			new_v4.z+=dr.z*drn;
#endif
		}
	}
	for(i=0;i<NMEM2;i++){
		dr.x=r_mem2[i].x-r0.x;
		dr.y=r_mem2[i].y-r0.y;
		dr.z=r_mem2[i].z-r0.z;
		dr1=sqrt(dr.x*dr.x+dr.y*dr.y+dr.z*dr.z);
		if(dr1<r_co){
			rho=dr1*r_co1;
			dr1=1.0/dr1;
			dr.x*=dr1;
			dr.y*=dr1;
			dr.z*=dr1;

#ifdef VISCOSITY_CONTRAST
			dvdr=(v_mem_prev[i].x*dr.x+v_mem_prev[i].y*dr.y+v_mem_prev[i].z*dr.z)*dr1;
#endif
			w=1.0-W_DEF;
			dr1*=w;
#ifdef VISCOSITY_CONTRAST
			dvdr*=dr1;
#endif
//calculating contribution of f[i] to v[j]
			temp0=fdA2[i][1].x*dr.x+fdA2[i][1].y*dr.y+fdA2[i][1].z*dr.z;
			v0->x+=dr1*(fdA2[i][1].x+dr.x*temp0);
			v0->y+=dr1*(fdA2[i][1].y+dr.y*temp0);
			v0->z+=dr1*(fdA2[i][1].z+dr.z*temp0);
//calculating contribution of v[i] to v[j]
#ifdef VISCOSITY_CONTRAST
			drn=fdA2[i][0].x*dr.x+fdA2[i][0].y*dr.y+fdA2[i][0].z*dr.z;
			drn*=dvdr;
			new_v4.x+=dr.x*drn;
			new_v4.y+=dr.y*drn;
			new_v4.z+=dr.z*drn;
#endif
		}
	}

//first velocity
#ifdef VISCOSITY_CONTRAST
	v0->x=cst*(eta0*v0->x+eta1*new_v4.x+xflow(r0,time0));
	v0->y=cst*(eta0*v0->y+eta1*new_v4.y+yflow(r0,time0));
	v0->z=cst*(eta0*v0->z+eta1*new_v4.z+zflow(r0,time0));
#else
	v0->x=eta0*v0->x+xflow(r0,time0);
	v0->y=eta0*v0->y+yflow(r0,time0);
	v0->z=eta0*v0->z+zflow(r0,time0);
#endif
}

void free_space_green_fast(int triang_site[NTRIANG][3], int slaves[NMEM][NSLA], int Nslaves[NMEM], struct point3D r_mem[NMEM], struct point3D r_mem2[NMEM2], struct point3D v_mem[NMEM][4], struct point3D f_mem[NMEM2][4], struct point3D fdA[NMEM][4], struct point3D fdA2[NMEM2][4], double eta, double pp, double GxndA[NMEM][3][3], struct point3D v_mem_prev[NMEM2], int slaves2[NMEM][NSLA2], int Nslaves2[NMEM],double time0){

	int i,j,k,j1,i1,i0,j0;
	double fn,fGndA,dr1,drn,eta0,temp0,w,w1,drn1,r_maxtemp;
	struct point3D new_v5[NMEM], new_v6[NMEM], dr, fGxndA, fxn, vtemp, dr1ndA;

	double r_max[NMEM],rho,r_co1,r_co2;
#ifdef VISCOSITY_CONTRAST
	struct point3D new_v4[NMEM];
	double cst,eta1,eta2,dvdr;
	eta1=0.75*(pp-1.0)/PI;
	eta2=0.5*(pp-1.0);
	cst=2.0/(1.0+pp);
#endif
	eta0=1.0/(8.0*PI*eta);
	r_co1=1.0/r_co;
	r_co2=r_co*r_co;
	for(i=0;i<NMEM;i++){
		for(j=0;j<4;j++)v_mem[i][j].x=v_mem[i][j].y=v_mem[i][j].z=0.0;
		new_v5[i].x=new_v5[i].y=new_v5[i].z=0.0;
		new_v6[i].x=new_v6[i].y=new_v6[i].z=0.0;
		for(j=0;j<3;j++) for(k=0;k<3;k++) GxndA[i][j][k]=0.0;
#ifdef VISCOSITY_CONTRAST
		new_v4[i].x=new_v4[i].y=new_v4[i].z=0.0;
#endif
	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<i;j++){
			dr.x=r_mem[i].x-r_mem[j].x;
			dr.y=r_mem[i].y-r_mem[j].y;
			dr.z=r_mem[i].z-r_mem[j].z;
			dr1=sqrt(dr.x*dr.x+dr.y*dr.y+dr.z*dr.z);
			if(dr1>r_co){
				dr1=1.0/dr1;
				dr.x*=dr1;
				dr.y*=dr1;
				dr.z*=dr1;

#ifdef VISCOSITY_CONTRAST
				dvdr=((v_mem_prev[i].x-v_mem_prev[j].x)*dr.x+(v_mem_prev[i].y-v_mem_prev[j].y)*dr.y+(v_mem_prev[i].z-v_mem_prev[j].z)*dr.z)*dr1*dr1;
#endif
//calculating contribution of f[i] to v[j]
				temp0=fdA[i][1].x*dr.x+fdA[i][1].y*dr.y+fdA[i][1].z*dr.z;
				v_mem[j][1].x+=dr1*(fdA[i][1].x+dr.x*temp0);
				v_mem[j][1].y+=dr1*(fdA[i][1].y+dr.y*temp0);
				v_mem[j][1].z+=dr1*(fdA[i][1].z+dr.z*temp0);
				temp0=fdA[i][2].x*dr.x+fdA[i][2].y*dr.y+fdA[i][2].z*dr.z;
				v_mem[j][2].x+=dr1*(fdA[i][2].x+dr.x*temp0);
				v_mem[j][2].y+=dr1*(fdA[i][2].y+dr.y*temp0);
				v_mem[j][2].z+=dr1*(fdA[i][2].z+dr.z*temp0);
				temp0=fdA[i][3].x*dr.x+fdA[i][3].y*dr.y+fdA[i][3].z*dr.z;
				v_mem[j][3].x+=dr1*(fdA[i][3].x+dr.x*temp0);
				v_mem[j][3].y+=dr1*(fdA[i][3].y+dr.y*temp0);
				v_mem[j][3].z+=dr1*(fdA[i][3].z+dr.z*temp0);
//calculating contribution of v[i] to v[j]
#ifdef VISCOSITY_CONTRAST
				drn=fdA[i][0].x*dr.x+fdA[i][0].y*dr.y+fdA[i][0].z*dr.z;
				drn*=dvdr;
				new_v4[j].x+=dr.x*drn;
				new_v4[j].y+=dr.y*drn;
				new_v4[j].z+=dr.z*drn;
#endif

//calculating contribution of f[j] to v[i]
				temp0=fdA[j][1].x*dr.x+fdA[j][1].y*dr.y+fdA[j][1].z*dr.z;
				v_mem[i][1].x+=dr1*(fdA[j][1].x+dr.x*temp0);
				v_mem[i][1].y+=dr1*(fdA[j][1].y+dr.y*temp0);
				v_mem[i][1].z+=dr1*(fdA[j][1].z+dr.z*temp0);
				temp0=fdA[j][2].x*dr.x+fdA[j][2].y*dr.y+fdA[j][2].z*dr.z;
				v_mem[i][2].x+=dr1*(fdA[j][2].x+dr.x*temp0);
				v_mem[i][2].y+=dr1*(fdA[j][2].y+dr.y*temp0);
				v_mem[i][2].z+=dr1*(fdA[j][2].z+dr.z*temp0);
				temp0=fdA[j][3].x*dr.x+fdA[j][3].y*dr.y+fdA[j][3].z*dr.z;
				v_mem[i][3].x+=dr1*(fdA[j][3].x+dr.x*temp0);
				v_mem[i][3].y+=dr1*(fdA[j][3].y+dr.y*temp0);
				v_mem[i][3].z+=dr1*(fdA[j][3].z+dr.z*temp0);
//calculating contribution of v[j] to v[i]
#ifdef VISCOSITY_CONTRAST
				drn=fdA[j][0].x*dr.x+fdA[j][0].y*dr.y+fdA[j][0].z*dr.z;
				drn*=dvdr;
				new_v4[i].x+=dr.x*drn;
				new_v4[i].y+=dr.y*drn;
				new_v4[i].z+=dr.z*drn;
#endif
			}
			else {
				rho=dr1*r_co1;
				dr1=1.0/dr1;
				dr.x*=dr1;
				dr.y*=dr1;
				dr.z*=dr1;

#ifdef VISCOSITY_CONTRAST
				dvdr=((v_mem_prev[i].x-v_mem_prev[j].x)*dr.x+(v_mem_prev[i].y-v_mem_prev[j].y)*dr.y+(v_mem_prev[i].z-v_mem_prev[j].z)*dr.z)*dr1;
				dvdr*=dr1;
#endif
				w=1.0-W_DEF;
				w1=W1_DEF;

//calculating contribution of f[i] to v[j]
				temp0=fdA[i][1].x*dr.x+fdA[i][1].y*dr.y+fdA[i][1].z*dr.z;
				v_mem[j][1].x+=dr1*(fdA[i][1].x+dr.x*temp0);
				v_mem[j][1].y+=dr1*(fdA[i][1].y+dr.y*temp0);
				v_mem[j][1].z+=dr1*(fdA[i][1].z+dr.z*temp0);
				temp0=fdA[i][2].x*dr.x+fdA[i][2].y*dr.y+fdA[i][2].z*dr.z;
				v_mem[j][2].x+=dr1*(fdA[i][2].x+dr.x*temp0);
				v_mem[j][2].y+=dr1*(fdA[i][2].y+dr.y*temp0);
				v_mem[j][2].z+=dr1*(fdA[i][2].z+dr.z*temp0);
				temp0=fdA[i][3].x*dr.x+fdA[i][3].y*dr.y+fdA[i][3].z*dr.z;
				v_mem[j][3].x+=dr1*(fdA[i][3].x+dr.x*temp0);
				v_mem[j][3].y+=dr1*(fdA[i][3].y+dr.y*temp0);
				v_mem[j][3].z+=dr1*(fdA[i][3].z+dr.z*temp0);

//calculating contribution of v[i] to v[j]
#ifdef VISCOSITY_CONTRAST
				drn=fdA[i][0].x*dr.x+fdA[i][0].y*dr.y+fdA[i][0].z*dr.z;
				drn*=dvdr;
				new_v4[j].x+=dr.x*drn;
				new_v4[j].y+=dr.y*drn;
				new_v4[j].z+=dr.z*drn;
#endif

//calculating contribution of f[j] to v[i]
				temp0=fdA[j][1].x*dr.x+fdA[j][1].y*dr.y+fdA[j][1].z*dr.z;
				v_mem[i][1].x+=dr1*(fdA[j][1].x+dr.x*temp0);
				v_mem[i][1].y+=dr1*(fdA[j][1].y+dr.y*temp0);
				v_mem[i][1].z+=dr1*(fdA[j][1].z+dr.z*temp0);
				temp0=fdA[j][2].x*dr.x+fdA[j][2].y*dr.y+fdA[j][2].z*dr.z;
				v_mem[i][2].x+=dr1*(fdA[j][2].x+dr.x*temp0);
				v_mem[i][2].y+=dr1*(fdA[j][2].y+dr.y*temp0);
				v_mem[i][2].z+=dr1*(fdA[j][2].z+dr.z*temp0);
				temp0=fdA[j][3].x*dr.x+fdA[j][3].y*dr.y+fdA[j][3].z*dr.z;
				v_mem[i][3].x+=dr1*(fdA[j][3].x+dr.x*temp0);
				v_mem[i][3].y+=dr1*(fdA[j][3].y+dr.y*temp0);
				v_mem[i][3].z+=dr1*(fdA[j][3].z+dr.z*temp0);

//calculating contribution of v[j] to v[i]
#ifdef VISCOSITY_CONTRAST
				drn=fdA[j][0].x*dr.x+fdA[j][0].y*dr.y+fdA[j][0].z*dr.z;
				drn*=dvdr;
				new_v4[i].x+=dr.x*drn;
				new_v4[i].y+=dr.y*drn;
				new_v4[i].z+=dr.z*drn;
#endif

				dr1*=w;
				temp0=dr1+w1;

				dr1ndA.x=dr1*fdA[i][0].x;
				dr1ndA.y=dr1*fdA[i][0].y;
				dr1ndA.z=dr1*fdA[i][0].z;
				new_v5[j].x+=dr1ndA.x;
				new_v5[j].y+=dr1ndA.y;
				new_v5[j].z+=dr1ndA.z;
				new_v6[j].x+=w1*fdA[i][0].x;
				new_v6[j].y+=w1*fdA[i][0].y;
				new_v6[j].z+=w1*fdA[i][0].z;
				vtemp.x=(dr.y*fdA[i][0].z-dr.z*fdA[i][0].y)*temp0;
				vtemp.y=(dr.z*fdA[i][0].x-dr.x*fdA[i][0].z)*temp0;
				vtemp.z=(dr.x*fdA[i][0].y-dr.y*fdA[i][0].x)*temp0;
				GxndA[j][0][0]+=dr.x*vtemp.x;
				GxndA[j][0][1]+=dr.x*vtemp.y;
				GxndA[j][0][2]+=dr.x*vtemp.z;
				GxndA[j][1][0]+=dr.y*vtemp.x;
				GxndA[j][1][1]+=dr.y*vtemp.y;
				GxndA[j][1][2]+=dr.y*vtemp.z;
				GxndA[j][2][0]+=dr.z*vtemp.x;
				GxndA[j][2][1]+=dr.z*vtemp.y;

				dr1ndA.x=dr1*fdA[j][0].x;
				dr1ndA.y=dr1*fdA[j][0].y;
				dr1ndA.z=dr1*fdA[j][0].z;
				new_v5[i].x+=dr1ndA.x;
				new_v5[i].y+=dr1ndA.y;
				new_v5[i].z+=dr1ndA.z;
				new_v6[i].x+=w1*fdA[j][0].x;
				new_v6[i].y+=w1*fdA[j][0].y;
				new_v6[i].z+=w1*fdA[j][0].z;
				vtemp.x=(dr.y*fdA[j][0].z-dr.z*fdA[j][0].y)*temp0;
				vtemp.y=(dr.z*fdA[j][0].x-dr.x*fdA[j][0].z)*temp0;
				vtemp.z=(dr.x*fdA[j][0].y-dr.y*fdA[j][0].x)*temp0;
				GxndA[i][0][0]+=dr.x*vtemp.x;
				GxndA[i][0][1]+=dr.x*vtemp.y;
				GxndA[i][0][2]+=dr.x*vtemp.z;
				GxndA[i][1][0]+=dr.y*vtemp.x;
				GxndA[i][1][1]+=dr.y*vtemp.y;
				GxndA[i][1][2]+=dr.y*vtemp.z;
				GxndA[i][2][0]+=dr.z*vtemp.x;
				GxndA[i][2][1]+=dr.z*vtemp.y;
			}
		}
	}
	for(i=0;i<NMEM;i++){
		v_mem[i][0].x=GxndA[i][1][2]-GxndA[i][2][1]+2.0*new_v5[i].x;
		v_mem[i][0].y=GxndA[i][2][0]-GxndA[i][0][2]+2.0*new_v5[i].y;
		v_mem[i][0].z=GxndA[i][0][1]-GxndA[i][1][0]+2.0*new_v5[i].z;
		GxndA[i][0][1]+=new_v5[i].z-2.0*v_mem[i][0].z;
		GxndA[i][1][2]+=new_v5[i].x-2.0*v_mem[i][0].x;
		GxndA[i][2][0]+=new_v5[i].y-2.0*v_mem[i][0].y;
		GxndA[i][1][0]-=new_v5[i].z-2.0*v_mem[i][0].z;
		GxndA[i][2][1]-=new_v5[i].x-2.0*v_mem[i][0].x;
		GxndA[i][0][2]-=new_v5[i].y-2.0*v_mem[i][0].y;
		GxndA[i][2][2]=-(GxndA[i][0][0]+GxndA[i][1][1]);
	}
	for(i=0;i<NMEM;i++) {
//first velocity
		fn=f_mem[i][1].x*f_mem[i][0].x+f_mem[i][1].y*f_mem[i][0].y+f_mem[i][1].z*f_mem[i][0].z;
		fGndA=f_mem[i][1].x*v_mem[i][0].x+f_mem[i][1].y*v_mem[i][0].y+f_mem[i][1].z*v_mem[i][0].z;
		fGxndA.x=f_mem[i][1].x*GxndA[i][0][0]+f_mem[i][1].y*GxndA[i][1][0]+f_mem[i][1].z*GxndA[i][2][0];
		fGxndA.y=f_mem[i][1].x*GxndA[i][0][1]+f_mem[i][1].y*GxndA[i][1][1]+f_mem[i][1].z*GxndA[i][2][1];
		fGxndA.z=f_mem[i][1].x*GxndA[i][0][2]+f_mem[i][1].y*GxndA[i][1][2]+f_mem[i][1].z*GxndA[i][2][2];
		fxn.x=f_mem[i][1].y*f_mem[i][0].z-f_mem[i][1].z*f_mem[i][0].y;
		fxn.y=f_mem[i][1].z*f_mem[i][0].x-f_mem[i][1].x*f_mem[i][0].z;
		fxn.z=f_mem[i][1].x*f_mem[i][0].y-f_mem[i][1].y*f_mem[i][0].x;
#ifdef VISCOSITY_CONTRAST
		temp0=fxn.x*GxndA[i][0][0]+fxn.y*GxndA[i][0][1]+fxn.z*GxndA[i][0][2];
		v_mem[i][1].x=cst*(eta0*(v_mem[i][1].x-MU1*(fGndA*f_mem[i][0].x+f_mem[i][0].y*fGxndA.z-f_mem[i][0].z*fGxndA.y)-MU2*(fn*v_mem[i][0].x+temp0))+eta1*new_v4[i].x+eta2*v_mem_prev[i].x+xflow(r_mem[i],time0));
		temp0=fxn.x*GxndA[i][1][0]+fxn.y*GxndA[i][1][1]+fxn.z*GxndA[i][1][2];
		v_mem[i][1].y=cst*(eta0*(v_mem[i][1].y-MU1*(fGndA*f_mem[i][0].y+f_mem[i][0].z*fGxndA.x-f_mem[i][0].x*fGxndA.z)-MU2*(fn*v_mem[i][0].y+temp0))+eta1*new_v4[i].y+eta2*v_mem_prev[i].y+yflow(r_mem[i],time0));
		temp0=fxn.x*GxndA[i][2][0]+fxn.y*GxndA[i][2][1]+fxn.z*GxndA[i][2][2];
		v_mem[i][1].z=cst*(eta0*(v_mem[i][1].z-MU1*(fGndA*f_mem[i][0].z+f_mem[i][0].x*fGxndA.y-f_mem[i][0].y*fGxndA.x)-MU2*(fn*v_mem[i][0].z+temp0))+eta1*new_v4[i].z+eta2*v_mem_prev[i].z+zflow(r_mem[i],time0));
#else
		temp0=fxn.x*GxndA[i][0][0]+fxn.y*GxndA[i][0][1]+fxn.z*GxndA[i][0][2];
		v_mem[i][1].x=eta0*(v_mem[i][1].x-MU1*(fGndA*f_mem[i][0].x+f_mem[i][0].y*fGxndA.z-f_mem[i][0].z*fGxndA.y)-MU2*(fn*v_mem[i][0].x+temp0))+xflow(r_mem[i],time0);
		temp0=fxn.x*GxndA[i][1][0]+fxn.y*GxndA[i][1][1]+fxn.z*GxndA[i][1][2];
		v_mem[i][1].y=eta0*(v_mem[i][1].y-MU1*(fGndA*f_mem[i][0].y+f_mem[i][0].z*fGxndA.x-f_mem[i][0].x*fGxndA.z)-MU2*(fn*v_mem[i][0].y+temp0))+yflow(r_mem[i],time0);
		temp0=fxn.x*GxndA[i][2][0]+fxn.y*GxndA[i][2][1]+fxn.z*GxndA[i][2][2];
		v_mem[i][1].z=eta0*(v_mem[i][1].z-MU1*(fGndA*f_mem[i][0].z+f_mem[i][0].x*fGxndA.y-f_mem[i][0].y*fGxndA.x)-MU2*(fn*v_mem[i][0].z+temp0))+zflow(r_mem[i],time0);
#endif
//second velocity
		fn=f_mem[i][2].x*f_mem[i][0].x+f_mem[i][2].y*f_mem[i][0].y+f_mem[i][2].z*f_mem[i][0].z;
		fGndA=f_mem[i][2].x*v_mem[i][0].x+f_mem[i][2].y*v_mem[i][0].y+f_mem[i][2].z*v_mem[i][0].z;
		fGxndA.x=f_mem[i][2].x*GxndA[i][0][0]+f_mem[i][2].y*GxndA[i][1][0]+f_mem[i][2].z*GxndA[i][2][0];
		fGxndA.y=f_mem[i][2].x*GxndA[i][0][1]+f_mem[i][2].y*GxndA[i][1][1]+f_mem[i][2].z*GxndA[i][2][1];
		fGxndA.z=f_mem[i][2].x*GxndA[i][0][2]+f_mem[i][2].y*GxndA[i][1][2]+f_mem[i][2].z*GxndA[i][2][2];
		fxn.x=f_mem[i][2].y*f_mem[i][0].z-f_mem[i][2].z*f_mem[i][0].y;
		fxn.y=f_mem[i][2].z*f_mem[i][0].x-f_mem[i][2].x*f_mem[i][0].z;
		fxn.z=f_mem[i][2].x*f_mem[i][0].y-f_mem[i][2].y*f_mem[i][0].x;
#ifdef VISCOSITY_CONTRAST
		temp0=fxn.x*GxndA[i][0][0]+fxn.y*GxndA[i][0][1]+fxn.z*GxndA[i][0][2];
		v_mem[i][2].x=cst*eta0*(v_mem[i][2].x-MU1*(fGndA*f_mem[i][0].x+f_mem[i][0].y*fGxndA.z-f_mem[i][0].z*fGxndA.y)-MU2*(fn*v_mem[i][0].x+temp0));
		temp0=fxn.x*GxndA[i][1][0]+fxn.y*GxndA[i][1][1]+fxn.z*GxndA[i][1][2];
		v_mem[i][2].y=cst*eta0*(v_mem[i][2].y-MU1*(fGndA*f_mem[i][0].y+f_mem[i][0].z*fGxndA.x-f_mem[i][0].x*fGxndA.z)-MU2*(fn*v_mem[i][0].y+temp0));
		temp0=fxn.x*GxndA[i][2][0]+fxn.y*GxndA[i][2][1]+fxn.z*GxndA[i][2][2];
		v_mem[i][2].z=cst*eta0*(v_mem[i][2].z-MU1*(fGndA*f_mem[i][0].z+f_mem[i][0].x*fGxndA.y-f_mem[i][0].y*fGxndA.x)-MU2*(fn*v_mem[i][0].z+temp0));
#else
		temp0=fxn.x*GxndA[i][0][0]+fxn.y*GxndA[i][0][1]+fxn.z*GxndA[i][0][2];
		v_mem[i][2].x=eta0*(v_mem[i][2].x-MU1*(fGndA*f_mem[i][0].x+f_mem[i][0].y*fGxndA.z-f_mem[i][0].z*fGxndA.y)-MU2*(fn*v_mem[i][0].x+temp0));
		temp0=fxn.x*GxndA[i][1][0]+fxn.y*GxndA[i][1][1]+fxn.z*GxndA[i][1][2];
		v_mem[i][2].y=eta0*(v_mem[i][2].y-MU1*(fGndA*f_mem[i][0].y+f_mem[i][0].z*fGxndA.x-f_mem[i][0].x*fGxndA.z)-MU2*(fn*v_mem[i][0].y+temp0));
		temp0=fxn.x*GxndA[i][2][0]+fxn.y*GxndA[i][2][1]+fxn.z*GxndA[i][2][2];
		v_mem[i][2].z=eta0*(v_mem[i][2].z-MU1*(fGndA*f_mem[i][0].z+f_mem[i][0].x*fGxndA.y-f_mem[i][0].y*fGxndA.x)-MU2*(fn*v_mem[i][0].z+temp0));
#endif
//third velocity
		fn=f_mem[i][3].x*f_mem[i][0].x+f_mem[i][3].y*f_mem[i][0].y+f_mem[i][3].z*f_mem[i][0].z;
		fGndA=f_mem[i][3].x*v_mem[i][0].x+f_mem[i][3].y*v_mem[i][0].y+f_mem[i][3].z*v_mem[i][0].z;
		fGxndA.x=f_mem[i][3].x*GxndA[i][0][0]+f_mem[i][3].y*GxndA[i][1][0]+f_mem[i][3].z*GxndA[i][2][0];
		fGxndA.y=f_mem[i][3].x*GxndA[i][0][1]+f_mem[i][3].y*GxndA[i][1][1]+f_mem[i][3].z*GxndA[i][2][1];
		fGxndA.z=f_mem[i][3].x*GxndA[i][0][2]+f_mem[i][3].y*GxndA[i][1][2]+f_mem[i][3].z*GxndA[i][2][2];
		fxn.x=f_mem[i][3].y*f_mem[i][0].z-f_mem[i][3].z*f_mem[i][0].y;
		fxn.y=f_mem[i][3].z*f_mem[i][0].x-f_mem[i][3].x*f_mem[i][0].z;
		fxn.z=f_mem[i][3].x*f_mem[i][0].y-f_mem[i][3].y*f_mem[i][0].x;
#ifdef VISCOSITY_CONTRAST
		temp0=fxn.x*GxndA[i][0][0]+fxn.y*GxndA[i][0][1]+fxn.z*GxndA[i][0][2];
		v_mem[i][3].x=cst*eta0*(v_mem[i][3].x-MU1*(fGndA*f_mem[i][0].x+f_mem[i][0].y*fGxndA.z-f_mem[i][0].z*fGxndA.y)-MU2*(fn*v_mem[i][0].x+temp0));
		temp0=fxn.x*GxndA[i][1][0]+fxn.y*GxndA[i][1][1]+fxn.z*GxndA[i][1][2];
		v_mem[i][3].y=cst*eta0*(v_mem[i][3].y-MU1*(fGndA*f_mem[i][0].y+f_mem[i][0].z*fGxndA.x-f_mem[i][0].x*fGxndA.z)-MU2*(fn*v_mem[i][0].y+temp0));
		temp0=fxn.x*GxndA[i][2][0]+fxn.y*GxndA[i][2][1]+fxn.z*GxndA[i][2][2];
		v_mem[i][3].z=cst*eta0*(v_mem[i][3].z-MU1*(fGndA*f_mem[i][0].z+f_mem[i][0].x*fGxndA.y-f_mem[i][0].y*fGxndA.x)-MU2*(fn*v_mem[i][0].z+temp0));
#else
		temp0=fxn.x*GxndA[i][0][0]+fxn.y*GxndA[i][0][1]+fxn.z*GxndA[i][0][2];
		v_mem[i][3].x=eta0*(v_mem[i][3].x-MU1*(fGndA*f_mem[i][0].x+f_mem[i][0].y*fGxndA.z-f_mem[i][0].z*fGxndA.y)-MU2*(fn*v_mem[i][0].x+temp0));
		temp0=fxn.x*GxndA[i][1][0]+fxn.y*GxndA[i][1][1]+fxn.z*GxndA[i][1][2];
		v_mem[i][3].y=eta0*(v_mem[i][3].y-MU1*(fGndA*f_mem[i][0].y+f_mem[i][0].z*fGxndA.x-f_mem[i][0].x*fGxndA.z)-MU2*(fn*v_mem[i][0].y+temp0));
		temp0=fxn.x*GxndA[i][2][0]+fxn.y*GxndA[i][2][1]+fxn.z*GxndA[i][2][2];
		v_mem[i][3].z=eta0*(v_mem[i][3].z-MU1*(fGndA*f_mem[i][0].z+f_mem[i][0].x*fGxndA.y-f_mem[i][0].y*fGxndA.x)-MU2*(fn*v_mem[i][0].z+temp0));
#endif


	}
}

void interaction_green16(int triang_site[NTRIANG][3], int slaves[NMEM][NSLA], int Nslaves[NMEM], struct point3D r_mem[NMEM], struct point3D r_mem2[NMEM2], struct point3D v_mem0[NMEM][4], struct point3D f_mem[NMEM2][4], struct point3D fdA[NMEM][4], struct point3D fdA2[NMEM2][4], double eta, double pp, struct point3D v_mem_prev[NMEM2], int slaves2[NMEM][NSLA2], int Nslaves2[NMEM], double r_min[NMEM]){

	int i,j,k,j1,i1,i0,j0;
	double fn,fGndA,dr1,drn,eta0,temp0,w,w1,drn1,r_maxtemp;
	struct point3D dr, fGxndA, fxn, vtemp, dr1ndA,v_mem[NMEM][4];

	double r_max[NMEM],rho,r_co1,r_co2;
#ifdef VISCOSITY_CONTRAST
	struct point3D new_v4[NMEM];
	double cst,eta1,eta2,dvdr,dvdr2;
	eta1=0.75*(pp-1.0)/PI;
	cst=2.0/(1.0+pp);
#endif
	eta0=1.0/(8.0*PI*eta);
	r_co1=1.0/r_co;
	r_co2=r_co*r_co;
	for(i=0;i<NMEM;i++){
		for(k=1;k<4;k++)v_mem[i][k].x=v_mem[i][k].y=v_mem[i][k].z=0.0;
		r_min[i]=1.0;
#ifdef VISCOSITY_CONTRAST
		new_v4[i].x=new_v4[i].y=new_v4[i].z=0.0;
#endif
	}
	for(i=0;i<NMEM;i++){
		r_max[i]=0.0;
		for(j=0;j<Nslaves2[i];j++){
			vtemp.x=r_mem2[i].x-r_mem2[slaves2[i][j]].x;
			vtemp.y=r_mem2[i].y-r_mem2[slaves2[i][j]].y;
			vtemp.z=r_mem2[i].z-r_mem2[slaves2[i][j]].z;
			temp0=vtemp.x*vtemp.x+vtemp.y*vtemp.y+vtemp.z*vtemp.z;
			if(r_max[i]<temp0) r_max[i]=temp0;
		}
		r_max[i]=0.5*sqrt(r_max[i]);
	}
	for(i=0;i<NMEM;i++){
		r_maxtemp=r_max[i]+r_co;
		for(j=0;j<i;j++){
			dr.x=r_mem[i].x+r_mem[j].x;
			dr.y=r_mem[i].y+r_mem[j].y;
			dr.z=r_mem[i].z+r_mem[j].z;
			dr1=sqrt(dr.x*dr.x+dr.y*dr.y+dr.z*dr.z);
			if(dr1>r_maxtemp+r_max[j]+fabs(r_max[i]-r_max[j])){
				dr1=1.0/dr1;
				dr.x*=dr1;
				dr.y*=dr1;
				dr.z*=dr1;

//calculating contribution of f[i] to v[j]
				temp0=fdA[i][1].x*dr.x+fdA[i][1].y*dr.y+fdA[i][1].z*dr.z;
				v_mem[j][1].x+=dr1*(fdA[i][1].x+dr.x*temp0);
				v_mem[j][1].y+=dr1*(fdA[i][1].y+dr.y*temp0);
				v_mem[j][1].z+=dr1*(fdA[i][1].z+dr.z*temp0);
				temp0=fdA[i][2].x*dr.x+fdA[i][2].y*dr.y+fdA[i][2].z*dr.z;
				v_mem[j][2].x+=dr1*(fdA[i][2].x+dr.x*temp0);
				v_mem[j][2].y+=dr1*(fdA[i][2].y+dr.y*temp0);
				v_mem[j][2].z+=dr1*(fdA[i][2].z+dr.z*temp0);
				temp0=fdA[i][3].x*dr.x+fdA[i][3].y*dr.y+fdA[i][3].z*dr.z;
				v_mem[j][3].x+=dr1*(fdA[i][3].x+dr.x*temp0);
				v_mem[j][3].y+=dr1*(fdA[i][3].y+dr.y*temp0);
				v_mem[j][3].z+=dr1*(fdA[i][3].z+dr.z*temp0);
//calculating contribution of v[i] to v[j]
#ifdef VISCOSITY_CONTRAST
				dvdr=(v_mem_prev[i].x*dr.x+v_mem_prev[i].y*dr.y+v_mem_prev[i].z*dr.z)*dr1*dr1;
				drn=fdA[i][0].x*dr.x+fdA[i][0].y*dr.y+fdA[i][0].z*dr.z;
				drn*=dvdr;
				new_v4[j].x+=dr.x*drn;
				new_v4[j].y+=dr.y*drn;
				new_v4[j].z+=dr.z*drn;
#endif

//calculating contribution of f[j] to v[i]
				temp0=fdA[j][1].x*dr.x+fdA[j][1].y*dr.y+fdA[j][1].z*dr.z;
				v_mem[i][1].x+=dr1*(fdA[j][1].x+dr.x*temp0);
				v_mem[i][1].y+=dr1*(fdA[j][1].y+dr.y*temp0);
				v_mem[i][1].z+=dr1*(fdA[j][1].z+dr.z*temp0);
				temp0=fdA[j][2].x*dr.x+fdA[j][2].y*dr.y+fdA[j][2].z*dr.z;
				v_mem[i][2].x+=dr1*(fdA[j][2].x+dr.x*temp0);
				v_mem[i][2].y+=dr1*(fdA[j][2].y+dr.y*temp0);
				v_mem[i][2].z+=dr1*(fdA[j][2].z+dr.z*temp0);
				temp0=fdA[j][3].x*dr.x+fdA[j][3].y*dr.y+fdA[j][3].z*dr.z;
				v_mem[i][3].x+=dr1*(fdA[j][3].x+dr.x*temp0);
				v_mem[i][3].y+=dr1*(fdA[j][3].y+dr.y*temp0);
				v_mem[i][3].z+=dr1*(fdA[j][3].z+dr.z*temp0);
//calculating contribution of v[j] to v[i]
#ifdef VISCOSITY_CONTRAST
				dvdr=(v_mem_prev[j].x*dr.x+v_mem_prev[j].y*dr.y+v_mem_prev[j].z*dr.z)*dr1*dr1;
				drn=fdA[j][0].x*dr.x+fdA[j][0].y*dr.y+fdA[j][0].z*dr.z;
				drn*=dvdr;
				new_v4[i].x+=dr.x*drn;
				new_v4[i].y+=dr.y*drn;
				new_v4[i].z+=dr.z*drn;
#endif
			}
			else {
				rho=dr1*r_co1;
				dr1=1.0/dr1;
				dr.x*=dr1;
				dr.y*=dr1;
				dr.z*=dr1;

#ifdef VISCOSITY_CONTRAST
				dvdr=(v_mem_prev[i].x*dr.x+v_mem_prev[i].y*dr.y+v_mem_prev[i].z*dr.z)*dr1;
				dvdr2=(v_mem_prev[j].x*dr.x+v_mem_prev[j].y*dr.y+v_mem_prev[j].z*dr.z)*dr1;
#endif
				if(rho<1.0){
					w=W_DEF;
					dr1*=w;
					if(r_min[i]>rho) r_min[i]=rho;
					if(r_min[j]>rho) r_min[j]=rho;
				}
#ifdef VISCOSITY_CONTRAST
				dvdr*=dr1;
				dvdr2*=dr1;
#endif
//calculating contribution of f[i] to v[j]
				temp0=fdA[i][1].x*dr.x+fdA[i][1].y*dr.y+fdA[i][1].z*dr.z;
				v_mem[j][1].x+=dr1*(fdA[i][1].x+dr.x*temp0);
				v_mem[j][1].y+=dr1*(fdA[i][1].y+dr.y*temp0);
				v_mem[j][1].z+=dr1*(fdA[i][1].z+dr.z*temp0);
				temp0=fdA[i][2].x*dr.x+fdA[i][2].y*dr.y+fdA[i][2].z*dr.z;
				v_mem[j][2].x+=dr1*(fdA[i][2].x+dr.x*temp0);
				v_mem[j][2].y+=dr1*(fdA[i][2].y+dr.y*temp0);
				v_mem[j][2].z+=dr1*(fdA[i][2].z+dr.z*temp0);
				temp0=fdA[i][3].x*dr.x+fdA[i][3].y*dr.y+fdA[i][3].z*dr.z;
				v_mem[j][3].x+=dr1*(fdA[i][3].x+dr.x*temp0);
				v_mem[j][3].y+=dr1*(fdA[i][3].y+dr.y*temp0);
				v_mem[j][3].z+=dr1*(fdA[i][3].z+dr.z*temp0);
//calculating contribution of v[i] to v[j]
#ifdef VISCOSITY_CONTRAST
				drn=fdA[i][0].x*dr.x+fdA[i][0].y*dr.y+fdA[i][0].z*dr.z;
				drn*=dvdr;
				new_v4[j].x+=dr.x*drn;
				new_v4[j].y+=dr.y*drn;
				new_v4[j].z+=dr.z*drn;
#endif

//calculating contribution of f[j] to v[i]
				temp0=fdA[j][1].x*dr.x+fdA[j][1].y*dr.y+fdA[j][1].z*dr.z;
				v_mem[i][1].x+=dr1*(fdA[j][1].x+dr.x*temp0);
				v_mem[i][1].y+=dr1*(fdA[j][1].y+dr.y*temp0);
				v_mem[i][1].z+=dr1*(fdA[j][1].z+dr.z*temp0);
				temp0=fdA[j][2].x*dr.x+fdA[j][2].y*dr.y+fdA[j][2].z*dr.z;
				v_mem[i][2].x+=dr1*(fdA[j][2].x+dr.x*temp0);
				v_mem[i][2].y+=dr1*(fdA[j][2].y+dr.y*temp0);
				v_mem[i][2].z+=dr1*(fdA[j][2].z+dr.z*temp0);
				temp0=fdA[j][3].x*dr.x+fdA[j][3].y*dr.y+fdA[j][3].z*dr.z;
				v_mem[i][3].x+=dr1*(fdA[j][3].x+dr.x*temp0);
				v_mem[i][3].y+=dr1*(fdA[j][3].y+dr.y*temp0);
				v_mem[i][3].z+=dr1*(fdA[j][3].z+dr.z*temp0);
//calculating contribution of v[j] to v[i]
#ifdef VISCOSITY_CONTRAST
				drn=fdA[j][0].x*dr.x+fdA[j][0].y*dr.y+fdA[j][0].z*dr.z;
				drn*=dvdr2;
				new_v4[i].x+=dr.x*drn;
				new_v4[i].y+=dr.y*drn;
				new_v4[i].z+=dr.z*drn;
#endif
				for(i1=0;i1<Nslaves2[i];i1++){
					i0=slaves2[i][i1];
					dr.x=r_mem[j].x+r_mem2[i0].x;
					dr.y=r_mem[j].y+r_mem2[i0].y;
					dr.z=r_mem[j].z+r_mem2[i0].z;
					dr1=dr.x*dr.x+dr.y*dr.y+dr.z*dr.z;
					if(dr1>r_co2) continue;
					dr1=sqrt(dr1);
					rho=dr1*r_co1;
					dr1=1.0/dr1;
					dr.x*=dr1;
					dr.y*=dr1;
					dr.z*=dr1;

#ifdef VISCOSITY_CONTRAST
					dvdr=(v_mem_prev[i0].x*dr.x+v_mem_prev[i0].y*dr.y+v_mem_prev[i0].z*dr.z)*dr1;
#endif
					w=1.0-W_DEF;
					dr1*=w;
#ifdef VISCOSITY_CONTRAST
					dvdr*=dr1;
#endif
//calculating contribution of f2[i] to v[j]
					temp0=fdA2[i0][1].x*dr.x+fdA2[i0][1].y*dr.y+fdA2[i0][1].z*dr.z;
					v_mem[j][1].x+=dr1*(fdA2[i0][1].x+dr.x*temp0);
					v_mem[j][1].y+=dr1*(fdA2[i0][1].y+dr.y*temp0);
					v_mem[j][1].z+=dr1*(fdA2[i0][1].z+dr.z*temp0);
					temp0=fdA2[i0][2].x*dr.x+fdA2[i0][2].y*dr.y+fdA2[i0][2].z*dr.z;
					v_mem[j][2].x+=dr1*(fdA2[i0][2].x+dr.x*temp0);
					v_mem[j][2].y+=dr1*(fdA2[i0][2].y+dr.y*temp0);
					v_mem[j][2].z+=dr1*(fdA2[i0][2].z+dr.z*temp0);
					temp0=fdA2[i0][3].x*dr.x+fdA2[i0][3].y*dr.y+fdA2[i0][3].z*dr.z;
					v_mem[j][3].x+=dr1*(fdA2[i0][3].x+dr.x*temp0);
					v_mem[j][3].y+=dr1*(fdA2[i0][3].y+dr.y*temp0);
					v_mem[j][3].z+=dr1*(fdA2[i0][3].z+dr.z*temp0);
//calculating contribution of v[i] to v[j]
#ifdef VISCOSITY_CONTRAST
					drn=fdA2[i0][0].x*dr.x+fdA2[i0][0].y*dr.y+fdA2[i0][0].z*dr.z;
					drn*=dvdr;
					new_v4[j].x+=dr.x*drn;
					new_v4[j].y+=dr.y*drn;
					new_v4[j].z+=dr.z*drn;
#endif
				}
				for(j1=0;j1<Nslaves2[j];j1++){
					j0=slaves2[j][j1];
					dr.x=r_mem[i].x+r_mem2[j0].x;
					dr.y=r_mem[i].y+r_mem2[j0].y;
					dr.z=r_mem[i].z+r_mem2[j0].z;
					dr1=dr.x*dr.x+dr.y*dr.y+dr.z*dr.z;
					if(dr1>r_co2) continue;
					dr1=sqrt(dr1);
					rho=dr1*r_co1;
					dr1=1.0/dr1;
					dr.x*=dr1;
					dr.y*=dr1;
					dr.z*=dr1;
	
#ifdef VISCOSITY_CONTRAST
					dvdr=(v_mem_prev[j0].x*dr.x+v_mem_prev[j0].y*dr.y+v_mem_prev[j0].z*dr.z)*dr1;
#endif
					w=1.0-W_DEF;
					dr1*=w;
#ifdef VISCOSITY_CONTRAST
					dvdr*=dr1;
#endif
//calculating contribution of f2[j] to v[i]
					temp0=fdA2[j0][1].x*dr.x+fdA2[j0][1].y*dr.y+fdA2[j0][1].z*dr.z;
					v_mem[i][1].x+=dr1*(fdA2[j0][1].x+dr.x*temp0);
					v_mem[i][1].y+=dr1*(fdA2[j0][1].y+dr.y*temp0);
					v_mem[i][1].z+=dr1*(fdA2[j0][1].z+dr.z*temp0);
					temp0=fdA2[j0][2].x*dr.x+fdA2[j0][2].y*dr.y+fdA2[j0][2].z*dr.z;
					v_mem[i][2].x+=dr1*(fdA2[j0][2].x+dr.x*temp0);
					v_mem[i][2].y+=dr1*(fdA2[j0][2].y+dr.y*temp0);
					v_mem[i][2].z+=dr1*(fdA2[j0][2].z+dr.z*temp0);
					temp0=fdA2[j0][3].x*dr.x+fdA2[j0][3].y*dr.y+fdA2[j0][3].z*dr.z;
					v_mem[i][3].x+=dr1*(fdA2[j0][3].x+dr.x*temp0);
					v_mem[i][3].y+=dr1*(fdA2[j0][3].y+dr.y*temp0);
					v_mem[i][3].z+=dr1*(fdA2[j0][3].z+dr.z*temp0);
//calculating contribution of v[j] to v[i]
#ifdef VISCOSITY_CONTRAST
					drn=fdA2[j0][0].x*dr.x+fdA2[j0][0].y*dr.y+fdA2[j0][0].z*dr.z;
					drn*=dvdr;
					new_v4[i].x+=dr.x*drn;
					new_v4[i].y+=dr.y*drn;
					new_v4[i].z+=dr.z*drn;
#endif
				}
			}
		}
		dr.x=r_mem[i].x+r_mem[i].x;
		dr.y=r_mem[i].y+r_mem[i].y;
		dr.z=r_mem[i].z+r_mem[i].z;
		dr1=sqrt(dr.x*dr.x+dr.y*dr.y+dr.z*dr.z);
		if(dr1>r_maxtemp+r_max[i]){
			rho=dr1*r_co1;
			dr1=1.0/dr1;
			dr.x*=dr1;
			dr.y*=dr1;
			dr.z*=dr1;
#ifdef VISCOSITY_CONTRAST
			dvdr=(v_mem_prev[i].x*dr.x+v_mem_prev[i].y*dr.y+v_mem_prev[i].z*dr.z)*dr1;
#endif
//calculating contribution of f[i] to v[i]
			temp0=fdA[i][1].x*dr.x+fdA[i][1].y*dr.y+fdA[i][1].z*dr.z;
			v_mem[i][1].x+=dr1*(fdA[i][1].x+dr.x*temp0);
			v_mem[i][1].y+=dr1*(fdA[i][1].y+dr.y*temp0);
			v_mem[i][1].z+=dr1*(fdA[i][1].z+dr.z*temp0);
			temp0=fdA[i][2].x*dr.x+fdA[i][2].y*dr.y+fdA[i][2].z*dr.z;
			v_mem[i][2].x+=dr1*(fdA[i][2].x+dr.x*temp0);
			v_mem[i][2].y+=dr1*(fdA[i][2].y+dr.y*temp0);
			v_mem[i][2].z+=dr1*(fdA[i][2].z+dr.z*temp0);
			temp0=fdA[i][3].x*dr.x+fdA[i][3].y*dr.y+fdA[i][3].z*dr.z;
			v_mem[i][3].x+=dr1*(fdA[i][3].x+dr.x*temp0);
			v_mem[i][3].y+=dr1*(fdA[i][3].y+dr.y*temp0);
			v_mem[i][3].z+=dr1*(fdA[i][3].z+dr.z*temp0);
#ifdef VISCOSITY_CONTRAST
			drn=fdA[i][0].x*dr.x+fdA[i][0].y*dr.y+fdA[i][0].z*dr.z;
			drn*=dvdr;
			new_v4[i].x+=dr.x*drn;
			new_v4[i].y+=dr.y*drn;
			new_v4[i].z+=dr.z*drn;
#endif
		}
		else {
			rho=dr1*r_co1;
			dr1=1.0/dr1;
			dr.x*=dr1;
			dr.y*=dr1;
			dr.z*=dr1;
#ifdef VISCOSITY_CONTRAST
			dvdr=(v_mem_prev[i].x*dr.x+v_mem_prev[i].y*dr.y+v_mem_prev[i].z*dr.z)*dr1;
#endif
			if(rho<1.0){
				w=W_DEF;
				dr1*=w;
				if(r_min[i]>rho) r_min[i]=rho;
			}
#ifdef VISCOSITY_CONTRAST
			dvdr*=dr1;
#endif
//calculating contribution of f[i] to v[i]
			temp0=fdA[i][1].x*dr.x+fdA[i][1].y*dr.y+fdA[i][1].z*dr.z;
			v_mem[i][1].x+=dr1*(fdA[i][1].x+dr.x*temp0);
			v_mem[i][1].y+=dr1*(fdA[i][1].y+dr.y*temp0);
			v_mem[i][1].z+=dr1*(fdA[i][1].z+dr.z*temp0);
			temp0=fdA[i][2].x*dr.x+fdA[i][2].y*dr.y+fdA[i][2].z*dr.z;
			v_mem[i][2].x+=dr1*(fdA[i][2].x+dr.x*temp0);
			v_mem[i][2].y+=dr1*(fdA[i][2].y+dr.y*temp0);
			v_mem[i][2].z+=dr1*(fdA[i][2].z+dr.z*temp0);
			temp0=fdA[i][3].x*dr.x+fdA[i][3].y*dr.y+fdA[i][3].z*dr.z;
			v_mem[i][3].x+=dr1*(fdA[i][3].x+dr.x*temp0);
			v_mem[i][3].y+=dr1*(fdA[i][3].y+dr.y*temp0);
			v_mem[i][3].z+=dr1*(fdA[i][3].z+dr.z*temp0);
#ifdef VISCOSITY_CONTRAST
			drn=fdA[i][0].x*dr.x+fdA[i][0].y*dr.y+fdA[i][0].z*dr.z;
			drn*=dvdr;
			new_v4[i].x+=dr.x*drn;
			new_v4[i].y+=dr.y*drn;
			new_v4[i].z+=dr.z*drn;
#endif
			for(i1=0;i1<Nslaves2[i];i1++){
				i0=slaves2[i][i1];
				dr.x=r_mem[i].x+r_mem2[i0].x;
				dr.y=r_mem[i].y+r_mem2[i0].y;
				dr.z=r_mem[i].z+r_mem2[i0].z;
				dr1=dr.x*dr.x+dr.y*dr.y+dr.z*dr.z;
				if(dr1>r_co2) continue;
				dr1=sqrt(dr1);
				rho=dr1*r_co1;
				dr1=1.0/dr1;
				dr.x*=dr1;
				dr.y*=dr1;
				dr.z*=dr1;
#ifdef VISCOSITY_CONTRAST
				dvdr=(v_mem_prev[i0].x*dr.x+v_mem_prev[i0].y*dr.y+v_mem_prev[i0].z*dr.z)*dr1;
#endif
				w=1.0-W_DEF;
				dr1*=w;
#ifdef VISCOSITY_CONTRAST
				dvdr*=dr1;
#endif
//calculating contribution of f2[i] to v[i]
				temp0=fdA2[i0][1].x*dr.x+fdA2[i0][1].y*dr.y+fdA2[i0][1].z*dr.z;
				v_mem[i][1].x+=dr1*(fdA2[i0][1].x+dr.x*temp0);
				v_mem[i][1].y+=dr1*(fdA2[i0][1].y+dr.y*temp0);
				v_mem[i][1].z+=dr1*(fdA2[i0][1].z+dr.z*temp0);
				temp0=fdA2[i0][2].x*dr.x+fdA2[i0][2].y*dr.y+fdA2[i0][2].z*dr.z;
				v_mem[i][2].x+=dr1*(fdA2[i0][2].x+dr.x*temp0);
				v_mem[i][2].y+=dr1*(fdA2[i0][2].y+dr.y*temp0);
				v_mem[i][2].z+=dr1*(fdA2[i0][2].z+dr.z*temp0);
				temp0=fdA2[i0][3].x*dr.x+fdA2[i0][3].y*dr.y+fdA2[i0][3].z*dr.z;
				v_mem[i][3].x+=dr1*(fdA2[i0][3].x+dr.x*temp0);
				v_mem[i][3].y+=dr1*(fdA2[i0][3].y+dr.y*temp0);
				v_mem[i][3].z+=dr1*(fdA2[i0][3].z+dr.z*temp0);
#ifdef VISCOSITY_CONTRAST
				drn=fdA2[i0][0].x*dr.x+fdA2[i0][0].y*dr.y+fdA2[i0][0].z*dr.z;
				drn*=dvdr;
				new_v4[i].x+=dr.x*drn;
				new_v4[i].y+=dr.y*drn;
				new_v4[i].z+=dr.z*drn;
#endif
			}
		}
	}
	for(i=0;i<NMEM;i++) {
//first velocity
#ifdef VISCOSITY_CONTRAST
		v_mem0[i][1].x-=cst*(eta0*v_mem[i][1].x+eta1*new_v4[i].x);
		v_mem0[i][1].y-=cst*(eta0*v_mem[i][1].y+eta1*new_v4[i].y);
		v_mem0[i][1].z-=cst*(eta0*v_mem[i][1].z+eta1*new_v4[i].z);
#else
		v_mem0[i][1].x-=eta0*v_mem[i][1].x;
		v_mem0[i][1].y-=eta0*v_mem[i][1].y;
		v_mem0[i][1].z-=eta0*v_mem[i][1].z;
#endif
//second velocity
#ifdef VISCOSITY_CONTRAST
		v_mem0[i][2].x-=cst*eta0*v_mem[i][2].x;
		v_mem0[i][2].y-=cst*eta0*v_mem[i][2].y;
		v_mem0[i][2].z-=cst*eta0*v_mem[i][2].z;
#else
		v_mem0[i][2].x-=eta0*v_mem[i][2].x;
		v_mem0[i][2].y-=eta0*v_mem[i][2].y;
		v_mem0[i][2].z-=eta0*v_mem[i][2].z;
#endif
//third velocity
#ifdef VISCOSITY_CONTRAST
		v_mem0[i][3].x-=cst*eta0*v_mem[i][3].x;
		v_mem0[i][3].y-=cst*eta0*v_mem[i][3].y;
		v_mem0[i][3].z-=cst*eta0*v_mem[i][3].z;
#else
		v_mem0[i][3].x-=eta0*v_mem[i][3].x;
		v_mem0[i][3].y-=eta0*v_mem[i][3].y;
		v_mem0[i][3].z-=eta0*v_mem[i][3].z;
#endif
	}
}

void wall_green16(int triang_site[NTRIANG][3], int slaves[NMEM][NSLA], int Nslaves[NMEM], struct point3D r_mem[NMEM], struct point3D r_mem2[NMEM2], struct point3D v_mem0[NMEM][4], struct point3D f_mem[NMEM2][4], struct point3D fdA[NMEM][4], struct point3D fdA2[NMEM2][4], double eta, double pp, struct point3D v_mem_prev[NMEM2], int slaves2[NMEM][NSLA2], int Nslaves2[NMEM]){

	int i,j,k,j1,i1,i0,j0;
	double fn,fGndA,dr1,drn,eta0,temp0,temp1,w,w1,drn1,r_maxtemp,h_i,h_j,h0;
	struct point3D dr, fGxndA, fxn, vtemp, dr1ndA,v_mem[NMEM][4];

	double r_max[NMEM],rho,r_co1,r_co2;
#ifdef VISCOSITY_CONTRAST
	struct point3D new_v4[NMEM];
	double cst,eta1,eta2,dvdr,dvdr2;
	eta1=0.75*(pp-1.0)/PI;
	cst=2.0/(1.0+pp);
#endif
	eta0=1.0/(8.0*PI*eta);
	r_co1=1.0/r_co;
	r_co2=r_co*r_co;
	for(i=0;i<NMEM;i++){
		for(k=1;k<4;k++)v_mem[i][k].x=v_mem[i][k].y=v_mem[i][k].z=0.0;
#ifdef VISCOSITY_CONTRAST
		new_v4[i].x=new_v4[i].y=new_v4[i].z=0.0;
#endif
	}
	for(i=0;i<NMEM;i++){
		r_max[i]=0.0;
		for(j=0;j<Nslaves2[i];j++){
			vtemp.x=r_mem2[i].x-r_mem2[slaves2[i][j]].x;
			vtemp.y=r_mem2[i].y-r_mem2[slaves2[i][j]].y;
			vtemp.z=r_mem2[i].z-r_mem2[slaves2[i][j]].z;
			temp0=vtemp.x*vtemp.x+vtemp.y*vtemp.y+vtemp.z*vtemp.z;
			if(r_max[i]<temp0) r_max[i]=temp0;
		}
		r_max[i]=0.5*sqrt(r_max[i]);
	}
	for(i=0;i<NMEM;i++){
		r_maxtemp=r_max[i]+r_co;
		for(j=0;j<i;j++){
			dr.x=r_mem[j].x-r_mem[i].x;
			dr.y=r_mem[j].y+r_mem[i].y;
			dr.z=r_mem[j].z-r_mem[i].z;
			dr1=sqrt(dr.x*dr.x+dr.y*dr.y+dr.z*dr.z);
//			if(dr1>r_maxtemp+r_max[j]+fabs(r_max[i]-r_max[j])){
			if(1){
				dr1=1.0/dr1;
				dr.x*=dr1;
				dr.y*=dr1;
				dr.z*=dr1;
				h_i=2.0*r_mem[i].y*dr1;
				h_j=r_mem[j].y*dr1;
				h0=h_i*h_j;
				h_j*=2.0;
//calculating contribution of f[i] to v[j]
				temp0=fdA[i][1].x*dr.x+fdA[i][1].y*dr.y+fdA[i][1].z*dr.z;
				temp1=fdA[i][1].x*dr.x-fdA[i][1].y*dr.y+fdA[i][1].z*dr.z;
				v_mem[j][1].x+=dr1*(h_i*dr.x*fdA[i][1].y+h0*(3.0*dr.x*temp1-fdA[i][1].x)-fdA[i][1].x-dr.x*temp0);
				v_mem[j][1].y+=dr1*(h_i*(dr.y*fdA[i][1].y+temp1)+h0*(3.0*dr.y*temp1+fdA[i][1].y)-fdA[i][1].y-dr.y*temp0);
				v_mem[j][1].z+=dr1*(h_i*dr.z*fdA[i][1].y+h0*(3.0*dr.z*temp1-fdA[i][1].z)-fdA[i][1].z-dr.z*temp0);
				temp0=fdA[i][2].x*dr.x+fdA[i][2].y*dr.y+fdA[i][2].z*dr.z;
				temp1=fdA[i][2].x*dr.x-fdA[i][2].y*dr.y+fdA[i][2].z*dr.z;
				v_mem[j][2].x+=dr1*(h_i*dr.x*fdA[i][2].y+h0*(3.0*dr.x*temp1-fdA[i][2].x)-fdA[i][2].x-dr.x*temp0);
				v_mem[j][2].y+=dr1*(h_i*(dr.y*fdA[i][2].y+temp1)+h0*(3.0*dr.y*temp1+fdA[i][2].y)-fdA[i][2].y-dr.y*temp0);
				v_mem[j][2].z+=dr1*(h_i*dr.z*fdA[i][2].y+h0*(3.0*dr.z*temp1-fdA[i][2].z)-fdA[i][2].z-dr.z*temp0);
				temp0=fdA[i][3].x*dr.x+fdA[i][3].y*dr.y+fdA[i][3].z*dr.z;
				temp1=fdA[i][3].x*dr.x-fdA[i][3].y*dr.y+fdA[i][3].z*dr.z;
				v_mem[j][3].x+=dr1*(h_i*dr.x*fdA[i][3].y+h0*(3.0*dr.x*temp1-fdA[i][3].x)-fdA[i][3].x-dr.x*temp0);
				v_mem[j][3].y+=dr1*(h_i*(dr.y*fdA[i][3].y+temp1)+h0*(3.0*dr.y*temp1+fdA[i][3].y)-fdA[i][3].y-dr.y*temp0);
				v_mem[j][3].z+=dr1*(h_i*dr.z*fdA[i][3].y+h0*(3.0*dr.z*temp1-fdA[i][3].z)-fdA[i][3].z-dr.z*temp0);
//calculating contribution of v[i] to v[j]
#ifdef VISCOSITY_CONTRAST
				dvdr=(v_mem_prev[i].x*dr.x+v_mem_prev[i].y*dr.y+v_mem_prev[i].z*dr.z)*dr1*dr1;
				drn=fdA[i][0].x*dr.x+fdA[i][0].y*dr.y+fdA[i][0].z*dr.z;
				drn*=dvdr;
				new_v4[j].x+=dr.x*drn;
				new_v4[j].y+=dr.y*drn;
				new_v4[j].z+=dr.z*drn;
#endif
				dr.x=-dr.x;
				dr.z=-dr.z;

//calculating contribution of f[j] to v[i]
				temp0=fdA[j][1].x*dr.x+fdA[j][1].y*dr.y+fdA[j][1].z*dr.z;
				temp1=fdA[j][1].x*dr.x-fdA[j][1].y*dr.y+fdA[j][1].z*dr.z;
				v_mem[i][1].x+=dr1*(h_j*dr.x*fdA[j][1].y+h0*(3.0*dr.x*temp1-fdA[j][1].x)-fdA[j][1].x-dr.x*temp0);
				v_mem[i][1].y+=dr1*(h_j*(dr.y*fdA[j][1].y+temp1)+h0*(3.0*dr.y*temp1+fdA[j][1].y)-fdA[j][1].y-dr.y*temp0);
				v_mem[i][1].z+=dr1*(h_j*dr.z*fdA[j][1].y+h0*(3.0*dr.z*temp1-fdA[j][1].z)-fdA[j][1].z-dr.z*temp0);
				temp0=fdA[j][2].x*dr.x+fdA[j][2].y*dr.y+fdA[j][2].z*dr.z;
				temp1=fdA[j][2].x*dr.x-fdA[j][2].y*dr.y+fdA[j][2].z*dr.z;
				v_mem[i][2].x+=dr1*(h_j*dr.x*fdA[j][2].y+h0*(3.0*dr.x*temp1-fdA[j][2].x)-fdA[j][2].x-dr.x*temp0);
				v_mem[i][2].y+=dr1*(h_j*(dr.y*fdA[j][2].y+temp1)+h0*(3.0*dr.y*temp1+fdA[j][2].y)-fdA[j][2].y-dr.y*temp0);
				v_mem[i][2].z+=dr1*(h_j*dr.z*fdA[j][2].y+h0*(3.0*dr.z*temp1-fdA[j][2].z)-fdA[j][2].z-dr.z*temp0);
				temp0=fdA[j][3].x*dr.x+fdA[j][3].y*dr.y+fdA[j][3].z*dr.z;
				temp1=fdA[j][3].x*dr.x-fdA[j][3].y*dr.y+fdA[j][3].z*dr.z;
				v_mem[i][3].x+=dr1*(h_j*dr.x*fdA[j][3].y+h0*(3.0*dr.x*temp1-fdA[j][3].x)-fdA[j][3].x-dr.x*temp0);
				v_mem[i][3].y+=dr1*(h_j*(dr.y*fdA[j][3].y+temp1)+h0*(3.0*dr.y*temp1+fdA[j][3].y)-fdA[j][3].y-dr.y*temp0);
				v_mem[i][3].z+=dr1*(h_j*dr.z*fdA[j][3].y+h0*(3.0*dr.z*temp1-fdA[j][3].z)-fdA[j][3].z-dr.z*temp0);
//calculating contribution of v[j] to v[i]
#ifdef VISCOSITY_CONTRAST
				dvdr=(v_mem_prev[j].x*dr.x+v_mem_prev[j].y*dr.y+v_mem_prev[j].z*dr.z)*dr1*dr1;
				drn=fdA[j][0].x*dr.x+fdA[j][0].y*dr.y+fdA[j][0].z*dr.z;
				drn*=dvdr;
				new_v4[i].x+=dr.x*drn;
				new_v4[i].y+=dr.y*drn;
				new_v4[i].z+=dr.z*drn;
#endif
			}
			else {
				rho=dr1*r_co1;
				dr1=1.0/dr1;
				dr.x*=dr1;
				dr.y*=dr1;
				dr.z*=dr1;
				h_i=2.0*r_mem[i].y*dr1;
				h_j=r_mem[j].y*dr1;
				h0=h_i*h_j;
				h_j*=2.0;

#ifdef VISCOSITY_CONTRAST
				dvdr=(v_mem_prev[i].x*dr.x+v_mem_prev[i].y*dr.y+v_mem_prev[i].z*dr.z)*dr1;
				dvdr2=(v_mem_prev[j].x*dr.x+v_mem_prev[j].y*dr.y+v_mem_prev[j].z*dr.z)*dr1;
#endif
				if(rho<1.0){
					w=W_DEF;
					dr1*=w;
				}
#ifdef VISCOSITY_CONTRAST
				dvdr*=dr1;
				dvdr2*=dr1;
#endif
//calculating contribution of f[i] to v[j]
				temp0=fdA[i][1].x*dr.x+fdA[i][1].y*dr.y+fdA[i][1].z*dr.z;
				temp1=fdA[i][1].x*dr.x-fdA[i][1].y*dr.y+fdA[i][1].z*dr.z;
				v_mem[j][1].x+=dr1*(h_i*dr.x*fdA[i][1].y+h0*(3.0*dr.x*temp1-fdA[i][1].x)-fdA[i][1].x-dr.x*temp0);
				v_mem[j][1].y+=dr1*(h_i*(dr.y*fdA[i][1].y+temp1)+h0*(3.0*dr.y*temp1+fdA[i][1].y)-fdA[i][1].y-dr.y*temp0);
				v_mem[j][1].z+=dr1*(h_i*dr.z*fdA[i][1].y+h0*(3.0*dr.z*temp1-fdA[i][1].z)-fdA[i][1].z-dr.z*temp0);
				temp0=fdA[i][2].x*dr.x+fdA[i][2].y*dr.y+fdA[i][2].z*dr.z;
				temp1=fdA[i][2].x*dr.x-fdA[i][2].y*dr.y+fdA[i][2].z*dr.z;
				v_mem[j][2].x+=dr1*(h_i*dr.x*fdA[i][2].y+h0*(3.0*dr.x*temp1-fdA[i][2].x)-fdA[i][2].x-dr.x*temp0);
				v_mem[j][2].y+=dr1*(h_i*(dr.y*fdA[i][2].y+temp1)+h0*(3.0*dr.y*temp1+fdA[i][2].y)-fdA[i][2].y-dr.y*temp0);
				v_mem[j][2].z+=dr1*(h_i*dr.z*fdA[i][2].y+h0*(3.0*dr.z*temp1-fdA[i][2].z)-fdA[i][2].z-dr.z*temp0);
				temp0=fdA[i][3].x*dr.x+fdA[i][3].y*dr.y+fdA[i][3].z*dr.z;
				temp1=fdA[i][3].x*dr.x-fdA[i][3].y*dr.y+fdA[i][3].z*dr.z;
				v_mem[j][3].x+=dr1*(h_i*dr.x*fdA[i][3].y+h0*(3.0*dr.x*temp1-fdA[i][3].x)-fdA[i][3].x-dr.x*temp0);
				v_mem[j][3].y+=dr1*(h_i*(dr.y*fdA[i][3].y+temp1)+h0*(3.0*dr.y*temp1+fdA[i][3].y)-fdA[i][3].y-dr.y*temp0);
				v_mem[j][3].z+=dr1*(h_i*dr.z*fdA[i][3].y+h0*(3.0*dr.z*temp1-fdA[i][3].z)-fdA[i][3].z-dr.z*temp0);
//calculating contribution of v[i] to v[j]
#ifdef VISCOSITY_CONTRAST
				drn=fdA[i][0].x*dr.x+fdA[i][0].y*dr.y+fdA[i][0].z*dr.z;
				drn*=dvdr;
				new_v4[j].x+=dr.x*drn;
				new_v4[j].y+=dr.y*drn;
				new_v4[j].z+=dr.z*drn;
#endif

				dr.x=-dr.x;
				dr.z=-dr.z;

//calculating contribution of f[j] to v[i]
				temp0=fdA[j][1].x*dr.x+fdA[j][1].y*dr.y+fdA[j][1].z*dr.z;
				temp1=fdA[j][1].x*dr.x-fdA[j][1].y*dr.y+fdA[j][1].z*dr.z;
				v_mem[i][1].x+=dr1*(h_j*dr.x*fdA[j][1].y+h0*(3.0*dr.x*temp1-fdA[j][1].x)-fdA[j][1].x-dr.x*temp0);
				v_mem[i][1].y+=dr1*(h_j*(dr.y*fdA[j][1].y+temp1)+h0*(3.0*dr.y*temp1+fdA[j][1].y)-fdA[j][1].y-dr.y*temp0);
				v_mem[i][1].z+=dr1*(h_j*dr.z*fdA[j][1].y+h0*(3.0*dr.z*temp1-fdA[j][1].z)-fdA[j][1].z-dr.z*temp0);
				temp0=fdA[j][2].x*dr.x+fdA[j][2].y*dr.y+fdA[j][2].z*dr.z;
				temp1=fdA[j][2].x*dr.x-fdA[j][2].y*dr.y+fdA[j][2].z*dr.z;
				v_mem[i][2].x+=dr1*(h_j*dr.x*fdA[j][2].y+h0*(3.0*dr.x*temp1-fdA[j][2].x)-fdA[j][2].x-dr.x*temp0);
				v_mem[i][2].y+=dr1*(h_j*(dr.y*fdA[j][2].y+temp1)+h0*(3.0*dr.y*temp1+fdA[j][2].y)-fdA[j][2].y-dr.y*temp0);
				v_mem[i][2].z+=dr1*(h_j*dr.z*fdA[j][2].y+h0*(3.0*dr.z*temp1-fdA[j][2].z)-fdA[j][2].z-dr.z*temp0);
				temp0=fdA[j][3].x*dr.x+fdA[j][3].y*dr.y+fdA[j][3].z*dr.z;
				temp1=fdA[j][3].x*dr.x-fdA[j][3].y*dr.y+fdA[j][3].z*dr.z;
				v_mem[i][3].x+=dr1*(h_j*dr.x*fdA[j][3].y+h0*(3.0*dr.x*temp1-fdA[j][3].x)-fdA[j][3].x-dr.x*temp0);
				v_mem[i][3].y+=dr1*(h_j*(dr.y*fdA[j][3].y+temp1)+h0*(3.0*dr.y*temp1+fdA[j][3].y)-fdA[j][3].y-dr.y*temp0);
				v_mem[i][3].z+=dr1*(h_j*dr.z*fdA[j][3].y+h0*(3.0*dr.z*temp1-fdA[j][3].z)-fdA[j][3].z-dr.z*temp0);
//calculating contribution of v[j] to v[i]
#ifdef VISCOSITY_CONTRAST
				drn=fdA[j][0].x*dr.x+fdA[j][0].y*dr.y+fdA[j][0].z*dr.z;
				drn*=dvdr2;
				new_v4[i].x+=dr.x*drn;
				new_v4[i].y+=dr.y*drn;
				new_v4[i].z+=dr.z*drn;
#endif
				for(i1=0;i1<Nslaves2[i];i1++){
					i0=slaves2[i][i1];
					dr.x=r_mem[j].x-r_mem2[i0].x;
					dr.y=r_mem[j].y+r_mem2[i0].y;
					dr.z=r_mem[j].z-r_mem2[i0].z;
					dr1=dr.x*dr.x+dr.y*dr.y+dr.z*dr.z;
					if(dr1>r_co2) continue;
					dr1=sqrt(dr1);
					rho=dr1*r_co1;
					dr1=1.0/dr1;
					dr.x*=dr1;
					dr.y*=dr1;
					dr.z*=dr1;
					h_i=2.0*r_mem[i0].y*dr1;
					h_j=r_mem[j].y*dr1;
					h0=h_i*h_j;

#ifdef VISCOSITY_CONTRAST
					dvdr=(v_mem_prev[i0].x*dr.x+v_mem_prev[i0].y*dr.y+v_mem_prev[i0].z*dr.z)*dr1;
#endif
					w=1.0-W_DEF;
					dr1*=w;
#ifdef VISCOSITY_CONTRAST
					dvdr*=dr1;
#endif
//calculating contribution of f[i] to v[j]
					temp0=fdA2[i0][1].x*dr.x+fdA2[i0][1].y*dr.y+fdA2[i0][1].z*dr.z;
					temp1=fdA2[i0][1].x*dr.x-fdA2[i0][1].y*dr.y+fdA2[i0][1].z*dr.z;
					v_mem[j][1].x+=dr1*(h_i*dr.x*fdA2[i0][1].y+h0*(3.0*dr.x*temp1-fdA2[i0][1].x)-fdA2[i0][1].x-dr.x*temp0);
					v_mem[j][1].y+=dr1*(h_i*(dr.y*fdA2[i0][1].y+temp1)+h0*(3.0*dr.y*temp1+fdA2[i0][1].y)-fdA2[i0][1].y-dr.y*temp0);
					v_mem[j][1].z+=dr1*(h_i*dr.z*fdA2[i0][1].y+h0*(3.0*dr.z*temp1-fdA2[i0][1].z)-fdA2[i0][1].z-dr.z*temp0);
					temp0=fdA2[i0][2].x*dr.x+fdA2[i0][2].y*dr.y+fdA2[i0][2].z*dr.z;
					temp1=fdA2[i0][2].x*dr.x-fdA2[i0][2].y*dr.y+fdA2[i0][2].z*dr.z;
					v_mem[j][2].x+=dr1*(h_i*dr.x*fdA2[i0][2].y+h0*(3.0*dr.x*temp1-fdA2[i0][2].x)-fdA2[i0][2].x-dr.x*temp0);
					v_mem[j][2].y+=dr1*(h_i*(dr.y*fdA2[i0][2].y+temp1)+h0*(3.0*dr.y*temp1+fdA2[i0][2].y)-fdA2[i0][2].y-dr.y*temp0);
					v_mem[j][2].z+=dr1*(h_i*dr.z*fdA2[i0][2].y+h0*(3.0*dr.z*temp1-fdA2[i0][2].z)-fdA2[i0][2].z-dr.z*temp0);
					temp0=fdA2[i0][3].x*dr.x+fdA2[i0][3].y*dr.y+fdA2[i0][3].z*dr.z;
					temp1=fdA2[i0][3].x*dr.x-fdA2[i0][3].y*dr.y+fdA2[i0][3].z*dr.z;
					v_mem[j][3].x+=dr1*(h_i*dr.x*fdA2[i0][3].y+h0*(3.0*dr.x*temp1-fdA2[i0][3].x)-fdA2[i0][3].x-dr.x*temp0);
					v_mem[j][3].y+=dr1*(h_i*(dr.y*fdA2[i0][3].y+temp1)+h0*(3.0*dr.y*temp1+fdA2[i0][3].y)-fdA2[i0][3].y-dr.y*temp0);
					v_mem[j][3].z+=dr1*(h_i*dr.z*fdA2[i0][3].y+h0*(3.0*dr.z*temp1-fdA2[i0][3].z)-fdA2[i0][3].z-dr.z*temp0);
//calculating contribution of v[i] to v[j]
#ifdef VISCOSITY_CONTRAST
					drn=fdA2[i0][0].x*dr.x+fdA2[i0][0].y*dr.y+fdA2[i0][0].z*dr.z;
					drn*=dvdr;
					new_v4[j].x+=dr.x*drn;
					new_v4[j].y+=dr.y*drn;
					new_v4[j].z+=dr.z*drn;
#endif
				}
				for(j1=0;j1<Nslaves2[j];j1++){
					j0=slaves2[j][j1];
					dr.x=r_mem[i].x-r_mem2[j0].x;
					dr.y=r_mem[i].y+r_mem2[j0].y;
					dr.z=r_mem[i].z-r_mem2[j0].z;
					dr1=dr.x*dr.x+dr.y*dr.y+dr.z*dr.z;
					if(dr1>r_co2) continue;
					dr1=sqrt(dr1);
					rho=dr1*r_co1;
					dr1=1.0/dr1;
					dr.x*=dr1;
					dr.y*=dr1;
					dr.z*=dr1;
					h_i=r_mem[i].y*dr1;
					h_j=2.0*r_mem[j0].y*dr1;
					h0=h_i*h_j;
	
#ifdef VISCOSITY_CONTRAST
					dvdr=(v_mem_prev[j0].x*dr.x+v_mem_prev[j0].y*dr.y+v_mem_prev[j0].z*dr.z)*dr1;
#endif
					w=1.0-W_DEF;
					dr1*=w;
#ifdef VISCOSITY_CONTRAST
					dvdr*=dr1;
#endif
//calculating contribution of f2[j] to v[i]
					temp0=fdA2[j0][1].x*dr.x+fdA2[j0][1].y*dr.y+fdA2[j0][1].z*dr.z;
					temp1=fdA2[j0][1].x*dr.x-fdA2[j0][1].y*dr.y+fdA2[j0][1].z*dr.z;
					v_mem[i][1].x+=dr1*(h_j*dr.x*fdA2[j0][1].y+h0*(3.0*dr.x*temp1-fdA2[j0][1].x)-fdA2[j0][1].x-dr.x*temp0);
					v_mem[i][1].y+=dr1*(h_j*(dr.y*fdA2[j0][1].y+temp1)+h0*(3.0*dr.y*temp1+fdA2[j0][1].y)-fdA2[j0][1].y-dr.y*temp0);
					v_mem[i][1].z+=dr1*(h_j*dr.z*fdA2[j0][1].y+h0*(3.0*dr.z*temp1-fdA2[j0][1].z)-fdA2[j0][1].z-dr.z*temp0);
					temp0=fdA2[j0][2].x*dr.x+fdA2[j0][2].y*dr.y+fdA2[j0][2].z*dr.z;
					temp1=fdA2[j0][2].x*dr.x-fdA2[j0][2].y*dr.y+fdA2[j0][2].z*dr.z;
					v_mem[i][2].x+=dr1*(h_j*dr.x*fdA2[j0][2].y+h0*(3.0*dr.x*temp1-fdA2[j0][2].x)-fdA2[j0][2].x-dr.x*temp0);
					v_mem[i][2].y+=dr1*(h_j*(dr.y*fdA2[j0][2].y+temp1)+h0*(3.0*dr.y*temp1+fdA2[j0][2].y)-fdA2[j0][2].y-dr.y*temp0);
					v_mem[i][2].z+=dr1*(h_j*dr.z*fdA2[j0][2].y+h0*(3.0*dr.z*temp1-fdA2[j0][2].z)-fdA2[j0][2].z-dr.z*temp0);
					temp0=fdA2[j0][3].x*dr.x+fdA2[j0][3].y*dr.y+fdA2[j0][3].z*dr.z;
					temp1=fdA2[j0][3].x*dr.x-fdA2[j0][3].y*dr.y+fdA2[j0][3].z*dr.z;
					v_mem[i][3].x+=dr1*(h_j*dr.x*fdA2[j0][3].y+h0*(3.0*dr.x*temp1-fdA2[j0][3].x)-fdA2[j0][3].x-dr.x*temp0);
					v_mem[i][3].y+=dr1*(h_j*(dr.y*fdA2[j0][3].y+temp1)+h0*(3.0*dr.y*temp1+fdA2[j0][3].y)-fdA2[j0][3].y-dr.y*temp0);
					v_mem[i][3].z+=dr1*(h_j*dr.z*fdA2[j0][3].y+h0*(3.0*dr.z*temp1-fdA2[j0][3].z)-fdA2[j0][3].z-dr.z*temp0);
//calculating contribution of v[j] to v[i]
#ifdef VISCOSITY_CONTRAST
					drn=fdA2[j0][0].x*dr.x+fdA2[j0][0].y*dr.y+fdA2[j0][0].z*dr.z;
					drn*=dvdr;
					new_v4[i].x+=dr.x*drn;
					new_v4[i].y+=dr.y*drn;
					new_v4[i].z+=dr.z*drn;
#endif
				}
			}
		}
		dr.x=0.0;
		dr.y=r_mem[i].y+r_mem[i].y;
		dr.z=0.0;
		dr1=sqrt(dr.x*dr.x+dr.y*dr.y+dr.z*dr.z);
//		if(dr1>r_maxtemp+r_max[i]){
		if(1){
			dr1=1.0/dr1;
			dr.x*=dr1;
			dr.y*=dr1;
			dr.z*=dr1;
			h_j=r_mem[i].y*dr1;
			h_i=2.0*h_j;
			h0=h_i*h_j;
#ifdef VISCOSITY_CONTRAST
			dvdr=(v_mem_prev[i].x*dr.x+v_mem_prev[i].y*dr.y+v_mem_prev[i].z*dr.z)*dr1;
#endif
//calculating contribution of f[i] to v[i]
			temp0=fdA[i][1].x*dr.x+fdA[i][1].y*dr.y+fdA[i][1].z*dr.z;
			temp1=fdA[i][1].x*dr.x-fdA[i][1].y*dr.y+fdA[i][1].z*dr.z;
			v_mem[i][1].x+=dr1*(h_i*dr.x*fdA[i][1].y+h0*(3.0*dr.x*temp1-fdA[i][1].x)-fdA[i][1].x-dr.x*temp0);
			v_mem[i][1].y+=dr1*(h_i*(dr.y*fdA[i][1].y+temp1)+h0*(3.0*dr.y*temp1+fdA[i][1].y)-fdA[i][1].y-dr.y*temp0);
			v_mem[i][1].z+=dr1*(h_i*dr.z*fdA[i][1].y+h0*(3.0*dr.z*temp1-fdA[i][1].z)-fdA[i][1].z-dr.z*temp0);
			temp0=fdA[i][2].x*dr.x+fdA[i][2].y*dr.y+fdA[i][2].z*dr.z;
			temp1=fdA[i][2].x*dr.x-fdA[i][2].y*dr.y+fdA[i][2].z*dr.z;
			v_mem[i][2].x+=dr1*(h_i*dr.x*fdA[i][2].y+h0*(3.0*dr.x*temp1-fdA[i][2].x)-fdA[i][2].x-dr.x*temp0);
			v_mem[i][2].y+=dr1*(h_i*(dr.y*fdA[i][2].y+temp1)+h0*(3.0*dr.y*temp1+fdA[i][2].y)-fdA[i][2].y-dr.y*temp0);
			v_mem[i][2].z+=dr1*(h_i*dr.z*fdA[i][2].y+h0*(3.0*dr.z*temp1-fdA[i][2].z)-fdA[i][2].z-dr.z*temp0);
			temp0=fdA[i][3].x*dr.x+fdA[i][3].y*dr.y+fdA[i][3].z*dr.z;
			temp1=fdA[i][3].x*dr.x-fdA[i][3].y*dr.y+fdA[i][3].z*dr.z;
			v_mem[i][3].x+=dr1*(h_i*dr.x*fdA[i][3].y+h0*(3.0*dr.x*temp1-fdA[i][3].x)-fdA[i][3].x-dr.x*temp0);
			v_mem[i][3].y+=dr1*(h_i*(dr.y*fdA[i][3].y+temp1)+h0*(3.0*dr.y*temp1+fdA[i][3].y)-fdA[i][3].y-dr.y*temp0);
			v_mem[i][3].z+=dr1*(h_i*dr.z*fdA[i][3].y+h0*(3.0*dr.z*temp1-fdA[i][3].z)-fdA[i][3].z-dr.z*temp0);
#ifdef VISCOSITY_CONTRAST
			drn=fdA[i][0].x*dr.x+fdA[i][0].y*dr.y+fdA[i][0].z*dr.z;
			drn*=dvdr;
			new_v4[i].x+=dr.x*drn;
			new_v4[i].y+=dr.y*drn;
			new_v4[i].z+=dr.z*drn;
#endif
		}
		else {
			rho=dr1*r_co1;
			dr1=1.0/dr1;
			dr.x*=dr1;
			dr.y*=dr1;
			dr.z*=dr1;
			h_j=r_mem[i].y*dr1;
			h_i=2.0*h_j;
			h0=h_i*h_j;
#ifdef VISCOSITY_CONTRAST
			dvdr=(v_mem_prev[i].x*dr.x+v_mem_prev[i].y*dr.y+v_mem_prev[i].z*dr.z)*dr1;
#endif
			if(rho<1.0){
				w=W_DEF;
				dr1*=w;
			}
#ifdef VISCOSITY_CONTRAST
			dvdr*=dr1;
#endif
//calculating contribution of f[i] to v[i]
			temp0=fdA[i][1].x*dr.x+fdA[i][1].y*dr.y+fdA[i][1].z*dr.z;
			temp1=fdA[i][1].x*dr.x-fdA[i][1].y*dr.y+fdA[i][1].z*dr.z;
			v_mem[i][1].x+=dr1*(h_i*dr.x*fdA[i][1].y+h0*(3.0*dr.x*temp1-fdA[i][1].x)-fdA[i][1].x-dr.x*temp0);
			v_mem[i][1].y+=dr1*(h_i*(dr.y*fdA[i][1].y+temp1)+h0*(3.0*dr.y*temp1+fdA[i][1].y)-fdA[i][1].y-dr.y*temp0);
			v_mem[i][1].z+=dr1*(h_i*dr.z*fdA[i][1].y+h0*(3.0*dr.z*temp1-fdA[i][1].z)-fdA[i][1].z-dr.z*temp0);
			temp0=fdA[i][2].x*dr.x+fdA[i][2].y*dr.y+fdA[i][2].z*dr.z;
			temp1=fdA[i][2].x*dr.x-fdA[i][2].y*dr.y+fdA[i][2].z*dr.z;
			v_mem[i][2].x+=dr1*(h_i*dr.x*fdA[i][2].y+h0*(3.0*dr.x*temp1-fdA[i][2].x)-fdA[i][2].x-dr.x*temp0);
			v_mem[i][2].y+=dr1*(h_i*(dr.y*fdA[i][2].y+temp1)+h0*(3.0*dr.y*temp1+fdA[i][2].y)-fdA[i][2].y-dr.y*temp0);
			v_mem[i][2].z+=dr1*(h_i*dr.z*fdA[i][2].y+h0*(3.0*dr.z*temp1-fdA[i][2].z)-fdA[i][2].z-dr.z*temp0);
			temp0=fdA[i][3].x*dr.x+fdA[i][3].y*dr.y+fdA[i][3].z*dr.z;
			temp1=fdA[i][3].x*dr.x-fdA[i][3].y*dr.y+fdA[i][3].z*dr.z;
			v_mem[i][3].x+=dr1*(h_i*dr.x*fdA[i][3].y+h0*(3.0*dr.x*temp1-fdA[i][3].x)-fdA[i][3].x-dr.x*temp0);
			v_mem[i][3].y+=dr1*(h_i*(dr.y*fdA[i][3].y+temp1)+h0*(3.0*dr.y*temp1+fdA[i][3].y)-fdA[i][3].y-dr.y*temp0);
			v_mem[i][3].z+=dr1*(h_i*dr.z*fdA[i][3].y+h0*(3.0*dr.z*temp1-fdA[i][3].z)-fdA[i][3].z-dr.z*temp0);
#ifdef VISCOSITY_CONTRAST
			drn=fdA[i][0].x*dr.x+fdA[i][0].y*dr.y+fdA[i][0].z*dr.z;
			drn*=dvdr;
			new_v4[i].x+=dr.x*drn;
			new_v4[i].y+=dr.y*drn;
			new_v4[i].z+=dr.z*drn;
#endif
			for(i1=0;i1<Nslaves2[i];i1++){
				i0=slaves2[i][i1];
				dr.x=r_mem[i].x-r_mem2[i0].x;
				dr.y=r_mem[i].y+r_mem2[i0].y;
				dr.z=r_mem[i].z-r_mem2[i0].z;
				dr1=dr.x*dr.x+dr.y*dr.y+dr.z*dr.z;
				if(dr1>r_co2) continue;
				dr1=sqrt(dr1);
				rho=dr1*r_co1;
				dr1=1.0/dr1;
				dr.x*=dr1;
				dr.y*=dr1;
				dr.z*=dr1;
				h_i=r_mem[i].y*dr1;
				h_j=2.0*r_mem[i0].y*dr1;
				h0=h_i*h_j;
#ifdef VISCOSITY_CONTRAST
				dvdr=(v_mem_prev[i0].x*dr.x+v_mem_prev[i0].y*dr.y+v_mem_prev[i0].z*dr.z)*dr1;
#endif
				w=1.0-W_DEF;
				dr1*=w;
#ifdef VISCOSITY_CONTRAST
				dvdr*=dr1;
#endif
//calculating contribution of f2[i] to v[i]
				temp0=fdA2[i0][1].x*dr.x+fdA2[i0][1].y*dr.y+fdA2[i0][1].z*dr.z;
				temp1=fdA2[i0][1].x*dr.x-fdA2[i0][1].y*dr.y+fdA2[i0][1].z*dr.z;
				v_mem[i][1].x+=dr1*(h_j*dr.x*fdA2[i0][1].y+h0*(3.0*dr.x*temp1-fdA2[i0][1].x)-fdA2[i0][1].x-dr.x*temp0);
				v_mem[i][1].y+=dr1*(h_j*(dr.y*fdA2[i0][1].y+temp1)+h0*(3.0*dr.y*temp1+fdA2[i0][1].y)-fdA2[i0][1].y-dr.y*temp0);
				v_mem[i][1].z+=dr1*(h_j*dr.z*fdA2[i0][1].y+h0*(3.0*dr.z*temp1-fdA2[i0][1].z)-fdA2[i0][1].z-dr.z*temp0);
				temp0=fdA2[i0][2].x*dr.x+fdA2[i0][2].y*dr.y+fdA2[i0][2].z*dr.z;
				temp1=fdA2[i0][2].x*dr.x-fdA2[i0][2].y*dr.y+fdA2[i0][2].z*dr.z;
				v_mem[i][2].x+=dr1*(h_j*dr.x*fdA2[i0][2].y+h0*(3.0*dr.x*temp1-fdA2[i0][2].x)-fdA2[i0][2].x-dr.x*temp0);
				v_mem[i][2].y+=dr1*(h_j*(dr.y*fdA2[i0][2].y+temp1)+h0*(3.0*dr.y*temp1+fdA2[i0][2].y)-fdA2[i0][2].y-dr.y*temp0);
				v_mem[i][2].z+=dr1*(h_j*dr.z*fdA2[i0][2].y+h0*(3.0*dr.z*temp1-fdA2[i0][2].z)-fdA2[i0][2].z-dr.z*temp0);
				temp0=fdA2[i0][3].x*dr.x+fdA2[i0][3].y*dr.y+fdA2[i0][3].z*dr.z;
				temp1=fdA2[i0][3].x*dr.x-fdA2[i0][3].y*dr.y+fdA2[i0][3].z*dr.z;
				v_mem[i][3].x+=dr1*(h_j*dr.x*fdA2[i0][3].y+h0*(3.0*dr.x*temp1-fdA2[i0][3].x)-fdA2[i0][3].x-dr.x*temp0);
				v_mem[i][3].y+=dr1*(h_j*(dr.y*fdA2[i0][3].y+temp1)+h0*(3.0*dr.y*temp1+fdA2[i0][3].y)-fdA2[i0][3].y-dr.y*temp0);
				v_mem[i][3].z+=dr1*(h_j*dr.z*fdA2[i0][3].y+h0*(3.0*dr.z*temp1-fdA2[i0][3].z)-fdA2[i0][3].z-dr.z*temp0);
#ifdef VISCOSITY_CONTRAST
				drn=fdA2[i0][0].x*dr.x+fdA2[i0][0].y*dr.y+fdA2[i0][0].z*dr.z;
				drn*=dvdr;
				new_v4[i].x+=dr.x*drn;
				new_v4[i].y+=dr.y*drn;
				new_v4[i].z+=dr.z*drn;
#endif
			}
		}
	}
	for(i=0;i<NMEM;i++) {
//first velocity
#ifdef VISCOSITY_CONTRAST
		v_mem0[i][1].x+=cst*(eta0*v_mem[i][1].x+eta1*new_v4[i].x);
		v_mem0[i][1].y+=cst*(eta0*v_mem[i][1].y+eta1*new_v4[i].y);
		v_mem0[i][1].z+=cst*(eta0*v_mem[i][1].z+eta1*new_v4[i].z);
#else
		v_mem0[i][1].x+=eta0*v_mem[i][1].x;
		v_mem0[i][1].y+=eta0*v_mem[i][1].y;
		v_mem0[i][1].z+=eta0*v_mem[i][1].z;
#endif
//second velocity
#ifdef VISCOSITY_CONTRAST
		v_mem0[i][2].x+=cst*eta0*v_mem[i][2].x;
		v_mem0[i][2].y+=cst*eta0*v_mem[i][2].y;
		v_mem0[i][2].z+=cst*eta0*v_mem[i][2].z;
#else
		v_mem0[i][2].x+=eta0*v_mem[i][2].x;
		v_mem0[i][2].y+=eta0*v_mem[i][2].y;
		v_mem0[i][2].z+=eta0*v_mem[i][2].z;
#endif
//third velocity
#ifdef VISCOSITY_CONTRAST
		v_mem0[i][3].x+=cst*eta0*v_mem[i][3].x;
		v_mem0[i][3].y+=cst*eta0*v_mem[i][3].y;
		v_mem0[i][3].z+=cst*eta0*v_mem[i][3].z;
#else
		v_mem0[i][3].x+=eta0*v_mem[i][3].x;
		v_mem0[i][3].y+=eta0*v_mem[i][3].y;
		v_mem0[i][3].z+=eta0*v_mem[i][3].z;
#endif
	}
}

