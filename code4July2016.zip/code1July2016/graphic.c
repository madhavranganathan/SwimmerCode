#include "includes.h"

#ifdef use_windows

#define			NTRIANGL		10000
#define			BOXLX		(100.0*RAD)
#define			BOXLY		(100.0*RAD)
#define			BOXLZ		(100.0*RAD)


struct	faces {
		struct point	vertex[4];
		struct point    centre;
		struct point	perp;
		int		fill;
		char		color[10];
	     };

struct faces 	face[6];

struct point		view_temp;
struct triangle		*triang[NTRIANGL];
struct point		site[NMEM];


void	plot_ves( TB_viewer *view, TB_event *event, int triang_site[NTRIANG][3], struct point r_mem[],struct point v_mem[], int show_frame)
{

    int			i, j, itriang, ntriang, label;
    int			jord[NTRIANGL];

    double		fading, dist, dum, sum;
    struct point	tmp1, tmp2, tmp3, sun_dir, my_dir;

    int                 top, bottom;

    char		color[10], blabla[100];

    /* triangulation */

    sun_dir.x = +0.5*sqrt(2.0);
    sun_dir.y = 0.;
    sun_dir.z = -0.5*sqrt(2.0);


    itriang =  ntriang = 0;

    for (i=0;i<NTRIANG;i++) {
        alloc_triang(r_mem[triang_site[i][0]],
                     r_mem[triang_site[i][1]],
                     r_mem[triang_site[i][2]],
                         triang,&ntriang,&itriang);

    }

/*
    init_box();
    top = 1;
    bottom = 0;

    draw_box(bottom,&view,&event);
*/
    /*      trie des triangles  */

    for (i=0;i<itriang;i++) jord[i]=i;

    view_temp = view->pos;
    qsort(jord,itriang,sizeof jord[0],(int (*)(void *,void *)) compare_triangles);

    for (i=0;i<itriang;i++) {
        label = jord[i];
        sprintf(color,"#8888ff");

        /* just for fun ! */

        tmp1.x = triang[label]->vertex[1].x - triang[label]->vertex[0].x;
        tmp1.y = triang[label]->vertex[1].y - triang[label]->vertex[0].y;
        tmp1.z = triang[label]->vertex[1].z - triang[label]->vertex[0].z;
        tmp1 = normalize(tmp1);
        tmp2.x = triang[label]->vertex[2].x - triang[label]->vertex[0].x;
        tmp2.y = triang[label]->vertex[2].y - triang[label]->vertex[0].y;
        tmp2.z = triang[label]->vertex[2].z - triang[label]->vertex[0].z;
        tmp2 = normalize(tmp2);

        tmp1 = vecprod(tmp1,tmp2);

        tmp1 = normalize(tmp1);

        my_dir.x = my_dir.y = my_dir.z = 0.0;

#ifdef use_cavaliere
        my_dir.x = - view->pos.x;
        my_dir.y = - view->pos.y;
        my_dir.z = - view->pos.z;
#else

        for (j=0;j<triang[label]->nvertex;j++) {
            my_dir.x = my_dir.x + triang[label]->vertex[j].x;
            my_dir.y = my_dir.y + triang[label]->vertex[j].y;
            my_dir.z = my_dir.z + triang[label]->vertex[j].z;
        }
        my_dir.x = my_dir.x / (double)triang[label]->nvertex - view->pos.x;
        my_dir.y = my_dir.y / (double)triang[label]->nvertex - view->pos.y;
        my_dir.z = my_dir.z / (double)triang[label]->nvertex - view->pos.z;
#endif

        if (dotprod(my_dir,tmp1) < 0.0) {
            tmp1.x = -tmp1.x;
            tmp1.y = -tmp1.y;
            tmp1.z = -tmp1.z;
        }
/*
                if (dotprod(tmp1,sun_dir) > 0.0) {

                    tmp2.x = sun_dir.x + view->orient[2].x;
                    tmp2.y = sun_dir.y + view->orient[2].y;
                    tmp2.z = sun_dir.z + view->orient[2].z;
                    tmp2 = normalize(tmp2);

                    fading = 0.5 + 0.5*(1.0 - fabs(dotprod(tmp1,tmp2)));
                }
                else fading = 0.3;
*/

        if ((dum=dotprod(tmp1,sun_dir)) > -0.2) {

            tmp2.x = -sun_dir.x+2.0*dum*tmp1.x;
            tmp2.y = -sun_dir.y+2.0*dum*tmp1.y;
            tmp2.z = -sun_dir.z+2.0*dum*tmp1.z;

            tmp2 = normalize(tmp2);

            tmp3 = normalize(my_dir);

            fading = 0.3 + 0.7*(dotprod(tmp3,tmp2)+1.0)*0.5;

        }
        else fading = 0.3;

/*
        tmp2.x = triang[label]->test.x - triang[label]->vertex[0].x;
        tmp2.y = triang[label]->test.y - triang[label]->vertex[0].y;
        tmp2.z = triang[label]->test.z - triang[label]->vertex[0].z;
        (void) periodic(&tmp2);

        if (dotprod(tmp1,tmp2)<0.0) {
            if(triang[label]->value >0.0) sprintf(color,"#8888ff");
            else sprintf(color,"#ff0000");
        }
        else {
            if(triang[label]->value >0.0) sprintf(color,"#ff0000");
            else sprintf(color,"#8888ff");
        }
*/

        sprintf(color,"#333333");//sprintf(color,"#8888ff");
        draw_triangle(view,event,triang[label],color,fading);

        if (show_frame) {
           sprintf(color,"#ffffff");
           draw_triangle_frame(view,event,triang[label],color,fading);
        }
    }


        if(!event->lock) {
            sprintf(color,"#eeee99");

            DrawLine(&view,&event,0.5*view->width-100.0,0.5*view->height,
            		      0.5*view->width+100.0,0.5*view->height,color);

            DrawLine(&view,&event,0.5*view->width,0.5*view->height-100.0,
            		      0.5*view->width,0.5*view->height+100.0,color);
        }





}

void	plot_map( TB_viewer *view, TB_event *event, int triang_site[NTRIANG][3], struct point r_mem[], double aux[], int show_frame)
{

    int			i, j, itriang, ntriang, label;
    int			jord[NTRIANGL];

    double		fading, dist, dum, sum;
    struct point	tmp1, tmp2, tmp3, sun_dir, my_dir;

    int                 top, bottom;

    char		color[10], color1[10], color2[10], blabla[100];

    double		l_min, l_max, value, lamb;


    l_min =  1.e+10;
    l_max = -1.e+10;

    for (i=0;i<NMEM;i++) {

        value = aux[i];
        if (value>l_max) l_max = value;
        if (value<l_min) l_min = value;

    }

    fprintf(stderr," min = %e max = %e\n",l_min,l_max);

    sprintf(color1,"#0000aa");
    sprintf(color2,"#ffee33");



   /* triangulation */

    itriang =  ntriang = 0;

    for (i=0;i<NTRIANG;i++) {
        alloc_triang(r_mem[triang_site[i][0]],
                     r_mem[triang_site[i][1]],
                     r_mem[triang_site[i][2]],
                         triang,&ntriang,&itriang);

    }

/*
    init_box();
    top = 1;
    bottom = 0;

    draw_box(bottom,&view,&event);
*/
    /*      trie des triangles  */

    for (i=0;i<itriang;i++) jord[i]=i;

    view_temp = view->pos;
    qsort(jord,itriang,sizeof jord[0],(int (*)(void *,void *)) compare_triangles);

    for (i=0;i<itriang;i++) {
        label = jord[i];

        value = (aux[triang_site[label][0]] + aux[triang_site[label][1]] + aux[triang_site[label][2]])/3.0;
        lamb = (value - l_min)/(l_max - l_min);
        interpolate_color(color1,color2,lamb,color);
        draw_triangle(view,event,triang[label],color,1.0);

        if (show_frame) {
           sprintf(color,"#ffffff");
           draw_triangle_frame(view,event,triang[label],color,fading);
        }
    }


        if(!event->lock) {
            sprintf(color,"#eeee99");

            DrawLine(&view,&event,0.5*view->width-100.0,0.5*view->height,
            		      0.5*view->width+100.0,0.5*view->height,color);

            DrawLine(&view,&event,0.5*view->width,0.5*view->height-100.0,
            		      0.5*view->width,0.5*view->height+100.0,color);
        }





}


void	plot_triang_map( TB_viewer *view, TB_event *event, int triang_site[NTRIANG][3], struct point r_mem[], double aux[], int show_frame)
{

    int			i, j, itriang, ntriang, label;
    int			jord[NTRIANGL];

    double		fading, dist, dum, sum;
    struct point	tmp1, tmp2, tmp3, sun_dir, my_dir;

    int                 top, bottom;

    char		color[10], color1[10], color2[10], blabla[100];

    double		l_min, l_max, value, lamb;


    l_min =  1.e+10;
    l_max = -1.e+10;

    for (i=0;i<NTRIANG;i++) {

        value = aux[i];
        if (value>l_max) l_max = value;
        if (value<l_min) l_min = value;

    }

    fprintf(stderr," min = %e max = %e\n",l_min,l_max);

    sprintf(color1,"#0000aa");
    sprintf(color2,"#ffee33");



   /* triangulation */

    itriang =  ntriang = 0;

    for (i=0;i<NTRIANG;i++) {
        alloc_triang(r_mem[triang_site[i][0]],
                     r_mem[triang_site[i][1]],
                     r_mem[triang_site[i][2]],
                         triang,&ntriang,&itriang);

    }

/*
    init_box();
    top = 1;
    bottom = 0;

    draw_box(bottom,&view,&event);
*/
    /*      trie des triangles  */

    for (i=0;i<itriang;i++) jord[i]=i;

    view_temp = view->pos;
    qsort(jord,itriang,sizeof jord[0],(int (*)(void *,void *)) compare_triangles);

    for (i=0;i<itriang;i++) {
        label = jord[i];

        value = aux[label];
        lamb = (value - l_min)/(l_max - l_min);
        interpolate_color(color1,color2,lamb,color);
        draw_triangle(view,event,triang[label],color,1.0);

        if (show_frame) {
           sprintf(color,"#ffffff");
           draw_triangle_frame(view,event,triang[label],color,fading);
        }
    }


        if(!event->lock) {
            sprintf(color,"#eeee99");

            DrawLine(&view,&event,0.5*view->width-100.0,0.5*view->height,
            		      0.5*view->width+100.0,0.5*view->height,color);

            DrawLine(&view,&event,0.5*view->width,0.5*view->height-100.0,
            		      0.5*view->width,0.5*view->height+100.0,color);
        }





}



void	plot_sites( TB_viewer *view, TB_event *event, struct point r_mem[], double aux[])
{

    int			i, j, label;
    int			jord[NMEM];
    TB_sphere		sphere[NMEM];

    char		color[10], color1[10], color2[10];

    double		l_min, l_max, value, lamb;

    rand_vec_1 = normalized_rand_vec();
    rand_vec_2 = normalized_rand_vec();

    l_min =  1.e+10;
    l_max = -1.e+10;

    for (i=0;i<NMEM;i++) {

        value = aux[i];
        if (value>l_max) l_max = value;
        if (value<l_min) l_min = value;

        site[i] = r_mem[i];

    }

    fprintf(stderr," min = %e max = %e\n",l_min,l_max);

    sprintf(color1,"#0000aa");
    sprintf(color2,"#ffee33");

    /*      trie des points  */

    for (i=0;i<NMEM;i++) jord[i]=i;

    view_temp = view->pos;
    qsort(jord,NMEM,sizeof jord[0],(int (*)(void *,void *)) compare_sites);

    for (i=0;i<NMEM;i++) {
        label = jord[i];
        value = aux[label];
        lamb = (value - l_min)/(l_max - l_min);
        interpolate_color(color1,color2,lamb,color);
        sphere[label].drawit=1;
        draw_sphere(&sphere[label],site[label],0.08*RAD,color,view,event,1.0);

    }
}


void	plot_wall( TB_viewer *view, TB_event *event, struct point r_wall[],struct point v_wall[], int show_frame)
{

    int			i, j, itriang, ntriang, label;
    int			jord[NTRIANGL];

    double		fading, dist, dum, sum;
    struct point	tmp1, tmp2, tmp3, sun_dir, my_dir;

    int                 top, bottom;

    char		color[10], blabla[100];

    /* triangulation */

    sun_dir.x = +0.5*sqrt(2.0);
    sun_dir.y = 0.;
    sun_dir.z = -0.5*sqrt(2.0);


    itriang =  ntriang = 0;

    for (i=0;i<NX-1;i++) {
    for (j=0;j<NY-1;j++) {

        alloc_triang(r_wall[site_label_wall(i,j)],
                     r_wall[site_label_wall(i,j+1)],
                     r_wall[site_label_wall(i+1,j+1)],
                         triang,&ntriang,&itriang);

        alloc_triang(r_wall[site_label_wall(i,j)],
                     r_wall[site_label_wall(i+1,j)],
                     r_wall[site_label_wall(i+1,j+1)],
                         triang,&ntriang,&itriang);

    }
    }



    /*      trie des triangles  */

    for (i=0;i<itriang;i++) jord[i]=i;

    view_temp = view->pos;
    qsort(jord,itriang,sizeof jord[0],(int (*)(void *,void *)) compare_triangles);

    for (i=0;i<itriang;i++) {
        label = jord[i];
        sprintf(color,"#ffff88");

        /* just for fun ! */

        tmp1.x = triang[label]->vertex[1].x - triang[label]->vertex[0].x;
        tmp1.y = triang[label]->vertex[1].y - triang[label]->vertex[0].y;
        tmp1.z = triang[label]->vertex[1].z - triang[label]->vertex[0].z;
        tmp1 = normalize(tmp1);
        tmp2.x = triang[label]->vertex[2].x - triang[label]->vertex[0].x;
        tmp2.y = triang[label]->vertex[2].y - triang[label]->vertex[0].y;
        tmp2.z = triang[label]->vertex[2].z - triang[label]->vertex[0].z;
        tmp2 = normalize(tmp2);

        tmp1 = vecprod(tmp1,tmp2);

        tmp1 = normalize(tmp1);

        my_dir.x = my_dir.y = my_dir.z = 0.0;

#ifdef use_cavaliere
        my_dir.x = - view->pos.x;
        my_dir.y = - view->pos.y;
        my_dir.z = - view->pos.z;
#else

        for (j=0;j<triang[label]->nvertex;j++) {
            my_dir.x = my_dir.x + triang[label]->vertex[j].x;
            my_dir.y = my_dir.y + triang[label]->vertex[j].y;
            my_dir.z = my_dir.z + triang[label]->vertex[j].z;
        }
        my_dir.x = my_dir.x / (double)triang[label]->nvertex - view->pos.x;
        my_dir.y = my_dir.y / (double)triang[label]->nvertex - view->pos.y;
        my_dir.z = my_dir.z / (double)triang[label]->nvertex - view->pos.z;
#endif

        if (dotprod(my_dir,tmp1) < 0.0) {
            tmp1.x = -tmp1.x;
            tmp1.y = -tmp1.y;
            tmp1.z = -tmp1.z;
        }
/*
                if (dotprod(tmp1,sun_dir) > 0.0) {

                    tmp2.x = sun_dir.x + view->orient[2].x;
                    tmp2.y = sun_dir.y + view->orient[2].y;
                    tmp2.z = sun_dir.z + view->orient[2].z;
                    tmp2 = normalize(tmp2);

                    fading = 0.5 + 0.5*(1.0 - fabs(dotprod(tmp1,tmp2)));
                }
                else fading = 0.3;
*/

        if ((dum=dotprod(tmp1,sun_dir)) > -0.2) {

            tmp2.x = -sun_dir.x+2.0*dum*tmp1.x;
            tmp2.y = -sun_dir.y+2.0*dum*tmp1.y;
            tmp2.z = -sun_dir.z+2.0*dum*tmp1.z;

            tmp2 = normalize(tmp2);

            tmp3 = normalize(my_dir);

            fading = 0.3 + 0.7*(dotprod(tmp3,tmp2)+1.0)*0.5;

        }
        else fading = 0.3;

/*
        tmp2.x = triang[label]->test.x - triang[label]->vertex[0].x;
        tmp2.y = triang[label]->test.y - triang[label]->vertex[0].y;
        tmp2.z = triang[label]->test.z - triang[label]->vertex[0].z;
        (void) periodic(&tmp2);

        if (dotprod(tmp1,tmp2)<0.0) {
            if(triang[label]->value >0.0) sprintf(color,"#8888ff");
            else sprintf(color,"#ff0000");
        }
        else {
            if(triang[label]->value >0.0) sprintf(color,"#ff0000");
            else sprintf(color,"#8888ff");
        }
*/

        sprintf(color,"#8888ff");
        draw_triangle(view,event,triang[label],color,fading);

        if (show_frame) {
           sprintf(color,"#ffffff");
           draw_triangle_frame(view,event,triang[label],color,fading);
        }
    }


        if(!event->lock) {
            sprintf(color,"#eeee99");

            DrawLine(&view,&event,0.5*view->width-100.0,0.5*view->height,
            		      0.5*view->width+100.0,0.5*view->height,color);

            DrawLine(&view,&event,0.5*view->width,0.5*view->height-100.0,
            		      0.5*view->width,0.5*view->height+100.0,color);
        }





}

void	alloc_triang(struct point as, struct point bs, struct point cs,
	             struct triangle *triang[], int *ntriang, int *itriang)
{
    struct point	tmp,shift1,shift2;
    struct point	poly[10],poly_ref[10];
    int			nvertex,i,j,k,l;
    int			forget_x,forget_y,forget_z,ii[8],jj[8],kk[8],n;



    poly_ref[0] = as;

    tmp.x = bs.x - as.x;
    tmp.y = bs.y - as.y;
    tmp.z = bs.z - as.z;
    shift1 = periodic(&tmp);
    tmp.x = as.x + tmp.x;
    tmp.y = as.y + tmp.y;
    tmp.z = as.z + tmp.z;

    poly_ref[1] = tmp;

    tmp.x = cs.x - as.x;
    tmp.y = cs.y - as.y;
    tmp.z = cs.z - as.z;
    shift2 = periodic(&tmp);
    tmp.x = as.x + tmp.x;
    tmp.y = as.y + tmp.y;
    tmp.z = as.z + tmp.z;

    poly_ref[2] = tmp;

    if (shift1.x==0.0) shift1.x = shift2.x;
    if (shift1.y==0.0) shift1.y = shift2.y;
    if (shift1.z==0.0) shift1.z = shift2.z;

    forget_x = forget_y = forget_z = 0;
    if (shift1.x==0.0) forget_x = 1;
    if (shift1.y==0.0) forget_y = 1;
    if (shift1.z==0.0) forget_z = 1;


    if (forget_x && forget_y && forget_z) {
        ii[0] = jj[0] = kk[0] = 0;
        n = 1;
    }
    else if (forget_x && forget_y){
        n = 0;
        for (i=0;i<2;i++) {
            ii[n  ] = 0;
            jj[n  ] = 0;
            kk[n++] = i;
        }
    }
    else if (forget_x && forget_z){
        n = 0;
        for (i=0;i<2;i++) {
            ii[n  ] = 0;
            jj[n  ] = i;
            kk[n++] = 0;
        }
    }
    else if (forget_y && forget_z){
        n = 0;
        for (i=0;i<2;i++) {
            ii[n  ] = i;
            jj[n  ] = 0;
            kk[n++] = 0;
        }
    }
    else if (forget_x){
        n = 0;
        for (i=0;i<2;i++) {
        for (j=0;j<2;j++) {
            ii[n  ] = 0;
            jj[n  ] = i;
            kk[n++] = j;
        }
        }
    }
    else if (forget_y){
        n = 0;
        for (i=0;i<2;i++) {
        for (j=0;j<2;j++) {
            ii[n  ] = i;
            jj[n  ] = 0;
            kk[n++] = j;
        }
        }
    }
    else if (forget_z){
        n = 0;
        for (i=0;i<2;i++) {
        for (j=0;j<2;j++) {
            ii[n  ] = i;
            jj[n  ] = j;
            kk[n++] = 0;
        }
        }
    }
    else {
        n = 0;
        for (i=0;i<2;i++) {
        for (j=0;j<2;j++) {
        for (k=0;k<2;k++) {
            ii[n  ] = i;
            jj[n  ] = j;
            kk[n++] = k;
        }
        }
        }
    }


    for (i=0;i<n;i++) {

        for (l=0;l<3;l++) {
            poly[l].x = poly_ref[l].x - ii[i]*shift1.x;
            poly[l].y = poly_ref[l].y - jj[i]*shift1.y;
            poly[l].z = poly_ref[l].z - kk[i]*shift1.z;
        }

        if (*itriang >= *ntriang) {

            if (*ntriang >= NTRIANGL) {
                fprintf(stderr," not enough space to store all triangles\n");
                fprintf(stderr," increase the value of NTRIANGL\n");

                exit(1);
            }
            else  {
                triang[(*ntriang)++] =
                      (struct triangle *) malloc(sizeof(struct triangle));

            }
        }

        nvertex = 3;
        get_triang(poly,&nvertex);

        if (nvertex>0) {
            for(j=0;j<nvertex;j++) triang[*itriang]->vertex[j] = poly[j];
            triang[(*itriang)++]->nvertex = nvertex;
        }

    }




}

struct point  periodic(struct point *r)
{
    struct point  tmp, boxl;

    boxl.x = BOXLX;
    boxl.y = BOXLY;
    boxl.z = BOXLZ;

    tmp.x = tmp.y = tmp.z = 0.0;

    while (r->x < -0.5*boxl.x) {
        r->x = r->x + boxl.x;
        tmp.x = tmp.x + boxl.x;
    }
    while (r->y < -0.5*boxl.y) {
        r->y = r->y + boxl.y;
        tmp.y = tmp.y + boxl.y;
    }
    while (r->z < -0.5*boxl.z) {
        r->z = r->z + boxl.z;
        tmp.z = tmp.z + boxl.z;
    }
    while (r->x >= 0.5*boxl.x) {
        r->x = r->x - boxl.x;
        tmp.x = tmp.x - boxl.x;
    }
    while (r->y >= 0.5*boxl.y) {
        r->y = r->y - boxl.y;
        tmp.y = tmp.y - boxl.y;
    }
    while (r->z >= 0.5*boxl.z) {
        r->z = r->z - boxl.z;
        tmp.z = tmp.z - boxl.z;
    }


    return tmp;

}


void	get_triang(struct point poly[], int *nvertex)
{
    struct point	tmp[10], boxl;
    int 		i, j, n, jnext;
    double 		d1, d2, ai;

    boxl.x = BOXLX;
    boxl.y = BOXLY;
    boxl.z = BOXLZ;



    for ( i=0 ; i<2 && *nvertex!=0 ; i++) {

	n = 0;
        d1 = 0.5*boxl.x + (2*i-1) * poly[0].x ;

	for ( j=0 ; j<*nvertex ; j++ ) {

	    if ( d1 >= 0 ) tmp[n++] = poly[j];

	    jnext = j+1;
	    if ( jnext == *nvertex ) jnext=0;

            d2 = 0.5*boxl.x + (2*i-1) * poly[jnext].x ;

	    if( d2*d1 < 0.0 ) {

		ai = d2/(d2-d1);
		tmp[n].x   = ai * poly[j].x + (1.0-ai) * poly[jnext].x ;
		tmp[n].y   = ai * poly[j].y + (1.0-ai) * poly[jnext].y ;
		tmp[n++].z = ai * poly[j].z + (1.0-ai) * poly[jnext].z ;

	    }

	    d1 = d2;

	}

	for ( j=0 ; j<n ; j++ ) poly[j] = tmp[j];
	*nvertex = n;

    }




    for ( i=0 ; i<2 && *nvertex!=0 ; i++) {

	n = 0;
        d1 = 0.5*boxl.y + (2*i-1) * poly[0].y ;

	for ( j=0 ; j<*nvertex ; j++ ) {

	    if ( d1 >= 0 ) tmp[n++] = poly[j];

	    jnext = j+1;
	    if ( jnext == *nvertex ) jnext=0;

            d2 = 0.5*boxl.y + (2*i-1) * poly[jnext].y ;

	    if( d2*d1 < 0.0 ) {

		ai = d2/(d2-d1);
		tmp[n].x   = ai * poly[j].x + (1.0-ai) * poly[jnext].x ;
		tmp[n].y   = ai * poly[j].y + (1.0-ai) * poly[jnext].y ;
		tmp[n++].z = ai * poly[j].z + (1.0-ai) * poly[jnext].z ;

	    }

	    d1 = d2;

	}

	for ( j=0 ; j<n ; j++ ) poly[j] = tmp[j];
	*nvertex = n;

    }


    for ( i=0 ; i<2 && *nvertex!=0 ; i++) {

	n = 0;
        d1 = 0.5*boxl.z + (2*i-1) * poly[0].z ;

	for ( j=0 ; j<*nvertex ; j++ ) {

	    if ( d1 >= 0 ) tmp[n++] = poly[j];

	    jnext = j+1;
	    if ( jnext == *nvertex ) jnext=0;

            d2 = 0.5*boxl.z + (2*i-1) * poly[jnext].z ;

	    if( d2*d1 < 0.0 ) {

		ai = d2/(d2-d1);
		tmp[n].x   = ai * poly[j].x + (1.0-ai) * poly[jnext].x ;
		tmp[n].y   = ai * poly[j].y + (1.0-ai) * poly[jnext].y ;
		tmp[n++].z = ai * poly[j].z + (1.0-ai) * poly[jnext].z ;

	    }

	    d1 = d2;

	}

	for ( j=0 ; j<n ; j++ ) poly[j] = tmp[j];
	*nvertex = n;

    }
}






int compare_triangles(int *i1, int *i2)
{
    double 		d1, d2;
    struct point	tmp;
    int			i,n;

    n = triang[*i1]->nvertex;
    tmp.x = 0.0;
    for(i=0;i<n;i++) tmp.x = tmp.x + triang[*i1]->vertex[i].x;
    tmp.y = 0.0;
    for(i=0;i<n;i++) tmp.y = tmp.y + triang[*i1]->vertex[i].y;
    tmp.z = 0.0;
    for(i=0;i<n;i++) tmp.z = tmp.z + triang[*i1]->vertex[i].z;


    tmp.x = tmp.x/(double) n - view_temp.x;
    tmp.y = tmp.y/(double) n - view_temp.y;
    tmp.z = tmp.z/(double) n - view_temp.z;

    d1 = - dotprod(tmp,tmp);

    n = triang[*i2]->nvertex;
    tmp.x = 0.0;
    for(i=0;i<n;i++) tmp.x = tmp.x + triang[*i2]->vertex[i].x;
    tmp.y = 0.0;
    for(i=0;i<n;i++) tmp.y = tmp.y + triang[*i2]->vertex[i].y;
    tmp.z = 0.0;
    for(i=0;i<n;i++) tmp.z = tmp.z + triang[*i2]->vertex[i].z;

    tmp.x = tmp.x/(double) n - view_temp.x;
    tmp.y = tmp.y/(double) n - view_temp.y;
    tmp.z = tmp.z/(double) n - view_temp.z;

    d2 = - dotprod(tmp,tmp);

    if     (d1<d2) return -1;
    else if(d1>d2) return +1;
    else           return 0;
}


int compare_sites(int *i1, int *i2)
{
    double 		d1, d2;
    struct point	tmp;


    tmp.x = site[*i1].x - view_temp.x;
    tmp.y = site[*i1].y - view_temp.y;
    tmp.z = site[*i1].z - view_temp.z;

    d1 = - dotprod(tmp,tmp);

    tmp.x = site[*i2].x - view_temp.x;
    tmp.y = site[*i2].y - view_temp.y;
    tmp.z = site[*i2].z - view_temp.z;

    d2 = - dotprod(tmp,tmp);

    if     (d1<d2) return -1;
    else if(d1>d2) return +1;
    else           return 0;
}


void init_box()
{
    struct point	coin[8];

    coin[0].x = -0.5*BOXLX;
    coin[0].y = -0.5*BOXLY;
    coin[0].z = -0.5*BOXLZ;

    coin[1].x =  0.5*BOXLX;
    coin[1].y = -0.5*BOXLY;
    coin[1].z = -0.5*BOXLZ;

    coin[2].x =  0.5*BOXLX;
    coin[2].y =  0.5*BOXLY;
    coin[2].z = -0.5*BOXLZ;

    coin[3].x = -0.5*BOXLX;
    coin[3].y =  0.5*BOXLY;
    coin[3].z = -0.5*BOXLZ;

    coin[4].x = -0.5*BOXLX;
    coin[4].y = -0.5*BOXLY;
    coin[4].z =  0.5*BOXLZ;

    coin[5].x =  0.5*BOXLX;
    coin[5].y = -0.5*BOXLY;
    coin[5].z =  0.5*BOXLZ;

    coin[6].x =  0.5*BOXLX;
    coin[6].y =  0.5*BOXLY;
    coin[6].z =  0.5*BOXLZ;

    coin[7].x = -0.5*BOXLX;
    coin[7].y =  0.5*BOXLY;
    coin[7].z =  0.5*BOXLZ;


    face[0].vertex[0] = coin[0];
    face[0].vertex[1] = coin[1];
    face[0].vertex[2] = coin[2];
    face[0].vertex[3] = coin[3];

    face[0].perp.x = 0.0;
    face[0].perp.y = 0.0;
    face[0].perp.z = -1.0;
    face[0].centre.x = 0.0;
    face[0].centre.y = 0.0;
    face[0].centre.z = -0.5*BOXLZ;

#ifdef walls
    face[0].fill = 1;
    sprintf(face[0].color,"#eeee99");
#else
    face[0].fill = 0;
#endif

    face[1].vertex[0] = coin[4];
    face[1].vertex[1] = coin[5];
    face[1].vertex[2] = coin[6];
    face[1].vertex[3] = coin[7];

    face[1].perp.x = 0.0;
    face[1].perp.y = 0.0;
    face[1].perp.z = 1.0;
    face[1].centre.x = 0.0;
    face[1].centre.y = 0.0;
    face[1].centre.z = 0.5*BOXLZ;

#ifdef walls
    face[1].fill = 1;
    sprintf(face[1].color,"#eeee99");
#else
    face[1].fill = 0;
#endif


    face[2].vertex[0] = coin[0];
    face[2].vertex[1] = coin[1];
    face[2].vertex[2] = coin[5];
    face[2].vertex[3] = coin[4];

    face[2].perp.x = 0.0;
    face[2].perp.y = -1.0;
    face[2].perp.z = 0.0;
    face[2].centre.x = 0.0;
    face[2].centre.y = -0.5*BOXLY;
    face[2].centre.z = 0.0;

    face[2].fill = 0;

    face[3].vertex[0] = coin[3];
    face[3].vertex[1] = coin[2];
    face[3].vertex[2] = coin[6];
    face[3].vertex[3] = coin[7];

    face[3].perp.x = 0.0;
    face[3].perp.y = 1.0;
    face[3].perp.z = 0.0;
    face[3].centre.x = 0.0;
    face[3].centre.y = 0.5*BOXLY;
    face[3].centre.z = 0.0;

    face[3].fill = 0;

    face[4].vertex[0] = coin[0];
    face[4].vertex[1] = coin[3];
    face[4].vertex[2] = coin[7];
    face[4].vertex[3] = coin[4];

    face[4].perp.x = -1.0;
    face[4].perp.y = 0.0;
    face[4].perp.z = 0.0;
    face[4].centre.x = -0.5*BOXLX;
    face[4].centre.y = 0.0;
    face[4].centre.z = 0.0;

    face[4].fill = 0;

    face[5].vertex[0] = coin[1];
    face[5].vertex[1] = coin[2];
    face[5].vertex[2] = coin[6];
    face[5].vertex[3] = coin[5];

    face[5].perp.x = 1.0;
    face[5].perp.y = 0.0;
    face[5].perp.z = 0.0;
    face[5].centre.x = 0.5*BOXLX;
    face[5].centre.y = 0.0;
    face[5].centre.z = 0.0;

    face[5].fill = 0;

}


void draw_box(int top, TB_viewer *view, TB_event *event)
{
    int			iface, drawit;
    int                 nvertex, ipt, i;
    struct point        poly[10], rpoly[10] ;
    XPoint              Xpoly[10] ;

    struct point	tmp;
    double		test;

    char                tmp_color[10];


    for (iface=0;iface<6;iface++) {


        drawit=0;

#ifdef use_cavaliere

        tmp.x = - view->pos.x;
        tmp.y = - view->pos.y;
        tmp.z = - view->pos.z;

#else

        tmp.x = face[iface].centre.x - view->pos.x;
        tmp.y = face[iface].centre.y - view->pos.y;
        tmp.z = face[iface].centre.z - view->pos.z;

#endif

        test = dotprod(tmp,face[iface].perp);
        if (top) { if(test<0.0) drawit=1; }
        else if(test>0.0) drawit=1;

        if (drawit) {

            nvertex = 4;

            for ( ipt=0 ; ipt < nvertex ; ipt++) {

                poly[ipt] = face[iface].vertex[ipt];
                poly[ipt].x = poly[ipt].x - view->pos.x;
                poly[ipt].y = poly[ipt].y - view->pos.y;
                poly[ipt].z = poly[ipt].z - view->pos.z;

            }
            poly[nvertex] = poly[0];
            nvertex = 5;

            get_poly(poly, &nvertex, view->planes);

            if (nvertex!=0) {

#ifdef use_cavaliere

                cavaliere(poly, nvertex, rpoly, (double) view->u.xcentre,(double) view->u.ycentre,
                                 view->echelle, view->orient);
#else
                conic(poly, nvertex, rpoly,(double) view->u.xcentre,(double) view->u.ycentre,
                                 view->echelle, view->orient);
#endif

                rpoly[nvertex] = rpoly[0];

                for (i=0;i<=nvertex;i++) {
                    Xpoly[i].x = (int) floor(rpoly[i].x);
                    Xpoly[i].y = (int) floor(rpoly[i].y);
                }

		if (face[iface].fill && !top) {

                    FillPolygon(view,event,rpoly,Xpoly,nvertex,face[iface].color);
                }

                sprintf(tmp_color,"#000000");

                DrawLines(view,event,rpoly,Xpoly,nvertex+1,tmp_color);

            }

        }

    }

}



void    init_my_default(struct point *pos, struct point orient[], double dist)
{
    struct point        view_dir;
    double              tmp, teta, phi;

/*    teta = -PI/2.0 + 0.01; */
    teta = 2.0*PI/4.0;
    phi  = 0.0;//2.0*PI/3.0;

    view_dir.x = sin(teta)*cos(phi);
    view_dir.y = sin(phi);
    view_dir.z = cos(teta);

/*
 *   view the xy plane
 */
/*
    view_dir.x = view_dir.y = 0.0;
    view_dir.z = -1.0;
*/
    orient[2] = view_dir;
    orient[1].x = 0.0;
    orient[1].y = -1.0;
    orient[1].z = 0.0;

/*
 *   view the xz plane
 */
/*
    view_dir.x = view_dir.z = 0.0;
    view_dir.y = -1.0;

    orient[2] = view_dir;
    orient[1].x = -1.0;
    orient[1].y = 0.0;
    orient[1].z = 0.0;
*/




    tmp = dotprod(orient[1],orient[2]);
    if (tmp < 1.0) {
        orient[1].x = orient[1].x - tmp * orient[2].x;
        orient[1].y = orient[1].y - tmp * orient[2].y;
        orient[1].z = orient[1].z - tmp * orient[2].z;
    }
    else {
        orient[1].x = orient[1].y = 0.0;
        orient[1].z = 1.0;
        tmp = dotprod(orient[1],orient[2]);
        orient[1].x = orient[1].x - tmp * orient[2].x;
        orient[1].y = orient[1].y - tmp * orient[2].y;
        orient[1].z = orient[1].z - tmp * orient[2].z;
    }
    orient[1] = normalize(orient[1]);
    orient[0] = vecprod(orient[1],orient[2]);

    pos->x = - dist * orient[2].x;
    pos->y = - dist * orient[2].y;
    pos->z = - dist * orient[2].z;

}
#endif
