#include "includes.h"

inline double DotProduct3D(struct point3D A,struct point3D B){
	return A.x*B.x+A.y*B.y+A.z*B.z;
}

inline void CrossProduct3D(struct point3D* result,struct point3D A,struct point3D B){
	result->x=A.y*B.z-A.z*B.y;
	result->y=A.z*B.x-A.x*B.z;
	result->z=A.x*B.y-A.y*B.x;
}

inline void smul3D(struct point3D* result, double A,struct point3D B){
	result->x=A*B.x;
	result->y=A*B.y;
	result->z=A*B.z;
}

inline void add3D(struct point3D* result, struct point3D A,struct point3D B){
	result->x=A.x+B.x;
	result->y=A.y+B.y;
	result->z=A.z+B.z;
}

inline void sub3D(struct point3D* result, struct point3D A,struct point3D B){
	result->x=A.x-B.x;
	result->y=A.y-B.y;
	result->z=A.z-B.z;
}

inline void smul3D2(struct point3D* result, double A){
	result->x*=A;
	result->y*=A;
	result->z*=A;
}

inline void add3D2(struct point3D* result, struct point3D A){
	result->x+=A.x;
	result->y+=A.y;
	result->z+=A.z;
}

inline void sub3D2(struct point3D* result, struct point3D A){
	result->x-=A.x;
	result->y-=A.y;
	result->z-=A.z;
}

double det2D(double m[2][2]){
	return m[0][0]*m[1][1]-m[0][1]*m[1][0];
}

void tangent_plane(int n, struct point3D points[], struct point3D* normal){
	gsl_matrix *M;
	gsl_matrix *E;
	gsl_vector *V;
	gsl_eigen_symmv_workspace *ws;
	double Atemp[3][3];
	struct point3D localz;

	int i,j,k,imin;

	if (n<5) {
		printf("not enough points for the tangent plane\n");
		exit(1);
	}
	if (n>6) {
		printf("too many points for the tangent plane\n");
		exit(1);
	}

	M=gsl_matrix_alloc(3,3);
	E=gsl_matrix_alloc(3,3);
	V=gsl_vector_alloc(3);
	ws=gsl_eigen_symmv_alloc(3);
	for(i=0;i<3;i++)for(j=0;j<3;j++)Atemp[i][j]=0.0;
	for(i=0;i<n;i++){
		Atemp[0][0]+=points[i].x*points[i].x;
		Atemp[1][1]+=points[i].y*points[i].y;
		Atemp[2][2]+=points[i].z*points[i].z;
		Atemp[1][0]+=points[i].y*points[i].x;
		Atemp[2][1]+=points[i].z*points[i].y;
		Atemp[0][2]+=points[i].x*points[i].z;
	}
	Atemp[0][1]=Atemp[1][0];
	Atemp[1][2]=Atemp[2][1];
	Atemp[2][0]=Atemp[0][2];
	for(i=0;i<3;i++)for(j=0;j<3;j++)gsl_matrix_set(M,i,j,Atemp[i][j]);
	gsl_eigen_symmv(M,V,E,ws);
	imin=gsl_vector_get(V,0)>gsl_vector_get(V,1)?1:0;
	imin=gsl_vector_get(V,imin)>gsl_vector_get(V,2)?2:imin;
	localz.x=gsl_matrix_get(E,0,imin);
	localz.y=gsl_matrix_get(E,1,imin);
	localz.z=gsl_matrix_get(E,2,imin);
	if(DotProduct3D(localz,*normal)>0.0)
		smul3D(normal,1.0,localz);
	else
		smul3D(normal,-1.0,localz);
	gsl_eigen_symmv_free(ws);
	gsl_matrix_free(M);
	gsl_matrix_free(E);
	gsl_vector_free(V);
}

void quadratic_interpolator(int n, struct point3D points[], struct point3D* normal, double* mean_curvature, double* gaussian_curvature)
{
	double s1[6];
	double s2[6];
	double temp1[6][5];
	struct point3D localx,localy;
	struct point3D dR[2];
	struct point3D ddR[2][2];
	double temp;
	double g[2][2];
	double h[2][2];
	double detg1;

	gsl_matrix *M;
	gsl_vector *V;

	int i,j,k;

	if (n<5) {
		printf("not enough points for the interpolation\n");
		exit(1);
	}
	if (n>6) {
		printf("too many points for the interpolation\n");
		exit(1);
	}


	M=gsl_matrix_alloc(5,5);
	V=gsl_vector_alloc(5);	

	temp=DotProduct3D(points[0],*normal);
	smul3D(&localx,-temp,*normal);
	add3D2(&localx,points[0]);
	temp=sqrt(DotProduct3D(localx,localx));
	smul3D2(&localx,1.0/temp);
	CrossProduct3D(&localy,*normal,localx);

	for(i=0;i<n;i++){
		s1[i]=DotProduct3D(localx,points[i]);
		s2[i]=DotProduct3D(localy,points[i]);
		temp1[i][0]=s1[i];
		temp1[i][1]=s2[i];
		temp1[i][2]=0.5*s1[i]*s1[i];
		temp1[i][3]=s1[i]*s2[i];
		temp1[i][4]=0.5*s2[i]*s2[i];
	}

	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].x*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].x=gsl_vector_get(V,0);
	dR[1].x=gsl_vector_get(V,1);
	ddR[0][0].x=gsl_vector_get(V,2);
	ddR[0][1].x=ddR[1][0].x=gsl_vector_get(V,3);
	ddR[1][1].x=gsl_vector_get(V,4);

	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].y*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].y=gsl_vector_get(V,0);
	dR[1].y=gsl_vector_get(V,1);
	ddR[0][0].y=gsl_vector_get(V,2);
	ddR[0][1].y=ddR[1][0].y=gsl_vector_get(V,3);
	ddR[1][1].y=gsl_vector_get(V,4);
	
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].z*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].z=gsl_vector_get(V,0);
	dR[1].z=gsl_vector_get(V,1);
	ddR[0][0].z=gsl_vector_get(V,2);
	ddR[0][1].z=ddR[1][0].z=gsl_vector_get(V,3);
	ddR[1][1].z=gsl_vector_get(V,4);

	CrossProduct3D(normal,dR[0],dR[1]);


	temp=sqrt(DotProduct3D(*normal,*normal));
	smul3D2(normal,1.0/temp);

	for(i=0;i<2;i++)
		for(j=0;j<2;j++){
			g[i][j]=DotProduct3D(dR[i],dR[j]);
			h[i][j]=DotProduct3D(ddR[i][j],*normal);
		}
	detg1=1.0/det2D(g);

	*gaussian_curvature=det2D(h)*detg1;
	*mean_curvature=0.5*(h[0][0]*g[1][1]+h[1][1]*g[0][0]-h[1][0]*g[0][1]-h[0][1]*g[1][0])*detg1;
	
	gsl_matrix_free(M);
	gsl_vector_free(V);	

}

void new_quadratic_interpolator(int n, struct point3D points[], struct point3D* normal, double* mean_curvature, double* gaussian_curvature, int slaves[], struct point3D r_mem2[NMEM2], struct point3D r_memtemp[NMEM2])
{
	double s1[6];
	double s2[6];
	double temp1[6][5];
	struct point3D localx,localy;
	struct point3D dR[2];
	struct point3D ddR[2][2];
	double temp;
	double g[2][2];
	double h[2][2];
	double detg1;
	double s1_slaves[6][3];
	double s2_slaves[6][3];
	double norm[3];

	gsl_matrix *M;
	gsl_vector *V;

	int i,j,k;

	if (n<5) {
		printf("not enough points for the interpolation\n");
		exit(1);
	}
	if (n>6) {
		printf("too many points for the interpolation\n");
		exit(1);
	}


	M=gsl_matrix_alloc(5,5);
	V=gsl_vector_alloc(5);	

	temp=DotProduct3D(points[0],*normal);
	smul3D(&localx,-temp,*normal);
	add3D2(&localx,points[0]);
	temp=sqrt(DotProduct3D(localx,localx));
	smul3D2(&localx,1.0/temp);
	CrossProduct3D(&localy,*normal,localx);

	for(i=0;i<n;i++){
		s1[i]=DotProduct3D(localx,points[i]);
		s2[i]=DotProduct3D(localy,points[i]);
		for(j=0;j<3;j++){
			s1_slaves[i][j]=DotProduct3D(localx,r_mem2[slaves[i+1+6*j]])-DotProduct3D(localx,r_mem2[slaves[0]]);
			s2_slaves[i][j]=DotProduct3D(localy,r_mem2[slaves[i+1+6*j]])-DotProduct3D(localy,r_mem2[slaves[0]]);
		}
		temp1[i][0]=s1[i];
		temp1[i][1]=s2[i];
		temp1[i][2]=0.5*s1[i]*s1[i];
		temp1[i][3]=s1[i]*s2[i];
		temp1[i][4]=0.5*s2[i]*s2[i];
	}
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].x*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].x=gsl_vector_get(V,0);
	dR[1].x=gsl_vector_get(V,1);
	ddR[0][0].x=gsl_vector_get(V,2);
	ddR[0][1].x=ddR[1][0].x=gsl_vector_get(V,3);
	ddR[1][1].x=gsl_vector_get(V,4);

	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].y*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].y=gsl_vector_get(V,0);
	dR[1].y=gsl_vector_get(V,1);
	ddR[0][0].y=gsl_vector_get(V,2);
	ddR[0][1].y=ddR[1][0].y=gsl_vector_get(V,3);
	ddR[1][1].y=gsl_vector_get(V,4);
	
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].z*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].z=gsl_vector_get(V,0);
	dR[1].z=gsl_vector_get(V,1);
	ddR[0][0].z=gsl_vector_get(V,2);
	ddR[0][1].z=ddR[1][0].z=gsl_vector_get(V,3);
	ddR[1][1].z=gsl_vector_get(V,4);

	CrossProduct3D(normal,dR[0],dR[1]);


	temp=sqrt(DotProduct3D(*normal,*normal));
	smul3D2(normal,1.0/temp);

	for(i=0;i<2;i++)
		for(j=0;j<2;j++){
			g[i][j]=DotProduct3D(dR[i],dR[j]);
			h[i][j]=DotProduct3D(ddR[i][j],*normal);
		}
	detg1=1.0/det2D(g);

	*gaussian_curvature=det2D(h)*detg1;
	*mean_curvature=0.5*(h[0][0]*g[1][1]+h[1][1]*g[0][0]-h[1][0]*g[0][1]-h[0][1]*g[1][0])*detg1;
	
	norm[0]=4.0/7.0;
	norm[1]=2.0/7.0;
	norm[2]=1.0/7.0;
	for(i=0;i<n;i++){
		for(j=0;j<3;j++){
			r_memtemp[slaves[i+1+j*6]].x+=(r_mem2[slaves[0]].x+dR[0].x*s1_slaves[i][j]+dR[1].x*s2_slaves[i][j]+0.5*(ddR[0][0].x*s1_slaves[i][j]*s1_slaves[i][j]+ddR[1][1].x*s2_slaves[i][j]*s2_slaves[i][j])+ddR[0][1].x*s1_slaves[i][j]*s2_slaves[i][j])*norm[j];
			r_memtemp[slaves[i+1+j*6]].y+=(r_mem2[slaves[0]].y+dR[0].y*s1_slaves[i][j]+dR[1].y*s2_slaves[i][j]+0.5*(ddR[0][0].y*s1_slaves[i][j]*s1_slaves[i][j]+ddR[1][1].y*s2_slaves[i][j]*s2_slaves[i][j])+ddR[0][1].y*s1_slaves[i][j]*s2_slaves[i][j])*norm[j];
			r_memtemp[slaves[i+1+j*6]].z+=(r_mem2[slaves[0]].z+dR[0].z*s1_slaves[i][j]+dR[1].z*s2_slaves[i][j]+0.5*(ddR[0][0].z*s1_slaves[i][j]*s1_slaves[i][j]+ddR[1][1].z*s2_slaves[i][j]*s2_slaves[i][j])+ddR[0][1].z*s1_slaves[i][j]*s2_slaves[i][j])*norm[j];
		}
	}
	r_memtemp[slaves[0]].x=r_mem2[slaves[0]].x;
	r_memtemp[slaves[0]].y=r_mem2[slaves[0]].y;
	r_memtemp[slaves[0]].z=r_mem2[slaves[0]].z;
	gsl_matrix_free(M);
	gsl_vector_free(V);
}

void new_quadratic_interpolator16(int n, struct point3D points[], struct point3D* normal, double* mean_curvature, double* gaussian_curvature, int slaves[], struct point3D r_mem2[NMEM2], struct point3D r_memtemp[NMEM2])
{
	double s1[6];
	double s2[6];
	double temp1[6][5];
	struct point3D localx,localy;
	struct point3D dR[2];
	struct point3D ddR[2][2];
	double temp;
	double g[2][2];
	double h[2][2];
	double detg1;
	double s1_slaves[6][3][3];
	double s2_slaves[6][3][3];
	double norm[3];

	gsl_matrix *M;
	gsl_vector *V;

	int i,j,k;

	if (n<5) {
		printf("not enough points for the interpolation\n");
		exit(1);
	}
	if (n>6) {
		printf("too many points for the interpolation\n");
		exit(1);
	}


	M=gsl_matrix_alloc(5,5);
	V=gsl_vector_alloc(5);	

	temp=DotProduct3D(points[0],*normal);
	smul3D(&localx,-temp,*normal);
	add3D2(&localx,points[0]);
	temp=sqrt(DotProduct3D(localx,localx));
	smul3D2(&localx,1.0/temp);
	CrossProduct3D(&localy,*normal,localx);
	for(i=0;i<n;i++){
		s1[i]=DotProduct3D(localx,points[i]);
		s2[i]=DotProduct3D(localy,points[i]);
		temp1[i][0]=s1[i];
		temp1[i][1]=s2[i];
		temp1[i][2]=0.5*s1[i]*s1[i];
		temp1[i][3]=s1[i]*s2[i];
		temp1[i][4]=0.5*s2[i]*s2[i];
		for(j=0;j<3;j++){
			for(k=0;k<=j;k++){
				s1_slaves[i][j][k]=DotProduct3D(localx,r_mem2[slaves[1+i+3*j*(j+1)+k*n]])-DotProduct3D(localx,r_mem2[slaves[0]]);
				s2_slaves[i][j][k]=DotProduct3D(localy,r_mem2[slaves[1+i+3*j*(j+1)+k*n]])-DotProduct3D(localy,r_mem2[slaves[0]]);
			}
		}
	}
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].x*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].x=gsl_vector_get(V,0);
	dR[1].x=gsl_vector_get(V,1);
	ddR[0][0].x=gsl_vector_get(V,2);
	ddR[0][1].x=ddR[1][0].x=gsl_vector_get(V,3);
	ddR[1][1].x=gsl_vector_get(V,4);

	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].y*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].y=gsl_vector_get(V,0);
	dR[1].y=gsl_vector_get(V,1);
	ddR[0][0].y=gsl_vector_get(V,2);
	ddR[0][1].y=ddR[1][0].y=gsl_vector_get(V,3);
	ddR[1][1].y=gsl_vector_get(V,4);
	
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].z*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].z=gsl_vector_get(V,0);
	dR[1].z=gsl_vector_get(V,1);
	ddR[0][0].z=gsl_vector_get(V,2);
	ddR[0][1].z=ddR[1][0].z=gsl_vector_get(V,3);
	ddR[1][1].z=gsl_vector_get(V,4);

	CrossProduct3D(normal,dR[0],dR[1]);


	temp=sqrt(DotProduct3D(*normal,*normal));
	smul3D2(normal,1.0/temp);

	for(i=0;i<2;i++)
		for(j=0;j<2;j++){
			g[i][j]=DotProduct3D(dR[i],dR[j]);
			h[i][j]=DotProduct3D(ddR[i][j],*normal);
		}
	detg1=1.0/det2D(g);

	*gaussian_curvature=det2D(h)*detg1;
	*mean_curvature=0.5*(h[0][0]*g[1][1]+h[1][1]*g[0][0]-h[1][0]*g[0][1]-h[0][1]*g[1][0])*detg1;
	
	norm[0]=0.75;
	norm[1]=0.5;
	norm[2]=0.25;
	for(i=0;i<n;i++){
		for(j=0;j<3;j++){
			for(k=0;k<=j;k++){
				r_memtemp[slaves[i+1+3*j*(j+1)+k*n]].x+=(dR[0].x*s1_slaves[i][j][k]+dR[1].x*s2_slaves[i][j][k]+0.5*(ddR[0][0].x*s1_slaves[i][j][k]*s1_slaves[i][j][k]+ddR[1][1].x*s2_slaves[i][j][k]*s2_slaves[i][j][k])+ddR[0][1].x*s1_slaves[i][j][k]*s2_slaves[i][j][k])*norm[j];
				r_memtemp[slaves[i+1+3*j*(j+1)+k*n]].y+=(dR[0].y*s1_slaves[i][j][k]+dR[1].y*s2_slaves[i][j][k]+0.5*(ddR[0][0].y*s1_slaves[i][j][k]*s1_slaves[i][j][k]+ddR[1][1].y*s2_slaves[i][j][k]*s2_slaves[i][j][k])+ddR[0][1].y*s1_slaves[i][j][k]*s2_slaves[i][j][k])*norm[j];
				r_memtemp[slaves[i+1+3*j*(j+1)+k*n]].z+=(dR[0].z*s1_slaves[i][j][k]+dR[1].z*s2_slaves[i][j][k]+0.5*(ddR[0][0].z*s1_slaves[i][j][k]*s1_slaves[i][j][k]+ddR[1][1].z*s2_slaves[i][j][k]*s2_slaves[i][j][k])+ddR[0][1].z*s1_slaves[i][j][k]*s2_slaves[i][j][k])*norm[j];
			}
		}
	}
	gsl_matrix_free(M);
	gsl_vector_free(V);
}

void new_force_interpolator16(int n, struct point3D points[], struct point3D forces[], struct point3D* normal, int slaves[], struct point3D r_mem2[NMEM2], struct point3D f_mem0[NMEM2][4],int kk)
{
	double s1[6];
	double s2[6];
	double temp1[6][5];
	struct point3D localx,localy;
	struct point3D dR[2];
	struct point3D ddR[2][2];
	double temp;
	double s1_slaves[6][3][3];
	double s2_slaves[6][3][3];
	double norm[3];

	gsl_matrix *M;
	gsl_vector *V;

	int i,j,k;

	if (n<5) {
		printf("not enough points for the interpolation\n");
		exit(1);
	}
	if (n>6) {
		printf("too many points for the interpolation\n");
		exit(1);
	}


	M=gsl_matrix_alloc(5,5);
	V=gsl_vector_alloc(5);	

	temp=DotProduct3D(points[0],*normal);
	smul3D(&localx,-temp,*normal);
	add3D2(&localx,points[0]);
	temp=sqrt(DotProduct3D(localx,localx));
	smul3D2(&localx,1.0/temp);
	CrossProduct3D(&localy,*normal,localx);
	for(i=0;i<n;i++){
		s1[i]=DotProduct3D(localx,points[i]);
		s2[i]=DotProduct3D(localy,points[i]);
		temp1[i][0]=s1[i];
		temp1[i][1]=s2[i];
		temp1[i][2]=0.5*s1[i]*s1[i];
		temp1[i][3]=s1[i]*s2[i];
		temp1[i][4]=0.5*s2[i]*s2[i];
		for(j=0;j<3;j++){
			for(k=0;k<=j;k++){
				s1_slaves[i][j][k]=DotProduct3D(localx,r_mem2[slaves[1+i+3*j*(j+1)+k*n]])-DotProduct3D(localx,r_mem2[slaves[0]]);
				s2_slaves[i][j][k]=DotProduct3D(localy,r_mem2[slaves[1+i+3*j*(j+1)+k*n]])-DotProduct3D(localy,r_mem2[slaves[0]]);
			}
		}
	}
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=forces[k].x*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].x=gsl_vector_get(V,0);
	dR[1].x=gsl_vector_get(V,1);
	ddR[0][0].x=gsl_vector_get(V,2);
	ddR[0][1].x=ddR[1][0].x=gsl_vector_get(V,3);
	ddR[1][1].x=gsl_vector_get(V,4);

	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=forces[k].y*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].y=gsl_vector_get(V,0);
	dR[1].y=gsl_vector_get(V,1);
	ddR[0][0].y=gsl_vector_get(V,2);
	ddR[0][1].y=ddR[1][0].y=gsl_vector_get(V,3);
	ddR[1][1].y=gsl_vector_get(V,4);
	
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=forces[k].z*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].z=gsl_vector_get(V,0);
	dR[1].z=gsl_vector_get(V,1);
	ddR[0][0].z=gsl_vector_get(V,2);
	ddR[0][1].z=ddR[1][0].z=gsl_vector_get(V,3);
	ddR[1][1].z=gsl_vector_get(V,4);
	
	norm[0]=0.75;
	norm[1]=0.5;
	norm[2]=0.25;
	for(i=0;i<n;i++){
		for(j=0;j<3;j++){
			for(k=0;k<=j;k++){
				f_mem0[slaves[i+1+3*j*(j+1)+k*n]][kk].x+=(dR[0].x*s1_slaves[i][j][k]+dR[1].x*s2_slaves[i][j][k]+0.5*(ddR[0][0].x*s1_slaves[i][j][k]*s1_slaves[i][j][k]+ddR[1][1].x*s2_slaves[i][j][k]*s2_slaves[i][j][k])+ddR[0][1].x*s1_slaves[i][j][k]*s2_slaves[i][j][k])*norm[j];
				f_mem0[slaves[i+1+3*j*(j+1)+k*n]][kk].y+=(dR[0].y*s1_slaves[i][j][k]+dR[1].y*s2_slaves[i][j][k]+0.5*(ddR[0][0].y*s1_slaves[i][j][k]*s1_slaves[i][j][k]+ddR[1][1].y*s2_slaves[i][j][k]*s2_slaves[i][j][k])+ddR[0][1].y*s1_slaves[i][j][k]*s2_slaves[i][j][k])*norm[j];
				f_mem0[slaves[i+1+3*j*(j+1)+k*n]][kk].z+=(dR[0].z*s1_slaves[i][j][k]+dR[1].z*s2_slaves[i][j][k]+0.5*(ddR[0][0].z*s1_slaves[i][j][k]*s1_slaves[i][j][k]+ddR[1][1].z*s2_slaves[i][j][k]*s2_slaves[i][j][k])+ddR[0][1].z*s1_slaves[i][j][k]*s2_slaves[i][j][k])*norm[j];
			}
		}
	}
	gsl_matrix_free(M);
	gsl_vector_free(V);
}

void new_velocity_interpolator16(int n, struct point3D points[], struct point3D forces[], struct point3D* normal, int slaves[], struct point3D r_mem2[NMEM2], struct point3D v_mem0[NMEM2])
{
	double s1[6];
	double s2[6];
	double temp1[6][5];
	struct point3D localx,localy;
	struct point3D dR[2];
	struct point3D ddR[2][2];
	double temp;
	double s1_slaves[6][3][3];
	double s2_slaves[6][3][3];
	double norm[3];

	gsl_matrix *M;
	gsl_vector *V;

	int i,j,k;

	if (n<5) {
		printf("not enough points for the interpolation\n");
		exit(1);
	}
	if (n>6) {
		printf("too many points for the interpolation\n");
		exit(1);
	}


	M=gsl_matrix_alloc(5,5);
	V=gsl_vector_alloc(5);	

	temp=DotProduct3D(points[0],*normal);
	smul3D(&localx,-temp,*normal);
	add3D2(&localx,points[0]);
	temp=sqrt(DotProduct3D(localx,localx));
	smul3D2(&localx,1.0/temp);
	CrossProduct3D(&localy,*normal,localx);
	for(i=0;i<n;i++){
		s1[i]=DotProduct3D(localx,points[i]);
		s2[i]=DotProduct3D(localy,points[i]);
		temp1[i][0]=s1[i];
		temp1[i][1]=s2[i];
		temp1[i][2]=0.5*s1[i]*s1[i];
		temp1[i][3]=s1[i]*s2[i];
		temp1[i][4]=0.5*s2[i]*s2[i];
		for(j=0;j<3;j++){
			for(k=0;k<=j;k++){
				s1_slaves[i][j][k]=DotProduct3D(localx,r_mem2[slaves[1+i+3*j*(j+1)+k*n]])-DotProduct3D(localx,r_mem2[slaves[0]]);
				s2_slaves[i][j][k]=DotProduct3D(localy,r_mem2[slaves[1+i+3*j*(j+1)+k*n]])-DotProduct3D(localy,r_mem2[slaves[0]]);
			}
		}
	}
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=forces[k].x*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].x=gsl_vector_get(V,0);
	dR[1].x=gsl_vector_get(V,1);
	ddR[0][0].x=gsl_vector_get(V,2);
	ddR[0][1].x=ddR[1][0].x=gsl_vector_get(V,3);
	ddR[1][1].x=gsl_vector_get(V,4);

	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=forces[k].y*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].y=gsl_vector_get(V,0);
	dR[1].y=gsl_vector_get(V,1);
	ddR[0][0].y=gsl_vector_get(V,2);
	ddR[0][1].y=ddR[1][0].y=gsl_vector_get(V,3);
	ddR[1][1].y=gsl_vector_get(V,4);
	
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=forces[k].z*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].z=gsl_vector_get(V,0);
	dR[1].z=gsl_vector_get(V,1);
	ddR[0][0].z=gsl_vector_get(V,2);
	ddR[0][1].z=ddR[1][0].z=gsl_vector_get(V,3);
	ddR[1][1].z=gsl_vector_get(V,4);
	
	norm[0]=0.75;
	norm[1]=0.5;
	norm[2]=0.25;
	for(i=0;i<n;i++){
		for(j=0;j<3;j++){
			for(k=0;k<=j;k++){
				v_mem0[slaves[i+1+3*j*(j+1)+k*n]].x+=(dR[0].x*s1_slaves[i][j][k]+dR[1].x*s2_slaves[i][j][k]+0.5*(ddR[0][0].x*s1_slaves[i][j][k]*s1_slaves[i][j][k]+ddR[1][1].x*s2_slaves[i][j][k]*s2_slaves[i][j][k])+ddR[0][1].x*s1_slaves[i][j][k]*s2_slaves[i][j][k])*norm[j];
				v_mem0[slaves[i+1+3*j*(j+1)+k*n]].y+=(dR[0].y*s1_slaves[i][j][k]+dR[1].y*s2_slaves[i][j][k]+0.5*(ddR[0][0].y*s1_slaves[i][j][k]*s1_slaves[i][j][k]+ddR[1][1].y*s2_slaves[i][j][k]*s2_slaves[i][j][k])+ddR[0][1].y*s1_slaves[i][j][k]*s2_slaves[i][j][k])*norm[j];
				v_mem0[slaves[i+1+3*j*(j+1)+k*n]].z+=(dR[0].z*s1_slaves[i][j][k]+dR[1].z*s2_slaves[i][j][k]+0.5*(ddR[0][0].z*s1_slaves[i][j][k]*s1_slaves[i][j][k]+ddR[1][1].z*s2_slaves[i][j][k]*s2_slaves[i][j][k])+ddR[0][1].z*s1_slaves[i][j][k]*s2_slaves[i][j][k])*norm[j];
			}
		}
	}
	gsl_matrix_free(M);
	gsl_vector_free(V);
}

void quartic_interpolator(int n, struct point3D points[], struct point3D* normal, double* mean_curvature, double* gaussian_curvature)
{
	double s1[18];
	double s2[18];
	double temp1[18][14];
	struct point3D localx,localy;
	struct point3D dR[2];
	struct point3D ddR[2][2];
	double temp;
	double g[2][2];
	double h[2][2];
	double detg1;
	gsl_matrix *M;
	gsl_vector *V;
	int i,j,k;

	if (n<14) {
		printf("not enough points for the interpolation\n");
		exit(1);
	}
	if (n>18) {
		printf("too many points for the interpolation\n");
		exit(1);
	}

	M=gsl_matrix_alloc(14,14);
	V=gsl_vector_alloc(14);	

	temp=DotProduct3D(points[0],*normal);
	smul3D(&localx,-temp,*normal);
	add3D2(&localx,points[0]);
	temp=sqrt(DotProduct3D(localx,localx));
	smul3D2(&localx,1.0/temp);
	CrossProduct3D(&localy,*normal,localx);

	for(i=0;i<n;i++){
		s1[i]=DotProduct3D(localx,points[i]);
		s2[i]=DotProduct3D(localy,points[i]);
		temp1[i][0]=s1[i];
		temp1[i][1]=s2[i];
		temp1[i][2]=0.5*s1[i]*s1[i];
		temp1[i][3]=s1[i]*s2[i];
		temp1[i][4]=0.5*s2[i]*s2[i];
		temp1[i][5]=s1[i]*s1[i]*s1[i];
		temp1[i][6]=s1[i]*s1[i]*s2[i];
		temp1[i][7]=s1[i]*s2[i]*s2[i];
		temp1[i][8]=s2[i]*s2[i]*s2[i];
		temp1[i][9]=s1[i]*s1[i]*s1[i]*s1[i];
		temp1[i][10]=s1[i]*s1[i]*s1[i]*s2[i];
		temp1[i][11]=s1[i]*s1[i]*s2[i]*s2[i];
		temp1[i][12]=s1[i]*s2[i]*s2[i]*s2[i];
		temp1[i][13]=s2[i]*s2[i]*s2[i]*s2[i];
	}

	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].x*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].x=gsl_vector_get(V,0);
	dR[1].x=gsl_vector_get(V,1);
	ddR[0][0].x=gsl_vector_get(V,2);
	ddR[0][1].x=ddR[1][0].x=gsl_vector_get(V,3);
	ddR[1][1].x=gsl_vector_get(V,4);

	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].y*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].y=gsl_vector_get(V,0);
	dR[1].y=gsl_vector_get(V,1);
	ddR[0][0].y=gsl_vector_get(V,2);
	ddR[0][1].y=ddR[1][0].y=gsl_vector_get(V,3);
	ddR[1][1].y=gsl_vector_get(V,4);
	
	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].z*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].z=gsl_vector_get(V,0);
	dR[1].z=gsl_vector_get(V,1);
	ddR[0][0].z=gsl_vector_get(V,2);
	ddR[0][1].z=ddR[1][0].z=gsl_vector_get(V,3);
	ddR[1][1].z=gsl_vector_get(V,4);

	CrossProduct3D(normal,dR[0],dR[1]);


	temp=sqrt(DotProduct3D(*normal,*normal));
	smul3D2(normal,1.0/temp);

	for(i=0;i<2;i++)
		for(j=0;j<2;j++){
			g[i][j]=DotProduct3D(dR[i],dR[j]);
			h[i][j]=DotProduct3D(ddR[i][j],*normal);
		}
	detg1=1.0/det2D(g);

	*gaussian_curvature=det2D(h)*detg1;
	*mean_curvature=0.5*(h[0][0]*g[1][1]+h[1][1]*g[0][0]-h[1][0]*g[0][1]-h[0][1]*g[1][0])*detg1;
	
	gsl_matrix_free(M);
	gsl_vector_free(V);	

}

void new_surface_gradient(int n, struct point3D points[], double a[], struct point3D* normal,struct point3D* gradsa)
{
	double s1[6];
	double s2[6];
	double temp1[6][5];
	struct point3D localx,localy,dR[2],ddR[2][2];
	double temp,da[2],dda[2][2];
	double g[2][2];
	double g1[2][2];
	double detg1;
	
	gsl_matrix *M;
	gsl_vector *V;
	int i,j,k;

	if (n<5) {
		printf("not enough points for the interpolation\n");
		exit(1);
	}
	if (n>6) {
		printf("too many points for the interpolation\n");
		exit(1);
	}

	M=gsl_matrix_alloc(5,5);
	V=gsl_vector_alloc(5);	

	temp=DotProduct3D(points[0],*normal);
	smul3D(&localx,-temp,*normal);
	add3D2(&localx,points[0]);
	temp=sqrt(DotProduct3D(localx,localx));
	smul3D2(&localx,1.0/temp);
	CrossProduct3D(&localy,*normal,localx);

	for(i=0;i<n;i++){
		s1[i]=DotProduct3D(localx,points[i]);
		s2[i]=DotProduct3D(localy,points[i]);
		temp1[i][0]=s1[i];
		temp1[i][1]=s2[i];
		temp1[i][2]=0.5*s1[i]*s1[i];
		temp1[i][3]=s1[i]*s2[i];
		temp1[i][4]=0.5*s2[i]*s2[i];
	}
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].x*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].x=gsl_vector_get(V,0);
	dR[1].x=gsl_vector_get(V,1);
	ddR[0][0].x=gsl_vector_get(V,2);
	ddR[1][0].x=ddR[0][1].x=gsl_vector_get(V,3);
	ddR[1][1].x=gsl_vector_get(V,4);

	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].y*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].y=gsl_vector_get(V,0);
	dR[1].y=gsl_vector_get(V,1);
	ddR[0][0].y=gsl_vector_get(V,2);
	ddR[1][0].y=ddR[0][1].y=gsl_vector_get(V,3);
	ddR[1][1].y=gsl_vector_get(V,4);
	
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].z*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].z=gsl_vector_get(V,0);
	dR[1].z=gsl_vector_get(V,1);
	ddR[0][0].z=gsl_vector_get(V,2);
	ddR[1][0].z=ddR[0][1].z=gsl_vector_get(V,3);
	ddR[1][1].z=gsl_vector_get(V,4);
//	for(i=0;i<5;i++)printf("%f\t",gsl_vector_get(V,i));
//	printf("\n");

	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=a[k]*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	da[0]=gsl_vector_get(V,0);
	da[1]=gsl_vector_get(V,1);
	dda[0][0]=gsl_vector_get(V,2);
	dda[1][0]=dda[0][1]=gsl_vector_get(V,3);
	dda[1][1]=gsl_vector_get(V,4);

//	for(i=0;i<5;i++)printf("%f\t",gsl_vector_get(V,i));
//	printf("\n");
	for(i=0;i<2;i++)
		for(j=0;j<2;j++)
			g[i][j]=DotProduct3D(dR[i],dR[j]);
	
	detg1=1.0/det2D(g);

	g1[0][0]=g[1][1]*detg1;
	g1[1][1]=g[0][0]*detg1;
	g1[1][0]=-g[0][1]*detg1;
	g1[0][1]=-g[1][0]*detg1;

	gradsa->x=0.0;
	gradsa->y=0.0;
	gradsa->z=0.0;

	for(i=0;i<2;i++)
		for(j=0;j<2;j++){
			gradsa->x+=g1[i][j]*dR[i].x*da[j];
			gradsa->y+=g1[i][j]*dR[i].y*da[j];
			gradsa->z+=g1[i][j]*dR[i].z*da[j];
		}

	gsl_matrix_free(M);
	gsl_vector_free(V);	
	
}

void new_interpolate(int n, struct point3D points[], double a[], struct point3D* normal, int slaves[], struct point3D r_mem2[NMEM2], double zeta2[NMEM2])
{
	double s1[6];
	double s2[6];
	double temp1[6][5];
	struct point3D localx,localy;
	double temp,da[2],dda[2][2];
	double s1_slaves[6];
	double s2_slaves[6];
	
	gsl_matrix *M;
	gsl_vector *V;
	int i,j,k;

	if (n<5) {
		printf("not enough points for the interpolation\n");
		exit(1);
	}
	if (n>6) {
		printf("too many points for the interpolation\n");
		exit(1);
	}

	M=gsl_matrix_alloc(5,5);
	V=gsl_vector_alloc(5);	

	temp=DotProduct3D(points[0],*normal);
	smul3D(&localx,-temp,*normal);
	add3D2(&localx,points[0]);
	temp=sqrt(DotProduct3D(localx,localx));
	smul3D2(&localx,1.0/temp);
	CrossProduct3D(&localy,*normal,localx);

	for(i=0;i<n;i++){
		s1_slaves[i]=DotProduct3D(localx,r_mem2[slaves[i+1]])-DotProduct3D(localx,r_mem2[slaves[0]]);
		s2_slaves[i]=DotProduct3D(localy,r_mem2[slaves[i+1]])-DotProduct3D(localy,r_mem2[slaves[0]]);
		s1[i]=DotProduct3D(localx,points[i]);
		s2[i]=DotProduct3D(localy,points[i]);
		temp1[i][0]=s1[i];
		temp1[i][1]=s2[i];
		temp1[i][2]=0.5*s1[i]*s1[i];
		temp1[i][3]=s1[i]*s2[i];
		temp1[i][4]=0.5*s2[i]*s2[i];
	}
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=a[k]*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	da[0]=gsl_vector_get(V,0);
	da[1]=gsl_vector_get(V,1);
	dda[0][0]=gsl_vector_get(V,2);
	dda[1][0]=dda[0][1]=gsl_vector_get(V,3);
	dda[1][1]=gsl_vector_get(V,4);

	for(i=0;i<n;i++){
		zeta2[slaves[i+1]]=zeta2[slaves[0]]+da[0]*s1_slaves[i]+da[1]*s2_slaves[i]+0.5*(dda[0][0]*s1_slaves[i]*s1_slaves[i]+dda[1][1]*s2_slaves[i]*s2_slaves[i])+dda[0][1]*s1_slaves[i]*s2_slaves[i];
	}


	gsl_matrix_free(M);
	gsl_vector_free(V);	
	
}

void new_surface_gradient2(int n, struct point3D points[], double a[], struct point3D* normal,struct point3D* gradsa)
{
	double s1[18];
	double s2[18];
	double temp1[18][14];
	struct point3D localx,localy,dR[2];
	double temp,da[2],dda[2][2];
	double g[2][2];
	double g1[2][2];
	double detg1;
//	double zetar,chi2,dz2;
	
	gsl_matrix *M;
	gsl_vector *V;
	int i,j,k;

	if (n<14) {
		printf("not enough points for the interpolation\n");
		exit(1);
	}
	if (n>18) {
		printf("too many points for the interpolation\n");
		exit(1);
	}

	M=gsl_matrix_alloc(14,14);
	V=gsl_vector_alloc(14);	

	temp=DotProduct3D(points[0],*normal);
	smul3D(&localx,-temp,*normal);
	add3D2(&localx,points[0]);
	temp=sqrt(DotProduct3D(localx,localx));
	smul3D2(&localx,1.0/temp);
	CrossProduct3D(&localy,*normal,localx);

	for(i=0;i<n;i++){
		s1[i]=DotProduct3D(localx,points[i]);
		s2[i]=DotProduct3D(localy,points[i]);
		temp1[i][0]=s1[i];
		temp1[i][1]=s2[i];
		temp1[i][2]=0.5*s1[i]*s1[i];
		temp1[i][3]=s1[i]*s2[i];
		temp1[i][4]=0.5*s2[i]*s2[i];
		temp1[i][5]=s1[i]*s1[i]*s1[i];
		temp1[i][6]=s1[i]*s1[i]*s2[i];
		temp1[i][7]=s1[i]*s2[i]*s2[i];
		temp1[i][8]=s2[i]*s2[i]*s2[i];
		temp1[i][9]=s1[i]*s1[i]*s1[i]*s1[i];
		temp1[i][10]=s1[i]*s1[i]*s1[i]*s2[i];
		temp1[i][11]=s1[i]*s1[i]*s2[i]*s2[i];
		temp1[i][12]=s1[i]*s2[i]*s2[i]*s2[i];
		temp1[i][13]=s2[i]*s2[i]*s2[i]*s2[i];
	}

	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].x*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].x=gsl_vector_get(V,0);
	dR[1].x=gsl_vector_get(V,1);

	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].y*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].y=gsl_vector_get(V,0);
	dR[1].y=gsl_vector_get(V,1);
	
	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].z*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].z=gsl_vector_get(V,0);
	dR[1].z=gsl_vector_get(V,1);

	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=a[k]*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	da[0]=gsl_vector_get(V,0);
	da[1]=gsl_vector_get(V,1);
/*	chi2=0.0;
	dz2=0.0;
	for(i=0;i<n;i++) {
		zetar=-a[i];
		for(j=0;j<14;j++) zetar+=temp1[i][j]*gsl_vector_get(V,j);
		chi2+=zetar*zetar;
		dz2+=a[i]*a[i];
	}
//	for(i=0;i<14;i++)printf("%f\t",gsl_vector_get(V,i));
	printf("%f\t%f\n",sqrt(chi2),sqrt(dz2));*/
	for(i=0;i<2;i++)
		for(j=0;j<2;j++)
			g[i][j]=DotProduct3D(dR[i],dR[j]);
	
	detg1=1.0/det2D(g);

	g1[0][0]=g[1][1]*detg1;
	g1[1][1]=g[0][0]*detg1;
	g1[1][0]=-g[0][1]*detg1;
	g1[0][1]=-g[1][0]*detg1;

	gradsa->x=0.0;
	gradsa->y=0.0;
	gradsa->z=0.0;

	for(i=0;i<2;i++)
		for(j=0;j<2;j++){
			gradsa->x+=g1[i][j]*dR[i].x*da[j];
			gradsa->y+=g1[i][j]*dR[i].y*da[j];
			gradsa->z+=g1[i][j]*dR[i].z*da[j];
		}

	gsl_matrix_free(M);
	gsl_vector_free(V);	
	
}

void new_surface_laplacian(int n, struct point3D points[], double a[], struct point3D* normal,double* lap_sa)
{
	double s1[6];
	double s2[6];
	double temp1[6][5];
	struct point3D localx,localy,dR[2],ddR[2][2];
	double temp,da[2],dda[2][2];
	double g[2][2];
	double g1[2][2];
	double detg1;
	double g1dda;
	struct point3D g1ddR;
	struct point3D gradsa;
	
	gsl_matrix *M;
	gsl_vector *V;
	int i,j,k;

	if (n<5) {
		printf("not enough points for the interpolation\n");
		exit(1);
	}
	if (n>6) {
		printf("too many points for the interpolation\n");
		exit(1);
	}

	M=gsl_matrix_alloc(5,5);
	V=gsl_vector_alloc(5);	

	temp=DotProduct3D(points[0],*normal);
	smul3D(&localx,-temp,*normal);
	add3D2(&localx,points[0]);
	temp=sqrt(DotProduct3D(localx,localx));
	smul3D2(&localx,1.0/temp);
	CrossProduct3D(&localy,*normal,localx);

	for(i=0;i<n;i++){
		s1[i]=DotProduct3D(localx,points[i]);
		s2[i]=DotProduct3D(localy,points[i]);
		temp1[i][0]=s1[i];
		temp1[i][1]=s2[i];
		temp1[i][2]=0.5*s1[i]*s1[i];
		temp1[i][3]=s1[i]*s2[i];
		temp1[i][4]=0.5*s2[i]*s2[i];
	}
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].x*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].x=gsl_vector_get(V,0);
	dR[1].x=gsl_vector_get(V,1);
	ddR[0][0].x=gsl_vector_get(V,2);
	ddR[1][0].x=ddR[0][1].x=gsl_vector_get(V,3);
	ddR[1][1].x=gsl_vector_get(V,4);

	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].y*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].y=gsl_vector_get(V,0);
	dR[1].y=gsl_vector_get(V,1);
	ddR[0][0].y=gsl_vector_get(V,2);
	ddR[1][0].y=ddR[0][1].y=gsl_vector_get(V,3);
	ddR[1][1].y=gsl_vector_get(V,4);
	
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].z*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].z=gsl_vector_get(V,0);
	dR[1].z=gsl_vector_get(V,1);
	ddR[0][0].z=gsl_vector_get(V,2);
	ddR[1][0].z=ddR[0][1].z=gsl_vector_get(V,3);
	ddR[1][1].z=gsl_vector_get(V,4);

	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=a[k]*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	da[0]=gsl_vector_get(V,0);
	da[1]=gsl_vector_get(V,1);
	dda[0][0]=gsl_vector_get(V,2);
	dda[1][0]=dda[0][1]=gsl_vector_get(V,3);
	dda[1][1]=gsl_vector_get(V,4);

	for(i=0;i<2;i++)
		for(j=0;j<2;j++)
			g[i][j]=DotProduct3D(dR[i],dR[j]);
	
	detg1=1.0/det2D(g);

	g1[0][0]=g[1][1]*detg1;
	g1[1][1]=g[0][0]*detg1;
	g1[1][0]=-g[0][1]*detg1;
	g1[0][1]=-g[1][0]*detg1;

	gradsa.x=0.0;
	gradsa.y=0.0;
	gradsa.z=0.0;

	for(i=0;i<2;i++){
		for(j=0;j<2;j++){
			gradsa.x+=g1[i][j]*dR[i].x*da[j];
			gradsa.y+=g1[i][j]*dR[i].y*da[j];
			gradsa.z+=g1[i][j]*dR[i].z*da[j];
		}
	}
	g1ddR.x=0.0;
	g1ddR.y=0.0;
	g1ddR.z=0.0;
	for(i=0;i<2;i++){
		for(j=0;j<2;j++){
			g1ddR.x+=g1[i][j]*ddR[i][j].x;
			g1ddR.y+=g1[i][j]*ddR[i][j].y;
			g1ddR.z+=g1[i][j]*ddR[i][j].z;
		}
	}
	g1dda=0.0;
	for(i=0;i<2;i++){
		for(j=0;j<2;j++){
			g1dda+=g1[i][j]*dda[i][j];
		}
	}
//	printf("%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n",g1[0][0],g1[0][1],g1[1][0],g1[1][1],dda[0][0],dda[0][1],dda[1][0],dda[1][1]);
//	printf("%f\t%f\t%f\t%f\n",dda[0][0],dda[0][1],dda[1][0],dda[1][1]);
//	printf("%f\t%f\t%f\t%f\t%f\t%f\t%f\n",gradsa.x,gradsa.y,gradsa.z,g1ddR.x,g1ddR.y,g1ddR.z,DotProduct3D(g1ddR,gradsa));
//	printf("%f\t%f\n",g1dda,DotProduct3D(g1ddR,gradsa));
	*lap_sa=g1dda-DotProduct3D(g1ddR,gradsa);
	gsl_matrix_free(M);
	gsl_vector_free(V);	
	
}

void new_surface_laplacian2(int n, struct point3D points[], double a[], struct point3D* normal,double* lap_sa)
{
	double s1[18];
	double s2[18];
	double temp1[18][14];
	struct point3D localx,localy,dR[2],ddR[2][2];
	double temp,da[2],dda[2][2];
	double g[2][2];
	double g1[2][2];
	double detg1;
	double g1dda;
	struct point3D g1ddR;
	struct point3D gradsa;
	
	gsl_matrix *M;
	gsl_vector *V;
	int i,j,k;

	if (n<14) {
		printf("not enough points for the interpolation\n");
		exit(1);
	}
	if (n>18) {
		printf("too many points for the interpolation\n");
		exit(1);
	}

	M=gsl_matrix_alloc(14,14);
	V=gsl_vector_alloc(14);	

	temp=DotProduct3D(points[0],*normal);
	smul3D(&localx,-temp,*normal);
	add3D2(&localx,points[0]);
	temp=sqrt(DotProduct3D(localx,localx));
	smul3D2(&localx,1.0/temp);
	CrossProduct3D(&localy,*normal,localx);

	for(i=0;i<n;i++){
		s1[i]=DotProduct3D(localx,points[i]);
		s2[i]=DotProduct3D(localy,points[i]);
		temp1[i][0]=s1[i];
		temp1[i][1]=s2[i];
		temp1[i][2]=0.5*s1[i]*s1[i];
		temp1[i][3]=s1[i]*s2[i];
		temp1[i][4]=0.5*s2[i]*s2[i];
		temp1[i][5]=s1[i]*s1[i]*s1[i];
		temp1[i][6]=s1[i]*s1[i]*s2[i];
		temp1[i][7]=s1[i]*s2[i]*s2[i];
		temp1[i][8]=s2[i]*s2[i]*s2[i];
		temp1[i][9]=s1[i]*s1[i]*s1[i]*s1[i];
		temp1[i][10]=s1[i]*s1[i]*s1[i]*s2[i];
		temp1[i][11]=s1[i]*s1[i]*s2[i]*s2[i];
		temp1[i][12]=s1[i]*s2[i]*s2[i]*s2[i];
		temp1[i][13]=s2[i]*s2[i]*s2[i]*s2[i];
	}
	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].x*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].x=gsl_vector_get(V,0);
	dR[1].x=gsl_vector_get(V,1);
	ddR[0][0].x=gsl_vector_get(V,2);
	ddR[1][0].x=ddR[0][1].x=gsl_vector_get(V,3);
	ddR[1][1].x=gsl_vector_get(V,4);

	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].y*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].y=gsl_vector_get(V,0);
	dR[1].y=gsl_vector_get(V,1);
	ddR[0][0].y=gsl_vector_get(V,2);
	ddR[1][0].y=ddR[0][1].y=gsl_vector_get(V,3);
	ddR[1][1].y=gsl_vector_get(V,4);
	
	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].z*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].z=gsl_vector_get(V,0);
	dR[1].z=gsl_vector_get(V,1);
	ddR[0][0].z=gsl_vector_get(V,2);
	ddR[1][0].z=ddR[0][1].z=gsl_vector_get(V,3);
	ddR[1][1].z=gsl_vector_get(V,4);

	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=a[k]*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	da[0]=gsl_vector_get(V,0);
	da[1]=gsl_vector_get(V,1);
	dda[0][0]=gsl_vector_get(V,2);
	dda[1][0]=dda[0][1]=gsl_vector_get(V,3);
	dda[1][1]=gsl_vector_get(V,4);
	for(i=0;i<2;i++)
		for(j=0;j<2;j++)
			g[i][j]=DotProduct3D(dR[i],dR[j]);
	
	detg1=1.0/det2D(g);

	g1[0][0]=g[1][1]*detg1;
	g1[1][1]=g[0][0]*detg1;
	g1[1][0]=-g[0][1]*detg1;
	g1[0][1]=-g[1][0]*detg1;

	gradsa.x=0.0;
	gradsa.y=0.0;
	gradsa.z=0.0;

	for(i=0;i<2;i++){
		for(j=0;j<2;j++){
			gradsa.x+=g1[i][j]*dR[i].x*da[j];
			gradsa.y+=g1[i][j]*dR[i].y*da[j];
			gradsa.z+=g1[i][j]*dR[i].z*da[j];
		}
	}
	g1ddR.x=0.0;
	g1ddR.y=0.0;
	g1ddR.z=0.0;
	for(i=0;i<2;i++){
		for(j=0;j<2;j++){
			g1ddR.x+=g1[i][j]*ddR[i][j].x;
			g1ddR.y+=g1[i][j]*ddR[i][j].y;
			g1ddR.z+=g1[i][j]*ddR[i][j].z;
		}
	}
	g1dda=0.0;
	for(i=0;i<2;i++){
		for(j=0;j<2;j++){
			g1dda+=g1[i][j]*dda[i][j];
		}
	}
//	printf("%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n",g1[0][0],g1[0][1],g1[1][0],g1[1][1],dda[0][0],dda[0][1],dda[1][0],dda[1][1]);
//	printf("%f\t%f\t%f\t%f\n",dda[0][0],dda[0][1],dda[1][0],dda[1][1]);
//	printf("%f\t%f\t%f\t%f\t%f\t%f\t%f\n",gradsa.x,gradsa.y,gradsa.z,g1ddR.x,g1ddR.y,g1ddR.z,DotProduct3D(g1ddR,gradsa));
//	printf("%f\t%f\n",g1dda,DotProduct3D(g1ddR,gradsa));
	*lap_sa=g1dda-DotProduct3D(g1ddR,gradsa);
	gsl_matrix_free(M);
	gsl_vector_free(V);	
	
}

void new_get_force(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double curv[], double gauss[], double lap_curv[], double zeta[],struct point3D f_mem[],double kappa,double tens,double f_n[],struct point3D f_t[]){
	int                 i, j, k, l, l0, l1, l2;
	double fn[NMEM],fn0,fn02;
	struct point3D      gradszeta[NMEM];
	int Nneighbours[NMEM];
	int neighbours[NMEM][6];
	int npoints;
	struct point3D points[6],gradsxi,gradszeta1[NMEM];
	double da[6],dz[6];

	for(i=0;i<NMEM;i++) Nneighbours[i]=0;
	for(i=0;i<NTRIANG;i++){
		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];
		for(j=0;j<Nneighbours[l0];j++) if(neighbours[l0][j]==l1) break;
		if(j==Nneighbours[l0]){
			neighbours[l0][j]=l1;
			Nneighbours[l0]++;
		}
		for(j=0;j<Nneighbours[l0];j++) if(neighbours[l0][j]==l2) break;
		if(j==Nneighbours[l0]){
			neighbours[l0][j]=l2;
			Nneighbours[l0]++;
		}
		for(j=0;j<Nneighbours[l1];j++) if(neighbours[l1][j]==l2) break;
		if(j==Nneighbours[l1]){
			neighbours[l1][j]=l2;
			Nneighbours[l1]++;
		}
		for(j=0;j<Nneighbours[l1];j++) if(neighbours[l1][j]==l0) break;
		if(j==Nneighbours[l1]){
			neighbours[l1][j]=l0;
			Nneighbours[l1]++;
		}
		for(j=0;j<Nneighbours[l2];j++) if(neighbours[l2][j]==l0) break;
		if(j==Nneighbours[l2]){
			neighbours[l2][j]=l0;
			Nneighbours[l2]++;
		}
		for(j=0;j<Nneighbours[l2];j++) if(neighbours[l2][j]==l1) break;
		if(j==Nneighbours[l2]){
			neighbours[l2][j]=l1;
			Nneighbours[l2]++;
		}
	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++) sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
		tangent_plane(Nneighbours[i],points,&n_mem[i]);
	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++) sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
		quadratic_interpolator(Nneighbours[i],points,&n_mem[i],&curv[i],&gauss[i]);
	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++){
			sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
			da[j]=curv[neighbours[i][j]]-curv[i];
		}
		new_surface_laplacian(Nneighbours[i],points,da,&n_mem[i],&lap_curv[i]);
		for(j=0;j<Nneighbours[i];j++) da[j]=zeta[neighbours[i][j]]-zeta[i];
		new_surface_gradient(Nneighbours[i],points,da,&n_mem[i],&gradszeta[i]);
	}
	old_surface_gradient(r_mem,triang_site,zeta,gradszeta1);
	fn0=0.0;
	for(i=0;i<NMEM;i++){
		f_n[i] =  -1.0*kappa*( 4.0*curv[i]*(curv[i]*curv[i]-gauss[i]) + 2.0*lap_curv[i])+2.0*zeta[i]*curv[i]+DotProduct3D(n_mem[i],gradszeta1[i]);
		fn0+=f_n[i];
	}
	fn0/=NMEM;
	for(i=0;i<NMEM;i++){
		f_n[i]-=fn0;
		CrossProduct3D(&f_t[i],n_mem[i],gradszeta[i]);
		smul3D(&f_mem[i],f_n[i],n_mem[i]);
		add3D2(&f_mem[i],gradszeta[i]);
	}
//	VTKdump("test0",r_mem,triang_site,zeta,curv,gauss,lap_curv,n_mem,n_mem);
//	VTKdump("test1",r_mem,triang_site,zeta,curv,gauss,lap_curv,n_mem,n_mem);
//	VTKdump("test2",r_mem,triang_site,zeta,curv,gauss,lap_curv,gradszeta1,gradszeta);
}

void find_neighbours(int triang_site[NTRIANG][3],int Nneighbours[NMEM],int neighbours[NMEM][6],int neighbour_sites[NMEM][6][2]){
	int	i, j, k, l, l0, l1, l2;
	for(i=0;i<NMEM;i++) Nneighbours[i]=0;
	for(i=0;i<NTRIANG;i++){
		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];
		for(j=0;j<Nneighbours[l0];j++) if(neighbours[l0][j]==l1) break;
		if(j==Nneighbours[l0]){
			neighbours[l0][j]=l1;
			neighbour_sites[l0][j][0]=i;
			Nneighbours[l0]++;
		}
		else neighbour_sites[l0][j][1]=i;			
		for(j=0;j<Nneighbours[l0];j++) if(neighbours[l0][j]==l2) break;
		if(j==Nneighbours[l0]){
			neighbours[l0][j]=l2;
			neighbour_sites[l0][j][0]=i;
			Nneighbours[l0]++;
		}
		else neighbour_sites[l0][j][1]=i;			
		for(j=0;j<Nneighbours[l1];j++) if(neighbours[l1][j]==l2) break;
		if(j==Nneighbours[l1]){
			neighbours[l1][j]=l2;
			neighbour_sites[l1][j][0]=i;
			Nneighbours[l1]++;
		}
		else neighbour_sites[l1][j][1]=i;			
		for(j=0;j<Nneighbours[l1];j++) if(neighbours[l1][j]==l0) break;
		if(j==Nneighbours[l1]){
			neighbours[l1][j]=l0;
			neighbour_sites[l1][j][0]=i;
			Nneighbours[l1]++;
		}
		else neighbour_sites[l1][j][1]=i;			
		for(j=0;j<Nneighbours[l2];j++) if(neighbours[l2][j]==l0) break;
		if(j==Nneighbours[l2]){
			neighbours[l2][j]=l0;
			neighbour_sites[l2][j][0]=i;
			Nneighbours[l2]++;
		}
		else neighbour_sites[l2][j][1]=i;			
		for(j=0;j<Nneighbours[l2];j++) if(neighbours[l2][j]==l1) break;
		if(j==Nneighbours[l2]){
			neighbours[l2][j]=l1;
			neighbour_sites[l2][j][0]=i;
			Nneighbours[l2]++;
		}
		else neighbour_sites[l2][j][1]=i;			
	}
}

void find_neighbours2(int triang_site[NTRIANG2][3],int Nneighbours[NMEM2],int neighbours[NMEM2][6],int neighbour_sites[NMEM2][6][2]){
	int	i, j, k, l, l0, l1, l2;
	for(i=0;i<NMEM2;i++) Nneighbours[i]=0;
	for(i=0;i<NTRIANG2;i++){
		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];
		for(j=0;j<Nneighbours[l0];j++) if(neighbours[l0][j]==l1) break;
		if(j==Nneighbours[l0]){
			neighbours[l0][j]=l1;
			neighbour_sites[l0][j][0]=i;
			Nneighbours[l0]++;
		}
		else neighbour_sites[l0][j][1]=i;			
		for(j=0;j<Nneighbours[l0];j++) if(neighbours[l0][j]==l2) break;
		if(j==Nneighbours[l0]){
			neighbours[l0][j]=l2;
			neighbour_sites[l0][j][0]=i;
			Nneighbours[l0]++;
		}
		else neighbour_sites[l0][j][1]=i;			
		for(j=0;j<Nneighbours[l1];j++) if(neighbours[l1][j]==l2) break;
		if(j==Nneighbours[l1]){
			neighbours[l1][j]=l2;
			neighbour_sites[l1][j][0]=i;
			Nneighbours[l1]++;
		}
		else neighbour_sites[l1][j][1]=i;			
		for(j=0;j<Nneighbours[l1];j++) if(neighbours[l1][j]==l0) break;
		if(j==Nneighbours[l1]){
			neighbours[l1][j]=l0;
			neighbour_sites[l1][j][0]=i;
			Nneighbours[l1]++;
		}
		else neighbour_sites[l1][j][1]=i;			
		for(j=0;j<Nneighbours[l2];j++) if(neighbours[l2][j]==l0) break;
		if(j==Nneighbours[l2]){
			neighbours[l2][j]=l0;
			neighbour_sites[l2][j][0]=i;
			Nneighbours[l2]++;
		}
		else neighbour_sites[l2][j][1]=i;			
		for(j=0;j<Nneighbours[l2];j++) if(neighbours[l2][j]==l1) break;
		if(j==Nneighbours[l2]){
			neighbours[l2][j]=l1;
			neighbour_sites[l2][j][0]=i;
			Nneighbours[l2]++;
		}
		else neighbour_sites[l2][j][1]=i;			
	}
}

void new_get_force3(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double kappa, double curv[], double gauss[], double lap_curv[], double zeta[], double dzeta[NMEM], struct point3D tension_force[NMEM], struct point3D tension_force2[NMEM], struct point3D tension_force3[NMEM], struct point3D tension0_force[NMEM], struct point3D tension0_force2[NMEM], struct point3D tension0_force3[NMEM],int Nneighbours[NMEM],int neighbours[NMEM][6]){
	int	i, j, k, l, l0, l1, l2;
	double	fn, triangle_area;
	int	npoints;
	struct	point3D points[6],triangle_normal,r01,r12,r20,vtemp;
	double	da[6],dz[6],areas[NMEM];

	for(i=0;i<NMEM;i++) tension_force[i].x=tension_force[i].y=tension_force[i].z=areas[i]=0.0;
	for(i=0;i<NMEM;i++) tension_force2[i].x=tension_force2[i].y=tension_force2[i].z=0.0;
	for(i=0;i<NMEM;i++) tension_force3[i].x=tension_force3[i].y=tension_force3[i].z=0.0;
/*	for(i=(NMEM-2)/4+2;i<NMEM;i++){
		zeta[i]=0.0;
		dzeta[i]=0.0;
	}
	for(i=0;i<(NMEM-2)/4+2;i++){
		for(j=0;j<Nneighbours[i];j++){
			zeta[neighbours[i][j]]+=zeta[i]*0.5;
			dzeta[neighbours[i][j]]+=dzeta[i]*0.5;
		}
	}*/
	for(i=0;i<NTRIANG;i++){
		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];
		sub3D(&r01,r_mem[l1],r_mem[l0]);
		sub3D(&r12,r_mem[l2],r_mem[l1]);
		sub3D(&r20,r_mem[l0],r_mem[l2]);
		CrossProduct3D(&triangle_normal,r12,r01);
		triangle_area=sqrt(DotProduct3D(triangle_normal,triangle_normal));
		smul3D2(&triangle_normal,0.5/triangle_area);
		CrossProduct3D(&vtemp,triangle_normal,r12);
		tension_force[l0].x+=(zeta[l1]+zeta[l2]+zeta[l0])*vtemp.x;
		tension_force[l0].y+=(zeta[l1]+zeta[l2]+zeta[l0])*vtemp.y;
		tension_force[l0].z+=(zeta[l1]+zeta[l2]+zeta[l0])*vtemp.z;
		tension_force2[l0].x+=(dzeta[l1]+dzeta[l2]+dzeta[l0])*vtemp.x;
		tension_force2[l0].y+=(dzeta[l1]+dzeta[l2]+dzeta[l0])*vtemp.y;
		tension_force2[l0].z+=(dzeta[l1]+dzeta[l2]+dzeta[l0])*vtemp.z;
		tension_force3[l0].x+=3.0*vtemp.x;
		tension_force3[l0].y+=3.0*vtemp.y;
		tension_force3[l0].z+=3.0*vtemp.z;
		CrossProduct3D(&vtemp,triangle_normal,r20);
		tension_force[l1].x+=(zeta[l2]+zeta[l0]+zeta[l1])*vtemp.x;
		tension_force[l1].y+=(zeta[l2]+zeta[l0]+zeta[l1])*vtemp.y;
		tension_force[l1].z+=(zeta[l2]+zeta[l0]+zeta[l1])*vtemp.z;
		tension_force2[l1].x+=(dzeta[l2]+dzeta[l0]+dzeta[l1])*vtemp.x;
		tension_force2[l1].y+=(dzeta[l2]+dzeta[l0]+dzeta[l1])*vtemp.y;
		tension_force2[l1].z+=(dzeta[l2]+dzeta[l0]+dzeta[l1])*vtemp.z;
		tension_force3[l1].x+=3.0*vtemp.x;
		tension_force3[l1].y+=3.0*vtemp.y;
		tension_force3[l1].z+=3.0*vtemp.z;
		CrossProduct3D(&vtemp,triangle_normal,r01);
		tension_force[l2].x+=(zeta[l0]+zeta[l1]+zeta[l2])*vtemp.x;
		tension_force[l2].y+=(zeta[l0]+zeta[l1]+zeta[l2])*vtemp.y;
		tension_force[l2].z+=(zeta[l0]+zeta[l1]+zeta[l2])*vtemp.z;
		tension_force2[l2].x+=(dzeta[l0]+dzeta[l1]+dzeta[l2])*vtemp.x;
		tension_force2[l2].y+=(dzeta[l0]+dzeta[l1]+dzeta[l2])*vtemp.y;
		tension_force2[l2].z+=(dzeta[l0]+dzeta[l1]+dzeta[l2])*vtemp.z;
		tension_force3[l2].x+=3.0*vtemp.x;
		tension_force3[l2].y+=3.0*vtemp.y;
		tension_force3[l2].z+=3.0*vtemp.z;
		areas[l0]+=triangle_area;
		areas[l1]+=triangle_area;
		areas[l2]+=triangle_area;
	}
	for(i=0;i<NMEM;i++){
		smul3D2(&tension_force[i],1.0/areas[i]);
		smul3D2(&tension_force2[i],1.0/areas[i]);
		smul3D2(&tension_force3[i],1.0/areas[i]);
	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++) sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
		tangent_plane(Nneighbours[i],points,&n_mem[i]);
	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++) sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
		quadratic_interpolator(Nneighbours[i],points,&n_mem[i],&curv[i],&gauss[i]);
	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++){
			sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
			da[j]=curv[neighbours[i][j]]-curv[i];
		}
		new_surface_laplacian(Nneighbours[i],points,da,&n_mem[i],&lap_curv[i]);
	}
	for(i=0;i<NMEM;i++){
		fn=kappa*(4.0*curv[i]*(curv[i]*curv[i]-gauss[i]) + 2.0*lap_curv[i]);
		tension_force[i].x -= fn*n_mem[i].x;
		tension_force[i].y -= fn*n_mem[i].y;
		tension_force[i].z -= fn*n_mem[i].z;
	}
	for(i=0;i<NMEM;i++) tension0_force[i].x=tension0_force[i].y=tension0_force[i].z=areas[i]=0.0;
	for(i=0;i<NMEM;i++) tension0_force2[i].x=tension0_force2[i].y=tension0_force2[i].z=0.0;
	for(i=0;i<NMEM;i++) tension0_force3[i].x=tension0_force3[i].y=tension0_force3[i].z=0.0;
	for(i=0;i<NTRIANG;i++){
		for(j=0;j<3;j++){
			l0 = triang_site[i][j];
			l1 = triang_site[i][(j+1)%3];
			l2 = triang_site[i][(j+2)%3];
			tension0_force[l0].x+=(tension_force[l1].x+tension_force[l2].x);
			tension0_force[l0].y+=(tension_force[l1].y+tension_force[l2].y);
			tension0_force[l0].z+=(tension_force[l1].z+tension_force[l2].z);
			tension0_force2[l0].x+=(tension_force2[l1].x+tension_force2[l2].x);
			tension0_force2[l0].y+=(tension_force2[l1].y+tension_force2[l2].y);
			tension0_force2[l0].z+=(tension_force2[l1].z+tension_force2[l2].z);
			tension0_force3[l0].x+=(tension_force3[l1].x+tension_force3[l2].x);
			tension0_force3[l0].y+=(tension_force3[l1].y+tension_force3[l2].y);
			tension0_force3[l0].z+=(tension_force3[l1].z+tension_force3[l2].z);
			areas[l0]+=2.0;
		}
	}
	for(i=0;i<NMEM;i++){
		smul3D2(&tension0_force[i],1.0/areas[i]);
		smul3D2(&tension0_force2[i],1.0/areas[i]);
		smul3D2(&tension0_force3[i],1.0/areas[i]);
	}



//	VTKdump("test0",r_mem,triang_site,zeta,curv,gauss,lap_curv,f_n,dzeta,f_t,f_t2);
//	VTKdump("test1",r_mem,triang_site,zeta,curv,gauss,lap_curv,n_mem,n_mem);
//	VTKdump("test2",r_mem,triang_site,zeta,curv,gauss,lap_curv,gradszeta1,gradszeta);
}


/*void test_get_force3(int triang_site[NTRIANG][3], int triang_site2[NTRIANG2][3], struct point3D r_mem[], struct point3D r_mem2[], struct point3D r_mem0[], struct point3D n_mem[], double kappa, double curv[], double gauss[], double lap_curv[], double zeta[], double zeta2[], double dzeta[NMEM], double dzeta2[NMEM2], struct point3D f_mem[NMEM2], struct point3D f_mem0[NMEM2][4], struct point3D fdA[NMEM][4], struct point3D fdA2[NMEM2][4], int Nneighbours[NMEM], int neighbours[NMEM][6], int slaves[NMEM][7], double r_max[NMEM]){
	int	i, j, k, l, l0, l1, l2,v;
	double	fn0, triangle_area,norm;
	int	npoints;
	struct	point3D points[6],triangle_normal,r01,r12,r20,vtemp,r_mem2temp[NMEM2];
	double	da[6],dz[6],areas[NMEM],areas2[NMEM2],fn2[NMEM2];


	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++) sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++) sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
		new_quadratic_interpolator(Nneighbours[i],points,&n_mem[i],&curv[i],&gauss[i],slaves[i],r_mem2,r_mem2temp);
	}

	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++){
			sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
			da[j]=curv[neighbours[i][j]]-curv[i];
		}
		new_surface_laplacian(Nneighbours[i],points,da,&n_mem[i],&lap_curv[i]);
	}
	for(i=0;i<NMEM;i++){
		fn2[i]=kappa*(4.0*curv[i]*(curv[i]*curv[i]-gauss[i]) + 2.0*lap_curv[i]);
		zeta2[i]=zeta[i];
		dzeta2[i]=dzeta[i];
	}
	VTKdump("test",r_mem,triang_site,zeta,curv,gauss,lap_curv,zeta,zeta,n_mem,n_mem);
	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++){
			sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
			da[j]=zeta[neighbours[i][j]]-zeta[i];
		}
		new_interpolate(Nneighbours[i],points,da,&n_mem[i],slaves[i],r_mem2,zeta2);
		for(j=0;j<Nneighbours[i];j++){
			da[j]=dzeta[neighbours[i][j]]-dzeta[i];
		}
		new_interpolate(Nneighbours[i],points,da,&n_mem[i],slaves[i],r_mem2,dzeta2);
		for(j=0;j<Nneighbours[i];j++){
			da[j]=fn2[neighbours[i][j]]-fn2[i];
		}
		new_interpolate(Nneighbours[i],points,da,&n_mem[i],slaves[i],r_mem2,fn2);
	}

	for(v=0;v<NMEM;v++){
		zeta2[v]=zeta[v];
		dzeta2[v]=dzeta[v];
	}
	norm=1.0/7.0;
	for(i=0;i<NTRIANG;i++){
		for(j=0;j<3;j++){
			l0 = triang_site[i][j];
			l1 = triang_site[i][(j+1)%3];
			l2 = triang_site[i][(j+2)%3];
			zeta2[v]=zeta[l2]+2.0*zeta[l1]+4.0*zeta[l0];
			zeta2[v]*=norm;
			dzeta2[v]=dzeta[l2]+2.0*dzeta[l1]+4.0*dzeta[l0];
			dzeta2[v]*=norm;
			fn2[v]=fn2[l2]+2.0*fn2[l1]+4.0*fn2[l0];
			fn2[v]*=norm;
			v++;
		}	
	}

	for(i=0;i<NMEM2;i++){
		for(j=0;j<4;j++) fdA2[i][j].x=fdA2[i][j].y=fdA2[i][j].z=0.0;
		areas2[i]=0.0;
	}
	for(i=0;i<NTRIANG2;i++){
		l0 = triang_site2[i][0];
		l1 = triang_site2[i][1];
		l2 = triang_site2[i][2];
		sub3D(&r01,r_mem2[l1],r_mem2[l0]);
		sub3D(&r12,r_mem2[l2],r_mem2[l1]);
		sub3D(&r20,r_mem2[l0],r_mem2[l2]);
		CrossProduct3D(&triangle_normal,r12,r01);
		smul3D2(&triangle_normal,1.0/6.0);
		triangle_area=sqrt(DotProduct3D(triangle_normal,triangle_normal));
		for(j=0;j<3;j++){
			fdA2[triang_site2[i][j]][0].x+=triangle_normal.x;
			fdA2[triang_site2[i][j]][0].y+=triangle_normal.y;
			fdA2[triang_site2[i][j]][0].z+=triangle_normal.z;
			areas2[triang_site2[i][j]]+=triangle_area;
			
		}
		smul3D2(&triangle_normal,1.0/triangle_area);
		CrossProduct3D(&vtemp,triangle_normal,r12);
		fdA2[l0][1].x+=(zeta2[l1]+zeta2[l2]+zeta2[l0])*vtemp.x;
		fdA2[l0][1].y+=(zeta2[l1]+zeta2[l2]+zeta2[l0])*vtemp.y;
		fdA2[l0][1].z+=(zeta2[l1]+zeta2[l2]+zeta2[l0])*vtemp.z;
		fdA2[l0][2].x+=(dzeta2[l1]+dzeta2[l2]+dzeta2[l0])*vtemp.x;
		fdA2[l0][2].y+=(dzeta2[l1]+dzeta2[l2]+dzeta2[l0])*vtemp.y;
		fdA2[l0][2].z+=(dzeta2[l1]+dzeta2[l2]+dzeta2[l0])*vtemp.z;
		fdA2[l0][3].x+=3.0*vtemp.x;
		fdA2[l0][3].y+=3.0*vtemp.y;
		fdA2[l0][3].z+=3.0*vtemp.z;
		CrossProduct3D(&vtemp,triangle_normal,r20);
		fdA2[l1][1].x+=(zeta2[l2]+zeta2[l0]+zeta2[l1])*vtemp.x;
		fdA2[l1][1].y+=(zeta2[l2]+zeta2[l0]+zeta2[l1])*vtemp.y;
		fdA2[l1][1].z+=(zeta2[l2]+zeta2[l0]+zeta2[l1])*vtemp.z;
		fdA2[l1][2].x+=(dzeta2[l2]+dzeta2[l0]+dzeta2[l1])*vtemp.x;
		fdA2[l1][2].y+=(dzeta2[l2]+dzeta2[l0]+dzeta2[l1])*vtemp.y;
		fdA2[l1][2].z+=(dzeta2[l2]+dzeta2[l0]+dzeta2[l1])*vtemp.z;
		fdA2[l1][3].x+=3.0*vtemp.x;
		fdA2[l1][3].y+=3.0*vtemp.y;
		fdA2[l1][3].z+=3.0*vtemp.z;
		CrossProduct3D(&vtemp,triangle_normal,r01);
		fdA2[l2][1].x+=(zeta2[l0]+zeta2[l1]+zeta2[l2])*vtemp.x;
		fdA2[l2][1].y+=(zeta2[l0]+zeta2[l1]+zeta2[l2])*vtemp.y;
		fdA2[l2][1].z+=(zeta2[l0]+zeta2[l1]+zeta2[l2])*vtemp.z;
		fdA2[l2][2].x+=(dzeta2[l0]+dzeta2[l1]+dzeta2[l2])*vtemp.x;
		fdA2[l2][2].y+=(dzeta2[l0]+dzeta2[l1]+dzeta2[l2])*vtemp.y;
		fdA2[l2][2].z+=(dzeta2[l0]+dzeta2[l1]+dzeta2[l2])*vtemp.z;
		fdA2[l2][3].x+=3.0*vtemp.x;
		fdA2[l2][3].y+=3.0*vtemp.y;
		fdA2[l2][3].z+=3.0*vtemp.z;
//		smul3D2(&triangle_normal,0.5/triangle_area);		
	}
	VTKdump_ref("test1",r_mem2,triang_site2,zeta2);
	for(i=0;i<NMEM2;i++){
		triangle_area=1.0/sqrt(DotProduct3D(fdA2[i][0],fdA2[i][0]));


		for(j=0;j<4;j++){
			smul3D(&f_mem0[i][j],triangle_area,fdA2[i][j]);
		}
		fdA2[i][1].x+=fn2[i]*fdA2[i][0].x;
		fdA2[i][1].y+=fn2[i]*fdA2[i][0].y;
		fdA2[i][1].z+=fn2[i]*fdA2[i][0].z;
		f_mem[i].x=f_mem0[i][1].x;
		f_mem[i].y=f_mem0[i][1].y;
		f_mem[i].z=f_mem0[i][1].z;
		r_mem2[i].x=r_mem2temp[i].x;
		r_mem2[i].y=r_mem2temp[i].y;
		r_mem2[i].z=r_mem2temp[i].z;
	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<4;j++) fdA[i][j].x=fdA[i][j].y=fdA[i][j].z=0.0;
		for(j=0;j<Nneighbours[i]+1;j++){
			l0=slaves[i][j];
			for(k=0;k<4;k++){
				fdA[i][k].x+=fdA2[l0][k].x;
				fdA[i][k].y+=fdA2[l0][k].y;
				fdA[i][k].z+=fdA2[l0][k].z;
			}
			areas[i]+=areas2[l0];
		}
	}
	for(i=0;i<NMEM2;i++){
		zeta2[i]=sqrt(DotProduct3D(fdA2[i][1],fdA2[i][1]));
	}
	VTKdump_ref("test",r_mem2temp,triang_site2,zeta2);



//	VTKdump("test0",r_mem,triang_site,zeta,curv,gauss,lap_curv,f_n,dzeta,f_t,f_t2);
//	VTKdump("test1",r_mem,triang_site,zeta,curv,gauss,lap_curv,n_mem,n_mem);
//	VTKdump("test2",r_mem,triang_site,zeta,curv,gauss,lap_curv,gradszeta1,gradszeta);
}*/

void test_get_force3(int triang_site[NTRIANG][3], int triang_site2[NTRIANG2][3], struct point3D r_mem[], struct point3D r_mem2[], struct point3D r_mem0[], struct point3D n_mem[], double kappa, double curv[], double gauss[], double lap_curv[], double zeta[], double zeta2[], double dzeta[NMEM], double dzeta2[NMEM2], struct point3D f_mem[NMEM2], struct point3D f_mem0[NMEM2][4], struct point3D fdA[NMEM][4], struct point3D fdA2[NMEM2][4], int Nneighbours[NMEM], int neighbours[NMEM][6], int slaves[NMEM][NSLA], double r_max[NMEM]){
	int	i, j, k, l, l0, l1, l2,v;
	double	fn0, fn, triangle_area,norm;
	int	npoints;
	struct	point3D points[6],triangle_normal,r01,r12,r20,vtemp,r_mem2temp[NMEM2];
	double	da[6],dz[6],areas[NMEM],areas2[NMEM2],fn2[NMEM2];

	for(i=0;i<NMEM;i++) {
		for(j=0;j<4;j++)f_mem0[i][j].x=f_mem0[i][j].y=f_mem0[i][j].z=0.0;
		areas[i]=0.0;
	}
	for(i=0;i<NMEM2;i++)r_mem2temp[i].x=r_mem2temp[i].y=r_mem2temp[i].z=0.0;
	for(i=0;i<NTRIANG;i++){
		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];
		sub3D(&r01,r_mem[l1],r_mem[l0]);
		sub3D(&r12,r_mem[l2],r_mem[l1]);
		sub3D(&r20,r_mem[l0],r_mem[l2]);
		CrossProduct3D(&triangle_normal,r12,r01);
		triangle_area=sqrt(DotProduct3D(triangle_normal,triangle_normal));
		smul3D2(&triangle_normal,1.0/triangle_area);
		CrossProduct3D(&vtemp,triangle_normal,r12);
		f_mem0[l0][1].x+=(zeta[l1]+zeta[l2]-2.0*zeta[l0])*vtemp.x;
		f_mem0[l0][1].y+=(zeta[l1]+zeta[l2]-2.0*zeta[l0])*vtemp.y;
		f_mem0[l0][1].z+=(zeta[l1]+zeta[l2]-2.0*zeta[l0])*vtemp.z;
		f_mem0[l0][2].x+=(dzeta[l1]+dzeta[l2]-2.0*dzeta[l0])*vtemp.x;
		f_mem0[l0][2].y+=(dzeta[l1]+dzeta[l2]-2.0*dzeta[l0])*vtemp.y;
		f_mem0[l0][2].z+=(dzeta[l1]+dzeta[l2]-2.0*dzeta[l0])*vtemp.z;
/*		f_mem0[l0][3].x+=3.0*vtemp.x;
		f_mem0[l0][3].y+=3.0*vtemp.y;
		f_mem0[l0][3].z+=3.0*vtemp.z;*/
		CrossProduct3D(&vtemp,triangle_normal,r20);
		f_mem0[l1][1].x+=(zeta[l2]+zeta[l0]-2.0*zeta[l1])*vtemp.x;
		f_mem0[l1][1].y+=(zeta[l2]+zeta[l0]-2.0*zeta[l1])*vtemp.y;
		f_mem0[l1][1].z+=(zeta[l2]+zeta[l0]-2.0*zeta[l1])*vtemp.z;
		f_mem0[l1][2].x+=(dzeta[l2]+dzeta[l0]-2.0*dzeta[l1])*vtemp.x;
		f_mem0[l1][2].y+=(dzeta[l2]+dzeta[l0]-2.0*dzeta[l1])*vtemp.y;
		f_mem0[l1][2].z+=(dzeta[l2]+dzeta[l0]-2.0*dzeta[l1])*vtemp.z;
/*		f_mem0[l1][3].x+=3.0*vtemp.x;
		f_mem0[l1][3].y+=3.0*vtemp.y;
		f_mem0[l1][3].z+=3.0*vtemp.z;*/
		CrossProduct3D(&vtemp,triangle_normal,r01);
		f_mem0[l2][1].x+=(zeta[l0]+zeta[l1]-2.0*zeta[l2])*vtemp.x;
		f_mem0[l2][1].y+=(zeta[l0]+zeta[l1]-2.0*zeta[l2])*vtemp.y;
		f_mem0[l2][1].z+=(zeta[l0]+zeta[l1]-2.0*zeta[l2])*vtemp.z;
		f_mem0[l2][2].x+=(dzeta[l0]+dzeta[l1]-2.0*dzeta[l2])*vtemp.x;
		f_mem0[l2][2].y+=(dzeta[l0]+dzeta[l1]-2.0*dzeta[l2])*vtemp.y;
		f_mem0[l2][2].z+=(dzeta[l0]+dzeta[l1]-2.0*dzeta[l2])*vtemp.z;
/*		f_mem0[l2][3].x+=3.0*vtemp.x;
		f_mem0[l2][3].y+=3.0*vtemp.y;
		f_mem0[l2][3].z+=3.0*vtemp.z;*/
		areas[l0]+=triangle_area;
		areas[l1]+=triangle_area;
		areas[l2]+=triangle_area;
	}
	for(i=0;i<NMEM;i++){
		for(j=1;j<4;j++) smul3D2(&f_mem0[i][j],1.0/areas[i]);
//		zeta[i]=f_mem0[i][3].x*n_mem[i].x+f_mem0[i][3].y*n_mem[i].y+f_mem0[i][3].z*n_mem[i].z;
	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++) sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++) sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
		new_quadratic_interpolator16(Nneighbours[i],points,&n_mem[i],&curv[i],&gauss[i],slaves[i],r_mem2,r_mem2temp);
	}
//	put_points16(r_mem, r_mem2, slaves, Nneighbours);
	VTKdump_ref("test",r_mem2temp,triang_site2,zeta2);
	VTKdump_ref("test1",r_mem2,triang_site2,zeta2);
	exit(0);
	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++){
			sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
			da[j]=curv[neighbours[i][j]]-curv[i];
		}
		new_surface_laplacian(Nneighbours[i],points,da,&n_mem[i],&lap_curv[i]);
/*		for(j=0;j<Nneighbours[i];j++){
			da[j]=zeta[neighbours[i][j]]-zeta[i];
		}
		new_surface_gradient(Nneighbours[i],points,da,&n_mem[i],&f_mem0[i][1]);
		for(j=0;j<Nneighbours[i];j++){
			da[j]=dzeta[neighbours[i][j]]-dzeta[i];
		}
		new_surface_gradient(Nneighbours[i],points,da,&n_mem[i],&f_mem0[i][2]);*/
	}
	for(i=0;i<NMEM;i++){
		fn2[i]=kappa*(4.0*curv[i]*(curv[i]*curv[i]-gauss[i]) + 2.0*lap_curv[i]);
		zeta2[i]=zeta[i];
		dzeta2[i]=dzeta[i];
	}


	for(i=0;i<NMEM;i++){
		fn=kappa*(4.0*curv[i]*(curv[i]*curv[i]-gauss[i]) + 2.0*lap_curv[i])-2.0*zeta[i]*curv[i];
		f_mem0[i][1].x -= fn*n_mem[i].x;
		f_mem0[i][1].y -= fn*n_mem[i].y;
		f_mem0[i][1].z -= fn*n_mem[i].z;
		fn=-2.0*dzeta[i]*curv[i];
		f_mem0[i][2].x -= fn*n_mem[i].x;
		f_mem0[i][2].y -= fn*n_mem[i].y;
		f_mem0[i][2].z -= fn*n_mem[i].z;
		fn=-2.0*curv[i];
		f_mem0[i][3].x -= fn*n_mem[i].x;
		f_mem0[i][3].y -= fn*n_mem[i].y;
		f_mem0[i][3].z -= fn*n_mem[i].z;
/*		f_mem0[i][1].x=r_mem[i].x;
		f_mem0[i][1].y=r_mem[i].y;
		f_mem0[i][1].z=-2.0*r_mem[i].z;*/
	//	f_mem0[i][1].x=f_mem0[i][1].y=f_mem0[i][1].z=0.0;
	}
//	f_mem0[0][1].x=1.0;




//	VTKdump("test",r_mem,triang_site,zeta,curv,gauss,lap_curv,zeta,zeta,n_mem,n_mem);
/*	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++){
			sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
			da[j]=zeta[neighbours[i][j]]-zeta[i];
		}
		new_interpolate(Nneighbours[i],points,da,&n_mem[i],slaves[i],r_mem2,zeta2);
		for(j=0;j<Nneighbours[i];j++){
			da[j]=dzeta[neighbours[i][j]]-dzeta[i];
		}
		new_interpolate(Nneighbours[i],points,da,&n_mem[i],slaves[i],r_mem2,dzeta2);
		for(j=0;j<Nneighbours[i];j++){
			da[j]=fn2[neighbours[i][j]]-fn2[i];
		}
		new_interpolate(Nneighbours[i],points,da,&n_mem[i],slaves[i],r_mem2,fn2);
	}*/

	for(v=0;v<NMEM;v++){
		zeta2[v]=curv[v];
		dzeta2[v]=dzeta[v];
	}
	norm=1.0/7.0;
	for(i=0;i<NTRIANG;i++){
		for(j=0;j<3;j++){
			l0 = triang_site[i][j];
			l1 = triang_site[i][(j+1)%3];
			l2 = triang_site[i][(j+2)%3];
			zeta2[v]=zeta2[l2]+2.0*zeta2[l1]+4.0*zeta2[l0];
			zeta2[v]*=norm;
			dzeta2[v]=dzeta2[l2]+2.0*dzeta2[l1]+4.0*dzeta2[l0];
			dzeta2[v]*=norm;
			fn2[v]=fn2[l2]+2.0*fn2[l1]+4.0*fn2[l0];
			fn2[v]*=norm;
			for(k=1;k<4;k++){
				f_mem0[v][k].x=norm*(f_mem0[l2][k].x+2.0*f_mem0[l1][k].x+4.0*f_mem0[l0][k].x);
				f_mem0[v][k].y=norm*(f_mem0[l2][k].y+2.0*f_mem0[l1][k].y+4.0*f_mem0[l0][k].y);
				f_mem0[v][k].z=norm*(f_mem0[l2][k].z+2.0*f_mem0[l1][k].z+4.0*f_mem0[l0][k].z);
			}
			v++;
		}	
	}
	for(i=0;i<NMEM2;i++){
		for(j=0;j<4;j++) fdA2[i][j].x=fdA2[i][j].y=fdA2[i][j].z=0.0;
		areas2[i]=0.0;
		r_mem2[i].x=r_mem2temp[i].x;
		r_mem2[i].y=r_mem2temp[i].y;
		r_mem2[i].z=r_mem2temp[i].z;
	}
	for(i=0;i<NTRIANG2;i++){
		l0 = triang_site2[i][0];
		l1 = triang_site2[i][1];
		l2 = triang_site2[i][2];
		sub3D(&r01,r_mem2[l1],r_mem2[l0]);
		sub3D(&r12,r_mem2[l2],r_mem2[l1]);
		sub3D(&r20,r_mem2[l0],r_mem2[l2]);
		CrossProduct3D(&triangle_normal,r12,r01);
		smul3D2(&triangle_normal,-1.0/6.0);
		triangle_area=sqrt(DotProduct3D(triangle_normal,triangle_normal));
		for(j=0;j<3;j++){
			fdA2[triang_site2[i][j]][0].x+=triangle_normal.x;
			fdA2[triang_site2[i][j]][0].y+=triangle_normal.y;
			fdA2[triang_site2[i][j]][0].z+=triangle_normal.z;
			areas2[triang_site2[i][j]]+=triangle_area;			
		}
	}
//	VTKdump_ref("test1",r_mem2,triang_site2,zeta2);
	for(i=0;i<NMEM2;i++){
		triangle_area=1.0/sqrt(DotProduct3D(fdA2[i][0],fdA2[i][0]));
//		zeta2[i]=areas2[i]/sqrt(DotProduct3D(fdA2[i][0],fdA2[i][0]));
		smul3D(&f_mem0[i][0],triangle_area,fdA2[i][0]);
		f_mem[i].x=f_mem0[i][1].x;
		f_mem[i].y=f_mem0[i][1].y;
		f_mem[i].z=f_mem0[i][1].z;
/*		r_mem2[i].x=r_mem2temp[i].x;
		r_mem2[i].y=r_mem2temp[i].y;
		r_mem2[i].z=r_mem2temp[i].z;*/
		for(j=1;j<4;j++) {
			fdA2[i][j].x=areas2[i]*f_mem0[i][j].x;
			fdA2[i][j].y=areas2[i]*f_mem0[i][j].y;
			fdA2[i][j].z=areas2[i]*f_mem0[i][j].z;
		}

	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<4;j++) fdA[i][j].x=fdA[i][j].y=fdA[i][j].z=0.0;
		for(j=0;j<Nneighbours[i]+1;j++){
			l0=slaves[i][j];
			for(k=0;k<4;k++){
				fdA[i][k].x+=fdA2[l0][k].x;
				fdA[i][k].y+=fdA2[l0][k].y;
				fdA[i][k].z+=fdA2[l0][k].z;
			}
			areas[i]+=areas2[l0];
		}
	}
	for(i=0;i<NMEM2;i++){
//		zeta2[i]=fdA2[i][1].z;
	}
//	VTKdump_ref("test",r_mem2temp,triang_site2,zeta2);



//	VTKdump("test0",r_mem,triang_site,zeta,curv,gauss,lap_curv,f_n,dzeta,f_t,f_t2);
//	VTKdump("test1",r_mem,triang_site,zeta,curv,gauss,lap_curv,n_mem,n_mem);
//	VTKdump("test2",r_mem,triang_site,zeta,curv,gauss,lap_curv,gradszeta1,gradszeta);
}


void test_get_force16(int triang_site[NTRIANG][3], int triang_site2[NTRIANG2][3], struct point3D r_mem[], struct point3D r_mem2[], struct point3D r_mem0[], struct point3D n_mem[], double kappa, double curv[], double gauss[], double lap_curv[], double zeta[], double zeta2[], double dzeta[NMEM], double dzeta2[NMEM2], struct point3D f_mem[NMEM2], struct point3D f_mem0[NMEM2][4], struct point3D fdA[NMEM][4], struct point3D fdA2[NMEM2][4], int Nneighbours[NMEM], int neighbours[NMEM][6], int slaves[NMEM][NSLA], double r_max[NMEM], struct point3D v_mem[NMEM], struct point3D v_mem2[NMEM2], double ref_state[NTRIANG][4],double areas[NMEM],double colors[NMEM],double time0,struct point3D r_ref[NMEM]){

	int	i, j, k, l, l0, l1, l2,v;
	double	fn0, fn, triangle_area,norm;
        double  totalarea;
	int	npoints;
	struct	point3D points[6],forces[6],triangle_normal,r01,r12,r20,r02,vtemp,r_mem2temp[NMEM2],intNx,intNy,intNz,intF,xi0[NMEM],r_mem_xm,intT,intN;
       
	double	da[6],dz[6],areas2[NMEM2],fn2[NMEM2],darea2[NTRIANG2],g11,g22,g12,temp1,temp2,temp3,temp0,I1,I2,detg0,detg01,detg012,C1,C2;
        double mt33, mt34, mt35, mt43, mt44, mt45, mt53, mt54, mt55;
        double sumxmem, sumymem, sumzmem;
 	double alphax,alphay,alphaz,betax,betay,betaz;
	gsl_matrix *M,*MT;
	gsl_vector *V,*VT;
        #ifdef STRETCH_EXPERIMENT
	        double F1,F2,temp0;
	        struct point3D Box_min,Box_max;
		int ixmax,ixmin,iymax,iymin,izmax,izmin;
		FILE* fp;
	#endif

	r_mem_xm.x=r_mem_xm.y=r_mem_xm.z=temp0=intNx.x=intNx.y=intNx.z=intNy.x=intNy.y=intNy.z=intNz.x=intNz.y=intNz.z=intF.x=intF.y=intF.z=0.0;

	for(i=0;i<NMEM2;i++) {
		for(j=0;j<4;j++)f_mem0[i][j].x=f_mem0[i][j].y=f_mem0[i][j].z=0.0;
	}
	for(i=0;i<NMEM;i++){
		areas[i]=0.0;
		v_mem2[i].x=v_mem[i].x;
		v_mem2[i].y=v_mem[i].y;
		v_mem2[i].z=v_mem[i].z;
	}
	for(i=NMEM;i<NMEM2;i++){
		v_mem2[i].x=v_mem2[i].y=v_mem2[i].z=0.0;
	}
	for(i=0;i<NMEM2;i++){
		r_mem2temp[i].x=r_mem2[i].x;
		r_mem2temp[i].y=r_mem2[i].y;
		r_mem2temp[i].z=r_mem2[i].z;
	}
	for(i=0;i<NTRIANG;i++){
		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];
		sub3D(&r01,r_mem[l1],r_mem[l0]);
		sub3D(&r12,r_mem[l2],r_mem[l1]);
		sub3D(&r20,r_mem[l0],r_mem[l2]);
		CrossProduct3D(&triangle_normal,r12,r01);
		triangle_area=sqrt(DotProduct3D(triangle_normal,triangle_normal));
		smul3D2(&triangle_normal,1.0/triangle_area);
		
		#ifndef EXTENSIBLE

			CrossProduct3D(&vtemp,triangle_normal,r12);
			f_mem0[l0][1].x+=(zeta[l1]+zeta[l2]+zeta[l0])*vtemp.x;
			f_mem0[l0][1].y+=(zeta[l1]+zeta[l2]+zeta[l0])*vtemp.y;
			f_mem0[l0][1].z+=(zeta[l1]+zeta[l2]+zeta[l0])*vtemp.z;
			f_mem0[l0][2].x+=(dzeta[l1]+dzeta[l2]+dzeta[l0])*vtemp.x;
			f_mem0[l0][2].y+=(dzeta[l1]+dzeta[l2]+dzeta[l0])*vtemp.y;
			f_mem0[l0][2].z+=(dzeta[l1]+dzeta[l2]+dzeta[l0])*vtemp.z;
			f_mem0[l0][3].x+=3.0*vtemp.x;
			f_mem0[l0][3].y+=3.0*vtemp.y;
			f_mem0[l0][3].z+=3.0*vtemp.z;
			CrossProduct3D(&vtemp,triangle_normal,r20);
			f_mem0[l1][1].x+=(zeta[l2]+zeta[l0]+zeta[l1])*vtemp.x;
			f_mem0[l1][1].y+=(zeta[l2]+zeta[l0]+zeta[l1])*vtemp.y;
			f_mem0[l1][1].z+=(zeta[l2]+zeta[l0]+zeta[l1])*vtemp.z;
			f_mem0[l1][2].x+=(dzeta[l2]+dzeta[l0]+dzeta[l1])*vtemp.x;
			f_mem0[l1][2].y+=(dzeta[l2]+dzeta[l0]+dzeta[l1])*vtemp.y;
			f_mem0[l1][2].z+=(dzeta[l2]+dzeta[l0]+dzeta[l1])*vtemp.z;
			f_mem0[l1][3].x+=3.0*vtemp.x;
			f_mem0[l1][3].y+=3.0*vtemp.y;
			f_mem0[l1][3].z+=3.0*vtemp.z;
			CrossProduct3D(&vtemp,triangle_normal,r01);
			f_mem0[l2][1].x+=(zeta[l0]+zeta[l1]+zeta[l2])*vtemp.x;
			f_mem0[l2][1].y+=(zeta[l0]+zeta[l1]+zeta[l2])*vtemp.y;
			f_mem0[l2][1].z+=(zeta[l0]+zeta[l1]+zeta[l2])*vtemp.z;
			f_mem0[l2][2].x+=(dzeta[l0]+dzeta[l1]+dzeta[l2])*vtemp.x;
			f_mem0[l2][2].y+=(dzeta[l0]+dzeta[l1]+dzeta[l2])*vtemp.y;
			f_mem0[l2][2].z+=(dzeta[l0]+dzeta[l1]+dzeta[l2])*vtemp.z;
			f_mem0[l2][3].x+=3.0*vtemp.x;
			f_mem0[l2][3].y+=3.0*vtemp.y;
			f_mem0[l2][3].z+=3.0*vtemp.z;

                        
		#endif

		areas[l0]+=triangle_area;
		areas[l1]+=triangle_area;
		areas[l2]+=triangle_area;
		

		#ifdef	CAPSULE
			sub3D(&r01,r_mem[l1],r_mem[l0]);
			sub3D(&r02,r_mem[l2],r_mem[l0]);

			g11=DotProduct3D(r01,r01);
			g22=DotProduct3D(r02,r02);
			g12=DotProduct3D(r01,r02);
		
			detg0=(ref_state[i][0]*ref_state[i][1]-ref_state[i][2]*ref_state[i][2]);
			detg01=1.0/detg0;
			detg012=sqrt(detg01);

			I1=(g11*ref_state[i][1]+g22*ref_state[i][0]-2.0*g12*ref_state[i][2])*detg01-2.0;
			I2=(g11*g22-g12*g12)*detg01-1.0;
		
			#ifdef NEOHOOKEAN
				C1=0.5*SHEAR_MU;
				C2=-0.5*SHEAR_MU/((I2+1.0)*(I2+1.0));
			#endif
			
			#ifdef SKALAK
				C1=0.5*(I1+1.0);
				C2=0.5*(SKALAK_C*I2-1.0);
			#endif

			#ifndef EXTENSIBLE
				temp3=1.0-(I1+2.0-2.0*sqrt(1.0+I2))*SHEAR_E2;
				C1=0.5*SHEAR_MU/(temp3*temp3);
				C2=-0.5*SHEAR_MU/sqrt(1.0+I2)/(temp3*temp3);
			#endif

//			temp3=0.5*SHEAR_MU/(sqrt(temp2)*(1.0-SHEAR_E2*(temp1*temp2-2.0*sqrt((g11*g22-g12*g12)*temp2)))*(1.0-SHEAR_E2*(temp1*temp2-2.0*sqrt((g11*g22-g12*g12)*temp2))));
			temp3=6.0*detg012;
		
			f_mem0[l1][1].x-=temp3*(C1*(ref_state[i][1]*r01.x-ref_state[i][2]*r02.x)+C2*(g22*r01.x-g12*r02.x));
			f_mem0[l1][1].y-=temp3*(C1*(ref_state[i][1]*r01.y-ref_state[i][2]*r02.y)+C2*(g22*r01.y-g12*r02.y));
			f_mem0[l1][1].z-=temp3*(C1*(ref_state[i][1]*r01.z-ref_state[i][2]*r02.z)+C2*(g22*r01.z-g12*r02.z));
			f_mem0[l2][1].x-=temp3*(C1*(ref_state[i][0]*r02.x-ref_state[i][2]*r01.x)+C2*(g11*r02.x-g12*r01.x));
			f_mem0[l2][1].y-=temp3*(C1*(ref_state[i][0]*r02.y-ref_state[i][2]*r01.y)+C2*(g11*r02.y-g12*r01.y));
			f_mem0[l2][1].z-=temp3*(C1*(ref_state[i][0]*r02.z-ref_state[i][2]*r01.z)+C2*(g11*r02.z-g12*r01.z));
			f_mem0[l0][1].x+=temp3*(C1*(ref_state[i][1]*r01.x+ref_state[i][0]*r02.x-ref_state[i][2]*(r02.x+r01.x))+C2*(g22*r01.x+g11*r02.x-g12*(r02.x+r01.x)));
			f_mem0[l0][1].y+=temp3*(C1*(ref_state[i][1]*r01.y+ref_state[i][0]*r02.y-ref_state[i][2]*(r02.y+r01.y))+C2*(g22*r01.y+g11*r02.y-g12*(r02.y+r01.y)));
			f_mem0[l0][1].z+=temp3*(C1*(ref_state[i][1]*r01.z+ref_state[i][0]*r02.z-ref_state[i][2]*(r02.z+r01.z))+C2*(g22*r01.z+g11*r02.z-g12*(r02.z+r01.z)));

                        /* f_mem0[i][1] contains the shear part and the inextensibility part*/
		#endif		
	} //End of FOR LOOP over NTriang

	for(i=0;i<NMEM;i++) for(j=1;j<4;j++) smul3D2(&f_mem0[i][j],1.0/areas[i]);
	
        for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++) sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
		new_quadratic_interpolator16(Nneighbours[i],points,&n_mem[i],&curv[i],&gauss[i],slaves[i],r_mem2,r_mem2temp);
	}

	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++){
			sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
			da[j]=curv[neighbours[i][j]]-curv[i];
		}
		new_surface_laplacian(Nneighbours[i],points,da,&n_mem[i],&lap_curv[i]);
	}



   	#ifdef CAPSULE_SWIMMER
		for(i=0;i<NTRIANG;i++){

			/* Looks like there is no reference to l0, l1 and l2 */

                        l0 = triang_site[i][0];
			l1 = triang_site[i][1];
			l2 = triang_site[i][2];                        

                             /* Added definition of l0, l1, l2 */


			sub3D(&r01,r_ref[l1],r_ref[l0]);
			sub3D(&r12,r_ref[l2],r_ref[l1]);
			CrossProduct3D(&triangle_normal,r12,r01);
			triangle_area=sqrt(DotProduct3D(triangle_normal,triangle_normal));
			for(j=0;j<3;j++){
				r_mem_xm.x+=r_ref[triang_site[i][j]].x*triangle_area;
				r_mem_xm.y+=r_ref[triang_site[i][j]].y*triangle_area;
				r_mem_xm.z+=r_ref[triang_site[i][j]].z*triangle_area;
				temp0+=triangle_area;
			}
		}
	#else
		for(i=0;i<NMEM;i++){
			r_mem_xm.x+=r_mem[i].x*areas[i];
			r_mem_xm.y+=r_mem[i].y*areas[i];
			r_mem_xm.z+=r_mem[i].z*areas[i];
			temp0+=areas[i];
		}
	#endif

	temp0=1.0/temp0;
	r_mem_xm.x*=temp0;
	r_mem_xm.y*=temp0;
	r_mem_xm.z*=temp0;
	for(i=0;i<NMEM;i++){

		#ifdef CAPSULE_SWIMMER
			vtemp.x=r_ref[i].x-r_mem_xm.x;
			vtemp.y=r_ref[i].y-r_mem_xm.y;
			vtemp.z=r_ref[i].z-r_mem_xm.z;
		#else
			vtemp.x=r_mem[i].x-r_mem_xm.x;
			vtemp.y=r_mem[i].y-r_mem_xm.y;
			vtemp.z=r_mem[i].z-r_mem_xm.z;
		#endif

		norm=1.0/sqrt(vtemp.x*vtemp.x+vtemp.y*vtemp.y+vtemp.z*vtemp.z);
		xi0[i].x=vtemp.x*norm;
		xi0[i].y=vtemp.y*norm;
		xi0[i].z=vtemp.z*norm;
	}

	for(i=0;i<NMEM;i++){
		colors[i]=F20*(1.5*xi0[i].z*xi0[i].z-0.5)+F30*(2.5*xi0[i].z*xi0[i].z*xi0[i].z-1.5*xi0[i].z)+F40*(4.375*xi0[i].z*xi0[i].z*xi0[i].z*xi0[i].z-3.75*xi0[i].z*xi0[i].z+0.375);
//		colors[i]=F32*(n_mem[i].z*(n_mem[i].x*n_mem[i].y))+F22*((n_mem[i].x*n_mem[i].y));
		f_mem[i].x=colors[i]*n_mem[i].x+Fx22*n_mem[i].y*n_mem[i].z;
		f_mem[i].y=colors[i]*n_mem[i].y+Fx22*n_mem[i].z*n_mem[i].x;
		f_mem[i].z=colors[i]*n_mem[i].z-Fx22*(n_mem[i].x*n_mem[i].y+n_mem[i].y*n_mem[i].x);
		
	}

	for(i=0;i<NMEM;i++){
		intNx.x+=areas[i]*n_mem[i].x*xi0[i].x;
		intNx.y+=areas[i]*n_mem[i].y*xi0[i].x;
		intNx.z+=areas[i]*n_mem[i].z*xi0[i].x;
		intNy.x+=areas[i]*n_mem[i].x*xi0[i].y;
		intNy.y+=areas[i]*n_mem[i].y*xi0[i].y;
		intNy.z+=areas[i]*n_mem[i].z*xi0[i].y;
		intNz.x+=areas[i]*n_mem[i].x*xi0[i].z;
		intNz.y+=areas[i]*n_mem[i].y*xi0[i].z;
		intNz.z+=areas[i]*n_mem[i].z*xi0[i].z;
		intF.x+=areas[i]*f_mem[i].x;
		intF.y+=areas[i]*f_mem[i].y;
		intF.z+=areas[i]*f_mem[i].z;
	}

	M=gsl_matrix_alloc(3,3);
	V=gsl_vector_alloc(3);
	gsl_matrix_set(M,0,0,intNx.x);
	gsl_matrix_set(M,0,1,intNy.x);
	gsl_matrix_set(M,0,2,intNz.x);
	gsl_vector_set(V,0,intF.x);
	gsl_matrix_set(M,1,0,intNx.y);
	gsl_matrix_set(M,1,1,intNy.y);
	gsl_matrix_set(M,1,2,intNz.y);
	gsl_vector_set(V,1,intF.y);
	gsl_matrix_set(M,2,0,intNx.z);
	gsl_matrix_set(M,2,1,intNy.z);
	gsl_matrix_set(M,2,2,intNz.z);
	gsl_vector_set(V,2,intF.z);
	gsl_linalg_HH_svx(M,V);

	for(i=0;i<NMEM;i++){
	
/* Not sure why these lines are here */	
             /*   vtemp.x=r_mem[i].x-r_mem_xm.x;  
		vtemp.y=r_mem[i].y-r_mem_xm.y;
		vtemp.z=r_mem[i].z-r_mem_xm.z; */
		temp0=gsl_vector_get(V,0)*xi0[i].x+gsl_vector_get(V,1)*xi0[i].y+gsl_vector_get(V,2)*xi0[i].z;
		f_mem[i].x-=temp0*n_mem[i].x;
		f_mem[i].y-=temp0*n_mem[i].y;
		f_mem[i].z-=temp0*n_mem[i].z;
		
	}

	gsl_matrix_free(M);
	gsl_vector_free(V);
	intF.x=intF.y=intF.z=0.0;
	intT.x=intT.y=intT.z=0.0;

	for(i=0;i<NMEM;i++){
		intF.x+=areas[i]*f_mem[i].x;
		intF.y+=areas[i]*f_mem[i].y;
	        intF.z+=areas[i]*f_mem[i].z;
		intT.x+=areas[i]*(f_mem[i].y*r_mem[i].z-f_mem[i].z*r_mem[i].y);
		intT.y+=areas[i]*(f_mem[i].z*r_mem[i].x-f_mem[i].x*r_mem[i].z);
		intT.z+=areas[i]*(f_mem[i].x*r_mem[i].y-f_mem[i].y*r_mem[i].x);
	}

	//if(lrint(time0/DT) % NSHOW == 0) printf("Active F %e %e %e  T  %e %e %e\n",intF.x,intF.y,intF.z,intT.x,intT.y,intT.z); 
	
        #ifdef STRETCH_EXPERIMENT
		F1=F2=0.0;
		Box_min.x=Box_min.y=Box_min.z=1.e10;
		Box_max.x=Box_max.y=Box_max.z=-1.e10;
	#endif


	for(i=0;i<NMEM;i++){

		fn= KAPPA*(4.0*curv[i]*(curv[i]*curv[i]-gauss[i]) + 2.0*lap_curv[i]); /* Spontaneous curvature = 0, fn includes only curvature terms */
		dzeta2[i]=(1.0-UNSTIFFENER)*dzeta2[i]+UNSTIFFENER*fn;
		f_mem0[i][1].x -= dzeta2[i]*n_mem[i].x;
		f_mem0[i][1].y -= dzeta2[i]*n_mem[i].y;
		f_mem0[i][1].z -= dzeta2[i]*n_mem[i].z;


		f_mem0[i][1].x+=f_mem[i].x;
		f_mem0[i][1].y+=f_mem[i].y;
		f_mem0[i][1].z+=f_mem[i].z;     /* f_mem0[i][1] contains the sum of active force and the curvature/bending force due to Helfrich, both along normal and one component of the inextensibility force, which probably has both tangential and normal components*/

		#ifdef STRETCH_EXPERIMENT
			temp0=(r_mem[i].x-r_mem[ZMAX].x)*(r_mem[i].x-r_mem[ZMAX].x)+(r_mem[i].y-r_mem[ZMAX].y)*(r_mem[i].y-r_mem[ZMAX].y)+(r_mem[i].z-r_mem[ZMAX].z)*(r_mem[i].z-r_mem[ZMAX].z);
			f_mem[i].x=f_mem[i].y=f_mem[i].z=0.0;
			if(temp0<PULL_AREA){
				temp0=(temp0/PULL_AREA-1.0);
				temp0=PULL_FORCE*temp0*temp0;
				f_mem0[i][1].z+=temp0;
				f_mem[i].z=temp0;
				F1+=areas[i]*temp0;
			}
			temp0=(r_mem[i].x-r_mem[ZMIN].x)*(r_mem[i].x-r_mem[ZMIN].x)+(r_mem[i].y-r_mem[ZMIN].y)*(r_mem[i].y-r_mem[ZMIN].y)+(r_mem[i].z-r_mem[ZMIN].z)*(r_mem[i].z-r_mem[ZMIN].z);
			if(temp0<PULL_AREA){
				temp0=(temp0/PULL_AREA-1.0);
				temp0=PULL_FORCE*temp0*temp0;
				f_mem0[i][1].z-=temp0;
				f_mem[i].z=-temp0;
				F2-=areas[i]*temp0;
			}
			if(r_mem[i].x>Box_max.x){
				Box_max.x=r_mem[i].x;
				ixmax=i;
			}
			if(r_mem[i].y>Box_max.y){
				Box_max.y=r_mem[i].y;
				iymax=i;
			}
			if(r_mem[i].z>Box_max.z){
				Box_max.z=r_mem[i].z;
				izmax=i;
			}
			if(r_mem[i].x<Box_min.x){
				Box_min.x=r_mem[i].x;
				ixmin=i;
			}
			if(r_mem[i].y<Box_min.y){
				Box_min.y=r_mem[i].y;
				iymin=i;
			}
			if(r_mem[i].z<Box_min.z){
				Box_min.z=r_mem[i].z;
				izmin=i;
			}

		#endif	
	
	} //End of For loop over NMEM

	#ifdef STRETCH_EXPERIMENT
		fp=fopen("stretch.dat","a+");
		fprintf(fp,"%f %f %f %f %f %f %f %f %f %f %f %f\n",F1-F2,Box_max.x-Box_min.x,Box_max.y-Box_min.y,Box_max.z-Box_min.z,F1,F2,Box_max.x,Box_max.y,Box_max.z,Box_min.z,Box_min.x,Box_min.y);
		fclose(fp);
	#endif

	for(i=0;i<NMEM2;i++){
		for(j=0;j<1;j++) fdA2[i][j].x=fdA2[i][j].y=fdA2[i][j].z=0.0;
		areas2[i]=0.0;
	}

	for(i=0;i<NTRIANG2;i++){
		l0 = triang_site2[i][0];
		l1 = triang_site2[i][1];
		l2 = triang_site2[i][2];
		sub3D(&r01,r_mem2[l1],r_mem2[l0]);
		sub3D(&r12,r_mem2[l2],r_mem2[l1]);
		sub3D(&r20,r_mem2[l0],r_mem2[l2]);
		CrossProduct3D(&triangle_normal,r12,r01);
		smul3D2(&triangle_normal,-1.0/6.0);
		darea2[i]=triangle_area=sqrt(DotProduct3D(triangle_normal,triangle_normal));
		for(j=0;j<3;j++){
			fdA2[triang_site2[i][j]][0].x+=triangle_normal.x;
			fdA2[triang_site2[i][j]][0].y+=triangle_normal.y;
			fdA2[triang_site2[i][j]][0].z+=triangle_normal.z;
			areas2[triang_site2[i][j]]+=triangle_area;			
		}
	}
	
	for(i=0;i<NMEM2;i++){
		triangle_area=1.0/sqrt(DotProduct3D(fdA2[i][0],fdA2[i][0]));
		smul3D(&f_mem0[i][0],triangle_area,fdA2[i][0]);
	}

/*	temp1=0.0;

	for(i=0;i<NMEM;i++)temp1+=DotProduct3D(n_mem[i],fdA2[i][0]);

	for(j=1;j<4;j++){
		temp2=0.0;
		for(i=0;i<NMEM;i++) temp2+=DotProduct3D(f_mem0[i][j],fdA2[i][0]);
		temp2=-temp2/temp1;
		for(i=0;i<NMEM;i++){
			f_mem0[i][j].x+=temp2*n_mem[i].x;                         // This looks like a subtraction of the integral normal force 
			f_mem0[i][j].y+=temp2*n_mem[i].y;
			f_mem0[i][j].z+=temp2*n_mem[i].z;
		}
	}*/

	for(v=0;v<NMEM;v++){

		for(j=0;j<Nneighbours[v];j++){

			for(k=1;k<4;k++){

				f_mem0[slaves[v][j+1]][k].x+=0.75*f_mem0[v][k].x;
				f_mem0[slaves[v][j+1]][k].y+=0.75*f_mem0[v][k].y;
				f_mem0[slaves[v][j+1]][k].z+=0.75*f_mem0[v][k].z;
				f_mem0[slaves[v][2*j+7]][k].x+=0.5*f_mem0[v][k].x;
				f_mem0[slaves[v][2*j+7]][k].y+=0.5*f_mem0[v][k].y;
				f_mem0[slaves[v][2*j+7]][k].z+=0.5*f_mem0[v][k].z;
				f_mem0[slaves[v][2*j+8]][k].x+=0.5*f_mem0[v][k].x;
				f_mem0[slaves[v][2*j+8]][k].y+=0.5*f_mem0[v][k].y;
				f_mem0[slaves[v][2*j+8]][k].z+=0.5*f_mem0[v][k].z;
				f_mem0[slaves[v][3*j+19]][k].x+=0.25*f_mem0[v][k].x;
				f_mem0[slaves[v][3*j+19]][k].y+=0.25*f_mem0[v][k].y;
				f_mem0[slaves[v][3*j+19]][k].z+=0.25*f_mem0[v][k].z;
				f_mem0[slaves[v][3*j+20]][k].x+=0.25*f_mem0[v][k].x;
				f_mem0[slaves[v][3*j+20]][k].y+=0.25*f_mem0[v][k].y;
				f_mem0[slaves[v][3*j+20]][k].z+=0.25*f_mem0[v][k].z;
				f_mem0[slaves[v][3*j+21]][k].x+=0.25*f_mem0[v][k].x;
				f_mem0[slaves[v][3*j+21]][k].y+=0.25*f_mem0[v][k].y;
				f_mem0[slaves[v][3*j+21]][k].z+=0.25*f_mem0[v][k].z;
			}

			v_mem2[slaves[v][j+1]].x+=0.75*v_mem2[v].x;
			v_mem2[slaves[v][j+1]].y+=0.75*v_mem2[v].y;
			v_mem2[slaves[v][j+1]].z+=0.75*v_mem2[v].z;
			v_mem2[slaves[v][2*j+7]].x+=0.5*v_mem2[v].x;
			v_mem2[slaves[v][2*j+7]].y+=0.5*v_mem2[v].y;
			v_mem2[slaves[v][2*j+7]].z+=0.5*v_mem2[v].z;
			v_mem2[slaves[v][2*j+8]].x+=0.5*v_mem2[v].x;
			v_mem2[slaves[v][2*j+8]].y+=0.5*v_mem2[v].y;
			v_mem2[slaves[v][2*j+8]].z+=0.5*v_mem2[v].z;
			v_mem2[slaves[v][3*j+19]].x+=0.25*v_mem2[v].x;
			v_mem2[slaves[v][3*j+19]].y+=0.25*v_mem2[v].y;
			v_mem2[slaves[v][3*j+19]].z+=0.25*v_mem2[v].z;
			v_mem2[slaves[v][3*j+20]].x+=0.25*v_mem2[v].x;
			v_mem2[slaves[v][3*j+20]].y+=0.25*v_mem2[v].y;
			v_mem2[slaves[v][3*j+20]].z+=0.25*v_mem2[v].z;
			v_mem2[slaves[v][3*j+21]].x+=0.25*v_mem2[v].x;
			v_mem2[slaves[v][3*j+21]].y+=0.25*v_mem2[v].y;
			v_mem2[slaves[v][3*j+21]].z+=0.25*v_mem2[v].z;

		} // End of for loop over Nnieghbours 

	} //End of For loop over NMEM



/*	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++){
			sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
		}
		for(k=1;k<3;k++){
			for(j=0;j<Nneighbours[i];j++){
				sub3D(&forces[j],f_mem0[neighbours[i][j]][k],f_mem0[i][k]);
			}
			new_force_interpolator16(Nneighbours[i],points,forces,&n_mem[i],slaves[i],r_mem2,f_mem0,k);
		}
		for(j=0;j<Nneighbours[i];j++){
			sub3D(&forces[j],v_mem2[neighbours[i][j]],v_mem2[i]);
		}
		new_velocity_interpolator16(Nneighbours[i],points,forces,&n_mem[i],slaves[i],r_mem2,v_mem2);
	}*/

/* 12/2/15: Changed corrections to force and torque to be simultaneous */
	intF.x=intF.y=intF.z=0.0;
	intT.x=intT.y=intT.z=0.0;
        intN.x=intN.y=intN.z=0.0;
        
        sumxmem=sumymem=sumzmem=0.0;
        totalarea=0.0;
        mt33=mt34=mt35=mt43=mt44=mt45=mt53=mt54=mt55=0.0;

        for(i=0;i<NMEM;i++){
		intF.x+=areas[i]*f_mem0[i][1].x;
		intF.y+=areas[i]*f_mem0[i][1].y;
		intF.z+=areas[i]*f_mem0[i][1].z;

		intT.x+=areas[i]*(f_mem0[i][1].y*r_mem[i].z-f_mem0[i][1].z*r_mem[i].y);
		intT.y+=areas[i]*(f_mem0[i][1].z*r_mem[i].x-f_mem0[i][1].x*r_mem[i].z);
		intT.z+=areas[i]*(f_mem0[i][1].x*r_mem[i].y-f_mem0[i][1].y*r_mem[i].x); 

                intN.x+=areas[i]*n_mem[i].x;
		intN.y+=areas[i]*n_mem[i].y;
		intN.z+=areas[i]*n_mem[i].z;

                sumxmem += areas[i]*r_mem[i].x;
                sumymem += areas[i]*r_mem[i].y;
		sumzmem += areas[i]*r_mem[i].z;

		mt33 -= areas[i]*(n_mem[i].z*r_mem[i].z+n_mem[i].y*r_mem[i].y) ;
		mt34 += areas[i]*n_mem[i].x*r_mem[i].y;
		mt35 += areas[i]*n_mem[i].x*r_mem[i].z;
		mt43 += areas[i]*n_mem[i].y*r_mem[i].x;
		mt44 -= areas[i]*(n_mem[i].z*r_mem[i].z+n_mem[i].x*r_mem[i].x) ;
		mt45 += areas[i]*n_mem[i].y*r_mem[i].z;
		mt53 += areas[i]*n_mem[i].z*r_mem[i].x;
		mt54 += areas[i]*n_mem[i].z*r_mem[i].y;
		mt55 -= areas[i]*(n_mem[i].x*r_mem[i].x+n_mem[i].y*r_mem[i].y) ;

                totalarea +=areas[i];
	}


      //if(lrint(time0/DT) % NSHOW == 0) printf("time %f Before correction Torq1 %e %e %e  Force1  %e  %e  %e\n",time0,intT.x,intT.y,intT.z,intF.x,intF.y,intF.z);
      

	MT=gsl_matrix_alloc(6,6);
	VT=gsl_vector_alloc(6);
	
	gsl_matrix_set(MT,0,0,totalarea);
	gsl_matrix_set(MT,0,1,0.0);
	gsl_matrix_set(MT,0,2,0.0);
	gsl_matrix_set(MT,0,3,0.0);
	gsl_matrix_set(MT,0,4,intN.z);
	gsl_matrix_set(MT,0,5,(-1.0*intN.y));
	gsl_vector_set(VT,0,intF.x);
       
	gsl_matrix_set(MT,1,0,0.0);
	gsl_matrix_set(MT,1,1,totalarea);
	gsl_matrix_set(MT,1,2,0.0);
	gsl_matrix_set(MT,1,3,(-1.0*intN.z));
	gsl_matrix_set(MT,1,4,0.0);
	gsl_matrix_set(MT,1,5,intN.x);
	gsl_vector_set(VT,1,intF.y); 


	gsl_matrix_set(MT,2,0,0.0);
	gsl_matrix_set(MT,2,1,0.0);
	gsl_matrix_set(MT,2,2,totalarea);
	gsl_matrix_set(MT,2,3,intN.y);
	gsl_matrix_set(MT,2,4,(-1.0*intN.x));
	gsl_matrix_set(MT,2,5,0.0);
	gsl_vector_set(VT,2,intF.z);

	gsl_matrix_set(MT,3,0,0.0);
	gsl_matrix_set(MT,3,1,sumzmem);
	gsl_matrix_set(MT,3,2,(-1.0*sumymem));
	gsl_matrix_set(MT,3,3,mt33);
	gsl_matrix_set(MT,3,4,mt34);
	gsl_matrix_set(MT,3,5,mt35);
	gsl_vector_set(VT,3,intT.x);

	gsl_matrix_set(MT,4,0,(-1.0*sumzmem));
	gsl_matrix_set(MT,4,1,0);
	gsl_matrix_set(MT,4,2,sumxmem);
	gsl_matrix_set(MT,4,3,mt43);
	gsl_matrix_set(MT,4,4,mt44);
	gsl_matrix_set(MT,4,5,mt45);
	gsl_vector_set(VT,4,intT.y);

	gsl_matrix_set(MT,5,0,sumymem);
	gsl_matrix_set(MT,5,1,(-1.0*sumxmem));
	gsl_matrix_set(MT,5,2,0.0);
	gsl_matrix_set(MT,5,3,mt53);
	gsl_matrix_set(MT,5,4,mt54);
	gsl_matrix_set(MT,5,5,mt55);
	gsl_vector_set(VT,5,intT.z);

	gsl_linalg_HH_svx(MT,VT);

  	betax=gsl_vector_get(VT,0);
	betay=gsl_vector_get(VT,1);
	betaz=gsl_vector_get(VT,2);      

        
        alphax=gsl_vector_get(VT,3);
	alphay=gsl_vector_get(VT,4);
	alphaz=gsl_vector_get(VT,5);

        /* Now we can apply the corrections to the forces */
        for(i=0;i<NMEM;i++){

       		f_mem0[i][1].x -= betax + (alphay*n_mem[i].z-alphaz*n_mem[i].y);
		f_mem0[i][1].y -= betay + (alphaz*n_mem[i].x-alphax*n_mem[i].z);
                f_mem0[i][1].z -= betaz + (alphax*n_mem[i].y-alphay*n_mem[i].x);
        } 


       /* Verify the integral force and torque values */
	intF.x=intF.y=intF.z=intT.x=intT.y=intT.z=0.0;
	
        for(i=0;i<NMEM;i++){
		intF.x+=areas[i]*f_mem0[i][1].x;
		intF.y+=areas[i]*f_mem0[i][1].y;
		intF.z+=areas[i]*f_mem0[i][1].z;
		intT.x+=areas[i]*(f_mem0[i][1].y*r_mem[i].z-f_mem0[i][1].z*r_mem[i].y);
		intT.y+=areas[i]*(f_mem0[i][1].z*r_mem[i].x-f_mem0[i][1].x*r_mem[i].z);
		intT.z+=areas[i]*(f_mem0[i][1].x*r_mem[i].y-f_mem0[i][1].y*r_mem[i].x);

               

	}
       // if (pow((intF.x*intF.x+ intF.y*intF.y + intF.z*intF.z),0.5) > 0.0000001) printf("WARNING - HIGH INTEGRAL FORCE \n");
       // if (pow((intT.x*intT.x+ intT.y*intT.y + intT.z*intT.z),0.5) > 0.0000001) printf("WARNING - HIGH INTEGRAL TORQUE \n");
       if(lrint(time0/DT) % NSHOW == 0)  printf("time %f After correction Torq1 %e %e %e  Force1  %e  %e  %e\n",time0,intT.x,intT.y,intT.z,intF.x,intF.y,intF.z);
      

	for(i=0;i<NMEM2;i++){
		f_mem[i].x=f_mem0[i][1].x;
		f_mem[i].y=f_mem0[i][1].y;
		f_mem[i].z=f_mem0[i][1].z;   /*Three lines above uncommented March 22 2016 so that stress calculation uses entire force*/
		for(j=1;j<4;j++) {
			fdA2[i][j].x=areas2[i]*f_mem0[i][j].x;
			fdA2[i][j].y=areas2[i]*f_mem0[i][j].y;
			fdA2[i][j].z=areas2[i]*f_mem0[i][j].z;
		}
	}

	for(i=0;i<NMEM;i++){
		areas[i]=areas2[i]*16.0;
		for(k=0;k<4;k++){
			fdA[i][k].x=16.0*fdA2[i][k].x;
			fdA[i][k].y=16.0*fdA2[i][k].y;
			fdA[i][k].z=16.0*fdA2[i][k].z;
		}
	}

}
/* END test_get_force16 */


void test_get_force161(int triang_site[NTRIANG][3], int triang_site2[NTRIANG2][3], struct point3D r_mem[], struct point3D r_mem2[], struct point3D r_mem0[], struct point3D n_mem[], double kappa, double curv[], double gauss[], double lap_curv[], double zeta[], double zeta2[], double dzeta[NMEM], double dzeta2[NMEM2], struct point3D f_mem[NMEM2], struct point3D f_mem0[NMEM2][4], struct point3D fdA[NMEM][4], struct point3D fdA2[NMEM2][4], int Nneighbours[NMEM], int neighbours[NMEM][6], int slaves[NMEM][NSLA], double r_max[NMEM], struct point3D v_mem[NMEM], struct point3D v_mem2[NMEM2], double ref_state[NTRIANG][4],double areas[NMEM]){
	int	i, j, k, l, l0, l1, l2,v;
	double	fn0[4], nn0, fn, triangle_area,norm;
	int	npoints;
	struct	point3D points[6],forces[6],triangle_normal,r01,r12,r20,r02,vtemp,r_mem2temp[NMEM2];
	double	da[6],dz[6],areas2[NMEM2],fn2[NMEM2],darea2[NTRIANG2],g11,g22,g12,temp1,temp2,temp3;

	for(i=0;i<NMEM2;i++) {
		for(j=0;j<4;j++)f_mem0[i][j].x=f_mem0[i][j].y=f_mem0[i][j].z=0.0;
	}
	for(i=0;i<NMEM;i++){
		areas[i]=0.0;
		v_mem2[i].x=v_mem[i].x;
		v_mem2[i].y=v_mem[i].y;
		v_mem2[i].z=v_mem[i].z;
	}
	for(i=NMEM;i<NMEM2;i++){
		v_mem2[i].x=v_mem2[i].y=v_mem2[i].z=0.0;
	}
	for(i=0;i<NMEM2;i++){
		r_mem2temp[i].x=r_mem2[i].x;
		r_mem2temp[i].y=r_mem2[i].y;
		r_mem2temp[i].z=r_mem2[i].z;
	}
	for(i=0;i<NTRIANG;i++){
		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];
		sub3D(&r01,r_mem[l1],r_mem[l0]);
		sub3D(&r12,r_mem[l2],r_mem[l1]);
		sub3D(&r20,r_mem[l0],r_mem[l2]);
		CrossProduct3D(&triangle_normal,r12,r01);
		triangle_area=sqrt(DotProduct3D(triangle_normal,triangle_normal));
		smul3D2(&triangle_normal,1.0/triangle_area);
		CrossProduct3D(&vtemp,triangle_normal,r12);
		f_mem0[l0][1].x+=(zeta[l1]+zeta[l2]+zeta[l0])*vtemp.x;
		f_mem0[l0][1].y+=(zeta[l1]+zeta[l2]+zeta[l0])*vtemp.y;
		f_mem0[l0][1].z+=(zeta[l1]+zeta[l2]+zeta[l0])*vtemp.z;
		f_mem0[l0][2].x+=(dzeta[l1]+dzeta[l2]+dzeta[l0])*vtemp.x;
		f_mem0[l0][2].y+=(dzeta[l1]+dzeta[l2]+dzeta[l0])*vtemp.y;
		f_mem0[l0][2].z+=(dzeta[l1]+dzeta[l2]+dzeta[l0])*vtemp.z;
		f_mem0[l0][3].x+=3.0*vtemp.x;
		f_mem0[l0][3].y+=3.0*vtemp.y;
		f_mem0[l0][3].z+=3.0*vtemp.z;
		CrossProduct3D(&vtemp,triangle_normal,r20);
		f_mem0[l1][1].x+=(zeta[l2]+zeta[l0]+zeta[l1])*vtemp.x;
		f_mem0[l1][1].y+=(zeta[l2]+zeta[l0]+zeta[l1])*vtemp.y;
		f_mem0[l1][1].z+=(zeta[l2]+zeta[l0]+zeta[l1])*vtemp.z;
		f_mem0[l1][2].x+=(dzeta[l2]+dzeta[l0]+dzeta[l1])*vtemp.x;
		f_mem0[l1][2].y+=(dzeta[l2]+dzeta[l0]+dzeta[l1])*vtemp.y;
		f_mem0[l1][2].z+=(dzeta[l2]+dzeta[l0]+dzeta[l1])*vtemp.z;
		f_mem0[l1][3].x+=3.0*vtemp.x;
		f_mem0[l1][3].y+=3.0*vtemp.y;
		f_mem0[l1][3].z+=3.0*vtemp.z;
		CrossProduct3D(&vtemp,triangle_normal,r01);
		f_mem0[l2][1].x+=(zeta[l0]+zeta[l1]+zeta[l2])*vtemp.x;
		f_mem0[l2][1].y+=(zeta[l0]+zeta[l1]+zeta[l2])*vtemp.y;
		f_mem0[l2][1].z+=(zeta[l0]+zeta[l1]+zeta[l2])*vtemp.z;
		f_mem0[l2][2].x+=(dzeta[l0]+dzeta[l1]+dzeta[l2])*vtemp.x;
		f_mem0[l2][2].y+=(dzeta[l0]+dzeta[l1]+dzeta[l2])*vtemp.y;
		f_mem0[l2][2].z+=(dzeta[l0]+dzeta[l1]+dzeta[l2])*vtemp.z;
		f_mem0[l2][3].x+=3.0*vtemp.x;
		f_mem0[l2][3].y+=3.0*vtemp.y;
		f_mem0[l2][3].z+=3.0*vtemp.z;
		areas[l0]+=triangle_area;
		areas[l1]+=triangle_area;
		areas[l2]+=triangle_area;
#ifdef	CAPSULE
		sub3D(&r01,r_mem[l1],r_mem[l0]);
		sub3D(&r02,r_mem[l2],r_mem[l0]);
		g11=DotProduct3D(r01,r01);
		g22=DotProduct3D(r02,r02);
		g12=DotProduct3D(r01,r02);
		temp1=(g11*ref_state[i][1]+g22*ref_state[i][0]-2.0*g12*ref_state[i][2]);
		temp2=1.0/(ref_state[i][0]*ref_state[i][1]-ref_state[i][2]*ref_state[i][2]);
	//	temp3=2.0*SHEAR_MU*ref_state[i][3]*temp2*exp((temp1*temp1*temp2-g11*g22+g12*g12)*temp2);
		temp3=2.0*SHEAR_MU*ref_state[i][3]*temp2;
		f_mem0[l1][1].x-=temp3*(temp1*(ref_state[i][1]*r01.x-ref_state[i][2]*r02.x)*temp2-2.0*(g22*r01.x-g12*r02.x));
		f_mem0[l1][1].y-=temp3*(temp1*(ref_state[i][1]*r01.y-ref_state[i][2]*r02.y)*temp2-2.0*(g22*r01.y-g12*r02.y));
		f_mem0[l1][1].z-=temp3*(temp1*(ref_state[i][1]*r01.z-ref_state[i][2]*r02.z)*temp2-2.0*(g22*r01.z-g12*r02.z));
		f_mem0[l2][1].x-=temp3*(temp1*(ref_state[i][0]*r02.x-ref_state[i][2]*r01.x)*temp2-2.0*(g11*r02.x-g12*r01.x));
		f_mem0[l2][1].y-=temp3*(temp1*(ref_state[i][0]*r02.y-ref_state[i][2]*r01.y)*temp2-2.0*(g11*r02.y-g12*r01.y));
		f_mem0[l2][1].z-=temp3*(temp1*(ref_state[i][0]*r02.z-ref_state[i][2]*r01.z)*temp2-2.0*(g11*r02.z-g12*r01.z));
		f_mem0[l0][1].x+=temp3*(temp1*(ref_state[i][1]*r01.x+ref_state[i][0]*r02.x-ref_state[i][2]*(r02.x+r01.x))*temp2-2.0*(g22*r01.x+g11*r02.x-g12*(r02.x+r01.x)));
		f_mem0[l0][1].y+=temp3*(temp1*(ref_state[i][1]*r01.y+ref_state[i][0]*r02.y-ref_state[i][2]*(r02.y+r01.y))*temp2-2.0*(g22*r01.y+g11*r02.y-g12*(r02.y+r01.y)));
		f_mem0[l0][1].z+=temp3*(temp1*(ref_state[i][1]*r01.z+ref_state[i][0]*r02.z-ref_state[i][2]*(r02.z+r01.z))*temp2-2.0*(g22*r01.z+g11*r02.z-g12*(r02.z+r01.z)));

#endif		
	}
	for(i=0;i<NMEM;i++) for(j=1;j<4;j++) smul3D2(&f_mem0[i][j],1.0/areas[i]);
	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++) sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
		new_quadratic_interpolator16(Nneighbours[i],points,&n_mem[i],&curv[i],&gauss[i],slaves[i],r_mem2,r_mem2temp);
	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++){
			sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
			da[j]=curv[neighbours[i][j]]-curv[i];
		}
		new_surface_laplacian(Nneighbours[i],points,da,&n_mem[i],&lap_curv[i]);
	}

	for(i=0;i<NMEM;i++){
		fn=kappa*(4.0*curv[i]*(curv[i]*curv[i]-gauss[i]) + 2.0*lap_curv[i]);
		dzeta2[i]=(1.0-UNSTIFFENER)*dzeta2[i]+UNSTIFFENER*fn;
		f_mem0[i][1].x -= dzeta2[i]*n_mem[i].x;
		f_mem0[i][1].y -= dzeta2[i]*n_mem[i].y;
		f_mem0[i][1].z -= dzeta2[i]*n_mem[i].z;
	}

	for(i=0;i<NMEM2;i++){
		for(j=0;j<1;j++) fdA2[i][j].x=fdA2[i][j].y=fdA2[i][j].z=0.0;
		areas2[i]=0.0;
	}
	for(i=0;i<NTRIANG2;i++){
		l0 = triang_site2[i][0];
		l1 = triang_site2[i][1];
		l2 = triang_site2[i][2];
		sub3D(&r01,r_mem2[l1],r_mem2[l0]);
		sub3D(&r12,r_mem2[l2],r_mem2[l1]);
		sub3D(&r20,r_mem2[l0],r_mem2[l2]);
		CrossProduct3D(&triangle_normal,r12,r01);
		smul3D2(&triangle_normal,-1.0/6.0);
		darea2[i]=triangle_area=sqrt(DotProduct3D(triangle_normal,triangle_normal));
		for(j=0;j<3;j++){
			fdA2[triang_site2[i][j]][0].x+=triangle_normal.x;
			fdA2[triang_site2[i][j]][0].y+=triangle_normal.y;
			fdA2[triang_site2[i][j]][0].z+=triangle_normal.z;
			areas2[triang_site2[i][j]]+=triangle_area;			
		}
	}
	
	for(i=0;i<NMEM2;i++){
		triangle_area=1.0/sqrt(DotProduct3D(fdA2[i][0],fdA2[i][0]));
		smul3D(&f_mem0[i][0],triangle_area,fdA2[i][0]);
	}
/*	temp1=0.0;
	for(i=0;i<NMEM;i++)temp1+=DotProduct3D(n_mem[i],fdA2[i][0]);
	for(j=1;j<4;j++){
		temp2=0.0;
		for(i=0;i<NMEM;i++) temp2+=DotProduct3D(f_mem0[i][j],fdA2[i][0]);
		temp2=-temp2/temp1;
		for(i=0;i<NMEM;i++){
			f_mem0[i][j].x+=temp2*n_mem[i].x;
			f_mem0[i][j].y+=temp2*n_mem[i].y;
			f_mem0[i][j].z+=temp2*n_mem[i].z;
		}
	}*/

	for(v=0;v<NMEM;v++){
		for(j=0;j<Nneighbours[v];j++){
			for(k=1;k<4;k++){
				f_mem0[slaves[v][j+1]][k].x+=0.75*f_mem0[v][k].x;
				f_mem0[slaves[v][j+1]][k].y+=0.75*f_mem0[v][k].y;
				f_mem0[slaves[v][j+1]][k].z+=0.75*f_mem0[v][k].z;
				f_mem0[slaves[v][2*j+7]][k].x+=0.5*f_mem0[v][k].x;
				f_mem0[slaves[v][2*j+7]][k].y+=0.5*f_mem0[v][k].y;
				f_mem0[slaves[v][2*j+7]][k].z+=0.5*f_mem0[v][k].z;
				f_mem0[slaves[v][2*j+8]][k].x+=0.5*f_mem0[v][k].x;
				f_mem0[slaves[v][2*j+8]][k].y+=0.5*f_mem0[v][k].y;
				f_mem0[slaves[v][2*j+8]][k].z+=0.5*f_mem0[v][k].z;
				f_mem0[slaves[v][3*j+19]][k].x+=0.25*f_mem0[v][k].x;
				f_mem0[slaves[v][3*j+19]][k].y+=0.25*f_mem0[v][k].y;
				f_mem0[slaves[v][3*j+19]][k].z+=0.25*f_mem0[v][k].z;
				f_mem0[slaves[v][3*j+20]][k].x+=0.25*f_mem0[v][k].x;
				f_mem0[slaves[v][3*j+20]][k].y+=0.25*f_mem0[v][k].y;
				f_mem0[slaves[v][3*j+20]][k].z+=0.25*f_mem0[v][k].z;
				f_mem0[slaves[v][3*j+21]][k].x+=0.25*f_mem0[v][k].x;
				f_mem0[slaves[v][3*j+21]][k].y+=0.25*f_mem0[v][k].y;
				f_mem0[slaves[v][3*j+21]][k].z+=0.25*f_mem0[v][k].z;
			}
			v_mem2[slaves[v][j+1]].x+=0.75*v_mem2[v].x;
			v_mem2[slaves[v][j+1]].y+=0.75*v_mem2[v].y;
			v_mem2[slaves[v][j+1]].z+=0.75*v_mem2[v].z;
			v_mem2[slaves[v][2*j+7]].x+=0.5*v_mem2[v].x;
			v_mem2[slaves[v][2*j+7]].y+=0.5*v_mem2[v].y;
			v_mem2[slaves[v][2*j+7]].z+=0.5*v_mem2[v].z;
			v_mem2[slaves[v][2*j+8]].x+=0.5*v_mem2[v].x;
			v_mem2[slaves[v][2*j+8]].y+=0.5*v_mem2[v].y;
			v_mem2[slaves[v][2*j+8]].z+=0.5*v_mem2[v].z;
			v_mem2[slaves[v][3*j+19]].x+=0.25*v_mem2[v].x;
			v_mem2[slaves[v][3*j+19]].y+=0.25*v_mem2[v].y;
			v_mem2[slaves[v][3*j+19]].z+=0.25*v_mem2[v].z;
			v_mem2[slaves[v][3*j+20]].x+=0.25*v_mem2[v].x;
			v_mem2[slaves[v][3*j+20]].y+=0.25*v_mem2[v].y;
			v_mem2[slaves[v][3*j+20]].z+=0.25*v_mem2[v].z;
			v_mem2[slaves[v][3*j+21]].x+=0.25*v_mem2[v].x;
			v_mem2[slaves[v][3*j+21]].y+=0.25*v_mem2[v].y;
			v_mem2[slaves[v][3*j+21]].z+=0.25*v_mem2[v].z;
		}
	}



/*	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++){
			sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
		}
		for(k=1;k<3;k++){
			for(j=0;j<Nneighbours[i];j++){
				sub3D(&forces[j],f_mem0[neighbours[i][j]][k],f_mem0[i][k]);
			}
			new_force_interpolator16(Nneighbours[i],points,forces,&n_mem[i],slaves[i],r_mem2,f_mem0,k);
		}
		for(j=0;j<Nneighbours[i];j++){
			sub3D(&forces[j],v_mem2[neighbours[i][j]],v_mem2[i]);
		}
		new_velocity_interpolator16(Nneighbours[i],points,forces,&n_mem[i],slaves[i],r_mem2,v_mem2);
	}*/

	for(i=0;i<NMEM2;i++){
		f_mem[i].x=f_mem0[i][1].x;
		f_mem[i].y=f_mem0[i][1].y;
		f_mem[i].z=f_mem0[i][1].z;
		for(j=1;j<4;j++) {
			fdA2[i][j].x=areas2[i]*f_mem0[i][j].x;
			fdA2[i][j].y=areas2[i]*f_mem0[i][j].y;
			fdA2[i][j].z=areas2[i]*f_mem0[i][j].z;
		}
	}
	for(i=0;i<NMEM;i++){
		areas[i]=areas2[i]*16.0;
		for(k=0;k<4;k++){
			fdA[i][k].x=16.0*fdA2[i][k].x;
			fdA[i][k].y=16.0*fdA2[i][k].y;
			fdA[i][k].z=16.0*fdA2[i][k].z;
		}
	}
}



void test_get_force_fast(int triang_site[NTRIANG][3], int triang_site2[NTRIANG2][3], struct point3D r_mem[], struct point3D r_mem2[], struct point3D r_mem0[], struct point3D n_mem[], double kappa, double curv[], double gauss[], double lap_curv[], double zeta[], double zeta2[], double dzeta[NMEM], double dzeta2[NMEM2], struct point3D f_mem[NMEM2], struct point3D f_mem0[NMEM2][4], struct point3D fdA[NMEM][4], struct point3D fdA2[NMEM2][4], int Nneighbours[NMEM], int neighbours[NMEM][6], int slaves[NMEM][NSLA], double r_max[NMEM], struct point3D v_mem[NMEM], struct point3D v_mem2[NMEM2]){
	int	i, j, k, l, l0, l1, l2,v;
	double	fn0, fn, triangle_area,norm;
	int	npoints;
	struct	point3D points[6],forces[6],triangle_normal,r01,r12,r20,vtemp,r_mem2temp[NMEM2];
	double	da[6],dz[6],areas[NMEM],areas2[NMEM2],fn2[NMEM2],darea2[NTRIANG2];

	for(i=0;i<NMEM;i++) {
		for(j=1;j<4;j++)f_mem0[i][j].x=f_mem0[i][j].y=f_mem0[i][j].z=0.0;
		fdA[i][0].x=fdA[i][0].y=fdA[i][0].z=0.0;
	}
	for(i=0;i<NMEM;i++){
		areas[i]=0.0;
		v_mem2[i].x=v_mem[i].x;
		v_mem2[i].y=v_mem[i].y;
		v_mem2[i].z=v_mem[i].z;
	}
	for(i=0;i<NTRIANG;i++){
		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];
		sub3D(&r01,r_mem[l1],r_mem[l0]);
		sub3D(&r12,r_mem[l2],r_mem[l1]);
		sub3D(&r20,r_mem[l0],r_mem[l2]);
		CrossProduct3D(&triangle_normal,r12,r01);
		triangle_normal.x*=-0.16666666666666666;
		triangle_normal.y*=-0.16666666666666666;
		triangle_normal.z*=-0.16666666666666666;
		for(j=0;j<3;j++) {
			fdA[triang_site[i][j]][0].x+=triangle_normal.x;
			fdA[triang_site[i][j]][0].y+=triangle_normal.y;
			fdA[triang_site[i][j]][0].z+=triangle_normal.z;
		}
		triangle_area=sqrt(DotProduct3D(triangle_normal,triangle_normal));
		smul3D2(&triangle_normal,1.0/triangle_area);
		CrossProduct3D(&vtemp,triangle_normal,r12);
		f_mem0[l0][1].x+=(zeta[l1]+zeta[l2]+zeta[l0])*vtemp.x;
		f_mem0[l0][1].y+=(zeta[l1]+zeta[l2]+zeta[l0])*vtemp.y;
		f_mem0[l0][1].z+=(zeta[l1]+zeta[l2]+zeta[l0])*vtemp.z;
		f_mem0[l0][2].x+=(dzeta[l1]+dzeta[l2]+dzeta[l0])*vtemp.x;
		f_mem0[l0][2].y+=(dzeta[l1]+dzeta[l2]+dzeta[l0])*vtemp.y;
		f_mem0[l0][2].z+=(dzeta[l1]+dzeta[l2]+dzeta[l0])*vtemp.z;
		f_mem0[l0][3].x+=3.0*vtemp.x;
		f_mem0[l0][3].y+=3.0*vtemp.y;
		f_mem0[l0][3].z+=3.0*vtemp.z;
		CrossProduct3D(&vtemp,triangle_normal,r20);
		f_mem0[l1][1].x+=(zeta[l2]+zeta[l0]+zeta[l1])*vtemp.x;
		f_mem0[l1][1].y+=(zeta[l2]+zeta[l0]+zeta[l1])*vtemp.y;
		f_mem0[l1][1].z+=(zeta[l2]+zeta[l0]+zeta[l1])*vtemp.z;
		f_mem0[l1][2].x+=(dzeta[l2]+dzeta[l0]+dzeta[l1])*vtemp.x;
		f_mem0[l1][2].y+=(dzeta[l2]+dzeta[l0]+dzeta[l1])*vtemp.y;
		f_mem0[l1][2].z+=(dzeta[l2]+dzeta[l0]+dzeta[l1])*vtemp.z;
		f_mem0[l1][3].x+=3.0*vtemp.x;
		f_mem0[l1][3].y+=3.0*vtemp.y;
		f_mem0[l1][3].z+=3.0*vtemp.z;
		CrossProduct3D(&vtemp,triangle_normal,r01);
		f_mem0[l2][1].x+=(zeta[l0]+zeta[l1]+zeta[l2])*vtemp.x;
		f_mem0[l2][1].y+=(zeta[l0]+zeta[l1]+zeta[l2])*vtemp.y;
		f_mem0[l2][1].z+=(zeta[l0]+zeta[l1]+zeta[l2])*vtemp.z;
		f_mem0[l2][2].x+=(dzeta[l0]+dzeta[l1]+dzeta[l2])*vtemp.x;
		f_mem0[l2][2].y+=(dzeta[l0]+dzeta[l1]+dzeta[l2])*vtemp.y;
		f_mem0[l2][2].z+=(dzeta[l0]+dzeta[l1]+dzeta[l2])*vtemp.z;
		f_mem0[l2][3].x+=3.0*vtemp.x;
		f_mem0[l2][3].y+=3.0*vtemp.y;
		f_mem0[l2][3].z+=3.0*vtemp.z;
		areas[l0]+=triangle_area;
		areas[l1]+=triangle_area;
		areas[l2]+=triangle_area;
	}
	for(i=0;i<NMEM;i++){
		norm=1.0/sqrt(fdA[i][0].x*fdA[i][0].x+fdA[i][0].y*fdA[i][0].y+fdA[i][0].z*fdA[i][0].z);
		f_mem0[i][0].x=norm*fdA[i][0].x;
		f_mem0[i][0].y=norm*fdA[i][0].y;
		f_mem0[i][0].z=norm*fdA[i][0].z;
		for(j=1;j<4;j++) smul3D2(&f_mem0[i][j],0.16666666666666666/areas[i]);
	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++) sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
		quadratic_interpolator(Nneighbours[i],points,&n_mem[i],&curv[i],&gauss[i]);
	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++){
			sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
			da[j]=curv[neighbours[i][j]]-curv[i];
		}
		new_surface_laplacian(Nneighbours[i],points,da,&n_mem[i],&lap_curv[i]);
	}
	for(i=0;i<NMEM;i++){
		fn=kappa*(4.0*curv[i]*(curv[i]*curv[i]-gauss[i]) + 2.0*lap_curv[i]);
		zeta2[i]=0.9*zeta2[i]+0.1*fn;
		f_mem0[i][1].x -= zeta2[i]*n_mem[i].x;
		f_mem0[i][1].y -= zeta2[i]*n_mem[i].y;
		f_mem0[i][1].z -= zeta2[i]*n_mem[i].z;
	}
	for(i=0;i<NMEM;i++){
		for(k=1;k<4;k++){
			fdA[i][k].x=f_mem0[i][k].x*areas[i];
			fdA[i][k].y=f_mem0[i][k].y*areas[i];
			fdA[i][k].z=f_mem0[i][k].z*areas[i];
		}
	}
}

/*void test_get_force3(int triang_site[NTRIANG][3], int triang_site2[NTRIANG2][3], struct point3D r_mem[], struct point3D r_mem2[], struct point3D r_mem0[], struct point3D n_mem[], double kappa, double curv[], double gauss[], double lap_curv[], double zeta[], double zeta2[], double dzeta[NMEM], double dzeta2[NMEM2], struct point3D f_mem[NMEM2], struct point3D f_mem0[NMEM2][4], struct point3D fdA[NMEM][4], struct point3D fdA2[NMEM2][4], int Nneighbours[NMEM], int neighbours[NMEM][6], int slaves[NMEM][NSLA], double r_max[NMEM]){
	int	i, j, k, l, l0, l1, l2,v;
	double	fn0, fn, triangle_area,norm;
	int	npoints;
	struct	point3D points[6],triangle_normal,r01,r12,r20,vtemp,r_mem2temp[NMEM2];
	double	da[6],dz[6],areas[NMEM],areas2[NMEM2],fn2[NMEM2];

	for(i=0;i<NMEM;i++) {
		for(j=0;j<4;j++)f_mem0[i][j].x=f_mem0[i][j].y=f_mem0[i][j].z=0.0;
		areas[i]=0.0;
	}
	for(i=0;i<NMEM2;i++)r_mem2temp[i].x=r_mem2temp[i].y=r_mem2temp[i].z=0.0;
	for(i=0;i<NTRIANG;i++){
		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];
		sub3D(&r01,r_mem[l1],r_mem[l0]);
		sub3D(&r12,r_mem[l2],r_mem[l1]);
		sub3D(&r20,r_mem[l0],r_mem[l2]);
		CrossProduct3D(&triangle_normal,r12,r01);
		triangle_area=sqrt(DotProduct3D(triangle_normal,triangle_normal));
		smul3D2(&triangle_normal,0.5/triangle_area);
		CrossProduct3D(&vtemp,triangle_normal,r12);
		f_mem0[l0][1].x+=(zeta[l1]+zeta[l2]+zeta[l0])*vtemp.x;
		f_mem0[l0][1].y+=(zeta[l1]+zeta[l2]+zeta[l0])*vtemp.y;
		f_mem0[l0][1].z+=(zeta[l1]+zeta[l2]+zeta[l0])*vtemp.z;
		f_mem0[l0][2].x+=(dzeta[l1]+dzeta[l2]+dzeta[l0])*vtemp.x;
		f_mem0[l0][2].y+=(dzeta[l1]+dzeta[l2]+dzeta[l0])*vtemp.y;
		f_mem0[l0][2].z+=(dzeta[l1]+dzeta[l2]+dzeta[l0])*vtemp.z;
		f_mem0[l0][3].x+=3.0*vtemp.x;
		f_mem0[l0][3].y+=3.0*vtemp.y;
		f_mem0[l0][3].z+=3.0*vtemp.z;
		CrossProduct3D(&vtemp,triangle_normal,r20);
		f_mem0[l1][1].x+=(zeta[l2]+zeta[l0]+zeta[l1])*vtemp.x;
		f_mem0[l1][1].y+=(zeta[l2]+zeta[l0]+zeta[l1])*vtemp.y;
		f_mem0[l1][1].z+=(zeta[l2]+zeta[l0]+zeta[l1])*vtemp.z;
		f_mem0[l1][2].x+=(dzeta[l2]+dzeta[l0]+dzeta[l1])*vtemp.x;
		f_mem0[l1][2].y+=(dzeta[l2]+dzeta[l0]+dzeta[l1])*vtemp.y;
		f_mem0[l1][2].z+=(dzeta[l2]+dzeta[l0]+dzeta[l1])*vtemp.z;
		f_mem0[l1][3].x+=3.0*vtemp.x;
		f_mem0[l1][3].y+=3.0*vtemp.y;
		f_mem0[l1][3].z+=3.0*vtemp.z;
		CrossProduct3D(&vtemp,triangle_normal,r01);
		f_mem0[l2][1].x+=(zeta[l0]+zeta[l1]+zeta[l2])*vtemp.x;
		f_mem0[l2][1].y+=(zeta[l0]+zeta[l1]+zeta[l2])*vtemp.y;
		f_mem0[l2][1].z+=(zeta[l0]+zeta[l1]+zeta[l2])*vtemp.z;
		f_mem0[l2][2].x+=(dzeta[l0]+dzeta[l1]+dzeta[l2])*vtemp.x;
		f_mem0[l2][2].y+=(dzeta[l0]+dzeta[l1]+dzeta[l2])*vtemp.y;
		f_mem0[l2][2].z+=(dzeta[l0]+dzeta[l1]+dzeta[l2])*vtemp.z;
		f_mem0[l2][3].x+=3.0*vtemp.x;
		f_mem0[l2][3].y+=3.0*vtemp.y;
		f_mem0[l2][3].z+=3.0*vtemp.z;
		areas[l0]+=triangle_area;
		areas[l1]+=triangle_area;
		areas[l2]+=triangle_area;
	}
	for(i=0;i<NMEM;i++){
		for(j=1;j<4;j++) smul3D2(&f_mem0[i][j],1.0/areas[i]);
	}

	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++) sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++) sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
		new_quadratic_interpolator(Nneighbours[i],points,&n_mem[i],&curv[i],&gauss[i],slaves[i],r_mem2,r_mem2temp);
	}

	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++){
			sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
			da[j]=curv[neighbours[i][j]]-curv[i];
		}
		new_surface_laplacian(Nneighbours[i],points,da,&n_mem[i],&lap_curv[i]);
	}
	for(i=0;i<NMEM;i++){
		fn2[i]=kappa*(4.0*curv[i]*(curv[i]*curv[i]-gauss[i]) + 2.0*lap_curv[i]);
		zeta2[i]=zeta[i];
		dzeta2[i]=dzeta[i];
	}


	for(i=0;i<NMEM;i++){
		fn=kappa*(4.0*curv[i]*(curv[i]*curv[i]-gauss[i]) + 2.0*lap_curv[i]);
		f_mem0[i][1].x -= fn*n_mem[i].x;
		f_mem0[i][1].y -= fn*n_mem[i].y;
		f_mem0[i][1].z -= fn*n_mem[i].z;
	}






	for(v=0;v<NMEM;v++){
		zeta2[v]=curv[v];
		dzeta2[v]=dzeta[v];
	}
	norm=1.0/7.0;
	for(i=0;i<NTRIANG;i++){
		for(j=0;j<3;j++){
			l0 = triang_site[i][j];
			l1 = triang_site[i][(j+1)%3];
			l2 = triang_site[i][(j+2)%3];
			zeta2[v]=zeta2[l2]+2.0*zeta2[l1]+4.0*zeta2[l0];
			zeta2[v]*=norm;
			dzeta2[v]=dzeta2[l2]+2.0*dzeta2[l1]+4.0*dzeta2[l0];
			dzeta2[v]*=norm;
			fn2[v]=fn2[l2]+2.0*fn2[l1]+4.0*fn2[l0];
			fn2[v]*=norm;
			for(k=1;k<4;k++){
				f_mem0[v][k].x=norm*(f_mem0[l2][k].x+2.0*f_mem0[l1][k].x+4.0*f_mem0[l0][k].x);
				f_mem0[v][k].y=norm*(f_mem0[l2][k].y+2.0*f_mem0[l1][k].y+4.0*f_mem0[l0][k].y);
				f_mem0[v][k].z=norm*(f_mem0[l2][k].z+2.0*f_mem0[l1][k].z+4.0*f_mem0[l0][k].z);
			}
			v++;
		}	
	}

	for(i=0;i<NMEM2;i++){
		for(j=0;j<4;j++) fdA2[i][j].x=fdA2[i][j].y=fdA2[i][j].z=0.0;
		areas2[i]=0.0;
	}
	for(i=0;i<NTRIANG2;i++){
		l0 = triang_site2[i][0];
		l1 = triang_site2[i][1];
		l2 = triang_site2[i][2];
		sub3D(&r01,r_mem2[l1],r_mem2[l0]);
		sub3D(&r12,r_mem2[l2],r_mem2[l1]);
		sub3D(&r20,r_mem2[l0],r_mem2[l2]);
		CrossProduct3D(&triangle_normal,r12,r01);
		smul3D2(&triangle_normal,-1.0/6.0);
		triangle_area=sqrt(DotProduct3D(triangle_normal,triangle_normal));
		for(j=0;j<3;j++){
			fdA2[triang_site2[i][j]][0].x+=triangle_normal.x;
			fdA2[triang_site2[i][j]][0].y+=triangle_normal.y;
			fdA2[triang_site2[i][j]][0].z+=triangle_normal.z;
			areas2[triang_site2[i][j]]+=triangle_area;			
		}
	}
//	VTKdump_ref("test1",r_mem2,triang_site2,zeta2);
	for(i=0;i<NMEM2;i++){
		triangle_area=1.0/sqrt(DotProduct3D(fdA2[i][0],fdA2[i][0]));
//		zeta2[i]=areas2[i]/sqrt(DotProduct3D(fdA2[i][0],fdA2[i][0]));
		smul3D(&f_mem0[i][0],triangle_area,fdA2[i][0]);
		f_mem[i].x=f_mem0[i][0].x;
		f_mem[i].y=f_mem0[i][0].y;
		f_mem[i].z=f_mem0[i][0].z;
		r_mem2[i].x=r_mem2temp[i].x;
		r_mem2[i].y=r_mem2temp[i].y;
		r_mem2[i].z=r_mem2temp[i].z;
		for(j=1;j<4;j++) {
			fdA2[i][j].x=areas2[i]*f_mem0[i][j].x;
			fdA2[i][j].y=areas2[i]*f_mem0[i][j].y;
			fdA2[i][j].z=areas2[i]*f_mem0[i][j].z;
		}

	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<4;j++) fdA[i][j].x=fdA[i][j].y=fdA[i][j].z=0.0;
		for(j=0;j<Nneighbours[i]+1;j++){
			l0=slaves[i][j];
			for(k=0;k<4;k++){
				fdA[i][k].x+=fdA2[l0][k].x;
				fdA[i][k].y+=fdA2[l0][k].y;
				fdA[i][k].z+=fdA2[l0][k].z;
			}
			areas[i]+=areas2[l0];
		}
	}
	for(i=0;i<NMEM2;i++){
//		zeta2[i]=fdA2[i][1].z;
	}
//	VTKdump_ref("test",r_mem2temp,triang_site2,zeta2);



//	VTKdump("test0",r_mem,triang_site,zeta,curv,gauss,lap_curv,f_n,dzeta,f_t,f_t2);
//	VTKdump("test1",r_mem,triang_site,zeta,curv,gauss,lap_curv,n_mem,n_mem);
//	VTKdump("test2",r_mem,triang_site,zeta,curv,gauss,lap_curv,gradszeta1,gradszeta);
}*/

void new_get_force0(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double zeta[NMEM], struct point3D tension_force[NMEM], struct point3D tension0_force[NMEM]){
	int	i, j, k, l, l0, l1, l2;
	double	fn, triangle_area;
	struct point3D	triangle_normal,r01,r12,r20,vtemp;
	double	areas[NMEM];

	for(i=0;i<NMEM;i++) tension_force[i].x=tension_force[i].y=tension_force[i].z=areas[i]=0.0;
	for(i=0;i<NTRIANG;i++){
		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];

		sub3D(&r01,r_mem[l1],r_mem[l0]);
		sub3D(&r12,r_mem[l2],r_mem[l1]);
		sub3D(&r20,r_mem[l0],r_mem[l2]);
		CrossProduct3D(&triangle_normal,r12,r01);
		triangle_area=sqrt(DotProduct3D(triangle_normal,triangle_normal));
		smul3D2(&triangle_normal,0.5/triangle_area);
		CrossProduct3D(&vtemp,triangle_normal,r12);
		tension_force[l0].x+=(zeta[l1]+zeta[l2]+zeta[l0])*vtemp.x;
		tension_force[l0].y+=(zeta[l1]+zeta[l2]+zeta[l0])*vtemp.y;
		tension_force[l0].z+=(zeta[l1]+zeta[l2]+zeta[l0])*vtemp.z;
		CrossProduct3D(&vtemp,triangle_normal,r20);
		tension_force[l1].x+=(zeta[l2]+zeta[l0]+zeta[l1])*vtemp.x;
		tension_force[l1].y+=(zeta[l2]+zeta[l0]+zeta[l1])*vtemp.y;
		tension_force[l1].z+=(zeta[l2]+zeta[l0]+zeta[l1])*vtemp.z;
		CrossProduct3D(&vtemp,triangle_normal,r01);
		tension_force[l2].x+=(zeta[l0]+zeta[l1]+zeta[l2])*vtemp.x;
		tension_force[l2].y+=(zeta[l0]+zeta[l1]+zeta[l2])*vtemp.y;
		tension_force[l2].z+=(zeta[l0]+zeta[l1]+zeta[l2])*vtemp.z;
		areas[l0]+=triangle_area;
		areas[l1]+=triangle_area;
		areas[l2]+=triangle_area;
	}
	for(i=0;i<NMEM;i++){
		smul3D2(&tension_force[i],1.0/areas[i]);
	}
	for(i=0;i<NMEM;i++) tension0_force[i].x=tension0_force[i].y=tension0_force[i].z=areas[i]=0.0;
	for(i=0;i<NTRIANG;i++){
		for(j=0;j<3;j++){
			l0 = triang_site[i][j];
			l1 = triang_site[i][(j+1)%3];
			l2 = triang_site[i][(j+2)%3];
			tension0_force[l0].x+=tension_force[l1].x+tension_force[l2].x-tension_force[l0].x;
			tension0_force[l0].y+=tension_force[l1].y+tension_force[l2].y-tension_force[l0].y;
			tension0_force[l0].z+=tension_force[l1].z+tension_force[l2].z-tension_force[l0].z;
			areas[l0]+=1.0;
		}
	}
	for(i=0;i<NMEM;i++){
		smul3D2(&tension0_force[i],1.0/areas[i]);
	}
//	VTKdump("test0",r_mem,triang_site,zeta,curv,gauss,lap_curv,f_n,dzeta,f_t,f_t2);
//	VTKdump("test1",r_mem,triang_site,zeta,curv,gauss,lap_curv,n_mem,n_mem);
//	VTKdump("test2",r_mem,triang_site,zeta,curv,gauss,lap_curv,gradszeta1,gradszeta);
}

void new_get_force2(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double curv[], double gauss[], double lap_curv[], double zeta[], struct point3D f_mem[],double kappa,double tens){
	int                 i, j, k, l, l0, l1, l2;
	double fn[NMEM];
	struct point3D      gradszeta[NMEM],gradszeta1[NMEM];
	int Nneighbours[NMEM];
	int neighbours[NMEM][6];
	int npoints;
	int neighbours2[18];
	struct point3D points[18];
	double da[18],dz[18];
	double test[NMEM];
/*	double curv4[NMEM];
	double gauss4[NMEM];
	double lap_curv4[NMEM];*/

/*	for(i=0;i<NMEM;i++) {
		smul3D2(&r_mem[i],1.0/sqrt(DotProduct3D(r_mem[i],r_mem[i])));
	}*/

	for(i=0;i<NMEM;i++) Nneighbours[i]=0;
	for(i=0;i<NTRIANG;i++){
		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];
		for(j=0;j<Nneighbours[l0];j++) if(neighbours[l0][j]==l1) break;
		if(j==Nneighbours[l0]){
			neighbours[l0][j]=l1;
			Nneighbours[l0]++;
		}
		for(j=0;j<Nneighbours[l0];j++) if(neighbours[l0][j]==l2) break;
		if(j==Nneighbours[l0]){
			neighbours[l0][j]=l2;
			Nneighbours[l0]++;
		}
		for(j=0;j<Nneighbours[l1];j++) if(neighbours[l1][j]==l2) break;
		if(j==Nneighbours[l1]){
			neighbours[l1][j]=l2;
			Nneighbours[l1]++;
		}
		for(j=0;j<Nneighbours[l1];j++) if(neighbours[l1][j]==l0) break;
		if(j==Nneighbours[l1]){
			neighbours[l1][j]=l0;
			Nneighbours[l1]++;
		}
		for(j=0;j<Nneighbours[l2];j++) if(neighbours[l2][j]==l0) break;
		if(j==Nneighbours[l2]){
			neighbours[l2][j]=l0;
			Nneighbours[l2]++;
		}
		for(j=0;j<Nneighbours[l2];j++) if(neighbours[l2][j]==l1) break;
		if(j==Nneighbours[l2]){
			neighbours[l2][j]=l1;
			Nneighbours[l2]++;
		}
	}
	for(i=0;i<NMEM;i++){
/*		for(j=0;j<Nneighbours[i];j++) sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
		quadratic_interpolator(Nneighbours[i],points,&n_mem[i],&curv[i],&gauss[i]);
		quadratic_interpolator(Nneighbours[i],points,&n_mem[i],&curv[i],&gauss[i]);*/
		npoints=0;
		for(j=0;j<Nneighbours[i];j++){
			for(k=0;k<Nneighbours[neighbours[i][j]];k++){
				if(neighbours[neighbours[i][j]][k]==i) continue;
				for(l=0;l<npoints;l++){
					if(neighbours2[l]==neighbours[neighbours[i][j]][k]) break;
				}
				if(l==npoints){
					neighbours2[npoints]=neighbours[neighbours[i][j]][k];
					npoints++;
				}
			}
		}
		for(j=0;j<npoints;j++) sub3D(&points[j],r_mem[neighbours2[j]],r_mem[i]);
/*		printf("%d: %d\t",npoints,i);
		for(j=0;j<npoints;j++) printf("%d\t",neighbours2[j]);
		printf("\n");*/
		quartic_interpolator(npoints,points,&n_mem[i],&curv[i],&gauss[i]);
	}
	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++){
			sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
			da[j]=curv[neighbours[i][j]]-curv[i];
		}
		new_surface_laplacian(Nneighbours[i],points,da,&n_mem[i],&lap_curv[i]);
		for(j=0;j<Nneighbours[i];j++) da[j]=tens*(zeta[neighbours[i][j]]-zeta[i]);
		new_surface_gradient(Nneighbours[i],points,da,&n_mem[i],&gradszeta[i]);

		npoints=0;
		for(j=0;j<Nneighbours[i];j++){
			for(k=0;k<Nneighbours[neighbours[i][j]];k++){
				if(neighbours[neighbours[i][j]][k]==i) continue;
				for(l=0;l<npoints;l++){
					if(neighbours2[l]==neighbours[neighbours[i][j]][k]) break;
				}
				if(l==npoints){
					neighbours2[npoints]=neighbours[neighbours[i][j]][k];
					npoints++;
				}
			}
		}
		for(j=0;j<npoints;j++){
			sub3D(&points[j],r_mem[neighbours2[j]],r_mem[i]);
			da[j]=curv[neighbours2[j]]-curv[i];
			dz[j]=tens*(zeta[neighbours2[j]]-zeta[i]);
//			printf("%f\t",dz[j]);
		}
//		printf("\n");
		new_surface_laplacian2(npoints,points,da,&n_mem[i],&lap_curv[i]);
		new_surface_gradient2(npoints,points,dz,&n_mem[i],&gradszeta1[i]);

/*		for(j=0;j<Nneighbours[i];j++) da[j]=r_mem[neighbours[i][j]].x-r_mem[i].x;
		new_surface_laplacian(Nneighbours[i],points,da,&n_mem[i],&fn[i]);
		test[i]=fn[i]*n_mem[i].x;
		for(j=0;j<Nneighbours[i];j++) da[j]=r_mem[neighbours[i][j]].y-r_mem[i].y;
		new_surface_laplacian(Nneighbours[i],points,da,&n_mem[i],&fn[i]);
		test[i]+=fn[i]*n_mem[i].y;
		for(j=0;j<Nneighbours[i];j++) da[j]=r_mem[neighbours[i][j]].z-r_mem[i].z;
		new_surface_laplacian(Nneighbours[i],points,da,&n_mem[i],&fn[i]);
		test[i]+=fn[i]*n_mem[i].z;
		test[i]-=2.0*curv[i];*/
	}
	for(i=0;i<NMEM;i++){
		fn[i] =  -0.0*kappa*( 4.0*curv[i]*(curv[i]*curv[i]-gauss[i]) + 2.0*lap_curv[i])+2.0*zeta[i]*curv[i]*tens;
		smul3D(&f_mem[i],fn[i],n_mem[i]);
		add3D2(&f_mem[i],gradszeta[i]);
	}
//	VTKdump("test1",r_mem,triang_site,zeta,curv,curv4,lap_curv,gradszeta1,gradszeta);
//	VTKdump("test2",r_mem,triang_site,zeta,curv,gauss,lap_curv,gradszeta1,gradszeta);
}


double new_get_zeta(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D v_mem[],
              struct point3D *v_mem_cm, double darea[],
              double dzeta[], double curv[], struct point3D n_mem[], double dtime)
{
	int i, j, k, l, l0, l1, l2;
	int Nneighbours[NMEM];
	int neighbours[NMEM][6];
	int npoints;
	int neighbours2[18];
	struct point3D points[18],temp;
	int pairs[6][2];
	int npairs;
	double darea1,darea0;
	double dzeta0;

	for(i=0;i<NMEM;i++) Nneighbours[i]=0;
	for(i=0;i<NTRIANG;i++){
		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];
		for(j=0;j<Nneighbours[l0];j++) if(neighbours[l0][j]==l1) break;
		if(j==Nneighbours[l0]){
			neighbours[l0][j]=l1;
			Nneighbours[l0]++;
		}
		for(j=0;j<Nneighbours[l0];j++) if(neighbours[l0][j]==l2) break;
		if(j==Nneighbours[l0]){
			neighbours[l0][j]=l2;
			Nneighbours[l0]++;
		}
		for(j=0;j<Nneighbours[l1];j++) if(neighbours[l1][j]==l2) break;
		if(j==Nneighbours[l1]){
			neighbours[l1][j]=l2;
			Nneighbours[l1]++;
		}
		for(j=0;j<Nneighbours[l1];j++) if(neighbours[l1][j]==l0) break;
		if(j==Nneighbours[l1]){
			neighbours[l1][j]=l0;
			Nneighbours[l1]++;
		}
		for(j=0;j<Nneighbours[l2];j++) if(neighbours[l2][j]==l0) break;
		if(j==Nneighbours[l2]){
			neighbours[l2][j]=l0;
			Nneighbours[l2]++;
		}
		for(j=0;j<Nneighbours[l2];j++) if(neighbours[l2][j]==l1) break;
		if(j==Nneighbours[l2]){
			neighbours[l2][j]=l1;
			Nneighbours[l2]++;
		}
	}
	dzeta0=0.0;
	for(i=0;i<NMEM;i++){
		npoints=Nneighbours[i];
		for(j=0;j<Nneighbours[i];j++) neighbours2[j]=neighbours[i][j];
		npairs=0;
		for(j=0;j<Nneighbours[i];j++){
			for(k=0;k<Nneighbours[neighbours[i][j]];k++){
				if(neighbours[neighbours[i][j]][k]==i) continue;
				for(l=0;l<npoints;l++){
					if(neighbours2[l]==neighbours[neighbours[i][j]][k]) break;
				}
				if(l==npoints){
					neighbours2[npoints]=neighbours[neighbours[i][j]][k];
					npoints++;
				}
				if(l<Nneighbours[i]) if(l<j){
					pairs[npairs][0]=l;
					pairs[npairs][1]=j;
					npairs++;
				}
			}
		}
		for(j=0;j<npoints;j++){
			sub3D(&points[j],r_mem[neighbours2[j]],r_mem[i]);
		}
		new_area_element2(npoints,points,&n_mem[i],Nneighbours[i],pairs,&darea0);
		for(j=0;j<npoints;j++){
			sub3D(&temp,v_mem[neighbours2[j]],v_mem[i]);
			smul3D2(&temp,dtime);
			add3D2(&points[j],temp);
		}
		new_area_element2(npoints,points,&n_mem[i],Nneighbours[i],pairs,&darea1);
		dzeta[i]=(darea1/darea0-1.0)/dtime;
		dzeta0+=dzeta[i]*dzeta[i];
	}
	printf("%f\n",sqrt(dzeta0/NMEM));
//	VTKdump("test1",r_mem,triang_site,dzeta,dzeta,dzeta,dzeta,v_mem,n_mem);
	return dzeta0;
}


void new_area_element(int n, struct point3D points[], struct point3D* normal,int n0,int pairs[][2],double* darea)
{
	double s[18][2];
	double temp1[18][14];
	struct point3D localx,localy,dR[2],ddR[2][2],dddR[2][2][2],ddddR[2][2][2][2];
	double temp;
	struct point3D NA0,dNA0[2],ddNA0[2][2],dddNA0[2][2][2];
	double A02,dA02[2],ddA02[2][2],dddA02[2][2][2];
	double A0,dA0[2],ddA0[2][2],dddA0[2][2][2];
	double g[2][2],g1[2][2],detg1,dChris[2][2][2][2],temp2[2],temp3[2];
	struct point3D temp3D;
	double Delta;
	
	gsl_matrix *M;
	gsl_vector *V;
	int i,j,k,l,m;

	if (n<14) {
		printf("not enough points for the interpolation\n");
		exit(1);
	}
	if (n>18) {
		printf("too many points for the interpolation\n");
		exit(1);
	}

	M=gsl_matrix_alloc(14,14);
	V=gsl_vector_alloc(14);	

	temp=DotProduct3D(points[0],*normal);
	smul3D(&localx,-temp,*normal);
	add3D2(&localx,points[0]);
	temp=sqrt(DotProduct3D(localx,localx));
	smul3D2(&localx,1.0/temp);
	CrossProduct3D(&localy,*normal,localx);

	for(i=0;i<n;i++){
		s[i][0]=DotProduct3D(localx,points[i]);
		s[i][1]=DotProduct3D(localy,points[i]);
		temp1[i][0]=s[i][0];
		temp1[i][1]=s[i][1];
		temp1[i][2]=0.5*s[i][0]*s[i][0];
		temp1[i][3]=s[i][0]*s[i][1];
		temp1[i][4]=0.5*s[i][1]*s[i][1];
		temp1[i][5]=0.16666666666666*s[i][0]*s[i][0]*s[i][0];
		temp1[i][6]=0.5*s[i][0]*s[i][0]*s[i][1];
		temp1[i][7]=0.5*s[i][0]*s[i][1]*s[i][1];
		temp1[i][8]=0.16666666666666*s[i][1]*s[i][1]*s[i][1];
		temp1[i][9]=0.04166666666666*s[i][0]*s[i][0]*s[i][0]*s[i][0];
		temp1[i][10]=0.16666666666666*s[i][0]*s[i][0]*s[i][0]*s[i][1];
		temp1[i][11]=0.25*s[i][0]*s[i][0]*s[i][1]*s[i][1];
		temp1[i][12]=0.16666666666666*s[i][0]*s[i][1]*s[i][1]*s[i][1];
		temp1[i][13]=0.04166666666666*s[i][1]*s[i][1]*s[i][1]*s[i][1];
	}
	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].x*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].x=gsl_vector_get(V,0);
	dR[1].x=gsl_vector_get(V,1);
	ddR[0][0].x=gsl_vector_get(V,2);
	ddR[1][0].x=ddR[0][1].x=gsl_vector_get(V,3);
	ddR[1][1].x=gsl_vector_get(V,4);
	dddR[0][0][0].x=gsl_vector_get(V,5);
	dddR[0][0][1].x=dddR[0][1][0].x=dddR[1][0][0].x=gsl_vector_get(V,6);
	dddR[0][1][1].x=dddR[1][1][0].x=dddR[1][0][1].x=gsl_vector_get(V,7);
	dddR[1][1][1].x=gsl_vector_get(V,8);
/*	ddddR[0][0][0][0].x=gsl_vector_get(V,9);
	ddddR[1][0][0][0].x=ddddR[0][1][0][0].x=ddddR[0][0][1][0].x=ddddR[0][0][0][1].x=gsl_vector_get(V,10);
	ddddR[1][1][0][0].x=ddddR[1][0][1][0].x=ddddR[1][0][0][1].x=ddddR[0][1][1][0].x=ddddR[0][1][0][1].x=ddddR[0][0][1][1].x=gsl_vector_get(V,11);
	ddddR[1][1][1][0].x=ddddR[1][1][0][1].x=ddddR[1][0][1][1].x=ddddR[0][1][1][1].x=gsl_vector_get(V,12);
	ddddR[1][1][1][1].x=gsl_vector_get(V,13);*/

	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].y*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].y=gsl_vector_get(V,0);
	dR[1].y=gsl_vector_get(V,1);
	ddR[0][0].y=gsl_vector_get(V,2);
	ddR[1][0].y=ddR[0][1].y=gsl_vector_get(V,3);
	ddR[1][1].y=gsl_vector_get(V,4);
	dddR[0][0][0].y=gsl_vector_get(V,5);
	dddR[0][0][1].y=dddR[0][1][0].y=dddR[1][0][0].y=gsl_vector_get(V,6);
	dddR[0][1][1].y=dddR[1][1][0].y=dddR[1][0][1].y=gsl_vector_get(V,7);
	dddR[1][1][1].y=gsl_vector_get(V,8);
/*	ddddR[0][0][0][0].y=gsl_vector_get(V,9);
	ddddR[1][0][0][0].y=ddddR[0][1][0][0].y=ddddR[0][0][1][0].y=ddddR[0][0][0][1].y=gsl_vector_get(V,10);
	ddddR[1][1][0][0].y=ddddR[1][0][1][0].y=ddddR[1][0][0][1].y=ddddR[0][1][1][0].y=ddddR[0][1][0][1].y=ddddR[0][0][1][1].y=gsl_vector_get(V,11);
	ddddR[1][1][1][0].y=ddddR[1][1][0][1].y=ddddR[1][0][1][1].y=ddddR[0][1][1][1].y=gsl_vector_get(V,12);
	ddddR[1][1][1][1].y=gsl_vector_get(V,13);*/
	
	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].z*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].z=gsl_vector_get(V,0);
	dR[1].z=gsl_vector_get(V,1);
	ddR[0][0].z=gsl_vector_get(V,2);
	ddR[1][0].z=ddR[0][1].z=gsl_vector_get(V,3);
	ddR[1][1].z=gsl_vector_get(V,4);
	dddR[0][0][0].z=gsl_vector_get(V,5);
	dddR[0][0][1].z=dddR[0][1][0].z=dddR[1][0][0].z=gsl_vector_get(V,6);
	dddR[0][1][1].z=dddR[1][1][0].z=dddR[1][0][1].z=gsl_vector_get(V,7);
	dddR[1][1][1].z=gsl_vector_get(V,8);
/*	ddddR[0][0][0][0].z=gsl_vector_get(V,9);
	ddddR[1][0][0][0].z=ddddR[0][1][0][0].z=ddddR[0][0][1][0].z=ddddR[0][0][0][1].z=gsl_vector_get(V,10);
	ddddR[1][1][0][0].z=ddddR[1][0][1][0].z=ddddR[1][0][0][1].z=ddddR[0][1][1][0].z=ddddR[0][1][0][1].z=ddddR[0][0][1][1].z=gsl_vector_get(V,11);
	ddddR[1][1][1][0].z=ddddR[1][1][0][1].z=ddddR[1][0][1][1].z=ddddR[0][1][1][1].z=gsl_vector_get(V,12);
	ddddR[1][1][1][1].z=gsl_vector_get(V,13);*/

	
	CrossProduct3D(&NA0,dR[0],dR[1]);
	for(i=0;i<2;i++){
		CrossProduct3D(&dNA0[i],ddR[0][i],dR[1]);
		CrossProduct3D(&temp3D,dR[0],ddR[1][i]);
		add3D2(&dNA0[i],temp3D);
		for(j=0;j<2;j++){
			CrossProduct3D(&ddNA0[i][j],dddR[0][i][j],dR[1]);
			CrossProduct3D(&temp3D,dR[0],dddR[1][i][j]);
			add3D2(&ddNA0[i][j],temp3D);
			smul3D2(&ddNA0[i][j],0.5);
			CrossProduct3D(&temp3D,ddR[0][i],ddR[1][j]);
			add3D2(&ddNA0[i][j],temp3D);
/*			for(k=0;k<2;k++){
				CrossProduct3D(&dddNA0[i][j][k],ddddR[0][i][j][k],dR[1]);
				CrossProduct3D(&temp3D,dR[0],ddddR[1][i][j][k]);
				add3D2(&dddNA0[i][j][k],temp3D);
				smul3D2(&dddNA0[i][j][k],0.33333333333333);
				CrossProduct3D(&temp3D,dddR[0][i][j],ddR[1][k]);
				add3D2(&dddNA0[i][j][k],temp3D);
				CrossProduct3D(&temp3D,ddR[0][i],dddR[1][j][k]);
				add3D2(&dddNA0[i][j][k],temp3D);
				smul3D2(&dddNA0[i][j][k],0.5);
			}*/
		}
	}
	A02=DotProduct3D(NA0,NA0);
	for(i=0;i<2;i++){
		dA02[i]=2.0*DotProduct3D(dNA0[i],NA0)/A02;
		for(j=0;j<2;j++){
			ddA02[i][j]=(2.0*DotProduct3D(ddNA0[i][j],NA0)+DotProduct3D(dNA0[i],dNA0[j]))/A02;
/*			for(k=0;k<2;k++){
				dddA02[i][j][k]=2.0*(DotProduct3D(dddNA0[i][j][k],NA0)+DotProduct3D(ddNA0[i][j],dNA0[k]))/A02;
			}*/
		}
	}
	A0=sqrt(A02);
	for(i=0;i<2;i++){
		dA0[i]=0.5*dA02[i];
		for(j=0;j<2;j++){
			ddA0[i][j]=0.5*ddA02[i][j]-0.125*dA02[i]*dA02[j];
/*			for(k=0;k<2;k++){
				dddA0[i][j][k]=0.5*dddA02[i][j][k]-0.25*dA0[i]*ddA0[j][k]+0.0625*dA0[i]*dA0[j]*dA0[k];
			}*/
		}
	}

	for(i=0;i<2;i++)
		for(j=0;j<2;j++)
			g[i][j]=DotProduct3D(dR[i],dR[j]);
	
	detg1=1.0/det2D(g);

	g1[0][0]=g[1][1]*detg1;
	g1[1][1]=g[0][0]*detg1;
	g1[1][0]=-g[0][1]*detg1;
	g1[0][1]=-g[1][0]*detg1;
	
	for(i=0;i<2;i++){
		for(j=0;j<2;j++){
			for(k=0;k<2;k++){
				for(l=0;l<2;l++){
					dChris[i][j][k][l]=DotProduct3D(ddR[i][j],ddR[k][l])+DotProduct3D(dR[i],dddR[j][k][l]);
				}
			}
		}
	}
	*darea=0.0;
	for(i=0;i<n0;i++){
		Delta=s[pairs[i][0]][0]*s[pairs[i][1]][1]-s[pairs[i][1]][0]*s[pairs[i][0]][1];
		temp=0.5;

		for(j=0;j<2;j++){
			temp+=0.33333333333333333*dA0[j]*(s[pairs[i][0]][j]+s[pairs[i][1]][j]);
			for(k=0;k<2;k++){
				temp+=0.083333333333333*ddA0[j][k]*(s[pairs[i][0]][j]*s[pairs[i][0]][k]+s[pairs[i][1]][j]*s[pairs[i][1]][k]+0.5*(s[pairs[i][0]][j]*s[pairs[i][1]][k]+s[pairs[i][1]][j]*s[pairs[i][0]][k]));
/*				for(l=0;l<2;l++){
					temp+=0.05*dddA0[i][j][k]*(s[pairs[i][0]][j]*s[pairs[i][0]][k]*s[pairs[i][0]][l]+s[pairs[i][1]][j]*s[pairs[i][1]][k]*s[pairs[i][1]][l]+0.3333333333333*(s[pairs[i][0]][j]*s[pairs[i][0]][k]*s[pairs[i][1]][l]+s[pairs[i][0]][j]*s[pairs[i][1]][k]*s[pairs[i][0]][l]+s[pairs[i][1]][j]*s[pairs[i][0]][k]*s[pairs[i][0]][l]+s[pairs[i][0]][j]*s[pairs[i][1]][k]*s[pairs[i][1]][l]+s[pairs[i][1]][j]*s[pairs[i][0]][k]*s[pairs[i][1]][l]+s[pairs[i][1]][j]*s[pairs[i][1]][k]*s[pairs[i][0]][l]));
				}*/
			}
		}
		temp*=Delta;
		for(j=0;j<2;j++){
			temp2[j]=0.0;
			for(k=0;k<2;k++)
				for(l=0;l<2;l++)
					for(m=0;m<2;m++){
						temp2[j]+=dChris[j][k][l][m]*(s[pairs[i][0]][k]+s[pairs[i][1]][k])*(s[pairs[i][0]][l]-s[pairs[i][1]][l])*(s[pairs[i][0]][m]-s[pairs[i][1]][m]);
					}
		}
		for(j=0;j<2;j++){
			temp3[j]=0.0;
			for(l=0;l<2;l++){
				temp3[j]+=g1[j][l]*temp2[l];
			}
		}
		temp-=0.041666666666666*((s[pairs[i][1]][0]-s[pairs[i][0]][0])*temp3[1]-(s[pairs[i][1]][1]-s[pairs[i][0]][1])*temp3[0]);
		*darea+=fabs(temp*A0);
	}
	*darea*=0.33333333333333333333;
	gsl_matrix_free(M);
	gsl_vector_free(V);	
}

void new_area_element2(int n, struct point3D points[], struct point3D* normal,int n0,int pairs[][2],double* darea)
{
	double s[18][2];
	double temp1[18][14];
	struct point3D localx,localy,dR[2],ddR[2][2],dddR[2][2][2],ddddR[2][2][2][2];
	double temp;
	struct point3D NA0,dNA0[2],ddNA0[2][2],dddNA0[2][2][2];
	double A02,dA02[2],ddA02[2][2],dddA02[2][2][2];
	double A0,dA0[2],ddA0[2][2],dddA0[2][2][2];
	double g[2][2],g1[2][2],detg1,dChris[2][2][2][2],temp2[2],temp3[2];
	struct point3D temp3D;
	double Delta;
	
	gsl_matrix *M;
	gsl_vector *V;
	int i,j,k,l,m;

	if (n<14) {
		printf("not enough points for the interpolation\n");
		exit(1);
	}
	if (n>18) {
		printf("too many points for the interpolation\n");
		exit(1);
	}

	M=gsl_matrix_alloc(14,14);
	V=gsl_vector_alloc(14);	

	temp=DotProduct3D(points[0],*normal);
	smul3D(&localx,-temp,*normal);
	add3D2(&localx,points[0]);
	temp=sqrt(DotProduct3D(localx,localx));
	smul3D2(&localx,1.0/temp);
	CrossProduct3D(&localy,*normal,localx);

	for(i=0;i<n;i++){
		s[i][0]=DotProduct3D(localx,points[i]);
		s[i][1]=DotProduct3D(localy,points[i]);
		temp1[i][0]=s[i][0];
		temp1[i][1]=s[i][1];
		temp1[i][2]=0.5*s[i][0]*s[i][0];
		temp1[i][3]=s[i][0]*s[i][1];
		temp1[i][4]=0.5*s[i][1]*s[i][1];
		temp1[i][5]=0.16666666666666*s[i][0]*s[i][0]*s[i][0];
		temp1[i][6]=0.5*s[i][0]*s[i][0]*s[i][1];
		temp1[i][7]=0.5*s[i][0]*s[i][1]*s[i][1];
		temp1[i][8]=0.16666666666666*s[i][1]*s[i][1]*s[i][1];
		temp1[i][9]=0.04166666666666*s[i][0]*s[i][0]*s[i][0]*s[i][0];
		temp1[i][10]=0.16666666666666*s[i][0]*s[i][0]*s[i][0]*s[i][1];
		temp1[i][11]=0.25*s[i][0]*s[i][0]*s[i][1]*s[i][1];
		temp1[i][12]=0.16666666666666*s[i][0]*s[i][1]*s[i][1]*s[i][1];
		temp1[i][13]=0.04166666666666*s[i][1]*s[i][1]*s[i][1]*s[i][1];
	}
	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].x*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].x=gsl_vector_get(V,0);
	dR[1].x=gsl_vector_get(V,1);
	ddR[0][0].x=gsl_vector_get(V,2);
	ddR[1][0].x=ddR[0][1].x=gsl_vector_get(V,3);
	ddR[1][1].x=gsl_vector_get(V,4);
	dddR[0][0][0].x=gsl_vector_get(V,5);
	dddR[0][0][1].x=dddR[0][1][0].x=dddR[1][0][0].x=gsl_vector_get(V,6);
	dddR[0][1][1].x=dddR[1][1][0].x=dddR[1][0][1].x=gsl_vector_get(V,7);
	dddR[1][1][1].x=gsl_vector_get(V,8);

	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].y*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].y=gsl_vector_get(V,0);
	dR[1].y=gsl_vector_get(V,1);
	ddR[0][0].y=gsl_vector_get(V,2);
	ddR[1][0].y=ddR[0][1].y=gsl_vector_get(V,3);
	ddR[1][1].y=gsl_vector_get(V,4);
	dddR[0][0][0].y=gsl_vector_get(V,5);
	dddR[0][0][1].y=dddR[0][1][0].y=dddR[1][0][0].y=gsl_vector_get(V,6);
	dddR[0][1][1].y=dddR[1][1][0].y=dddR[1][0][1].y=gsl_vector_get(V,7);
	dddR[1][1][1].y=gsl_vector_get(V,8);
	
	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].z*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].z=gsl_vector_get(V,0);
	dR[1].z=gsl_vector_get(V,1);
	ddR[0][0].z=gsl_vector_get(V,2);
	ddR[1][0].z=ddR[0][1].z=gsl_vector_get(V,3);
	ddR[1][1].z=gsl_vector_get(V,4);
	dddR[0][0][0].z=gsl_vector_get(V,5);
	dddR[0][0][1].z=dddR[0][1][0].z=dddR[1][0][0].z=gsl_vector_get(V,6);
	dddR[0][1][1].z=dddR[1][1][0].z=dddR[1][0][1].z=gsl_vector_get(V,7);
	dddR[1][1][1].z=gsl_vector_get(V,8);

	
	CrossProduct3D(&NA0,dR[0],dR[1]);
	for(i=0;i<2;i++){
		CrossProduct3D(&dNA0[i],ddR[0][i],dR[1]);
		CrossProduct3D(&temp3D,dR[0],ddR[1][i]);
		add3D2(&dNA0[i],temp3D);
		for(j=0;j<2;j++){
			CrossProduct3D(&ddNA0[i][j],dddR[0][i][j],dR[1]);
			CrossProduct3D(&temp3D,dR[0],dddR[1][i][j]);
			add3D2(&ddNA0[i][j],temp3D);
			smul3D2(&ddNA0[i][j],0.5);
			CrossProduct3D(&temp3D,ddR[0][i],ddR[1][j]);
			add3D2(&ddNA0[i][j],temp3D);
		}
	}
	A02=DotProduct3D(NA0,NA0);
	for(i=0;i<2;i++){
		dA02[i]=2.0*DotProduct3D(dNA0[i],NA0)/A02;
		for(j=0;j<2;j++){
			ddA02[i][j]=(2.0*DotProduct3D(ddNA0[i][j],NA0)+DotProduct3D(dNA0[i],dNA0[j]))/A02;
		}
	}
	A0=sqrt(A02);
	for(i=0;i<2;i++){
		dA0[i]=0.5*dA02[i];
		for(j=0;j<2;j++){
			ddA0[i][j]=0.5*ddA02[i][j]-0.125*dA02[i]*dA02[j];
		}
	}

	*darea=0.0;
	for(i=0;i<n0;i++){
		Delta=s[pairs[i][0]][0]*s[pairs[i][1]][1]-s[pairs[i][1]][0]*s[pairs[i][0]][1];
		temp=0.5;

		for(j=0;j<2;j++){
			temp+=0.3333333333333333333*dA0[j]*(s[pairs[i][0]][j]+s[pairs[i][1]][j]);
			for(k=0;k<2;k++){
				temp+=0.083333333333333*ddA0[j][k]*(s[pairs[i][0]][j]*s[pairs[i][0]][k]+s[pairs[i][1]][j]*s[pairs[i][1]][k]+0.5*(s[pairs[i][0]][j]*s[pairs[i][1]][k]+s[pairs[i][1]][j]*s[pairs[i][0]][k]));
			}
		}
		temp*=Delta;
		*darea+=fabs(temp*A0);
	}
	*darea*=0.33333333333333333333;
	gsl_matrix_free(M);
	gsl_vector_free(V);	
}

void new_volume_element(int n, struct point3D R0, struct point3D points[], struct point3D* normal,int n0,int pairs[][2],double* dvolume)
{
	double s[18][2];
	double temp1[18][14];
	struct point3D localx,localy,dR[2],ddR[2][2],dddR[2][2][2],ddddR[2][2][2][2];
	double temp;
	struct point3D NA0,dNA0[2],ddNA0[2][2],dddNA0[2][2][2];
	double V0,dV0[2],ddV0[2][2];
	double g[2][2],g1[2][2],detg1,dChris[2][2][2][2],temp2[2],temp3[2];
	struct point3D temp3D;
	double Delta;
	
	gsl_matrix *M;
	gsl_vector *V;
	int i,j,k,l,m;

	if (n<14) {
		printf("not enough points for the interpolation\n");
		exit(1);
	}
	if (n>18) {
		printf("too many points for the interpolation\n");
		exit(1);
	}

	M=gsl_matrix_alloc(14,14);
	V=gsl_vector_alloc(14);	

	temp=DotProduct3D(points[0],*normal);
	smul3D(&localx,-temp,*normal);
	add3D2(&localx,points[0]);
	temp=sqrt(DotProduct3D(localx,localx));
	smul3D2(&localx,1.0/temp);
	CrossProduct3D(&localy,*normal,localx);

	for(i=0;i<n;i++){
		s[i][0]=DotProduct3D(localx,points[i]);
		s[i][1]=DotProduct3D(localy,points[i]);
		temp1[i][0]=s[i][0];
		temp1[i][1]=s[i][1];
		temp1[i][2]=0.5*s[i][0]*s[i][0];
		temp1[i][3]=s[i][0]*s[i][1];
		temp1[i][4]=0.5*s[i][1]*s[i][1];
		temp1[i][5]=0.16666666666666*s[i][0]*s[i][0]*s[i][0];
		temp1[i][6]=0.5*s[i][0]*s[i][0]*s[i][1];
		temp1[i][7]=0.5*s[i][0]*s[i][1]*s[i][1];
		temp1[i][8]=0.16666666666666*s[i][1]*s[i][1]*s[i][1];
		temp1[i][9]=0.04166666666666*s[i][0]*s[i][0]*s[i][0]*s[i][0];
		temp1[i][10]=0.16666666666666*s[i][0]*s[i][0]*s[i][0]*s[i][1];
		temp1[i][11]=0.25*s[i][0]*s[i][0]*s[i][1]*s[i][1];
		temp1[i][12]=0.16666666666666*s[i][0]*s[i][1]*s[i][1]*s[i][1];
		temp1[i][13]=0.04166666666666*s[i][1]*s[i][1]*s[i][1]*s[i][1];
	}
	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].x*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].x=gsl_vector_get(V,0);
	dR[1].x=gsl_vector_get(V,1);
	ddR[0][0].x=gsl_vector_get(V,2);
	ddR[1][0].x=ddR[0][1].x=gsl_vector_get(V,3);
	ddR[1][1].x=gsl_vector_get(V,4);
	dddR[0][0][0].x=gsl_vector_get(V,5);
	dddR[0][0][1].x=dddR[0][1][0].x=dddR[1][0][0].x=gsl_vector_get(V,6);
	dddR[0][1][1].x=dddR[1][1][0].x=dddR[1][0][1].x=gsl_vector_get(V,7);
	dddR[1][1][1].x=gsl_vector_get(V,8);
/*	ddddR[0][0][0][0].x=gsl_vector_get(V,9);
	ddddR[1][0][0][0].x=ddddR[0][1][0][0].x=ddddR[0][0][1][0].x=ddddR[0][0][0][1].x=gsl_vector_get(V,10);
	ddddR[1][1][0][0].x=ddddR[1][0][1][0].x=ddddR[1][0][0][1].x=ddddR[0][1][1][0].x=ddddR[0][1][0][1].x=ddddR[0][0][1][1].x=gsl_vector_get(V,11);
	ddddR[1][1][1][0].x=ddddR[1][1][0][1].x=ddddR[1][0][1][1].x=ddddR[0][1][1][1].x=gsl_vector_get(V,12);
	ddddR[1][1][1][1].x=gsl_vector_get(V,13);*/

	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].y*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].y=gsl_vector_get(V,0);
	dR[1].y=gsl_vector_get(V,1);
	ddR[0][0].y=gsl_vector_get(V,2);
	ddR[1][0].y=ddR[0][1].y=gsl_vector_get(V,3);
	ddR[1][1].y=gsl_vector_get(V,4);
	dddR[0][0][0].y=gsl_vector_get(V,5);
	dddR[0][0][1].y=dddR[0][1][0].y=dddR[1][0][0].y=gsl_vector_get(V,6);
	dddR[0][1][1].y=dddR[1][1][0].y=dddR[1][0][1].y=gsl_vector_get(V,7);
	dddR[1][1][1].y=gsl_vector_get(V,8);
/*	ddddR[0][0][0][0].y=gsl_vector_get(V,9);
	ddddR[1][0][0][0].y=ddddR[0][1][0][0].y=ddddR[0][0][1][0].y=ddddR[0][0][0][1].y=gsl_vector_get(V,10);
	ddddR[1][1][0][0].y=ddddR[1][0][1][0].y=ddddR[1][0][0][1].y=ddddR[0][1][1][0].y=ddddR[0][1][0][1].y=ddddR[0][0][1][1].y=gsl_vector_get(V,11);
	ddddR[1][1][1][0].y=ddddR[1][1][0][1].y=ddddR[1][0][1][1].y=ddddR[0][1][1][1].y=gsl_vector_get(V,12);
	ddddR[1][1][1][1].y=gsl_vector_get(V,13);*/
	
	for(i=0;i<14;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].z*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<14;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].z=gsl_vector_get(V,0);
	dR[1].z=gsl_vector_get(V,1);
	ddR[0][0].z=gsl_vector_get(V,2);
	ddR[1][0].z=ddR[0][1].z=gsl_vector_get(V,3);
	ddR[1][1].z=gsl_vector_get(V,4);
	dddR[0][0][0].z=gsl_vector_get(V,5);
	dddR[0][0][1].z=dddR[0][1][0].z=dddR[1][0][0].z=gsl_vector_get(V,6);
	dddR[0][1][1].z=dddR[1][1][0].z=dddR[1][0][1].z=gsl_vector_get(V,7);
	dddR[1][1][1].z=gsl_vector_get(V,8);
/*	ddddR[0][0][0][0].z=gsl_vector_get(V,9);
	ddddR[1][0][0][0].z=ddddR[0][1][0][0].z=ddddR[0][0][1][0].z=ddddR[0][0][0][1].z=gsl_vector_get(V,10);
	ddddR[1][1][0][0].z=ddddR[1][0][1][0].z=ddddR[1][0][0][1].z=ddddR[0][1][1][0].z=ddddR[0][1][0][1].z=ddddR[0][0][1][1].z=gsl_vector_get(V,11);
	ddddR[1][1][1][0].z=ddddR[1][1][0][1].z=ddddR[1][0][1][1].z=ddddR[0][1][1][1].z=gsl_vector_get(V,12);
	ddddR[1][1][1][1].z=gsl_vector_get(V,13);*/

	
	CrossProduct3D(&NA0,dR[0],dR[1]);
	for(i=0;i<2;i++){
		CrossProduct3D(&dNA0[i],ddR[0][i],dR[1]);
		CrossProduct3D(&temp3D,dR[0],ddR[1][i]);
		add3D2(&dNA0[i],temp3D);
		for(j=0;j<2;j++){
			CrossProduct3D(&ddNA0[i][j],dddR[0][i][j],dR[1]);
			CrossProduct3D(&temp3D,dR[0],dddR[1][i][j]);
			add3D2(&ddNA0[i][j],temp3D);
			smul3D2(&ddNA0[i][j],0.5);
			CrossProduct3D(&temp3D,ddR[0][i],ddR[1][j]);
			add3D2(&ddNA0[i][j],temp3D);
/*			for(k=0;k<2;k++){
				CrossProduct3D(&dddNA0[i][j][k],ddddR[0][i][j][k],dR[1]);
				CrossProduct3D(&temp3D,dR[0],ddddR[1][i][j][k]);
				add3D2(&dddNA0[i][j][k],temp3D);
				smul3D2(&dddNA0[i][j][k],0.33333333333333);
				CrossProduct3D(&temp3D,dddR[0][i][j],ddR[1][k]);
				add3D2(&dddNA0[i][j][k],temp3D);
				CrossProduct3D(&temp3D,ddR[0][i],dddR[1][j][k]);
				add3D2(&dddNA0[i][j][k],temp3D);
				smul3D2(&dddNA0[i][j][k],0.5);
			}*/
		}
	}
	V0=DotProduct3D(R0,NA0);
	for(i=0;i<2;i++){
		dV0[i]=DotProduct3D(R0,dNA0[i])+DotProduct3D(dR[i],NA0);
		for(j=0;j<2;j++){
			ddV0[i][j]=DotProduct3D(R0,ddNA0[i][j])+DotProduct3D(dR[i],dNA0[j])+0.5*DotProduct3D(ddR[i][j],NA0);
/*			for(k=0;k<2;k++){
				dddA02[i][j][k]=2.0*(DotProduct3D(dddNA0[i][j][k],NA0)+DotProduct3D(ddNA0[i][j],dNA0[k]))/A02;
			}*/
		}
	}
	for(i=0;i<2;i++)
		for(j=0;j<2;j++)
			g[i][j]=DotProduct3D(dR[i],dR[j]);
	
	detg1=1.0/det2D(g);

	g1[0][0]=g[1][1]*detg1;
	g1[1][1]=g[0][0]*detg1;
	g1[1][0]=-g[0][1]*detg1;
	g1[0][1]=-g[1][0]*detg1;
	
	for(i=0;i<2;i++){
		for(j=0;j<2;j++){
			for(k=0;k<2;k++){
				for(l=0;l<2;l++){
					dChris[i][j][k][l]=DotProduct3D(ddR[i][j],ddR[k][l])+DotProduct3D(dR[i],dddR[j][k][l]);
				}
			}
		}
	}
	*dvolume=0.0;
	for(i=0;i<n0;i++){
		Delta=s[pairs[i][0]][0]*s[pairs[i][1]][1]-s[pairs[i][1]][0]*s[pairs[i][0]][1];
		temp=0.5*V0;

		for(j=0;j<2;j++){
			temp+=0.3333333333333333*dV0[j]*(s[pairs[i][0]][j]+s[pairs[i][1]][j]);
			for(k=0;k<2;k++){
				temp+=0.083333333333333*ddV0[j][k]*(s[pairs[i][0]][j]*s[pairs[i][0]][k]+s[pairs[i][1]][j]*s[pairs[i][1]][k]+0.5*(s[pairs[i][0]][j]*s[pairs[i][1]][k]+s[pairs[i][1]][j]*s[pairs[i][0]][k]));
/*				for(l=0;l<2;l++){
					temp+=0.05*dddA0[i][j][k]*(s[pairs[i][0]][j]*s[pairs[i][0]][k]*s[pairs[i][0]][l]+s[pairs[i][1]][j]*s[pairs[i][1]][k]*s[pairs[i][1]][l]+0.3333333333333*(s[pairs[i][0]][j]*s[pairs[i][0]][k]*s[pairs[i][1]][l]+s[pairs[i][0]][j]*s[pairs[i][1]][k]*s[pairs[i][0]][l]+s[pairs[i][1]][j]*s[pairs[i][0]][k]*s[pairs[i][0]][l]+s[pairs[i][0]][j]*s[pairs[i][1]][k]*s[pairs[i][1]][l]+s[pairs[i][1]][j]*s[pairs[i][0]][k]*s[pairs[i][1]][l]+s[pairs[i][1]][j]*s[pairs[i][1]][k]*s[pairs[i][0]][l]));
				}*/
			}
		}
		temp*=Delta;
		for(j=0;j<2;j++){
			temp2[j]=0.0;
			for(k=0;k<2;k++)
				for(l=0;l<2;l++)
					for(m=0;m<2;m++){
						temp2[j]+=dChris[j][k][l][m]*(s[pairs[i][0]][k]+s[pairs[i][1]][k])*(s[pairs[i][0]][l]-s[pairs[i][1]][l])*(s[pairs[i][0]][m]-s[pairs[i][1]][m]);
					}
		}
		for(j=0;j<2;j++){
			temp3[j]=0.0;
			for(l=0;l<2;l++){
				temp3[j]+=g1[j][l]*temp2[l];
			}
		}
		temp-=0.041666666666666*((s[pairs[i][1]][0]-s[pairs[i][0]][0])*temp3[1]-(s[pairs[i][1]][1]-s[pairs[i][0]][1])*temp3[0])*V0;
		*dvolume+=fabs(temp);
	}
	*dvolume*=0.1111111111111111111;
	gsl_matrix_free(M);
	gsl_vector_free(V);	
}



void Surface_Area(struct point3D r_mem[],int triang_site[][3],struct point3D n_mem[],double* Area0,double* Volume0){
	int i, j, k, l, l0, l1, l2;
	int Nneighbours[NMEM];
	int neighbours[NMEM][6];
	int npoints;
	int neighbours2[18];
	struct point3D points[18],temp;
	int pairs[6][2];
	int npairs;
	double darea,dvolume;

	for(i=0;i<NMEM;i++) Nneighbours[i]=0;
	for(i=0;i<NTRIANG;i++){
		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];
		for(j=0;j<Nneighbours[l0];j++) if(neighbours[l0][j]==l1) break;
		if(j==Nneighbours[l0]){
			neighbours[l0][j]=l1;
			Nneighbours[l0]++;
		}
		for(j=0;j<Nneighbours[l0];j++) if(neighbours[l0][j]==l2) break;
		if(j==Nneighbours[l0]){
			neighbours[l0][j]=l2;
			Nneighbours[l0]++;
		}
		for(j=0;j<Nneighbours[l1];j++) if(neighbours[l1][j]==l2) break;
		if(j==Nneighbours[l1]){
			neighbours[l1][j]=l2;
			Nneighbours[l1]++;
		}
		for(j=0;j<Nneighbours[l1];j++) if(neighbours[l1][j]==l0) break;
		if(j==Nneighbours[l1]){
			neighbours[l1][j]=l0;
			Nneighbours[l1]++;
		}
		for(j=0;j<Nneighbours[l2];j++) if(neighbours[l2][j]==l0) break;
		if(j==Nneighbours[l2]){
			neighbours[l2][j]=l0;
			Nneighbours[l2]++;
		}
		for(j=0;j<Nneighbours[l2];j++) if(neighbours[l2][j]==l1) break;
		if(j==Nneighbours[l2]){
			neighbours[l2][j]=l1;
			Nneighbours[l2]++;
		}
	}
	*Area0=0.0;
	*Volume0=0.0;
	for(i=0;i<NMEM;i++){
		npoints=Nneighbours[i];
		for(j=0;j<Nneighbours[i];j++) neighbours2[j]=neighbours[i][j];
		npairs=0;
		for(j=0;j<Nneighbours[i];j++){
			for(k=0;k<Nneighbours[neighbours[i][j]];k++){
				if(neighbours[neighbours[i][j]][k]==i) continue;
				for(l=0;l<npoints;l++){
					if(neighbours2[l]==neighbours[neighbours[i][j]][k]) break;
				}
				if(l==npoints){
					neighbours2[npoints]=neighbours[neighbours[i][j]][k];
					npoints++;
				}
				if(l<Nneighbours[i]) if(l<j){
					pairs[npairs][0]=l;
					pairs[npairs][1]=j;
					npairs++;
				}
			}
		}
		for(j=0;j<npoints;j++){
			sub3D(&points[j],r_mem[neighbours2[j]],r_mem[i]);
		}
		new_area_element(npoints,points,&n_mem[i],Nneighbours[i],pairs,&darea);
		*Area0+=darea;
		new_volume_element(npoints,r_mem[i],points,&n_mem[i],Nneighbours[i],pairs,&dvolume);
		*Volume0+=dvolume;
	}
	printf("%f\t%f\t%f\n",*Area0,*Volume0,*Volume0*pow(*Area0/(4.0*PI),-1.5)/PI*0.75);
}

void new_dynamique(struct point3D r_mem[NMEM],int triang_site[NTRIANG][3],struct point3D n_mem[NMEM],double colors[NMEM],struct point3D v_mem[NMEM],double weights[NMEM],struct point3D v_mem_cm,struct point3D dr_mem[NMEM],double dcolors[NMEM],struct point3D dv_mem[NMEM],double* dtime,double darea[NTRIANG]){
	int i, j, k, l, l0, l1, l2;
	int Nneighbours[NMEM];
	int neighbours[NMEM][6];
	double neighbourweight[NMEM][6];
	int npoints;
	struct point3D points[6],dv[6],v_t,v_n,v_mem_cm1;
	double dz[6],w[6],dc[6],drmax,drtemp;

	for(i=0;i<NMEM;i++) {
		Nneighbours[i]=0;
		for(j=0;j<6;j++) neighbourweight[i][j]=0.0;
	}
	for(i=0;i<NTRIANG;i++){
		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];
		for(j=0;j<Nneighbours[l0];j++) if(neighbours[l0][j]==l1) break;
		neighbourweight[l0][j]+=darea[i];
		if(j==Nneighbours[l0]){
			neighbours[l0][j]=l1;
			Nneighbours[l0]++;
		}
		for(j=0;j<Nneighbours[l0];j++) if(neighbours[l0][j]==l2) break;
		neighbourweight[l0][j]+=darea[i];
		if(j==Nneighbours[l0]){
			neighbours[l0][j]=l2;
			Nneighbours[l0]++;
		}
		for(j=0;j<Nneighbours[l1];j++) if(neighbours[l1][j]==l2) break;
		neighbourweight[l1][j]+=darea[i];
		if(j==Nneighbours[l1]){
			neighbours[l1][j]=l2;
			Nneighbours[l1]++;
		}
		for(j=0;j<Nneighbours[l1];j++) if(neighbours[l1][j]==l0) break;
		neighbourweight[l1][j]+=darea[i];
		if(j==Nneighbours[l1]){
			neighbours[l1][j]=l0;
			Nneighbours[l1]++;
		}
		for(j=0;j<Nneighbours[l2];j++) if(neighbours[l2][j]==l0) break;
		neighbourweight[l2][j]+=darea[i];
		if(j==Nneighbours[l2]){
			neighbours[l2][j]=l0;
			Nneighbours[l2]++;
		}
		for(j=0;j<Nneighbours[l2];j++) if(neighbours[l2][j]==l1) break;
		neighbourweight[l2][j]+=darea[i];
		if(j==Nneighbours[l2]){
			neighbours[l2][j]=l1;
			Nneighbours[l2]++;
		}
	}
	for(i=0;i<NMEM;i++)	if(Nneighbours[i]==5) weights[i]/=0.7813887112;

	drmax=0.0;	
	for(i=0;i<NMEM;i++){
		v_t.x=(v_mem[i].x-v_mem_cm.x)*(*dtime);
		v_t.y=(v_mem[i].y-v_mem_cm.y)*(*dtime);
		v_t.z=(v_mem[i].z-v_mem_cm.z)*(*dtime);
		for(j=0;j<Nneighbours[i];j++){
			sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
			sub3D(&dv[j],v_mem[neighbours[i][j]],v_mem[i]);
			w[j]=weights[neighbours[i][j]]*neighbourweight[i][j];
			dc[j]=colors[neighbours[i][j]]-colors[i];
		}
		advect(Nneighbours[i],points,dc,dv,&n_mem[i],w,&dr_mem[i],&dcolors[i],&dv_mem[i],v_t,1.0);
	}

/*	for(i=0;i<NMEM;i++){
		sub3D(&v_t,v_mem[i],v_mem_cm);
		smul3D(&v_n,DotProduct3D(n_mem[i],v_t),n_mem[i]);
		sub3D2(&v_t,v_n);
		smul3D2(&v_t,*dtime);
		add3D2(&v_n,v_mem_cm);
		smul3D2(&v_n,*dtime);
		for(j=0;j<Nneighbours[i];j++){
			sub3D(&points[j],r_mem[neighbours[i][j]],r_mem[i]);
			sub3D(&dv[j],v_mem[neighbours[i][j]],v_mem[i]);
//			dz[j]=zeta[neighbours[i][j]]-zeta[i];
			w[j]=weights[neighbours[i][j]]*neighbourweight[i][j];
			dc[j]=colors[neighbours[i][j]]-colors[i];
		}
		advect(Nneighbours[i],points,dc,dv,&n_mem[i],w,&dr_mem[i],&dcolors[i],&dv_mem[i],v_t,1.0);
		add3D2(&dr_mem[i],v_n);
	}*/

}

void advect(int n, struct point3D points[], double b[], struct point3D v_mem[],struct point3D* normal,double weights[], struct point3D* dr_mem, double *db_mem, struct point3D dv_mem[],struct point3D v_t,double advect_mul)
{
	double s1[6];
	double s2[6];
	double temp1[6][5];
	struct point3D localx,localy,dR[2],ddR[2][2],dV[2],ddV[2][2];
	double temp,db[2],ddb[2][2];
	double weight0,new_s[2],v_t_s[2],new_s0[2];
	struct point3D g1ddR;
	struct point3D gradsa;
	
	int i,j,k,imin;
	gsl_matrix *M;
	gsl_vector *V;

	if (n<5) {
		printf("not enough points for the interpolation\n");
		exit(1);
	}
	if (n>6) {
		printf("too many points for the interpolation\n");
		exit(1);
	}

	M=gsl_matrix_alloc(5,5);
	V=gsl_vector_alloc(5);	
	temp=DotProduct3D(points[0],*normal);
	smul3D(&localx,-temp,*normal);
	add3D2(&localx,points[0]);
	temp=sqrt(DotProduct3D(localx,localx));
	smul3D2(&localx,1.0/temp);
	CrossProduct3D(&localy,*normal,localx);
	v_t_s[0]=DotProduct3D(v_t,localx);
	v_t_s[1]=DotProduct3D(v_t,localy);
	for(i=0;i<n;i++){
		s1[i]=DotProduct3D(localx,points[i]);
		s2[i]=DotProduct3D(localy,points[i]);
		temp1[i][0]=s1[i];
		temp1[i][1]=s2[i];
		temp1[i][2]=0.5*s1[i]*s1[i];
		temp1[i][3]=s1[i]*s2[i];
		temp1[i][4]=0.5*s2[i]*s2[i];
	}
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].x*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].x=gsl_vector_get(V,0);
	dR[1].x=gsl_vector_get(V,1);
	ddR[0][0].x=gsl_vector_get(V,2);
	ddR[1][0].x=ddR[0][1].x=gsl_vector_get(V,3);
	ddR[1][1].x=gsl_vector_get(V,4);

	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].y*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].y=gsl_vector_get(V,0);
	dR[1].y=gsl_vector_get(V,1);
	ddR[0][0].y=gsl_vector_get(V,2);
	ddR[1][0].y=ddR[0][1].y=gsl_vector_get(V,3);
	ddR[1][1].y=gsl_vector_get(V,4);
	
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].z*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dR[0].z=gsl_vector_get(V,0);
	dR[1].z=gsl_vector_get(V,1);
	ddR[0][0].z=gsl_vector_get(V,2);
	ddR[1][0].z=ddR[0][1].z=gsl_vector_get(V,3);
	ddR[1][1].z=gsl_vector_get(V,4);

	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=b[k]*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	db[0]=gsl_vector_get(V,0);
	db[1]=gsl_vector_get(V,1);
	ddb[0][0]=gsl_vector_get(V,2);
	ddb[1][0]=ddb[0][1]=gsl_vector_get(V,3);
	ddb[1][1]=gsl_vector_get(V,4);

	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=v_mem[k].x*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dV[0].x=gsl_vector_get(V,0);
	dV[1].x=gsl_vector_get(V,1);
	ddV[0][0].x=gsl_vector_get(V,2);
	ddV[1][0].x=ddV[0][1].x=gsl_vector_get(V,3);
	ddV[1][1].x=gsl_vector_get(V,4);

	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=v_mem[k].y*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dV[0].y=gsl_vector_get(V,0);
	dV[1].y=gsl_vector_get(V,1);
	ddV[0][0].y=gsl_vector_get(V,2);
	ddV[1][0].y=ddV[0][1].y=gsl_vector_get(V,3);
	ddV[1][1].y=gsl_vector_get(V,4);
	
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=v_mem[k].z*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	dV[0].z=gsl_vector_get(V,0);
	dV[1].z=gsl_vector_get(V,1);
	ddV[0][0].z=gsl_vector_get(V,2);
	ddV[1][0].z=ddV[0][1].z=gsl_vector_get(V,3);
	ddV[1][1].z=gsl_vector_get(V,4);

	new_s[0]=0.0;
	new_s[1]=0.0;
	weight0=0.0;
	for(i=0;i<n;i++){
		new_s[0]+=weights[i]*s1[i];
		new_s[1]+=weights[i]*s2[i];
		weight0+=weights[i];
	}
	new_s0[0]=advect_mul*ADVECT_MUL*new_s[0]/weight0;
	new_s0[1]=advect_mul*ADVECT_MUL*new_s[1]/weight0;
#ifdef MESHTT
	new_s[0]=new_s0[0];
	new_s[1]=new_s0[1];
#else
	new_s[0]=new_s0[0]-v_t_s[0];
	new_s[1]=new_s0[1]-v_t_s[1];
#endif
	dr_mem->x=0.0;
	dr_mem->y=0.0;
	dr_mem->z=0.0;
	dv_mem->x=0.0;
	dv_mem->y=0.0;
	dv_mem->z=0.0;
	*db_mem=0.0;
	for(i=0;i<2;i++){
		dr_mem->x+=dR[i].x*new_s[i];
		dr_mem->y+=dR[i].y*new_s[i];
		dr_mem->z+=dR[i].z*new_s[i];
		dv_mem->x+=dV[i].x*new_s0[i];
		dv_mem->y+=dV[i].y*new_s0[i];
		dv_mem->z+=dV[i].z*new_s0[i];
		*db_mem+=db[i]*new_s[i];
		for(j=0;j<2;j++){
			dr_mem->x+=0.5*ddR[i][j].x*new_s[i]*new_s[j];
			dr_mem->y+=0.5*ddR[i][j].y*new_s[i]*new_s[j];
			dr_mem->z+=0.5*ddR[i][j].z*new_s[i]*new_s[j];
			dv_mem->x+=0.5*ddV[i][j].x*new_s0[i]*new_s0[j];
			dv_mem->y+=0.5*ddV[i][j].y*new_s0[i]*new_s0[j];
			dv_mem->z+=0.5*ddV[i][j].z*new_s0[i]*new_s0[j];
			*db_mem+=0.5*ddb[i][j]*new_s[i]*new_s[j];
		}
	}

	gsl_matrix_free(M);
	gsl_vector_free(V);	
	
}

void new_dynamique2(struct point3D r_mem[NMEM],int triang_site[NTRIANG][3],struct point3D n_mem[NMEM],double colors[NMEM],struct point3D v_mem[NMEM],double
 weights[NMEM],struct point3D v_mem_cm,struct point3D dr_mem[NMEM],double dcolors[NMEM],struct point3D dv_mem[NMEM],double* dtime,double darea[NTRIANG]){
	int i,j,l0,l1,l2;
	struct point3D r01,r12,r20,v01,v12,v20,triangle_normal,vtemp;
	double triangle_area,temp0,weight0,weights0[NMEM];
	for(i=0;i<NMEM;i++) dr_mem[i].x=dr_mem[i].y=dr_mem[i].z=dv_mem[i].x=dv_mem[i].y=dv_mem[i].z=weights0[i]=0.0;
	for(i=0;i<NTRIANG;i++){
		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];
		sub3D(&r01,r_mem[l1],r_mem[l0]);
		sub3D(&r12,r_mem[l2],r_mem[l1]);
		sub3D(&r20,r_mem[l0],r_mem[l2]);
		sub3D(&v01,v_mem[l1],v_mem[l0]);
		sub3D(&v12,v_mem[l2],v_mem[l1]);
		sub3D(&v20,v_mem[l0],v_mem[l2]);
		CrossProduct3D(&triangle_normal,r12,r01);
		triangle_area=sqrt(DotProduct3D(triangle_normal,triangle_normal));
//		smul3D2(&triangle_normal,1.0/triangle_area);
		CrossProduct3D(&vtemp,triangle_normal,r12);
		weight0=(weights[l1]+weights[l2]+weights[l0])*triangle_area;
		sub3D(&vtemp,r01,r20);
		dr_mem[l0].x+=weight0*vtemp.x;
		dr_mem[l0].y+=weight0*vtemp.y;
		dr_mem[l0].z+=weight0*vtemp.z;
		sub3D(&vtemp,v01,v20);
		dv_mem[l0].x+=weight0*vtemp.x;
		dv_mem[l0].y+=weight0*vtemp.y;
		dv_mem[l0].z+=weight0*vtemp.z;
		
		weights0[l0]+=weight0;
		sub3D(&vtemp,r12,r01);
		dr_mem[l1].x+=weight0*vtemp.x;
		dr_mem[l1].y+=weight0*vtemp.y;
		dr_mem[l1].z+=weight0*vtemp.z;
		sub3D(&vtemp,v12,v01);
		dv_mem[l1].x+=weight0*vtemp.x;
		dv_mem[l1].y+=weight0*vtemp.y;
		dv_mem[l1].z+=weight0*vtemp.z;
		weights0[l1]+=weight0;
		sub3D(&vtemp,r20,r12);
		dr_mem[l2].x+=weight0*vtemp.x;
		dr_mem[l2].y+=weight0*vtemp.y;
		dr_mem[l2].z+=weight0*vtemp.z;
		sub3D(&vtemp,v20,v12);
		dv_mem[l2].x+=weight0*vtemp.x;
		dv_mem[l2].y+=weight0*vtemp.y;
		dv_mem[l2].z+=weight0*vtemp.z;
		weights0[l2]+=weight0;
	}
	for(i=0;i<NMEM;i++){
		dr_mem[i].x=ADVECT_MUL*dr_mem[i].x/weights0[i];
		dr_mem[i].y=ADVECT_MUL*dr_mem[i].y/weights0[i];
		dr_mem[i].z=ADVECT_MUL*dr_mem[i].z/weights0[i];
		dv_mem[i].x=ADVECT_MUL*dv_mem[i].x/weights0[i];
		dv_mem[i].y=ADVECT_MUL*dv_mem[i].y/weights0[i];
		dv_mem[i].z=ADVECT_MUL*dv_mem[i].z/weights0[i];
	}
}

void outwarder(struct point3D r_mem[NMEM], int triang_site[NTRIANG][3],struct point3D n_mem[NMEM]){
	int intersections;
	int i,j,k;
	gsl_matrix *M;
	gsl_vector *V;
	gsl_vector *V1;
	M=gsl_matrix_alloc(3,3);
	V=gsl_vector_alloc(3);
	V1=gsl_vector_alloc(3);
	for(i=0;i<NMEM;i++) {
		intersections=0;
		gsl_vector_set(V,0,n_mem[i].x);
		gsl_vector_set(V,1,n_mem[i].y);
		gsl_vector_set(V,2,n_mem[i].z);
		for(j=0;j<NTRIANG;j++){
			for(k=0;k<3;k++) if(i==triang_site[j][k]) break;
			if(k<3) continue;
			for(k=0;k<3;k++){
				gsl_matrix_set(M,0,k,r_mem[triang_site[j][k]].x-r_mem[i].x);
				gsl_matrix_set(M,1,k,r_mem[triang_site[j][k]].y-r_mem[i].y);
				gsl_matrix_set(M,2,k,r_mem[triang_site[j][k]].z-r_mem[i].z);
			}
			gsl_linalg_HH_solve(M,V,V1);
			for(k=0;k<3;k++) if(gsl_vector_get(V1,k)<0) break;
			if(k==3) intersections++;
		}
		if(intersections%2==1) smul3D2(&n_mem[i],-1.0);
	}
	gsl_vector_free(V);
	gsl_vector_free(V1);
	gsl_matrix_free(M);

}

void old_surface_gradient(struct point3D r_mem[NMEM],int triang_site[NTRIANG][3],double a[NMEM],struct point3D gradsa[NMEM]){
	int i,l0,l1,l2,j;
	struct point3D temp,r01,r02;
	double darea[NMEM],g11,g22,g12,a20,a10,temp0;
	for(i=0;i<NMEM;i++) gradsa[i].x=gradsa[i].y=gradsa[i].z=darea[i]=0.0;
	for(i=0;i<NTRIANG;i++){
		l0=triang_site[i][0];
		l1=triang_site[i][1];
		l2=triang_site[i][2];
		sub3D(&r01,r_mem[l1],r_mem[l0]);
		sub3D(&r02,r_mem[l2],r_mem[l0]);
		g11=DotProduct3D(r01,r01);
		g22=DotProduct3D(r02,r02);
		g12=DotProduct3D(r01,r02);
		a20=a[l2]-a[l0];
		a10=a[l1]-a[l0];
		CrossProduct3D(&temp,r01,r02);
		temp0=sqrt(DotProduct3D(temp,temp));
		for(j=0;j<3;j++)darea[triang_site[i][j]]+=temp0;
		temp0=1.0/temp0;
		temp.x=(r01.x*(a10*g11-a20*g12)+r02.x*(a20*g22-a10*g12))*temp0;
		temp.y=(r01.y*(a10*g11-a20*g12)+r02.y*(a20*g22-a10*g12))*temp0;
		temp.z=(r01.z*(a10*g11-a20*g12)+r02.z*(a20*g22-a10*g12))*temp0;
		for(j=0;j<3;j++) add3D2(&gradsa[triang_site[i][j]],temp);
	}
	for(i=0;i<NMEM;i++) smul3D2(&gradsa[i],1.0/darea[i]);
}

void get_stress(struct point3D r_mem[NMEM],int triang_site[NTRIANG][3],struct point3D f_mem[NMEM],struct point3D n_mem[NMEM],struct point3D v_mem[NMEM],double stress[3][3],double darea[NTRIANG]){
	int i,j;
	double areas[NMEM];
	for(i=0;i<NMEM;i++) areas[i]=0.0;
	for(i=0;i<3;i++) for(j=0;j<3;j++) stress[i][j]=0.0;
	for(i=0;i<NTRIANG;i++) for(j=0;j<3;j++) areas[triang_site[i][j]]+=darea[i];
	for(i=0;i<NMEM;i++){
		stress[0][0]+=(-f_mem[i].x*r_mem[i].x+2.0*(VISC_RATIO-1.0)*v_mem[i].x*n_mem[i].x)*areas[i];
		stress[1][1]+=(-f_mem[i].y*r_mem[i].y+2.0*(VISC_RATIO-1.0)*v_mem[i].y*n_mem[i].y)*areas[i];
		stress[2][2]+=(-f_mem[i].z*r_mem[i].z+2.0*(VISC_RATIO-1.0)*v_mem[i].z*n_mem[i].z)*areas[i];
		stress[0][1]+=(-f_mem[i].x*r_mem[i].y+(VISC_RATIO-1.0)*(v_mem[i].x*n_mem[i].y+v_mem[i].y*n_mem[i].x))*areas[i];
		stress[1][2]+=(-f_mem[i].y*r_mem[i].z+(VISC_RATIO-1.0)*(v_mem[i].y*n_mem[i].z+v_mem[i].z*n_mem[i].y))*areas[i];
		stress[2][0]+=(-f_mem[i].z*r_mem[i].x+(VISC_RATIO-1.0)*(v_mem[i].z*n_mem[i].x+v_mem[i].x*n_mem[i].z))*areas[i];
		stress[1][0]+=(-f_mem[i].y*r_mem[i].x+(VISC_RATIO-1.0)*(v_mem[i].x*n_mem[i].y+v_mem[i].y*n_mem[i].x))*areas[i];
		stress[2][1]+=(-f_mem[i].z*r_mem[i].y+(VISC_RATIO-1.0)*(v_mem[i].y*n_mem[i].z+v_mem[i].z*n_mem[i].y))*areas[i];
		stress[0][2]+=(-f_mem[i].x*r_mem[i].z+(VISC_RATIO-1.0)*(v_mem[i].z*n_mem[i].x+v_mem[i].x*n_mem[i].z))*areas[i];
	}
	for(i=0;i<3;i++)for(j=0;j<3;j++) stress[i][j]/=3.0;
}

void put_points(int triang_site[NTRIANG][3], struct point3D r_mem[NMEM], struct point3D r_mem2[NMEM2])
{

	int		i, j, k, i1, j1, i2, j2, n, m, v, w, l0, l1, l2, a, b, c, d;
	double		norm;
	struct point3D	rmid;

	for(v=0;v<NMEM;v++){
		r_mem2[v].x=r_mem[v].x;
		r_mem2[v].y=r_mem[v].y;
		r_mem2[v].z=r_mem[v].z;
	}
	norm=1.0/7.0;
	for(i=0;i<NTRIANG;i++){
		for(j=0;j<3;j++){
			l0 = triang_site[i][j];
			l1 = triang_site[i][(j+1)%3];
			l2 = triang_site[i][(j+2)%3];
			r_mem2[v].x=r_mem[l2].x+2.0*r_mem[l1].x+4.0*r_mem[l0].x;
			r_mem2[v].y=r_mem[l2].y+2.0*r_mem[l1].y+4.0*r_mem[l0].y;
			r_mem2[v].z=r_mem[l2].z+2.0*r_mem[l1].z+4.0*r_mem[l0].z;
			r_mem2[v].x*=norm;
			r_mem2[v].y*=norm;
			r_mem2[v].z*=norm;
			v++;
		}	
	}
}

void put_points16(struct point3D r_mem[NMEM], struct point3D r_mem2[NMEM2], int slaves[NMEM][NSLA], int Nneighbours[NMEM])
{

	int		i, j, k, i1, j1, i2, j2, n, m, v, w, l0, l1, l2, a, b, c, d;
	double		norm;
	struct point3D	rmid;

	for(v=NMEM;v<NMEM2;v++)r_mem2[v].x=r_mem2[v].y=r_mem2[v].z=0.0;
	for(v=0;v<NMEM;v++){
		r_mem2[v].x=r_mem[v].x;
		r_mem2[v].y=r_mem[v].y;
		r_mem2[v].z=r_mem[v].z;
		for(j=0;j<Nneighbours[v];j++){
			r_mem2[slaves[v][j+1]].x+=0.75*r_mem[v].x;
			r_mem2[slaves[v][j+1]].y+=0.75*r_mem[v].y;
			r_mem2[slaves[v][j+1]].z+=0.75*r_mem[v].z;
			r_mem2[slaves[v][2*j+7]].x+=0.5*r_mem[v].x;
			r_mem2[slaves[v][2*j+7]].y+=0.5*r_mem[v].y;
			r_mem2[slaves[v][2*j+7]].z+=0.5*r_mem[v].z;
			r_mem2[slaves[v][2*j+8]].x+=0.5*r_mem[v].x;
			r_mem2[slaves[v][2*j+8]].y+=0.5*r_mem[v].y;
			r_mem2[slaves[v][2*j+8]].z+=0.5*r_mem[v].z;
			r_mem2[slaves[v][3*j+19]].x+=0.25*r_mem[v].x;
			r_mem2[slaves[v][3*j+19]].y+=0.25*r_mem[v].y;
			r_mem2[slaves[v][3*j+19]].z+=0.25*r_mem[v].z;
			r_mem2[slaves[v][3*j+20]].x+=0.25*r_mem[v].x;
			r_mem2[slaves[v][3*j+20]].y+=0.25*r_mem[v].y;
			r_mem2[slaves[v][3*j+20]].z+=0.25*r_mem[v].z;
			r_mem2[slaves[v][3*j+21]].x+=0.25*r_mem[v].x;
			r_mem2[slaves[v][3*j+21]].y+=0.25*r_mem[v].y;
			r_mem2[slaves[v][3*j+21]].z+=0.25*r_mem[v].z;
		}
	}
}

void find_angle(struct point3D r_mem[NMEM],struct point3D r_mem_cm){
	int i,i0;
	double dr,dr0;
	FILE* fp;

	dr0=0.0;
	for(i=0;i<NMEM;i++){
		dr=(r_mem[i].x-r_mem_cm.x)*(r_mem[i].x-r_mem_cm.x)+(r_mem[i].y-r_mem_cm.y)*(r_mem[i].y-r_mem_cm.y);
		if(dr0<dr){
			dr0=dr;
			i0=i;
		}
	}
	fp=fopen("angle.dat","a");
	dr=sqrt(dr0);
	dr0=1.0/dr;
	fprintf(fp,"%f\t%f\t%f\t%f\n",(r_mem[i0].x-r_mem_cm.x)*dr0,(r_mem[i0].y-r_mem_cm.y)*dr0,(r_mem[i0].z-r_mem_cm.z)*dr0,dr);
	fclose(fp);
}
