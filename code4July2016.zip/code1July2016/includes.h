#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_eigen.h>

/*
 *  includes for fftw
 */

// #include <rfftw.h>

#ifdef use_windows

    #include <graphic.h>

#else

    #include <des_math.h>

#endif

/*
 *  parameters
 */

#include "param.h"

struct  point3D {
        double x,y,z;
        };
#include "new_geom.h"
#include "test_green3D.h"

// green3D.c

void	green_mem(int triang_site[NTRIANG][3], struct point3D v_mem[], struct point3D *v_mem_cm, struct point3D f_mem[], struct point3D r_mem[], struct point3D n_mem[],  double darea[],
                    double eta, double pp, double shear);

void	green(int triang_site[NTRIANG][3], struct point3D pos, struct point3D *v, struct point3D v_mem[], struct point3D f_mem[], struct point3D r_mem[],
                    struct point3D n_mem[], double darea[], double eta, double pp, double shear);

void	singular_mem( struct point3D *sum, struct point3D f_mem0,
                                           struct point3D f_mem1,
                                           struct point3D f_mem2,
                                           struct point3D r_mem0,
                                           struct point3D r_mem1,
                                           struct point3D r_mem2, struct point3D n_mem,
                                           double eta, double pp, double shear, double dsurf);

void	singular_mem_contrib( struct point3D *sum, struct point3D f0,
                                           struct point3D r_mem0,
                                           struct point3D r_mem1,
                                           struct point3D r_mem2,
                                           struct point3D pos,double eta, double pp, double shear, double dsurf);

void	regular_mem_new(  struct point3D *sum, struct point3D f_mem0,
                                           struct point3D f_mem1,
                                           struct point3D f_mem2,
                                           struct point3D r_mem0,
                                           struct point3D r_mem1,
                                           struct point3D r_mem2,
                                           struct point3D pos,
                                           double eta, double pp, double shear);

void tabulate_greg( struct point3D r_mem[], struct point3D f_mem[], struct point3D pos, struct point3D v_tmp[]);

void tabulate_kreg( struct point3D r_mem[], struct point3D n_mem[], struct point3D v[], struct point3D pos, struct point3D vk_tmp[]);


// dynam.c
void new_val(int triang_site[NTRIANG][3], int triang_site2[NTRIANG2][3], double* dtime,
                 struct point3D r_mem[], struct point3D r_mem2[], struct point3D dr_mem[],
                 double zeta[], double zeta2[], double colors[], double dzeta[], double dzeta2[], double dcolors[],
                 struct point3D v_mem[],  struct point3D f_mem[], struct point3D *v_mem_cm, struct point3D *r_mem_cm,
                 struct point3D n_mem[], double curv[], double gauss[],
                 double lap_curv[], double darea[], double eta, double pp, double kappa,
                 double grav, double *area, double *vol, int step, struct point3D dv_mem[NMEM], double* target_area,
					  int Nneighbours[NMEM],int neighbours[NMEM][6],int neighbour_sites[NMEM][6][2],
					  int Nneighbours2[NMEM2],int neighbours2[NMEM2][6],int neighbour_sites2[NMEM2][6][2], int slaves[NMEM][NSLA], int slaves2[NMEM][NSLA2], int Nslaves2[NMEM], double ref_state[NTRIANG][4],double* time0,int istep,struct point3D r_ref[NMEM]);

void rescale(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D v_mem[], struct point3D r_mem_cm, double zeta[], double vol0, double vol);

// geom.c

void geom(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D v_mem[], struct point3D n_mem[],
          struct point3D *v_mem_cm, struct point3D *r_mem_cm, double *area, double *vol, double darea[]);

void get_curv(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double darea[],
              struct point3D cn_mem[], double curv[], double gauss[], double lap_curv[]);

void geom_triangle(struct point3D r0, struct point3D r1, struct point3D r2,
                   struct point3D *k_sum, double *s_sum, double *gauss_sum, double area);

void beltrami(struct point3D r0, struct point3D r1, struct point3D r2, double a0, double a1, double a2,
                   double *lap, double *s_sum, double area);

void grad2D(struct point3D r0, struct point3D r1, struct point3D r2, double a0, double a1, double a2,
                   struct point3D *grad, double *s_sum, double area);

void grad3D(struct point3D r0, struct point3D r1, struct point3D r2, double a0, double a1, double a2,
                   struct point3D *grad, double *s_sum, double area);

void scal_grad2D(struct point3D grad[], double a[], int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double darea[]);

void vec_grad2Dx(struct point3D grad[], struct point3D vec[], int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double darea[]);

void vec_grad2Dy(struct point3D grad[], struct point3D vec[], int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double darea[]);

void vec_grad2Dz(struct point3D grad[], struct point3D vec[], int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double darea[]);

void smooth( struct point3D vec[], int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double darea[]);

void get_tension(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D f_tens[],
                 double tens, double zeta[], double curv[], struct point3D n_mem[], double darea[]);

void tension(struct point3D r0, struct point3D r1, struct point3D r2, double a0, double a1, double a2,
                   struct point3D *grad, double *s_sum, double area);

void dtriangle_area(struct point3D r0, struct point3D r1, struct point3D r2, struct point3D v0, struct point3D v1, struct point3D v2,
                   double *delta_area, double dtime);

double get_zeta(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D v_mem[],
              struct point3D *v_mem_cm, double darea[],
              double dzeta[], double curv[], struct point3D n_mem[], double dtime );

void get_newtension(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D f_tens[],
                 double tens, double zeta[], double curv[], struct point3D n_mem[], double darea[]);

void	get_axis(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D r_mem_cm, double darea[], struct point3D axis[], double eival[])
;

double get_angle( double x, double y );

// genconf.c

void init_conf(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D v_mem[], double zeta[], double angle, double volume, double surface);

double excentricite_prolate();

double func_ell_prolate( double dum, double e);

double Kellips_prolate(double e);

double excentricite_oblate();

double func_ell_oblate( double dum, double e);

double Kellips_oblate(double e);

double func_sph_oblate( double kk);

double oblate_k( double tau);

void octaedre(int triang_site[NTRIANG][3], struct point3D r_sphere[], int *ntriang, int *nvertex);

void icosaedre(int triang_site[NTRIANG][3], struct point3D r_sphere[], int *ntriang, int *nvertex);

void icosaedre2(int triang_site[NTRIANG][3], struct point3D r_sphere[], int *ntriang, int *nvertex);

void refine(int triang_site[NTRIANG][3], struct point3D r_sphere[], int *ntriang, int *nvertex);

void refine7(int triang_site[NTRIANG2][3], int triang_site0[NTRIANG][3], struct point3D r_sphere[], int ntriang, int nvertex, int slaves[NMEM][NSLA]);

void refine16(int triang_site[NTRIANG2][3], int triang_site2[NTRIANG][3], struct point3D r_sphere[], struct point3D r_sphere2[], int slaves[NMEM][NSLA], int slaves2[NMEM][NSLA2], int Nslaves2[NMEM]);

// vesicle3D.c

void    condlim(int *longt);

int	site_label_mem( int longt, int lat);

int	site_label_wall( int i, int j);

void save_run(char suf[]);

void read_run(char suf[]);

void clear_message(char *argv[]);

void put_message(char message[],char *argv[]);

int stop_the_run();

double xflow(struct point3D r,double time0);

double yflow(struct point3D r,double time0);

double zflow(struct point3D r,double time0);

void euler(double dtime, double eta, double pp, double vol0, double kappa, double grav, int step,double* real_time);

// tank.c

void 	vtank(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D v_mem[], struct point3D n_mem[], double darea[],
          struct point3D *v_mem_cm, struct point3D v_tank[], struct point3D *u, double *omega );

void 	vrot(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D v_mem[], struct point3D n_mem[], double darea[],
          struct point3D *v_mem_cm, struct point3D *r_mem_cm, struct point3D v_rot[], struct point3D *u, double *omega );

void lu(double *d);

void lu_backsub( );

#ifdef use_windows
// graphic.c

void	plot_ves( TB_viewer *view, TB_event *event, int triang_site[NTRIANG][3], struct point r_mem[],struct point v_mem[], int show_frame);

void	plot_map( TB_viewer *view, TB_event *event, int triang_site[NTRIANG][3], struct point r_mem[], double aux[], int show_frame);

void	plot_triang_map( TB_viewer *view, TB_event *event, int triang_site[NTRIANG][3], struct point r_mem[], double aux[], int show_frame);

void	plot_sites( TB_viewer *view, TB_event *event, struct point r_mem[], double aux[]);

void	plot_wall( TB_viewer *view, TB_event *event, struct point r_wall[],struct point v_wall[], int show_frame);

void	alloc_triang(struct point as, struct point bs, struct point cs,
	             struct triangle *triang[], int *ntriang, int *itriang);

struct point  periodic(struct point *r);

void	get_triang(struct point poly[], int *nvertex);

int compare_triangles(int *i1, int *i2);

int compare_sites(int *i1, int *i2);

void init_box();

void draw_box(int top, TB_viewer *view, TB_event *event);

void    init_my_default(struct point *pos, struct point orient[], double dist);
#endif

#ifdef DOPIL
	void VTKdump(char suf[], struct point3D Vertices[], int Facets[NTRIANG][3], double Scalar_Field[], double Scalar_Field2[], double Scalar_Field3[], double Scalar_Field4[], double Scalar_Field5[],double Scalar_Field6[], struct point3D Vector_Field[], struct point3D Vector_Field2[]);
	void VTKdump_2vesicles(char suf[], struct point3D Vertices[], int Facets[NTRIANG][3], double Scalar_Field[], double Scalar_Field2[], double Scalar_Field3[], double Scalar_Field4[], double Scalar_Field5[],double Scalar_Field6[], struct point3D Vector_Field[], struct point3D Vector_Field2[]);
	void VTKdump_ref(char suf[], struct point3D Vertices[], int Facets[NTRIANG][3], double Scalar_Field[]);
#endif

void tabulate_all(struct point3D r_mem[NMEM],struct point3D n_mem[], struct point3D f[], struct point3D v[], int pos, struct point3D vg_tmp[], struct point3D vk_tmp[]);

void NaNcheck(void);

void write_info(void);

void rk2(double dtime, double eta, double pp, double vol0,
           double kappa, double grav, int step,double* real_time);

double get_zeta21(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D v_mem[],
              struct point3D *v_mem_cm, double darea[],
              double dzeta[], double curv[], struct point3D n_mem[],double areatemp,double* dA0, double ref_state[NTRIANG][4], double dtime);

void settau(int triang_site[NTRIANG][3], struct point3D r_mem[], double tau, double radius);
