void interaction_green16(int triang_site[NTRIANG][3], int slaves[NMEM][NSLA], int Nslaves[NMEM], struct point3D r_mem[NMEM], struct point3D r_mem2[NMEM2], struct point3D v_mem0[NMEM][4], struct point3D f_mem[NMEM2][4], struct point3D fdA[NMEM][4], struct point3D fdA2[NMEM2][4], double eta, double pp, struct point3D v_mem_prev[NMEM2], int slaves2[NMEM][NSLA2], int Nslaves2[NMEM], double r_min[NMEM]);

void interaction_green(int triang_site[NTRIANG][3], int slaves[NMEM][NSLA], int Nslaves[NMEM], struct point3D r_mem[NMEM], struct point3D r_mem2[NMEM2], struct point3D v_mem0[NMEM][4], struct point3D fdA[NMEM][4], struct point3D fdA2[NMEM2][4], double eta, double pp, struct point3D v_mem_prev[NMEM], double r_min[NMEM]);

void free_space_green(int triang_site[NTRIANG][3], int slaves[NMEM][NSLA], int Nslaves[NMEM], struct point3D r_mem[NMEM], struct point3D r_mem2[NMEM2], struct point3D v_mem[NMEM][4], struct point3D f_mem[NMEM2][4], struct point3D fdA[NMEM][4], struct point3D fdA2[NMEM2][4], double eta, double pp, double GxndA[NMEM][3][3], struct point3D v_mem_prev[NMEM]);

void prepare_slaves(int triang_site[NTRIANG][3], int neighbours[NMEM][6], int Nneighbours[NMEM], struct point3D r_mem[NMEM], double darea[NTRIANG], double areas[NMEM], struct point3D f_mem[NMEM][4], struct point3D fdA[NMEM][4], struct point3D fdA2[NMEM2][4], double r_max[NMEM]);

void singular_intGn(struct point3D* v0,double Gxn[3][3],struct point3D r0,struct point3D r1,struct point3D r2);
