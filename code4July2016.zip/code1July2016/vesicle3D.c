#include        "includes.h"

int			triang_site[NTRIANG][3];
int			triang_site2[NTRIANG2][3];

struct point3D 		v_mem[NMEM],   f_mem[NMEM2],   r_mem[NMEM], r_mem2[NMEM2], v_mem_cm, r_mem_cm, r_ref[NMEM];

struct point3D 		kr_mem[NMEM],kv_mem[NMEM];
double			zeta[NMEM],kzeta[NMEM],zeta_prev[NMEM];
double			curv[NMEM], gauss[NMEM], lap_curv[NMEM], darea[NTRIANG], area, vol;
double			colors[NMEM], kcolors[NMEM];
struct point3D		n_mem[NMEM];
double			target_area;
double			stress[3][3];
double			stress_prev[3][3];
double			stress_new[3][3];
double			stress_time;
int			Nneighbours[NMEM];
int			neighbours[NMEM][6];
int			neighbour_sites[NMEM][6][2];
int			Nneighbours2[NMEM2];
int			neighbours2[NMEM2][6];
int			neighbour_sites2[NMEM2][6][2];
int			Nslaves[NMEM];
int			slaves[NMEM][NSLA];
int			Nslaves2[NMEM];
int			slaves2[NMEM][NSLA2];
double			zeta2[NMEM2],kzeta2[NMEM2];
double			ref_state[NTRIANG][4];
double		time0;

int main(int argc, char *argv[])
{
	int		i, j, istep, i0_step, ip, im, l0, l1, l2;
	double 		eta, dtime, grav, kappa, shear, surface, volume, vol0, swel,temp0;
	double		real_time;
	char		suf[100], message[600];
	double		theta, pp, aux[NMEM], eival[3],curv0[NMEM];
	struct point3D	force_wall, force_mem, tau, axis[3],points[6],r_mem2temp[NMEM2];
	struct point3D	pos, v, r01, r02;
	double		t_min, t_max, rr, r_min, r_max, aa, a_min, a_max, vv, v_min, v_max, energ;
	int		imem, jmem, nremesh;
	FILE*		fp;

	volume  = 4.0*PI * RAD*RAD*RAD/3.0;
	surface = pow(6.0 * sqrt(PI) * volume / TAU, 2.0/3.0 );

	target_area =0.0;
	shear  = C_CURV/T_CURV;
	grav   = GRAV;
	eta    = (C_GRAV==0 || shear==0.0)?1.0:C_GRAV*GRAV*RAD/shear;
	kappa  = eta*pow(RAD,3.0)/T_CURV;
	pp     = VISC_RATIO;

	dtime = DT;
	nremesh = T_REMESH;
	real_time=0.0;



	if (GENCONF) {
#ifdef	STRESSFREE_SPHERE
		init_conf(triang_site,r_mem,v_mem,zeta,0.0,1.0,1.0);
#else
		init_conf(triang_site,r_mem,v_mem,zeta,0.0,TAU,1.0);// changed TAU to 1.0
#endif
                
		for(i=0;i<NMEM;i++){
/*			temp0=r_mem[i].x;
			r_mem[i].x=r_mem[i].z;
			r_mem[i].z=r_mem[i].y;
			r_mem[i].y=temp0;*/
			r_mem[i].x+=INITIAL_X0;
			r_mem[i].y+=INITIAL_Y0;
			r_mem[i].z+=INITIAL_Z0;
		}
		clear_message(argv);
		i0_step = 0;
                
	}
	else{
		sprintf(suf,"%d",RUNPREV);
		read_run(suf);
		for(i=0;i<NMEM;i++){
			temp0=r_mem[i].x;
			r_mem[i].x=r_mem[i].y;
			r_mem[i].y=r_mem[i].z;
			r_mem[i].z=temp0;   // Commented these 4 lines - Madhav - 19 March 2015, Uncommented 4 June 2015
//Commented lines again: 26 June 2015; Uncommented for calculations with initial conditions that Alexandr provided 6 July 2015; Commented again 7 July 2015                      
 			r_mem[i].x+=SHIFT_X0;
			r_mem[i].y+=SHIFT_Y0;
			r_mem[i].z+=SHIFT_Z0;
	/*		if(r_mem[i].x>0) zeta[i]+=1000.0;
			else zeta[i]-=1000.0;*/
		}
		
                printf("Made it here\n");
                settau(triang_site,r_mem,TAU,RAD);
		i0_step = RUNPREV;
		if (i0_step==0) clear_message(argv);
		j=0;
		temp0=0.0;
		for(i=0;i<NMEM;i++){
			if(r_mem[i].z>temp0){
				temp0=r_mem[i].z;
				j=i;
			}
		}
		printf("%d %f\n",j,temp0);
		j=0;
		temp0=0.0;
		for(i=0;i<NMEM;i++){
			if(r_mem[i].z<temp0){
				temp0=r_mem[i].z;
				j=i;
			}
		}
		printf("%d %f\n",j,temp0);
	}
	for(i=0;i<NMEM;i++) kzeta[i]=zeta_prev[i]=0.0;
	for(i=0;i<NMEM2;i++) zeta2[i]=0.0;
	for(i=0;i<3;i++) for(j=0;j<3;j++) stress[i][j]=stress_prev[i][j]=stress_new[i][j]=stress_time=0.0;
//	refine7(triang_site2,triang_site,r_mem2,NTRIANG,NMEM,slaves);
       printf("About to enter refine16\n");
	refine16(triang_site,triang_site2,r_mem,r_mem2,slaves,slaves2,Nslaves2);
       // printf("Finished refine16\n");
/*	for(i=0;i<NMEM;i++){
		rr=1.0/sqrt(r_mem[i].x*r_mem[i].x+r_mem[i].y*r_mem[i].y+r_mem[i].z*r_mem[i].z);
		r_mem[i].x*=(5.0*rr);
		r_mem[i].y*=rr;
		r_mem[i].z*=rr;
	}*/
printf("Made it here\n");
//  volume and area computation
	find_neighbours(triang_site,Nneighbours,neighbours,neighbour_sites);
	find_neighbours2(triang_site2,Nneighbours2,neighbours2,neighbour_sites2);
       
/*	for(i=0;i<NMEM;i++){
		for(j=0;j<Nneighbours[i];j++){
			zeta2[slaves[i][j+1]]=1.0;
			zeta2[slaves[i][2*j+7]]=2.0;
			zeta2[slaves[i][2*j+8]]=2.0;
		}
	}*/
	geom(triang_site,r_mem,v_mem,n_mem,&v_mem_cm,&r_mem_cm,&area,&vol0,darea);
	temp0=sqrt(4.0*PI/pow(TAU,2.0/3.0)/area);
	for(i=0;i<NMEM;i++){
		r_ref[i].x=r_mem[i].x*temp0;
		r_ref[i].y=r_mem[i].y*temp0;
		r_ref[i].z=r_mem[i].z*temp0;
	}
	for(i=0;i<NTRIANG;i++){
		l0=triang_site[i][0];
		l1=triang_site[i][1];
		l2=triang_site[i][2];
		sub3D(&r01,r_ref[l1],r_ref[l0]);
		sub3D(&r02,r_ref[l2],r_ref[l0]);

		ref_state[i][0]=DotProduct3D(r01,r01);
		ref_state[i][1]=DotProduct3D(r02,r02);
		ref_state[i][2]=DotProduct3D(r01,r02);
		ref_state[i][3]=darea[i]/area;
	}
#ifdef STRESSFREE_SPHERE
	settau(triang_site,r_mem,TAU,RAD);//added to set the reduced volume after the reference configuration is saved, Alexander
#endif
//	printf("Made it to beginning of get_axis\n");
        vol0=volume;
	get_axis(triang_site,r_mem,r_mem_cm,darea,axis,eival);
//   	get_curv(triang_site,r_mem,n_mem,darea,cn_mem,curv,gauss,lap_curv);
//	new_get_force(triang_site,r_mem,n_mem,curv,gauss,lap_curv,zeta,f_mem,kappa,0.0,curv,f_mem);
//	outwarder(r_mem,triang_site,n_mem);
//	new_get_force(triang_site,r_mem,n_mem,curv,gauss,lap_curv,zeta,f_mem,kappa,tens,curv,f_mem);
	for(i=0;i<NMEM;i++) colors[i]=r_mem[i].x;
    //fprintf(stderr," area %e, volume %e\n",area,vol0);
	time0=0.0;
//        printf("Made it to beginning of euler\n");
	for (istep=i0_step+1;istep<=NSTEP;istep++) {
		euler(dtime,eta,pp,vol0,kappa,grav,istep,&real_time);
/*Added Print statement printf("made it here\n"); */
		NaNcheck();
		energ = 0.0;
		for (i=0;i<NTRIANG;i++) {
			l0 = triang_site[i][0];
			l1 = triang_site[i][1];
			l2 = triang_site[i][2];
			aa = darea[i];
			energ += (curv[l0]*curv[l0]+curv[l1]*curv[l1]+curv[l2]*curv[l2])*aa/3.0;
		}
		fp=fopen("energy.dat","a+");
		fprintf(fp,"%f\n",energ);
		fclose(fp);
		rescale(triang_site,r_mem,v_mem,r_mem_cm,zeta,vol0,vol);
		find_angle(r_mem,r_mem_cm);
		if(istep%T_STRESS==0){
			fp=fopen("stress.dat","a+");
			fprintf(fp,"%f",real_time);
			for(i=0;i<3;i++) for(j=0;j<3;j++) fprintf(fp,"\t%f",0.5*stress[i][j]/stress_time);
			fprintf(fp,"\n");
			fclose(fp);
			stress_time=0.0;
			for(i=0;i<3;i++) for(j=0;j<3;j++) stress[i][j]=0.0;
			a_min=a_max=-1.0;
			for(i=0;i<NMEM;i++) {
				if(fabs(r_mem[i].z)>a_min) a_min=fabs(r_mem[i].z);
				if(fabs(r_mem[i].x)>a_max) a_max=fabs(r_mem[i].x);
			}
			fp=fopen("projection.dat","a+");
			fprintf(fp,"%f\t%f\t%f\n",real_time,a_max,a_min);
			fclose(fp);
		}
		if (istep!=1 && istep%nremesh==1) {
//			new_get_force(triang_site,r_mem,n_mem,curv,gauss,lap_curv,zeta,f_mem,kappa,0.0,curv,f_mem);
//			outwarder(r_mem,triang_site,n_mem);
//			VTKdump("normal",r_mem,triang_site,zeta,curv,gauss,colors,lap_curv,n_mem,f_mem);
		}

		if (istep%NPRINT==0) {

//          compute CM position of the particle

			get_axis(triang_site,r_mem,r_mem_cm,darea,axis,eival);

			if (axis[0].x<0.0) {
				axis[0].x = - axis[0].x;
				axis[0].y = - axis[0].y;
				axis[0].z = - axis[0].z;
			}
            //theta = sqrt(axis[0].y*axis[0].y+axis[0].z*axis[0].z);
			theta = get_angle(axis[0].x,axis[0].y)*180.0/3.14159265358;

			a_min = r_min = t_min = v_min = 1.e+10;
			a_max = r_max = t_max = v_max =-1.e+10;

			for (i=0;i<NMEM;i++) {
				rr = sqrt(pow(r_mem[i].x-r_mem_cm.x,2.0)+pow(r_mem[i].y-r_mem_cm.y,2.0)+pow(r_mem[i].z-r_mem_cm.z,2.0));
				vv = sqrt(pow(v_mem[i].x-v_mem_cm.x,2.0)+pow(v_mem[i].y-v_mem_cm.y,2.0)+pow(v_mem[i].z-v_mem_cm.z,2.0));
				if (r_max<rr) r_max = rr;
				if (r_min>rr) r_min = rr;
				if (v_max<vv) v_max = vv;
				if (v_min>vv) v_min = vv;
				if (t_max<zeta[i]) t_max = zeta[i];
				if (t_min>zeta[i]) t_min = zeta[i];
			}

			energ = 0.0;
			for (i=0;i<NTRIANG;i++) {

				l0 = triang_site[i][0];
				l1 = triang_site[i][1];
				l2 = triang_site[i][2];

				aa = darea[i];
				if (a_max<aa) a_max = aa;
				if (a_min>aa) a_min = aa;
	
				energ += (curv[l0]*curv[l0]+curv[l1]*curv[l1]+curv[l2]*curv[l2])*aa/3.0;
			}

			sprintf(message," time %e: step %d area = %e volume = %e r_min = %e r_max = %e angle = %e tau = %e l1 = %e l2 = %e l3 = %e t_min = %e t_max = %e a_min = %e a_max = %e v_min = %e v_max = %e energ = %e\n",
		real_time,istep,area,vol,r_min,r_max,theta,6.0*sqrt(PI)*vol/pow(area,1.5),eival[0],eival[1],eival[2],t_min,t_max,a_min,a_max,v_min,v_max,energ);
			printf("%f\t%f\t%f\t%f\t%f\t%f\n",r_mem_cm.x,r_mem_cm.y,r_mem_cm.z,v_mem_cm.x,v_mem_cm.y,v_mem_cm.z);
			fp=fopen("vm.dat","a+");
			fprintf(fp,"%f\t%f\t%f\t%f\t%f\t%f\n",r_mem_cm.x,r_mem_cm.y,r_mem_cm.z,v_mem_cm.x,v_mem_cm.y,v_mem_cm.z);
			fclose(fp);
			put_message(message,argv);

		}

        	if (istep%NSAVE==0 || stop_the_run()){
			sprintf(suf,"%d",istep);
			save_run(suf);
			if (stop_the_run()) exit(0);

		}
	}
	return 0;
}
/*END main */


void    condlim(int *longt)
{
    if (*longt < 0) *longt = NLONG - ( (- *longt) % NLONG );
    *longt = *longt % NLONG;
}
/* END condlim */

int	site_label_mem( int longt, int lat)
{
    condlim(&longt);
    if (lat==0) return 0;
    if (lat==NLAT-1) return (NLAT-2)*NLONG+1;
    else return 1+(lat-1)*NLONG + longt;
}
/*END site_label_mem */

int	site_label_wall( int i, int j)
{
    return j*NX + i;
}
/*END site_label_wall */




void save_run(char suf[])
{
	FILE*	fp;
	char	file[100];
	int	i;

	write_info();
	sprintf(file,"mem_%s",suf);
	fp = fopen(file,"w");

	for (i=0;i<NMEM;i++) {
		fprintf(fp,"%18.12e %18.12e %18.12e %18.12e %18.12e %18.12e %18.12e %18.12e %18.12e %18.12e\n",
			r_mem[i].x,r_mem[i].y,r_mem[i].z,
			f_mem[i].x,f_mem[i].y,f_mem[i].z,
			v_mem[i].x,v_mem[i].y,v_mem[i].z,zeta[i]);

	}
	fclose(fp);

	sprintf(file,"triang_%s",suf);
	fp = fopen(file,"w");

	for (i=0;i<NTRIANG;i++) fprintf(fp,"%d %d %d\n",triang_site[i][0],triang_site[i][1],triang_site[i][2]);
	fclose(fp);
}
/*END save_run */

void read_run(char suf[])
{
	FILE        	*fp;
	char		file[100];
	int		i, j, label,fret;
	double		dum;

	sprintf(file,"mem_%s",suf);
	fp = fopen(file,"r");
	if(fp==NULL) {
		printf("file not found: mem_%s\n",suf);
		exit(0);
	}
	for (i=0;i<NMEM;i++) {
		fret=fscanf(fp,"%lf %lf %lf %lf %lf %lf %lf %lf %lf %lf\n",
			&r_mem[i].x,&r_mem[i].y,&r_mem[i].z,
			&f_mem[i].x,&f_mem[i].y,&f_mem[i].z,
			&v_mem[i].x,&v_mem[i].y,&v_mem[i].z,&zeta[i]);
		if(fret==EOF){
			printf("not enough lines in mem_%s file: got %d wanted %d\n",suf,i+1,NMEM);
			fclose(fp);
			exit(0);
		}
//		r_mem[i].y*=0.26;
	}
	while((fret = fgetc(fp)) != EOF) if(fret == '\n') i++;
	if(i>NMEM){
		printf("too many lines in mem_%s file: got %d wanted %d\n",suf,i,NMEM);
		fclose(fp);
		exit(0);
	}
	fclose(fp);
	sprintf(file,"triang_%s",suf);
	fp = fopen(file,"r");
	if(fp==NULL) {
		printf("file not found: triang_%s\n",suf);
		exit(0);
	}
	for (i=0;i<NTRIANG;i++){
		fret=fscanf(fp,"%d %d %d\n",&triang_site[i][0],&triang_site[i][1],&triang_site[i][2]);
		if(fret==EOF){
			printf("not enough lines in triang_%s file: got %d wanted %d\n",suf,i+1,NTRIANG);
			fclose(fp);
			exit(0);
		}
	}
	while((fret = fgetc(fp)) != EOF) if(fret == '\n') i++;
	if(i>NTRIANG){
		printf("too many lines in mem_%s file: got %d wanted %d\n",suf,i,NTRIANG);
		fclose(fp);
		exit(0);
	}
	fclose(fp);
}
/*END read_run */




void clear_message(char *argv[])
{
    FILE		*fp;
    char		file[100];

    sprintf(file,"%s.errs",argv[0]);
    fp = fopen(file,"w");
    fclose(fp);
}
/*END clear_message */

void put_message(char message[],char *argv[])
{
    FILE		*fp;
    char		file[100];

    sprintf(file,"%s.errs",argv[0]);
    fp = fopen(file,"a+");
    fprintf(fp,"%s",message);
    fclose(fp);
}
/*END put_message */

int stop_the_run()
{
    FILE		*fp;
    char		file[10];

    sprintf(file,"stop");
    fp = fopen(file,"r");
    if ( fp == NULL) return 0;
    else return 1;

}
/*END stop_the_run */

/*double xflow(struct point3D r, double shear)
{
	int k;
	double tret,k21;
	tret=0.0;
	for(k=0;k<20;k++){
		k21=2.0*(double)k+1.0;
		if(k%2) tret-=(1.0-cosh(k21*PI*r.z/8.0)/cosh(k21*PI/2.0))*cos(k21*PI*r.y/8.0)/(k21*k21*k21);
		else tret+=(1.0-cosh(k21*PI*r.z/8.0)/cosh(k21*PI/2.0))*cos(k21*PI*r.y/8.0)/(k21*k21*k21);
	}
	tret*=2700.0;
   return tret;
}*/


double xflow(struct point3D r,double time0)
{
   return XFLOW;//-shear*r.x;//- 0.5*shear*r.y;
//	 return 10.0*r.y;
}
/*END xflow */

double yflow(struct point3D r,double time0)
{
//	return -0.0*r.x;
//	 return 0.0*r.y;
    return YFLOW;//-shear*r.x;//- 0.5*shear*r.y;
//   return 1.0*((r.x+10.0)*(r.x+10.0)+r.z*r.z);//-shear*r.x;//- 0.5*shear*r.y;
//   return 41.91*(r.x*r.x+r.z*r.z);//-shear*r.x;//- 0.5*shear*r.y;
}
/*END yflow */

double zflow(struct point3D r,double time0)
{
	 return ZFLOW;

//    return -r.z/(r.x*r.x+r.y*r.y+r.z*r.z); //shear*(r.y*r.y);//- 0.5*shear*r.z;
}
/*END zflow */

void euler(double dtime, double eta, double pp, double vol0,
           double kappa, double grav, int step,double* real_time)
{
    int		i,j;
	double temp0;
#ifdef DOPIL
	char suf[80];
#endif
#ifdef NO_MIGRATION
	struct point3D new_v_cm3;
	int l0;
	double area0,temp;
#endif
    //    printf("About to enter new_val\n");

    new_val(triang_site,triang_site2,&dtime,r_mem,r_mem2,kr_mem,zeta,zeta2,colors,kzeta,kzeta2,kcolors,v_mem,f_mem,&v_mem_cm,&r_mem_cm,
                  n_mem,curv,gauss,lap_curv,darea,eta,pp,kappa,
                  grav,&area,&vol,step,kv_mem,&target_area,Nneighbours,neighbours,neighbour_sites,Nneighbours2,neighbours2,neighbour_sites2,slaves,slaves2,Nslaves2,ref_state,&time0,step,r_ref);
//        printf("got through new_val\n");
	get_stress(r_mem,triang_site,f_mem,n_mem,v_mem,stress_new,darea);
	for(i=0;i<3;i++) for(j=0;j<3;j++) {
		stress[i][j]+=(stress_new[i][j]+stress_prev[i][j])*dtime;
		stress_prev[i][j]=stress_new[i][j];
	}
	stress_time+=dtime;
#ifdef DOPIL
	if (step%NSAVE==0 || stop_the_run()){
		sprintf(suf,"%d",step);
#if defined INTERACTION
		VTKdump_2vesicles(suf,r_mem,triang_site,zeta,curv,gauss,lap_curv,colors,kzeta,v_mem,f_mem);
//		VTKdump_ref(suf,r_mem2,triang_site2,zeta2);
#else
		for(i=0;i<NMEM;i++){
			temp0=DotProduct3D(v_mem[i],n_mem[i]);
			f_mem[i].x=v_mem[i].x-temp0*n_mem[i].x;
			f_mem[i].y=v_mem[i].y-temp0*n_mem[i].y;
			f_mem[i].z=v_mem[i].z-temp0*n_mem[i].z;
		}
		VTKdump(suf,r_mem,triang_site,zeta,curv,gauss,lap_curv,colors,kzeta,v_mem,f_mem);
//		VTKdump("test",r_mem,triang_site,zeta,curv,gauss,lap_curv,colors,kzeta,kr_mem,f_mem);
		VTKflow(suf,10,0.0,0.4,r_mem_cm.x,time0);
//		VTKdump_ref(suf,r_mem2,triang_site2,zeta2);
#endif
	}
#endif
	for (i=0;i<NMEM;i++) {
/*		r_mem[i].x += kr_mem[i].x;
		r_mem[i].y += kr_mem[i].y;
		r_mem[i].z += kr_mem[i].z;
		v_mem[i].x += kv_mem[i].x;
		v_mem[i].y += kv_mem[i].y;
		v_mem[i].z += kv_mem[i].z;*/
		colors[i] +=kcolors[i];

	}
	*real_time+=dtime;

#ifdef NO_MIGRATION
	new_v_cm3.x=0.0;
	new_v_cm3.y=0.0;
	new_v_cm3.z=0.0;
	area0=0.0;
	for (i=0;i<NTRIANG;i++){
			l0=triang_site[i][0];
			new_v_cm3.x+=r_mem[l0].x*darea[i];
			new_v_cm3.y+=r_mem[l0].y*darea[i];
			new_v_cm3.z+=r_mem[l0].z*darea[i];
			l0=triang_site[i][1];
			new_v_cm3.x+=r_mem[l0].x*darea[i];
			new_v_cm3.y+=r_mem[l0].y*darea[i];
			new_v_cm3.z+=r_mem[l0].z*darea[i];
			l0=triang_site[i][2];
			new_v_cm3.x+=r_mem[l0].x*darea[i];
			new_v_cm3.y+=r_mem[l0].y*darea[i];
			new_v_cm3.z+=r_mem[l0].z*darea[i];
			area0+=darea[i];
	}
	new_v_cm3.x/=(area0*3.0);
	new_v_cm3.y/=(area0*3.0);
	new_v_cm3.z/=(area0*3.0);
//	printf("vmx=%f vmy=%f vmz=%f\n",new_v_cm3.x/dtime,new_v_cm3.y/dtime,new_v_cm3.z/dtime);
	for (i=0;i<NMEM;i++)	{
		r_mem[i].x-=new_v_cm3.x;
		r_mem[i].y-=new_v_cm3.y;
		r_mem[i].z-=new_v_cm3.z;
	}
#endif
}
/* END euler*/


/*void rk2(double dtime, double eta, double pp, double vol0,
           double kappa, double grav, int step,double* real_time)
{
    int		i,j;
	struct point3D r_temp[NMEM];
	double c_temp[NMEM];
	struct point3D v_temp[NMEM];
	double dtime2;
#ifdef DOPIL
	char suf[80];
#endif
#ifdef NO_MIGRATION
	struct point3D new_v_cm3;
	int l0;
	double area0,temp;
#endif
	dtime2=0.5*dtime;
	new_val(triang_site,&dtime2,r_mem,kr_mem,zeta,colors,kzeta,kcolors,v_mem,f_mem,&v_mem_cm,&r_mem_cm,
                  n_mem,curv,gauss,lap_curv,darea,eta,pp,kappa,
                  grav,&area,&vol,step,kv_mem,&target_area,Nneighbours,neighbours,neighbour_sites);
	if(dtime2==0.5*dtime){
		for(i=0;i<NMEM;i++){
			r_temp[i].x = r_mem[i].x + kr_mem[i].x;
			r_temp[i].y = r_mem[i].y + kr_mem[i].y;
			r_temp[i].z = r_mem[i].z + kr_mem[i].z;
			v_temp[i].x = v_mem[i].x + kv_mem[i].x;
			v_temp[i].y = v_mem[i].y + kv_mem[i].y;
			v_temp[i].z = v_mem[i].z + kv_mem[i].z;
			c_temp[i] = colors[i] + kcolors[i];
		}
		new_val(triang_site,&dtime,r_temp,kr_mem,zeta,c_temp,kzeta,kcolors,v_temp,f_mem,&v_mem_cm,&r_mem_cm,
                  n_mem,curv,gauss,lap_curv,darea,eta,pp,kappa,
                  grav,&area,&vol,step,kv_mem,&target_area,Nneighbours,neighbours,neighbour_sites);
	}
	get_stress(r_mem,triang_site,f_mem,n_mem,v_mem,stress_new,darea);
	for(i=0;i<3;i++) for(j=0;j<3;j++) {
		stress[i][j]+=(stress_new[i][j]+stress_prev[i][j])*dtime;
		stress_prev[i][j]=stress_new[i][j];
	}
	stress_time+=dtime;
#ifdef DOPIL
	if (step%NSAVE==0 || stop_the_run()){
		sprintf(suf,"%d",step);
#if defined INTERACTION
		VTKdump_2vesicles(suf,r_mem,triang_site,zeta,curv,gauss,lap_curv,colors,kzeta,v_mem,f_mem);
#else
		VTKdump(suf,r_mem,triang_site,zeta,curv,gauss,lap_curv,colors,kzeta,v_mem,f_mem);
#endif
	}
#endif
	for (i=0;i<NMEM;i++) {
		r_mem[i].x += kr_mem[i].x;
		r_mem[i].y += kr_mem[i].y;
		r_mem[i].z += kr_mem[i].z;
		v_mem[i].x += kv_mem[i].x;
		v_mem[i].y += kv_mem[i].y;
		v_mem[i].z += kv_mem[i].z;
		colors[i] +=kcolors[i];

	}
	*real_time+=dtime;

#ifdef NO_MIGRATION
	new_v_cm3.x=0.0;
	new_v_cm3.y=0.0;
	new_v_cm3.z=0.0;
	area0=0.0;
	for (i=0;i<NTRIANG;i++){
			l0=triang_site[i][0];
			new_v_cm3.x+=r_mem[l0].x*darea[i];
			new_v_cm3.y+=r_mem[l0].y*darea[i];
			new_v_cm3.z+=r_mem[l0].z*darea[i];
			l0=triang_site[i][1];
			new_v_cm3.x+=r_mem[l0].x*darea[i];
			new_v_cm3.y+=r_mem[l0].y*darea[i];
			new_v_cm3.z+=r_mem[l0].z*darea[i];
			l0=triang_site[i][2];
			new_v_cm3.x+=r_mem[l0].x*darea[i];
			new_v_cm3.y+=r_mem[l0].y*darea[i];
			new_v_cm3.z+=r_mem[l0].z*darea[i];
			area0+=darea[i];
	}
	new_v_cm3.x/=(area0*3.0);
	new_v_cm3.y/=(area0*3.0);
	new_v_cm3.z/=(area0*3.0);
	for (i=0;i<NMEM;i++)	{
		r_mem[i].x-=new_v_cm3.x;
		r_mem[i].y-=new_v_cm3.y;
		r_mem[i].z-=new_v_cm3.z;
	}
#endif
}*/

void NaNcheck(void){
	int i;
	for(i=0;i<NMEM;i++){
		if(isnan(zeta[i])){
			printf("NaN in tension\n");
			exit(0);
		}
		if(isnan(r_mem[i].x) || isnan(r_mem[i].y) || isnan(r_mem[i].z)){
			printf("NaN in vertices\n");
			exit(0);
		}
	}
}
/*END NaNcheck */
#define QUOTE(name) #name
#define STR(macro) QUOTE(macro)


void write_info(void){
	FILE* fp;
	fp=fopen("!info.txt","w");
	fprintf(fp,INFO_STRING);
	fprintf(fp,"tau=%f, lambda=%f\n",TAU,VISC_RATIO);
	fprintf(fp,"NELL=%d, NMEM=%d, NTRIANG=%d, time step=%.2e\n",NELL,NMEM,NTRIANG,DT);
	fprintf(fp,"vx=%s\n",STR(XFLOW));
	fprintf(fp,"vy=%s\n",STR(YFLOW));
	fprintf(fp,"vz=%s\n",STR(ZFLOW));
	fclose(fp);
}
/* END write_info*/
