#include	"includes.h"




void geom(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D v_mem[], struct point3D n_mem[],
          struct point3D *v_mem_cm, struct point3D *r_mem_cm, double *area, double *vol, double darea[])
{
    int			i, j, l0, l1, l2;
    double		dvol, dsurf, norm, hight;
    struct point3D	r_cm, v_cm, n, r01, r02, r, norml[NTRIANG];

    *vol = *area = r_cm.x = r_cm.y = r_cm.z = v_cm.x = v_cm.y = v_cm.z = 0.0;

    for (i=0;i<NMEM;i++) n_mem[i].x = n_mem[i].y = n_mem[i].z = 0.0;


    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        r01.x = r_mem[l1].x - r_mem[l0].x;
        r01.y = r_mem[l1].y - r_mem[l0].y;
        r01.z = r_mem[l1].z - r_mem[l0].z;

        r02.x = r_mem[l2].x - r_mem[l0].x;
        r02.y = r_mem[l2].y - r_mem[l0].y;
        r02.z = r_mem[l2].z - r_mem[l0].z;

        r.x = r01.y*r02.z - r01.z*r02.y;
        r.y = r01.z*r02.x - r01.x*r02.z;
        r.z = r01.x*r02.y - r01.y*r02.x;

        norm = sqrt(r.x*r.x + r.y*r.y + r.z*r.z);
        dsurf = 0.5*norm;

        r.x = r.x / norm;
        r.y = r.y / norm;
        r.z = r.z / norm;

        n_mem[l0].x += r.x;
        n_mem[l0].y += r.y;
        n_mem[l0].z += r.z;

        n_mem[l1].x += r.x;
        n_mem[l1].y += r.y;
        n_mem[l1].z += r.z;

        n_mem[l2].x += r.x;
        n_mem[l2].y += r.y;
        n_mem[l2].z += r.z;

        norml[i] = r;

        darea[i] = dsurf;

        *area   += dsurf;
        r_cm.x += dsurf*( r_mem[l0].x + r_mem[l1].x + r_mem[l2].x )/3.0;
        r_cm.y += dsurf*( r_mem[l0].y + r_mem[l1].y + r_mem[l2].y )/3.0;
        r_cm.z += dsurf*( r_mem[l0].z + r_mem[l1].z + r_mem[l2].z )/3.0;

        v_cm.x += dsurf*( v_mem[l0].x + v_mem[l1].x + v_mem[l2].x )/3.0;
        v_cm.y += dsurf*( v_mem[l0].y + v_mem[l1].y + v_mem[l2].y )/3.0;
        v_cm.z += dsurf*( v_mem[l0].z + v_mem[l1].z + v_mem[l2].z )/3.0;

    }

    r_mem_cm->x = r_cm.x / *area;
    r_mem_cm->y = r_cm.y / *area;
    r_mem_cm->z = r_cm.z / *area;

    v_mem_cm->x = v_cm.x / *area;
    v_mem_cm->y = v_cm.y / *area;
    v_mem_cm->z = v_cm.z / *area;

    // normal vector at a site

    for (i=0;i<NMEM;i++) {
        norm = sqrt(n_mem[i].x*n_mem[i].x + n_mem[i].y*n_mem[i].y + n_mem[i].z*n_mem[i].z);
        if (norm<1.e-6) {
            fprintf(stderr,"probleme dans le calcul du vecteur normal\n");
            exit(0);
        }
        else {
            n_mem[i].x = n_mem[i].x / norm;
            n_mem[i].y = n_mem[i].y / norm;
            n_mem[i].z = n_mem[i].z / norm;
        }
 /*       r_cm.x = r_mem[i].x - r_mem_cm->x;
        r_cm.y = r_mem[i].y - r_mem_cm->y;
        r_cm.z = r_mem[i].z - r_mem_cm->z;
        if (r_cm.x*n_mem[i].x+r_cm.y*n_mem[i].y+r_cm.z*n_mem[i].z<0.0) {
            n_mem[i].x = -n_mem[i].x;
            n_mem[i].y = -n_mem[i].y;
            n_mem[i].z = -n_mem[i].z;
        }*/
    }


    // volume computation

    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        r_cm.x = r_mem[l0].x - r_mem_cm->x;
        r_cm.y = r_mem[l0].y - r_mem_cm->y;
        r_cm.z = r_mem[l0].z - r_mem_cm->z;

        hight = norml[i].x * r_cm.x + norml[i].y * r_cm.y + norml[i].z * r_cm.z;
        dvol = darea[i] * hight/3.0;

        *vol   += dvol;

    }

}
/*END geom*/


void get_curv(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double darea[],
              struct point3D cn_mem[], double curv[], double gauss[], double lap_curv[])
{
    int                 i, j, l0, l1, l2, imem;
    double		norm, angle[NMEM], area[NMEM], lap_curv1[NMEM];
    struct point3D      k_curv[NMEM],temp[NMEM],gradnx[NMEM],gradny[NMEM],gradnz[NMEM];
	 int Nneighbours[NMEM];
	 int neighbours[NMEM][6];
	 struct point3D points[6];
	 double da[6];
    for (i=0;i<NMEM;i++)
        angle[i] = area[i] = k_curv[i].x = k_curv[i].y = k_curv[i].z = 0.0;


    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        geom_triangle(r_mem[l0],r_mem[l1],r_mem[l2],&k_curv[l0],&area[l0],&angle[l0],darea[i]);
        geom_triangle(r_mem[l1],r_mem[l2],r_mem[l0],&k_curv[l1],&area[l1],&angle[l1],darea[i]);
        geom_triangle(r_mem[l2],r_mem[l0],r_mem[l1],&k_curv[l2],&area[l2],&angle[l2],darea[i]);

    }

    for (imem=0;imem<NMEM;imem++) {

        norm = sqrt(k_curv[imem].x*k_curv[imem].x + k_curv[imem].y*k_curv[imem].y + k_curv[imem].z*k_curv[imem].z);

        cn_mem[imem].x = 0.5*k_curv[imem].x/area[imem];
        cn_mem[imem].y = 0.5*k_curv[imem].y/area[imem];
        cn_mem[imem].z = 0.5*k_curv[imem].z/area[imem];

        curv[imem] = 0.5*norm/area[imem];
        if ((k_curv[imem].x*n_mem[imem].x + k_curv[imem].y*n_mem[imem].y + k_curv[imem].z*n_mem[imem].z)>0.0) curv[imem] = - curv[imem];
        gauss[imem] = (2.0*PI - angle[imem])/area[imem];

    }


//  laplacien de la courbure

/*    for (i=0;i<NMEM;i++) angle[i] = area[i] = 0.0;


    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        beltrami(r_mem[l0],r_mem[l1],r_mem[l2],curv[l0],curv[l1],curv[l2],&angle[l0],&area[l0],darea[i]);
        beltrami(r_mem[l1],r_mem[l2],r_mem[l0],curv[l1],curv[l2],curv[l0],&angle[l1],&area[l1],darea[i]);
        beltrami(r_mem[l2],r_mem[l0],r_mem[l1],curv[l2],curv[l0],curv[l1],&angle[l2],&area[l2],darea[i]);

    }*/

    for (imem=0;imem<NMEM;imem++) lap_curv[imem] = angle[imem]/area[imem];
/*    vec_grad2Dx(gradnx,n_mem,triang_site,r_mem,n_mem,darea);
    for(i=0;i<NMEM;i++)curv[i]=gradnx[i].x;
    vec_grad2Dy(gradny,n_mem,triang_site,r_mem,n_mem,darea);
    for(i=0;i<NMEM;i++)curv[i]+=gradny[i].y;
    vec_grad2Dz(gradnz,n_mem,triang_site,r_mem,n_mem,darea);
    for(i=0;i<NMEM;i++)curv[i]+=gradnz[i].z;
    for(i=0;i<NMEM;i++){
		  curv[i]*=-0.5;
		  gauss[i]=gradnx[i].x*gradny[i].y+gradny[i].y*gradnz[i].z+gradnz[i].z*gradnx[i].x-0.25*((gradnx[i].y+gradny[i].x)*(gradnx[i].y+gradny[i].x)+(gradny[i].z+gradnz[i].y)*(gradny[i].z+gradnz[i].y)+(gradnz[i].x+gradnx[i].z)*(gradnz[i].x+gradnx[i].z));
	 }*/
	 for(i=0;i<NMEM;i++) Nneighbours[i]=0;
	 for(i=0;i<NTRIANG;i++){
        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];
		  for(j=0;j<Nneighbours[l0];j++) if(neighbours[l0][j]==l1) break;
		  if(j==Nneighbours[l0]){
				neighbours[l0][j]=l1;
				Nneighbours[l0]++;
		  }
		  for(j=0;j<Nneighbours[l0];j++) if(neighbours[l0][j]==l2) break;
		  if(j==Nneighbours[l0]){
				neighbours[l0][j]=l2;
				Nneighbours[l0]++;
		  }

		  for(j=0;j<Nneighbours[l1];j++) if(neighbours[l1][j]==l2) break;
		  if(j==Nneighbours[l1]){
				neighbours[l1][j]=l2;
				Nneighbours[l1]++;
		  }
		  for(j=0;j<Nneighbours[l1];j++) if(neighbours[l1][j]==l0) break;
		  if(j==Nneighbours[l1]){
				neighbours[l1][j]=l0;
				Nneighbours[l1]++;
		  }
		  for(j=0;j<Nneighbours[l2];j++) if(neighbours[l2][j]==l0) break;
		  if(j==Nneighbours[l2]){
				neighbours[l2][j]=l0;
				Nneighbours[l2]++;
		  }
		  for(j=0;j<Nneighbours[l2];j++) if(neighbours[l2][j]==l1) break;
		  if(j==Nneighbours[l2]){
				neighbours[l2][j]=l1;
				Nneighbours[l2]++;
		  }
	 }
	 for(i=0;i<NMEM;i++){
		  for(j=0;j<Nneighbours[i];j++){
				points[j].x=r_mem[neighbours[i][j]].x-r_mem[i].x;
				points[j].y=r_mem[neighbours[i][j]].y-r_mem[i].y;
				points[j].z=r_mem[neighbours[i][j]].z-r_mem[i].z;
		  }
		 quadratic_interpolator(Nneighbours[i],points,&n_mem[i],&curv[i],&gauss[i]);
// 		 printf("%d\t%f\t%f\t%f\t%f\n",i,curv1[i],curv[i],gauss1[i],gauss[i]);
	 }
	 for(i=0;i<NMEM;i++){
		  for(j=0;j<Nneighbours[i];j++){
				points[j].x=r_mem[neighbours[i][j]].x-r_mem[i].x;
				points[j].y=r_mem[neighbours[i][j]].y-r_mem[i].y;
				points[j].z=r_mem[neighbours[i][j]].z-r_mem[i].z;
				da[j]=curv[neighbours[i][j]]-curv[i];
		  }
		 new_surface_laplacian(Nneighbours[i],points,da,&n_mem[i],&lap_curv[i]);
		 new_surface_gradient(Nneighbours[i],points,da,&n_mem[i],&gradnx[i]);
// 		 printf("%d\t%f\t%f\t%f\t%f\n",i,curv1[i],curv[i],gauss1[i],gauss[i]);
	 }

/*	 for(i=0;i<NMEM;i++){
		  for(j=0;j<Nneighbours[i];j++){
				points[j].x=r_mem[neighbours[i][j]].x-r_mem[i].x;
				points[j].y=r_mem[neighbours[i][j]].y-r_mem[i].y;
				points[j].z=r_mem[neighbours[i][j]].z-r_mem[i].z;
				da[j]=curv[neighbours[i][j]]-curv[i];
		  }
		 new_surface_gradient(Nneighbours[i],points,da,&n_mem[i],&temp[i]);
// 		 printf("%d\t%f\t%f\t%f\t%f\n",i,curv1[i],curv[i],gauss1[i],gauss[i]);
	 }
	 for(i=0;i<NMEM;i++){
		  for(j=0;j<Nneighbours[i];j++){
				points[j].x=r_mem[neighbours[i][j]].x-r_mem[i].x;
				points[j].y=r_mem[neighbours[i][j]].y-r_mem[i].y;
				points[j].z=r_mem[neighbours[i][j]].z-r_mem[i].z;
				da[j]=temp[neighbours[i][j]].x-temp[i].x;
		  }
		 new_surface_gradient(Nneighbours[i],points,da,&n_mem[i],&gradnx[i]);
// 		 printf("%d\t%f\t%f\t%f\t%f\n",i,curv1[i],curv[i],gauss1[i],gauss[i]);
	 }
    for(i=0;i<NMEM;i++)lap_curv[i]=gradnx[i].x;
	 for(i=0;i<NMEM;i++){
		  for(j=0;j<Nneighbours[i];j++){
				points[j].x=r_mem[neighbours[i][j]].x-r_mem[i].x;
				points[j].y=r_mem[neighbours[i][j]].y-r_mem[i].y;
				points[j].z=r_mem[neighbours[i][j]].z-r_mem[i].z;
				da[j]=temp[neighbours[i][j]].y-temp[i].y;
		  }
		 new_surface_gradient(Nneighbours[i],points,da,&n_mem[i],&gradnx[i]);
// 		 printf("%d\t%f\t%f\t%f\t%f\n",i,curv1[i],curv[i],gauss1[i],gauss[i]);
	 }
    for(i=0;i<NMEM;i++)lap_curv[i]+=gradnx[i].y;
	 for(i=0;i<NMEM;i++){
		  for(j=0;j<Nneighbours[i];j++){
				points[j].x=r_mem[neighbours[i][j]].x-r_mem[i].x;
				points[j].y=r_mem[neighbours[i][j]].y-r_mem[i].y;
				points[j].z=r_mem[neighbours[i][j]].z-r_mem[i].z;
				da[j]=temp[neighbours[i][j]].z-temp[i].z;
		  }
		 new_surface_gradient(Nneighbours[i],points,da,&n_mem[i],&gradnx[i]);
// 		 printf("%d\t%f\t%f\t%f\t%f\n",i,curv1[i],curv[i],gauss1[i],gauss[i]);
	 }
    for(i=0;i<NMEM;i++)lap_curv[i]+=gradnx[i].z;*/

/*    for (i=0;i<NMEM;i++) angle[i] = area[i] = 0.0;


    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        beltrami(r_mem[l0],r_mem[l1],r_mem[l2],curv[l0],curv[l1],curv[l2],&angle[l0],&area[l0],darea[i]);
        beltrami(r_mem[l1],r_mem[l2],r_mem[l0],curv[l1],curv[l2],curv[l0],&angle[l1],&area[l1],darea[i]);
        beltrami(r_mem[l2],r_mem[l0],r_mem[l1],curv[l2],curv[l0],curv[l1],&angle[l2],&area[l2],darea[i]);

    }
    for (imem=0;imem<NMEM;imem++) lap_curv[imem] = angle[imem]/area[imem];*/

/*	 scal_grad2D(temp,curv,triang_site,r_mem,n_mem,darea);
    vec_grad2Dx(gradnx,temp,triang_site,r_mem,n_mem,darea);
    for(i=0;i<NMEM;i++)lap_curv[i]=gradnx[i].x;
    vec_grad2Dy(gradny,temp,triang_site,r_mem,n_mem,darea);
    for(i=0;i<NMEM;i++)lap_curv[i]+=gradny[i].y;
    vec_grad2Dz(gradnz,temp,triang_site,r_mem,n_mem,darea);
    for(i=0;i<NMEM;i++)lap_curv[i]+=gradnz[i].z;*/
//	 scal_grad2D(gradny,curv,triang_site,r_mem,n_mem,darea);
//	 VTKdump("lap",r_mem,triang_site,lap_curv,curv,gauss,lap_curv1,gradny,gradnx);
//	 VTKdump("gauss",r_mem,triang_site,gauss,n_mem,n_mem);
//	 VTKdump("curv1",r_mem,triang_site,lap_curv1,n_mem,n_mem);
//	 VTKdump("gauss1",r_mem,triang_site,gauss1,n_mem,n_mem);
}
/*END get_curv*/

void geom_triangle(struct point3D r0, struct point3D r1, struct point3D r2,
                   struct point3D *k_sum, double *s_sum, double *gauss_sum, double area)
{
    struct point3D	n, r01, r02, r12;
    double		norm, rn01, rn02, rn12, alpha, beta, gamma, cobeta, cogamma;

    double 		tiny=1.e-10;

    r01.x = r1.x-r0.x;
    r01.y = r1.y-r0.y;
    r01.z = r1.z-r0.z;

    r02.x = r2.x-r0.x;
    r02.y = r2.y-r0.y;
    r02.z = r2.z-r0.z;

    r12.x = r2.x-r1.x;
    r12.y = r2.y-r1.y;
    r12.z = r2.z-r1.z;

    rn01 = sqrt(r01.x*r01.x + r01.y*r01.y + r01.z*r01.z);
    if (rn01<tiny) { fprintf(stderr,"triangle skipped\n"); return;}
    rn02 = sqrt(r02.x*r02.x + r02.y*r02.y + r02.z*r02.z);
    if (rn02<tiny) { fprintf(stderr,"triangle skipped\n"); return;}
    rn12 = sqrt(r12.x*r12.x + r12.y*r12.y + r12.z*r12.z);
    if (rn12<tiny) { fprintf(stderr,"triangle skipped\n"); return;}

    alpha = (r01.x*r02.x + r01.y*r02.y + r01.z*r02.z)/(rn01*rn02);
    alpha = acos(alpha);

    cobeta  = -(r01.x*r12.x + r01.y*r12.y + r01.z*r12.z)/(rn01*rn12);
    beta  = acos(cobeta);

    cogamma = (r12.x*r02.x + r12.y*r02.y + r12.z*r02.z)/(rn12*rn02);
    gamma = acos(cogamma);

    cobeta  = cobeta/sin(beta);
    cogamma = cogamma/sin(gamma);

    k_sum->x += - 0.5*(cobeta * r02.x + cogamma * r01.x);
    k_sum->y += - 0.5*(cobeta * r02.y + cogamma * r01.y);
    k_sum->z += - 0.5*(cobeta * r02.z + cogamma * r01.z);

    *s_sum += area/3.0;

    *gauss_sum += alpha;

}
/*END geom_triangle*/






void beltrami(struct point3D r0, struct point3D r1, struct point3D r2, double a0, double a1, double a2,
                   double *lap, double *s_sum, double area)
{
    struct point3D	n, r01, r02, r12;
    double		norm, rn01, rn02, rn12, alpha, beta, gamma, cobeta, cogamma;

    double 		tiny=1.e-10;

    r01.x = r1.x-r0.x;
    r01.y = r1.y-r0.y;
    r01.z = r1.z-r0.z;

    r02.x = r2.x-r0.x;
    r02.y = r2.y-r0.y;
    r02.z = r2.z-r0.z;

    r12.x = r2.x-r1.x;
    r12.y = r2.y-r1.y;
    r12.z = r2.z-r1.z;

    rn01 = sqrt(r01.x*r01.x + r01.y*r01.y + r01.z*r01.z);
    if (rn01<tiny) return;
    rn02 = sqrt(r02.x*r02.x + r02.y*r02.y + r02.z*r02.z);
    if (rn02<tiny) return;
    rn12 = sqrt(r12.x*r12.x + r12.y*r12.y + r12.z*r12.z);
    if (rn12<tiny) return;

    alpha = (r01.x*r02.x + r01.y*r02.y + r01.z*r02.z)/(rn01*rn02);
    alpha = acos(alpha);

    cobeta  = -(r01.x*r12.x + r01.y*r12.y + r01.z*r12.z)/(rn01*rn12);
    beta  = acos(cobeta);

    cogamma = (r12.x*r02.x + r12.y*r02.y + r12.z*r02.z)/(rn12*rn02);
    gamma = acos(cogamma);

    cobeta  = cobeta/sin(beta);
    cogamma = cogamma/sin(gamma);

    *s_sum += area/3.0;
    *lap += 0.5*(cobeta*(a2-a0) + cogamma*(a1-a0));

}
/*END beltrami*/




void grad2D(struct point3D r0, struct point3D r1, struct point3D r2, double a0, double a1, double a2,
                   struct point3D *grad, double *s_sum, double area)
{
    struct point3D	n, r01, r02, r12;
    double		norm, rn01, rn02, rn12, scal12, alpha, beta, gamma, cobeta, cogamma;

    double 		tiny=1.e-10;

    r01.x = r1.x-r0.x;
    r01.y = r1.y-r0.y;
    r01.z = r1.z-r0.z;

    r02.x = r2.x-r0.x;
    r02.y = r2.y-r0.y;
    r02.z = r2.z-r0.z;

    r12.x = r2.x-r1.x;
    r12.y = r2.y-r1.y;
    r12.z = r2.z-r1.z;

    rn01 = sqrt(r01.x*r01.x + r01.y*r01.y + r01.z*r01.z);
    if (rn01<tiny) return;
    rn02 = sqrt(r02.x*r02.x + r02.y*r02.y + r02.z*r02.z);
    if (rn02<tiny) return;
    rn12 = sqrt(r12.x*r12.x + r12.y*r12.y + r12.z*r12.z);
    if (rn12<tiny) return;

    *s_sum += area/3.0;

    scal12 = r01.x*r02.x + r01.y*r02.y + r01.z*r02.z;
    norm   = area/3.0/(rn01*rn01 * rn02*rn02 - scal12*scal12);
    grad->x += ( (a1-a0)*(rn02*rn02 * r01.x - scal12 * r02.x) + (a2-a0)*(rn01*rn01 * r02.x - scal12 * r01.x) )*norm;
    grad->y += ( (a1-a0)*(rn02*rn02 * r01.y - scal12 * r02.y) + (a2-a0)*(rn01*rn01 * r02.y - scal12 * r01.y) )*norm;
    grad->z += ( (a1-a0)*(rn02*rn02 * r01.z - scal12 * r02.z) + (a2-a0)*(rn01*rn01 * r02.z - scal12 * r01.z) )*norm;


}
/*END grad2D*/


void scal_grad2D(struct point3D grad[], double a[], int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double darea[])
{
    int				i, l0, l1, l2;
    double			area[NMEM], tmp_area;
    struct point3D		tmp_grad, smooth_grad[NMEM];

    for (i=0;i<NMEM;i++) area[i] = grad[i].x = grad[i].y = grad[i].z = 0.0;

    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        tmp_grad.x = tmp_grad.y = tmp_grad.z = tmp_area = 0.0;
        grad2D(r_mem[l0],r_mem[l1],r_mem[l2],a[l0],a[l1],a[l2],
                &tmp_grad,&tmp_area,darea[i]);

        grad[l0].x += tmp_grad.x;
        grad[l0].y += tmp_grad.y;
        grad[l0].z += tmp_grad.z;

        grad[l1].x += tmp_grad.x;
        grad[l1].y += tmp_grad.y;
        grad[l1].z += tmp_grad.z;

        grad[l2].x += tmp_grad.x;
        grad[l2].y += tmp_grad.y;
        grad[l2].z += tmp_grad.z;

        area[l0] += tmp_area;
        area[l1] += tmp_area;
        area[l2] += tmp_area;


    }
    for (i=0;i<NMEM;i++) {

        grad[i].x = grad[i].x/area[i];
        grad[i].y = grad[i].y/area[i];
        grad[i].z = grad[i].z/area[i];

        smooth_grad[i].x = smooth_grad[i].y = smooth_grad[i].z = area[i] =  0.0;

    }

/*
    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        tmp_grad.x = (grad[l0].x+(grad[l1].x+grad[l2].x)/6.0)*0.75;
        tmp_grad.y = (grad[l0].y+(grad[l1].y+grad[l2].y)/6.0)*0.75;
        tmp_grad.z = (grad[l0].z+(grad[l1].z+grad[l2].z)/6.0)*0.75;
        smooth_grad[l0].x += tmp_grad.x;
        smooth_grad[l0].y += tmp_grad.y;
        smooth_grad[l0].z += tmp_grad.z;

        tmp_grad.x = (grad[l1].x+(grad[l0].x+grad[l2].x)/6.0)*0.75;
        tmp_grad.y = (grad[l1].y+(grad[l0].y+grad[l2].y)/6.0)*0.75;
        tmp_grad.z = (grad[l1].z+(grad[l0].z+grad[l2].z)/6.0)*0.75;
        smooth_grad[l1].x += tmp_grad.x;
        smooth_grad[l1].y += tmp_grad.y;
        smooth_grad[l1].z += tmp_grad.z;

        tmp_grad.x = (grad[l2].x+(grad[l1].x+grad[l0].x)/6.0)*0.75;
        tmp_grad.y = (grad[l2].y+(grad[l1].y+grad[l0].y)/6.0)*0.75;
        tmp_grad.z = (grad[l2].z+(grad[l1].z+grad[l0].z)/6.0)*0.75;
        smooth_grad[l2].x += tmp_grad.x;
        smooth_grad[l2].y += tmp_grad.y;
        smooth_grad[l2].z += tmp_grad.z;

        area[l0] += 1.0;
        area[l1] += 1.0;
        area[l2] += 1.0;

    }
    for (i=0;i<NMEM;i++) {

        grad[i].x = smooth_grad[i].x/area[i];
        grad[i].y = smooth_grad[i].y/area[i];
        grad[i].z = smooth_grad[i].z/area[i];

    }
*/
}
/*END scal_grad2D*/

void vec_grad2Dx(struct point3D grad[], struct point3D vec[], int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double darea[])
{
    int				i, l0, l1, l2;
    double			area[NMEM], tmp_area;
    struct point3D		tmp_grad, smooth_grad[NMEM];

    for (i=0;i<NMEM;i++) area[i] = grad[i].x = grad[i].y = grad[i].z = 0.0;

    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        tmp_grad.x = tmp_grad.y = tmp_grad.z = tmp_area = 0.0;
        grad2D(r_mem[l0],r_mem[l1],r_mem[l2],vec[l0].x,vec[l1].x,vec[l2].x,
                &tmp_grad,&tmp_area,darea[i]);

        grad[l0].x += tmp_grad.x;
        grad[l0].y += tmp_grad.y;
        grad[l0].z += tmp_grad.z;

        grad[l1].x += tmp_grad.x;
        grad[l1].y += tmp_grad.y;
        grad[l1].z += tmp_grad.z;

        grad[l2].x += tmp_grad.x;
        grad[l2].y += tmp_grad.y;
        grad[l2].z += tmp_grad.z;

        area[l0] += tmp_area;
        area[l1] += tmp_area;
        area[l2] += tmp_area;


    }
    for (i=0;i<NMEM;i++) {

        grad[i].x = grad[i].x/area[i];
        grad[i].y = grad[i].y/area[i];
        grad[i].z = grad[i].z/area[i];

        smooth_grad[i].x = smooth_grad[i].y = smooth_grad[i].z = area[i] =  0.0;

    }

/*
    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        tmp_grad.x = (grad[l0].x+(grad[l1].x+grad[l2].x)/6.0)*0.75;
        tmp_grad.y = (grad[l0].y+(grad[l1].y+grad[l2].y)/6.0)*0.75;
        tmp_grad.z = (grad[l0].z+(grad[l1].z+grad[l2].z)/6.0)*0.75;
        smooth_grad[l0].x += tmp_grad.x;
        smooth_grad[l0].y += tmp_grad.y;
        smooth_grad[l0].z += tmp_grad.z;

        tmp_grad.x = (grad[l1].x+(grad[l0].x+grad[l2].x)/6.0)*0.75;
        tmp_grad.y = (grad[l1].y+(grad[l0].y+grad[l2].y)/6.0)*0.75;
        tmp_grad.z = (grad[l1].z+(grad[l0].z+grad[l2].z)/6.0)*0.75;
        smooth_grad[l1].x += tmp_grad.x;
        smooth_grad[l1].y += tmp_grad.y;
        smooth_grad[l1].z += tmp_grad.z;

        tmp_grad.x = (grad[l2].x+(grad[l1].x+grad[l0].x)/6.0)*0.75;
        tmp_grad.y = (grad[l2].y+(grad[l1].y+grad[l0].y)/6.0)*0.75;
        tmp_grad.z = (grad[l2].z+(grad[l1].z+grad[l0].z)/6.0)*0.75;
        smooth_grad[l2].x += tmp_grad.x;
        smooth_grad[l2].y += tmp_grad.y;
        smooth_grad[l2].z += tmp_grad.z;

        area[l0] += 1.0;
        area[l1] += 1.0;
        area[l2] += 1.0;

    }
    for (i=0;i<NMEM;i++) {

        grad[i].x = smooth_grad[i].x/area[i];
        grad[i].y = smooth_grad[i].y/area[i];
        grad[i].z = smooth_grad[i].z/area[i];

    }
*/
}


void vec_grad2Dy(struct point3D grad[], struct point3D vec[], int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double darea[])
{
    int				i, l0, l1, l2;
    double			area[NMEM], tmp_area;
    struct point3D		tmp_grad, smooth_grad[NMEM];

    for (i=0;i<NMEM;i++) area[i] = grad[i].x = grad[i].y = grad[i].z = 0.0;

    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        tmp_grad.x = tmp_grad.y = tmp_grad.z = tmp_area = 0.0;
        grad2D(r_mem[l0],r_mem[l1],r_mem[l2],vec[l0].y,vec[l1].y,vec[l2].y,
                &tmp_grad,&tmp_area,darea[i]);

        grad[l0].x += tmp_grad.x;
        grad[l0].y += tmp_grad.y;
        grad[l0].z += tmp_grad.z;

        grad[l1].x += tmp_grad.x;
        grad[l1].y += tmp_grad.y;
        grad[l1].z += tmp_grad.z;

        grad[l2].x += tmp_grad.x;
        grad[l2].y += tmp_grad.y;
        grad[l2].z += tmp_grad.z;

        area[l0] += tmp_area;
        area[l1] += tmp_area;
        area[l2] += tmp_area;


    }
    for (i=0;i<NMEM;i++) {

        grad[i].x = grad[i].x/area[i];
        grad[i].y = grad[i].y/area[i];
        grad[i].z = grad[i].z/area[i];

        smooth_grad[i].x = smooth_grad[i].y = smooth_grad[i].z = area[i] =  0.0;

    }

/*
    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        tmp_grad.x = (grad[l0].x+(grad[l1].x+grad[l2].x)/6.0)*0.75;
        tmp_grad.y = (grad[l0].y+(grad[l1].y+grad[l2].y)/6.0)*0.75;
        tmp_grad.z = (grad[l0].z+(grad[l1].z+grad[l2].z)/6.0)*0.75;
        smooth_grad[l0].x += tmp_grad.x;
        smooth_grad[l0].y += tmp_grad.y;
        smooth_grad[l0].z += tmp_grad.z;

        tmp_grad.x = (grad[l1].x+(grad[l0].x+grad[l2].x)/6.0)*0.75;
        tmp_grad.y = (grad[l1].y+(grad[l0].y+grad[l2].y)/6.0)*0.75;
        tmp_grad.z = (grad[l1].z+(grad[l0].z+grad[l2].z)/6.0)*0.75;
        smooth_grad[l1].x += tmp_grad.x;
        smooth_grad[l1].y += tmp_grad.y;
        smooth_grad[l1].z += tmp_grad.z;

        tmp_grad.x = (grad[l2].x+(grad[l1].x+grad[l0].x)/6.0)*0.75;
        tmp_grad.y = (grad[l2].y+(grad[l1].y+grad[l0].y)/6.0)*0.75;
        tmp_grad.z = (grad[l2].z+(grad[l1].z+grad[l0].z)/6.0)*0.75;
        smooth_grad[l2].x += tmp_grad.x;
        smooth_grad[l2].y += tmp_grad.y;
        smooth_grad[l2].z += tmp_grad.z;

        area[l0] += 1.0;
        area[l1] += 1.0;
        area[l2] += 1.0;

    }
    for (i=0;i<NMEM;i++) {

        grad[i].x = smooth_grad[i].x/area[i];
        grad[i].y = smooth_grad[i].y/area[i];
        grad[i].z = smooth_grad[i].z/area[i];

    }
*/
}



void vec_grad2Dz(struct point3D grad[], struct point3D vec[], int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double darea[])
{
    int				i, l0, l1, l2;
    double			area[NMEM], tmp_area;
    struct point3D		tmp_grad, smooth_grad[NMEM];

    for (i=0;i<NMEM;i++) area[i] = grad[i].x = grad[i].y = grad[i].z = 0.0;

    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        tmp_grad.x = tmp_grad.y = tmp_grad.z = tmp_area = 0.0;
        grad2D(r_mem[l0],r_mem[l1],r_mem[l2],vec[l0].z,vec[l1].z,vec[l2].z,
                &tmp_grad,&tmp_area,darea[i]);

        grad[l0].x += tmp_grad.x;
        grad[l0].y += tmp_grad.y;
        grad[l0].z += tmp_grad.z;

        grad[l1].x += tmp_grad.x;
        grad[l1].y += tmp_grad.y;
        grad[l1].z += tmp_grad.z;

        grad[l2].x += tmp_grad.x;
        grad[l2].y += tmp_grad.y;
        grad[l2].z += tmp_grad.z;

        area[l0] += tmp_area;
        area[l1] += tmp_area;
        area[l2] += tmp_area;


    }
    for (i=0;i<NMEM;i++) {

        grad[i].x = grad[i].x/area[i];
        grad[i].y = grad[i].y/area[i];
        grad[i].z = grad[i].z/area[i];

        smooth_grad[i].x = smooth_grad[i].y = smooth_grad[i].z = area[i] =  0.0;

    }
/*
    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        tmp_grad.x = (grad[l0].x+(grad[l1].x+grad[l2].x)/6.0)*0.75;
        tmp_grad.y = (grad[l0].y+(grad[l1].y+grad[l2].y)/6.0)*0.75;
        tmp_grad.z = (grad[l0].z+(grad[l1].z+grad[l2].z)/6.0)*0.75;
        smooth_grad[l0].x += tmp_grad.x;
        smooth_grad[l0].y += tmp_grad.y;
        smooth_grad[l0].z += tmp_grad.z;

        tmp_grad.x = (grad[l1].x+(grad[l0].x+grad[l2].x)/6.0)*0.75;
        tmp_grad.y = (grad[l1].y+(grad[l0].y+grad[l2].y)/6.0)*0.75;
        tmp_grad.z = (grad[l1].z+(grad[l0].z+grad[l2].z)/6.0)*0.75;
        smooth_grad[l1].x += tmp_grad.x;
        smooth_grad[l1].y += tmp_grad.y;
        smooth_grad[l1].z += tmp_grad.z;

        tmp_grad.x = (grad[l2].x+(grad[l1].x+grad[l0].x)/6.0)*0.75;
        tmp_grad.y = (grad[l2].y+(grad[l1].y+grad[l0].y)/6.0)*0.75;
        tmp_grad.z = (grad[l2].z+(grad[l1].z+grad[l0].z)/6.0)*0.75;
        smooth_grad[l2].x += tmp_grad.x;
        smooth_grad[l2].y += tmp_grad.y;
        smooth_grad[l2].z += tmp_grad.z;

        area[l0] += 1.0;
        area[l1] += 1.0;
        area[l2] += 1.0;

    }
    for (i=0;i<NMEM;i++) {

        grad[i].x = smooth_grad[i].x/area[i];
        grad[i].y = smooth_grad[i].y/area[i];
        grad[i].z = smooth_grad[i].z/area[i];

    }
*/
}

void vgrad2D(struct point3D v[], struct point3D vgrad[], struct point3D vec[], int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double darea[])
{
    int				i, l0, l1, l2;
    double			area[NMEM], tmp_area;
    struct point3D		gradx, grady, gradz, smooth_grad[NMEM], rcm;

    for (i=0;i<NMEM;i++) area[i] = vgrad[i].x = vgrad[i].y = vgrad[i].z = 0.0;

    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        gradx.x = gradx.y = gradx.z = tmp_area = 0.0;
        grad2D(r_mem[l0],r_mem[l1],r_mem[l2],vec[l0].x,vec[l1].x,vec[l2].x,
                &gradx,&tmp_area,darea[i]);

        grady.x = grady.y = grady.z = tmp_area = 0.0;
        grad2D(r_mem[l0],r_mem[l1],r_mem[l2],vec[l0].y,vec[l1].y,vec[l2].y,
                &grady,&tmp_area,darea[i]);

        gradz.x = gradz.y = gradz.z = tmp_area = 0.0;
        grad2D(r_mem[l0],r_mem[l1],r_mem[l2],vec[l0].z,vec[l1].z,vec[l2].z,
                &gradz,&tmp_area,darea[i]);
/*
        rcm.x = (r_mem[l1].x + r_mem[l2].x - 2.0*r_mem[l0].x)/3.0;
        rcm.y = (r_mem[l1].y + r_mem[l2].y - 2.0*r_mem[l0].y)/3.0;
        rcm.z = (r_mem[l1].z + r_mem[l2].z - 2.0*r_mem[l0].z)/3.0;

        if (rcm.x*v[l0].x + rcm.y*v[l0].y + rcm.z*v[l0].z < 1.0) {*/
            vgrad[l0].x += v[l0].x*gradx.x + v[l0].y*gradx.y + v[l0].z*gradx.z;
            vgrad[l0].y += v[l0].x*grady.x + v[l0].y*grady.y + v[l0].z*grady.z;
            vgrad[l0].z += v[l0].x*gradz.x + v[l0].y*gradz.y + v[l0].z*gradz.z;
            area[l0] += tmp_area;
/*        }

        rcm.x = (r_mem[l0].x + r_mem[l2].x - 2.0*r_mem[l1].x)/3.0;
        rcm.y = (r_mem[l0].y + r_mem[l2].y - 2.0*r_mem[l1].y)/3.0;
        rcm.z = (r_mem[l0].z + r_mem[l2].z - 2.0*r_mem[l1].z)/3.0;

        if (rcm.x*v[l1].x + rcm.y*v[l1].y + rcm.z*v[l1].z < 1.0) {*/
            vgrad[l1].x += v[l1].x*gradx.x + v[l1].y*gradx.y + v[l1].z*gradx.z;
            vgrad[l1].y += v[l1].x*grady.x + v[l1].y*grady.y + v[l1].z*grady.z;
            vgrad[l1].z += v[l1].x*gradz.x + v[l1].y*gradz.y + v[l1].z*gradz.z;
            area[l1] += tmp_area;
/*        }

        rcm.x = (r_mem[l0].x + r_mem[l1].x - 2.0*r_mem[l2].x)/3.0;
        rcm.y = (r_mem[l0].y + r_mem[l1].y - 2.0*r_mem[l2].y)/3.0;
        rcm.z = (r_mem[l0].z + r_mem[l1].z - 2.0*r_mem[l2].z)/3.0;

        if (rcm.x*v[l2].x + rcm.y*v[l2].y + rcm.z*v[l2].z < 1.0) {*/
            vgrad[l2].x += v[l2].x*gradx.x + v[l2].y*gradx.y + v[l2].z*gradx.z;
            vgrad[l2].y += v[l2].x*grady.x + v[l2].y*grady.y + v[l2].z*grady.z;
            vgrad[l2].z += v[l2].x*gradz.x + v[l2].y*gradz.y + v[l2].z*gradz.z;
            area[l2] += tmp_area;
       // }


    }
    for (i=0;i<NMEM;i++) {

        vgrad[i].x = vgrad[i].x/area[i];
        vgrad[i].y = vgrad[i].y/area[i];
        vgrad[i].z = vgrad[i].z/area[i];

    }

}


void vgrad2D_scal(struct point3D v[], double vgrad[], double a[], int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double darea[])
{
    int				i, l0, l1, l2;
    double			area[NMEM], tmp_area;
    struct point3D		grad, rcm;

    for (i=0;i<NMEM;i++) area[i] = vgrad[i] = 0.0;

    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        grad.x = grad.y = grad.z = tmp_area = 0.0;
        grad2D(r_mem[l0],r_mem[l1],r_mem[l2],a[l0],a[l1],a[l2],
                &grad,&tmp_area,darea[i]);
/*
        rcm.x = (r_mem[l1].x + r_mem[l2].x - 2.0*r_mem[l0].x)/3.0;
        rcm.y = (r_mem[l1].y + r_mem[l2].y - 2.0*r_mem[l0].y)/3.0;
        rcm.z = (r_mem[l1].z + r_mem[l2].z - 2.0*r_mem[l0].z)/3.0;

        if (rcm.x*v[l0].x + rcm.y*v[l0].y + rcm.z*v[l0].z < 1.0) {*/
            vgrad[l0] += v[l0].x*grad.x + v[l0].y*grad.y + v[l0].z*grad.z;
            area[l0] += tmp_area;
/*        }

        rcm.x = (r_mem[l0].x + r_mem[l2].x - 2.0*r_mem[l1].x)/3.0;
        rcm.y = (r_mem[l0].y + r_mem[l2].y - 2.0*r_mem[l1].y)/3.0;
        rcm.z = (r_mem[l0].z + r_mem[l2].z - 2.0*r_mem[l1].z)/3.0;

        if (rcm.x*v[l1].x + rcm.y*v[l1].y + rcm.z*v[l1].z < 1.0) {*/
            vgrad[l1] += v[l1].x*grad.x + v[l1].y*grad.y + v[l1].z*grad.z;
            area[l1] += tmp_area;
/*        }

        rcm.x = (r_mem[l0].x + r_mem[l1].x - 2.0*r_mem[l2].x)/3.0;
        rcm.y = (r_mem[l0].y + r_mem[l1].y - 2.0*r_mem[l2].y)/3.0;
        rcm.z = (r_mem[l0].z + r_mem[l1].z - 2.0*r_mem[l2].z)/3.0;

        if (rcm.x*v[l2].x + rcm.y*v[l2].y + rcm.z*v[l2].z < 1.0) {*/
            vgrad[l2] += v[l2].x*grad.x + v[l2].y*grad.y + v[l2].z*grad.z;
            area[l2] += tmp_area;
       // }


    }
    for (i=0;i<NMEM;i++) vgrad[i] = vgrad[i]/area[i];

}


void smooth( struct point3D vec[], int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double darea[])
{
    int				i, l0, l1, l2;
    double			area[NMEM];
    struct point3D              tmp, smooth[NMEM];

    for (i=0;i<NMEM;i++) smooth[i].x = smooth[i].y = smooth[i].z = area[i] = 0.0;

    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        tmp.x = (vec[l0].x+(vec[l1].x+vec[l2].x)/6.0)*0.75;
        tmp.y = (vec[l0].y+(vec[l1].y+vec[l2].y)/6.0)*0.75;
        tmp.z = (vec[l0].z+(vec[l1].z+vec[l2].z)/6.0)*0.75;
        smooth[l0].x += tmp.x;
        smooth[l0].y += tmp.y;
        smooth[l0].z += tmp.z;

        tmp.x = (vec[l1].x+(vec[l0].x+vec[l2].x)/6.0)*0.75;
        tmp.y = (vec[l1].y+(vec[l0].y+vec[l2].y)/6.0)*0.75;
        tmp.z = (vec[l1].z+(vec[l0].z+vec[l2].z)/6.0)*0.75;
        smooth[l1].x += tmp.x;
        smooth[l1].y += tmp.y;
        smooth[l1].z += tmp.z;

        tmp.x = (vec[l2].x+(vec[l1].x+vec[l0].x)/6.0)*0.75;
        tmp.y = (vec[l2].y+(vec[l1].y+vec[l0].y)/6.0)*0.75;
        tmp.z = (vec[l2].z+(vec[l1].z+vec[l0].z)/6.0)*0.75;
        smooth[l2].x += tmp.x;
        smooth[l2].y += tmp.y;
        smooth[l2].z += tmp.z;

        area[l0] += 1.0;
        area[l1] += 1.0;
        area[l2] += 1.0;

    }
    for (i=0;i<NMEM;i++) {

        vec[i].x = smooth[i].x/area[i];
        vec[i].y = smooth[i].y/area[i];
        vec[i].z = smooth[i].z/area[i];

    }



}


void dtriangle_area(struct point3D r0, struct point3D r1, struct point3D r2, struct point3D v0, struct point3D v1, struct point3D v2,
                   double *delta_area, double dtime)
{
    struct point3D	n, r01, r02, v01, v02, tmp, tmp1;
    double		norm;

    r01.x = r1.x-r0.x;
    r01.y = r1.y-r0.y;
    r01.z = r1.z-r0.z;

    r02.x = r2.x-r0.x;
    r02.y = r2.y-r0.y;
    r02.z = r2.z-r0.z;

    v01.x = v1.x-v0.x;
    v01.y = v1.y-v0.y;
    v01.z = v1.z-v0.z;

    v02.x = v2.x-v0.x;
    v02.y = v2.y-v0.y;
    v02.z = v2.z-v0.z;

    tmp.x = r01.y*r02.z - r01.z*r02.y;
    tmp.y = r01.z*r02.x - r01.x*r02.z;
    tmp.z = r01.x*r02.y - r01.y*r02.x;

    norm = sqrt(tmp.x*tmp.x + tmp.y*tmp.y + tmp.z*tmp.z);

    tmp.x += (v01.y*r02.z - v01.z*r02.y + r01.y*v02.z - r01.z*v02.y) * dtime;
    tmp.y += (v01.z*r02.x - v01.x*r02.z + r01.z*v02.x - r01.x*v02.z) * dtime;
    tmp.z += (v01.x*r02.y - v01.y*r02.x + r01.x*v02.y - r01.y*v02.x) * dtime;

    *delta_area = 0.5*(sqrt(tmp.x*tmp.x + tmp.y*tmp.y + tmp.z*tmp.z) - norm)/dtime;

}

void dtriangle_area2(struct point3D r0, struct point3D r1, struct point3D r2, struct point3D v0, struct point3D v1, struct point3D v2,
                   double *delta_area)
{
/*    struct point3D	n, r01, r02, v01, v02, tmp, tmp1;
    double		norm;

    r01.x = r1.x-r0.x;
    r01.y = r1.y-r0.y;
    r01.z = r1.z-r0.z;

    r02.x = r2.x-r0.x;
    r02.y = r2.y-r0.y;
    r02.z = r2.z-r0.z;

    v01.x = v1.x-v0.x;
    v01.y = v1.y-v0.y;
    v01.z = v1.z-v0.z;

    v02.x = v2.x-v0.x;
    v02.y = v2.y-v0.y;
    v02.z = v2.z-v0.z;

    tmp.x = r01.y*r02.z - r01.z*r02.y;
    tmp.y = r01.z*r02.x - r01.x*r02.z;
    tmp.z = r01.x*r02.y - r01.y*r02.x;

    norm = sqrt(tmp.x*tmp.x + tmp.y*tmp.y + tmp.z*tmp.z);

    tmp1.x = (v01.y*r02.z - v01.z*r02.y + r01.y*v02.z - r01.z*v02.y);
    tmp1.y = (v01.z*r02.x - v01.x*r02.z + r01.z*v02.x - r01.x*v02.z);
    tmp1.z = (v01.x*r02.y - v01.y*r02.x + r01.x*v02.y - r01.y*v02.x);

    *delta_area = 0.5*(tmp.x*tmp1.x+tmp.y*tmp1.y+tmp.z*tmp1.z);*/
	
	struct point3D triangle_normal,r01,r12,r20,vtemp;
	double triangle_area;
	sub3D(&r01,r1,r0);
	sub3D(&r12,r2,r1);
	sub3D(&r20,r0,r2);
	CrossProduct3D(&triangle_normal,r12,r01);
	triangle_area=sqrt(DotProduct3D(triangle_normal,triangle_normal));
	smul3D2(&triangle_normal,0.5/triangle_area);
	CrossProduct3D(&vtemp,triangle_normal,r12);
	*delta_area=DotProduct3D(v0,vtemp);
	CrossProduct3D(&vtemp,triangle_normal,r20);
	*delta_area+=DotProduct3D(v1,vtemp);
	CrossProduct3D(&vtemp,triangle_normal,r01);
	*delta_area+=DotProduct3D(v2,vtemp);


}





double get_zeta(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D v_mem[],
              struct point3D *v_mem_cm, double darea[],
              double dzeta[], double curv[], struct point3D n_mem[], double dtime)
{
    int			i, j, l0, l1, l2;
    double		area[NMEM], delta_area,dzeta0 ;
    struct point3D      v0, v1, v2;


  for (i=0;i<NMEM;i++) dzeta[i] = area[i] = 0.0;

    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        dtriangle_area(r_mem[l0],r_mem[l1],r_mem[l2],v_mem[l0],v_mem[l1],v_mem[l2],&delta_area,dtime);

        dzeta[l0] += delta_area;
        dzeta[l1] += delta_area;
        dzeta[l2] += delta_area;

        area[l0] += darea[i];
        area[l1] += darea[i];
        area[l2] += darea[i];

/*
        dzeta[l0] += delta_area/darea[i];
        dzeta[l1] += delta_area/darea[i];
        dzeta[l2] += delta_area/darea[i];

        area[l0] += 1.0;
        area[l1] += 1.0;
        area[l2] += 1.0;
*/
    }
	dzeta0=0.0;
    for (i=0;i<NMEM;i++) {
        delta_area = dzeta[i]/area[i] ;
        dzeta[i] = delta_area/(1.0+1.0*fabs(delta_area)) ;
	dzeta0+=dzeta[i]*dzeta[i];
    }
	dzeta0=sqrt(dzeta0/NMEM);
	printf("%f\n",dzeta0);
	return dzeta0;	
}


double get_zeta2(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D v_mem[],
              struct point3D *v_mem_cm, double darea[],
              double dzeta[], double curv[], struct point3D n_mem[],double areatemp,double* dA0)
{
	int			i, j, l0, l1, l2;
	double		delta_area;
	struct point3D      v0, v1, v2;

	*dA0=0.0;
	for(i=0;i<NMEM;i++) dzeta[i]=0.0;
	for (i=0;i<NTRIANG;i++) {

		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];

		dtriangle_area2(r_mem[l0],r_mem[l1],r_mem[l2],v_mem[l0],v_mem[l1],v_mem[l2],&delta_area);

		for(j=0;j<3;j++) dzeta[triang_site[i][j]] += (delta_area-areatemp*darea[i]);
		*dA0+=delta_area-areatemp*darea[i];
	}
}

double get_zeta21(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D v_mem[],
              struct point3D *v_mem_cm, double darea[],
              double dzeta[], double curv[], struct point3D n_mem[],double areatemp,double* dA0, double ref_state[NTRIANG][4], double dtime)
{
	int			i, j, l0, l1, l2;
	double		delta_area;
	struct point3D      v0, v1, v2;

	*dA0=0.0;
	for(i=0;i<NMEM;i++) dzeta[i]=0.0;
	for (i=0;i<NTRIANG;i++) {

		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];

		dtriangle_area2(r_mem[l0],r_mem[l1],r_mem[l2],v_mem[l0],v_mem[l1],v_mem[l2],&delta_area);

		for(j=0;j<3;j++) dzeta[triang_site[i][j]] += delta_area-0.5*(darea[i]-areatemp*ref_state[i][3])/dtime;
		*dA0+=delta_area-0.5*(darea[i]-areatemp*ref_state[i][3])/dtime;
	}
}



double get_zeta3(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D v_mem[],
              struct point3D *v_mem_cm, double darea[],
              double dzeta[], double curv[], struct point3D n_mem[],double areatemp,double* dA0)
{
	int			i, j, l0, l1, l2;
	double		delta_area;
	struct point3D      v0, v1, v2;
	int	Nneighbours[NMEM];
	int	neighbours[NMEM][6];

	*dA0=0.0;

	for(i=0;i<NMEM;i++) dzeta[i]=0.0;
	for (i=0;i<NTRIANG;i++) {

		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];

		dtriangle_area2(r_mem[l0],r_mem[l1],r_mem[l2],v_mem[l0],v_mem[l1],v_mem[l2],&delta_area);

		for(j=0;j<3;j++) dzeta[triang_site[i][j]] += delta_area-areatemp*darea[i];
		*dA0+=delta_area;
	}
	for(i=0;i<NMEM;i++) Nneighbours[i]=0;
	for(i=0;i<NTRIANG;i++){
		l0 = triang_site[i][0];
		l1 = triang_site[i][1];
		l2 = triang_site[i][2];
		for(j=0;j<Nneighbours[l0];j++) if(neighbours[l0][j]==l1) break;
		if(j==Nneighbours[l0]){
			neighbours[l0][j]=l1;
			Nneighbours[l0]++;
		}
		for(j=0;j<Nneighbours[l0];j++) if(neighbours[l0][j]==l2) break;
		if(j==Nneighbours[l0]){
			neighbours[l0][j]=l2;
			Nneighbours[l0]++;
		}
		for(j=0;j<Nneighbours[l1];j++) if(neighbours[l1][j]==l2) break;
		if(j==Nneighbours[l1]){
			neighbours[l1][j]=l2;
			Nneighbours[l1]++;
		}
		for(j=0;j<Nneighbours[l1];j++) if(neighbours[l1][j]==l0) break;
		if(j==Nneighbours[l1]){
			neighbours[l1][j]=l0;
			Nneighbours[l1]++;
		}
		for(j=0;j<Nneighbours[l2];j++) if(neighbours[l2][j]==l0) break;
		if(j==Nneighbours[l2]){
			neighbours[l2][j]=l0;
			Nneighbours[l2]++;
		}
		for(j=0;j<Nneighbours[l2];j++) if(neighbours[l2][j]==l1) break;
		if(j==Nneighbours[l2]){
			neighbours[l2][j]=l1;
			Nneighbours[l2]++;
		}
	}
	for(i=0;i<(NMEM-2)/4+2;i++){
		for(j=0;j<Nneighbours[i];j++){
			dzeta[i]+=dzeta[neighbours[i][j]]*0.5;
		}
	}
}





void get_tension(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D f_tens[],
                 double tens, double zeta[], double curv[], struct point3D n_mem[], double darea[])
{

    int			i, j, l0, l1, l2;
    double		area[NMEM], tmp, tmp_area;
    struct point3D	grad[NMEM], tmp_grad, smooth_grad[NMEM];


/*
    for (i=0;i<NMEM;i++) area[i] = grad[i].x = grad[i].y = grad[i].z = 0.0;

    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        tmp_grad.x = tmp_grad.y = tmp_grad.z = tmp_area = 0.0;
        grad2D(r_mem[l0],r_mem[l1],r_mem[l2],zeta[l0],zeta[l1],zeta[l2],
                &tmp_grad,&tmp_area,darea[i]);

        grad[l0].x += tmp_grad.x;
        grad[l0].y += tmp_grad.y;
        grad[l0].z += tmp_grad.z;

        grad[l1].x += tmp_grad.x;
        grad[l1].y += tmp_grad.y;
        grad[l1].z += tmp_grad.z;

        grad[l2].x += tmp_grad.x;
        grad[l2].y += tmp_grad.y;
        grad[l2].z += tmp_grad.z;

        area[l0] += tmp_area;
        area[l1] += tmp_area;
        area[l2] += tmp_area;


    }
*/

/*
    for (i=0;i<NMEM;i++) {

        grad[i].x = grad[i].x/area[i];
        grad[i].y = grad[i].y/area[i];
        grad[i].z = grad[i].z/area[i];

        smooth_grad[i].x = smooth_grad[i].y = smooth_grad[i].z = area[i] =  0.0;

    }
    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        tmp_grad.x = (grad[l0].x+0.5*(grad[l1].x+grad[l2].x))/2.0;
        tmp_grad.y = (grad[l0].y+0.5*(grad[l1].y+grad[l2].y))/2.0;
        tmp_grad.z = (grad[l0].z+0.5*(grad[l1].z+grad[l2].z))/2.0;
        smooth_grad[l0].x += tmp_grad.x;
        smooth_grad[l0].y += tmp_grad.y;
        smooth_grad[l0].z += tmp_grad.z;

        tmp_grad.x = (grad[l1].x+0.5*(grad[l0].x+grad[l2].x))/2.0;
        tmp_grad.y = (grad[l1].y+0.5*(grad[l0].y+grad[l2].y))/2.0;
        tmp_grad.z = (grad[l1].z+0.5*(grad[l0].z+grad[l2].z))/2.0;
        smooth_grad[l1].x += tmp_grad.x;
        smooth_grad[l1].y += tmp_grad.y;
        smooth_grad[l1].z += tmp_grad.z;

        tmp_grad.x = (grad[l2].x+0.5*(grad[l1].x+grad[l0].x))/2.0;
        tmp_grad.y = (grad[l2].y+0.5*(grad[l1].y+grad[l0].y))/2.0;
        tmp_grad.z = (grad[l2].z+0.5*(grad[l1].z+grad[l0].z))/2.0;
        smooth_grad[l2].x += tmp_grad.x;
        smooth_grad[l2].y += tmp_grad.y;
        smooth_grad[l2].z += tmp_grad.z;

        area[l0] += 1.0;
        area[l1] += 1.0;
        area[l2] += 1.0;

    }

*/

    scal_grad2D(grad,zeta,triang_site,r_mem,n_mem,darea);


    for (i=0;i<NMEM;i++) {
/*
        grad[i].x = grad[i].x/area[i];//smooth_grad[i].x/area[i];
        grad[i].y = grad[i].y/area[i];//smooth_grad[i].y/area[i];
        grad[i].z = grad[i].z/area[i];//smooth_grad[i].z/area[i];
*/
        f_tens[i].x += tens*( grad[i].x + 2.0*curv[i] * zeta[i] * n_mem[i].x);
        f_tens[i].y += tens*( grad[i].y + 2.0*curv[i] * zeta[i] * n_mem[i].y);
        f_tens[i].z += tens*( grad[i].z + 2.0*curv[i] * zeta[i] * n_mem[i].z);

    }



}




void	get_axis(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D r_mem_cm, double darea[], struct point3D axis[], double eival[])
{
    int			i, l0, l1, l2, nrot;
    struct point3D	r0, r1, r2;
    double		xx, xy, xz, yy, yz, zz, area, a[3][3], v[3][3];



//  compute the matrix

    area = xx = xy = xz = yy = yz = zz = 0.0;

    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        area   += darea[i];

        r0.x = r_mem[l0].x - r_mem_cm.x;
        r0.y = r_mem[l0].y - r_mem_cm.y;
        r0.z = r_mem[l0].z - r_mem_cm.z;

        r1.x = r_mem[l1].x - r_mem_cm.x;
        r1.y = r_mem[l1].y - r_mem_cm.y;
        r1.z = r_mem[l1].z - r_mem_cm.z;

        r2.x = r_mem[l2].x - r_mem_cm.x;
        r2.y = r_mem[l2].y - r_mem_cm.y;
        r2.z = r_mem[l2].z - r_mem_cm.z;


        xx += darea[i]*( r0.x*r0.x + r1.x*r1.x + r2.x*r2.x )/3.0;
        xy += darea[i]*( r0.x*r0.y + r1.x*r1.y + r2.x*r2.y )/3.0;
        xz += darea[i]*( r0.x*r0.z + r1.x*r1.z + r2.x*r2.z )/3.0;
        yy += darea[i]*( r0.y*r0.y + r1.y*r1.y + r2.y*r2.y )/3.0;
        yz += darea[i]*( r0.y*r0.z + r1.y*r1.z + r2.y*r2.z )/3.0;
        zz += darea[i]*( r0.z*r0.z + r1.z*r1.z + r2.z*r2.z )/3.0;

    }

    a[0][0] = xx / area;
    a[1][1] = yy / area;
    a[2][2] = zz / area;
    a[0][1] = a[1][0] = xy / area;
    a[0][2] = a[2][0] = xz / area;
    a[1][2] = a[2][1] = yz / area;

    jacobi(a,eival,v,&nrot);
    eigsrt(eival,v);

    for (i=0;i<3;i++) {
        axis[i].x = v[0][i];
        axis[i].y = v[1][i];
        axis[i].z = v[2][i];
    }

}


double get_angle( double x, double y )
{
    double      dum, teta, pi;

    pi = 4.0*atan(1.0);

    if (x==0.0)     teta = (y>0.0 ? 0.5*pi : -0.5*pi);
    else if (x>0.0) teta = (y>0.0 ? atan(y/x) : 2.0*pi + atan(y/x));
    else            teta = pi + atan(y/x);

    return teta;
}

/*void quadratic_interpolator(int n, struct point3D points[], struct point3D* normal, double* mean_curvature, double* gaussian_curvature)
{
	double s1[6];
	double s2[6];
	double temp1[6][5];
	struct point3D localx,localy,d1R,d2R,d11R,d12R,d22R;
	double temp;
	double g11,g12,g22;
	double h11,h12,h22;
	double detg1;
	gsl_matrix *M;
	gsl_vector *V;
	int i,j,k;

	if (n<5) {
		printf("not enough points for the interpolation\n");
		exit(1);
	}
	if (n>6) {
		printf("too many points for the interpolation\n");
		exit(1);
	}
	M=gsl_matrix_alloc(5,5);
	V=gsl_vector_alloc(5);	
	temp=points[1].x*normal->x+points[1].y*normal->y+points[1].z*normal->z;
	localx.x=points[1].x-normal->x*temp;
	localx.y=points[1].y-normal->y*temp;
	localx.z=points[1].z-normal->z*temp;
	temp=pow(localx.x*localx.x+localx.y*localx.y+localx.z*localx.z,-0.5);
	localx.x*=temp;
	localx.y*=temp;
	localx.z*=temp;
	localy.x=normal->y*localx.z-normal->z*localx.y;
	localy.y=normal->z*localx.x-normal->x*localx.z;
	localy.z=normal->x*localx.y-normal->y*localx.x;

	for(i=0;i<n;i++){
		s1[i]=localx.x*points[i].x+localx.y*points[i].y+localx.z*points[i].z;
		s2[i]=localy.x*points[i].x+localy.y*points[i].y+localy.z*points[i].z;
		temp1[i][0]=s1[i];
		temp1[i][1]=s2[i];
		temp1[i][2]=0.5*s1[i]*s1[i];
		temp1[i][3]=s1[i]*s2[i];
		temp1[i][4]=0.5*s2[i]*s2[i];
	}
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].x*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	d1R.x=gsl_vector_get(V,0);
	d2R.x=gsl_vector_get(V,1);
	d11R.x=gsl_vector_get(V,2);
	d12R.x=gsl_vector_get(V,3);
	d22R.x=gsl_vector_get(V,4);

	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].y*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	d1R.y=gsl_vector_get(V,0);
	d2R.y=gsl_vector_get(V,1);
	d11R.y=gsl_vector_get(V,2);
	d12R.y=gsl_vector_get(V,3);
	d22R.y=gsl_vector_get(V,4);
	
	for(i=0;i<5;i++){
		temp=0.0;
		for(k=0;k<n;k++){
			temp+=points[k].z*temp1[k][i];
		}
		gsl_vector_set(V,i,temp);
		for(j=0;j<5;j++){
			temp=0.0;
			for(k=0;k<n;k++){
				temp+=temp1[k][i]*temp1[k][j];
			}
			gsl_matrix_set(M,i,j,temp);
		}
	}
	gsl_linalg_HH_svx(M,V);
	d1R.z=gsl_vector_get(V,0);
	d2R.z=gsl_vector_get(V,1);
	d11R.z=gsl_vector_get(V,2);
	d12R.z=gsl_vector_get(V,3);
	d22R.z=gsl_vector_get(V,4);


	normal->x=d1R.y*d2R.z-d1R.z*d2R.y;
	normal->y=d1R.z*d2R.x-d1R.x*d2R.z;
	normal->z=d1R.x*d2R.y-d1R.y*d2R.x;

	temp=pow(normal->x*normal->x+normal->y*normal->y+normal->z*normal->z,-0.5);
	normal->x*=temp;
	normal->y*=temp;
	normal->z*=temp;

	g11=d1R.x*d1R.x+d1R.y*d1R.y+d1R.z*d1R.z;
	g22=d2R.x*d2R.x+d2R.y*d2R.y+d2R.z*d2R.z;
	g12=d1R.x*d2R.x+d1R.y*d2R.y+d1R.z*d2R.z;
	
	detg1=1.0/(g11*g22-g12*g12);

	h11=d11R.x*normal->x+d11R.y*normal->y+d11R.z*normal->z;
	h12=d12R.x*normal->x+d12R.y*normal->y+d12R.z*normal->z;
	h22=d22R.x*normal->x+d22R.y*normal->y+d22R.z*normal->z;

	*gaussian_curvature=(h11*h22-h12*h12)*detg1;
	*mean_curvature=(0.5*(h11*g22+h22*g11)-h12*g12)*detg1;
	
	gsl_matrix_free(M);
	gsl_vector_free(V);	

}*/

double DotProduct(struct point3D A,struct point3D B){
	return A.x*B.x+A.y*B.y+A.z*B.z;
}


