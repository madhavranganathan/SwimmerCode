inline double DotProduct3D(struct point3D A,struct point3D B);

inline void CrossProduct3D(struct point3D* result,struct point3D A,struct point3D B);

inline void smul3D(struct point3D* result, double A,struct point3D B);

inline void add3D(struct point3D* result, struct point3D A,struct point3D B);

inline void sub3D(struct point3D* result, struct point3D A,struct point3D B);

inline void smul3D2(struct point3D* result, double A);

inline void add3D2(struct point3D* result, struct point3D A);

inline void sub3D2(struct point3D* result, struct point3D A);

double det2D(double m[2][2]);

void quadratic_interpolator(int n, struct point3D points[], struct point3D* normal, double* mean_curvature, double* gaussian_curvature);

void new_quadratic_interpolator(int n, struct point3D points[], struct point3D* normal, double* mean_curvature, double* gaussian_curvature, int slaves[], struct point3D r_mem2[NMEM2], struct point3D r_memtemp[NMEM2]);

void quartic_interpolator(int n, struct point3D points[], struct point3D* normal, double* mean_curvature, double* gaussian_curvature);

void new_surface_laplacian(int n, struct point3D points[], double a[], struct point3D* normal,double* lap_sa);

void new_surface_laplacian2(int n, struct point3D points[], double a[], struct point3D* normal,double* lap_sa);

void new_surface_gradient(int n, struct point3D points[], double a[], struct point3D* normal,struct point3D* gradsa);

void new_surface_gradient2(int n, struct point3D points[], double a[], struct point3D* normal,struct point3D* gradsa);

//void new_get_force(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double curv[], double gauss[], double lap_curv[], double zeta[], struct point3D f_mem[], double kappa, double tens);

void new_get_force(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double curv[], double gauss[], double lap_curv[], double zeta[],struct point3D f_mem[],double kappa,double tens,double f_n[],struct point3D f_t[]);

void test_get_force3(int triang_site[NTRIANG][3], int triang_site2[NTRIANG2][3], struct point3D r_mem[], struct point3D r_mem2[], struct point3D r_mem0[], struct point3D n_mem[], double kappa, double curv[], double gauss[], double lap_curv[], double zeta[], double zeta2[], double dzeta[NMEM], double dzeta2[NMEM2], struct point3D f_mem[NMEM2], struct point3D f_mem0[NMEM2][4], struct point3D fdA[NMEM][4], struct point3D fdA2[NMEM2][4], int Nneighbours[NMEM], int neighbours[NMEM][6], int slaves[NMEM][NSLA], double r_max[NMEM]);

void new_get_force0(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double zeta[NMEM], struct point3D tension_force[NMEM], struct point3D tension0_force[NMEM]);

double new_get_zeta(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D v_mem[],
              struct point3D *v_mem_cm, double darea[],
              double dzeta[], double curv[], struct point3D n_mem[], double dtime);

void new_area_element(int n, struct point3D points[], struct point3D* normal,int n0,int pairs[][2],double* darea);

void new_volume_element(int n,struct point3D R0, struct point3D points[], struct point3D* normal,int n0,int pairs[][2],double* dvolume);

void new_area_element2(int n, struct point3D points[], struct point3D* normal,int n0,int pairs[][2],double* darea);

void Surface_Area(struct point3D r_mem[],int triang_site[][3],struct point3D n_mem[],double* Area0,double* Volume0);

void advect(int n, struct point3D points[], double b[], struct point3D v_mem[],struct point3D* normal,double weights[], struct point3D* dr_mem, double *db_mem, struct point3D dv_mem[],struct point3D v_t,double advect_mul);

void new_dynamique(struct point3D r_mem[NMEM],int triang_site[NTRIANG][3],struct point3D n_mem[NMEM],double colors[NMEM],struct point3D v_mem[NMEM],double weights[NMEM],struct point3D v_mem_cm,struct point3D dr_mem[NMEM],double dcolors[NMEM],struct point3D dv_mem[NMEM],double* dtime,double darea[NTRIANG]);

void outwarder(struct point3D r_mem[NMEM], int triang_site[NTRIANG][3],struct point3D n_mem[NMEM]);

double get_zeta2(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D v_mem[],
              struct point3D *v_mem_cm, double darea[],
              double dzeta[], double curv[], struct point3D n_mem[],double areatemp,double* dA0);

void find_neighbours(int triang_site[NTRIANG][3],int Nneighbours[NMEM],int neighbours[NMEM][6],int neighbour_sites[NMEM][6][2]);

void find_neighbours2(int triang_site[NTRIANG2][3],int Nneighbours[NMEM2],int neighbours[NMEM2][6],int neighbour_sites[NMEM2][6][2]);

void new_get_force3(int triang_site[NTRIANG][3], struct point3D r_mem[], struct point3D n_mem[], double kappa, double curv[], double gauss[], double lap_curv[], double zeta[], double dzeta[NMEM], struct point3D tension_force[NMEM], struct point3D tension_force2[NMEM], struct point3D tension_force3[NMEM], struct point3D tension0_force[NMEM], struct point3D tension0_force2[NMEM], struct point3D tension0_force3[NMEM],int Nneighbours[NMEM],int neighbours[NMEM][6]);

void old_surface_gradient(struct point3D r_mem[NMEM],int triang_site[NTRIANG][3],double a[NMEM],struct point3D gradsa[NMEM]);

void get_stress(struct point3D r_mem[NMEM],int triang_site[NTRIANG][3],struct point3D f_mem[NMEM],struct point3D n_mem[NMEM],struct point3D v_mem[NMEM],double stress[3][3],double darea[NTRIANG]);

void put_points(int triang_site[NTRIANG2][3], struct point3D r_mem[NMEM], struct point3D r_mem2[NMEM2]);

void put_points16(struct point3D r_mem[NMEM], struct point3D r_mem2[NMEM2], int slaves[NMEM][NSLA], int Nneighbours[NMEM]);

void new_interpolate(int n, struct point3D points[], double a[], struct point3D* normal, int slaves[], struct point3D r_mem2[NMEM2], double zeta2[NMEM2]);

void new_force_interpolator16(int n, struct point3D points[], struct point3D forces[], struct point3D* normal, int slaves[], struct point3D r_mem2[NMEM2], struct point3D f_mem0[NMEM2][4],int kk);

void find_angle(struct point3D r_mem[NMEM],struct point3D r_mem_cm);
