#include	"includes.h"



void	green_mem(int triang_site[NTRIANG][3], struct point3D v_mem[], struct point3D *v_mem_cm, struct point3D f_mem[],
                    struct point3D r_mem[], struct point3D n_mem[], double darea[],
                    double eta, double pp, double shear)
{
	int i, imem, tst, l0, l1, l2;
	struct point3D tmp, f_tmp[NMEM], v_tmp[NMEM], vg_tmp[NMEM], vk_tmp[NMEM], v_new[NMEM],tempr[NTRIANG],temp5;
	double fn, cst, cstk,cstk2,temp1,temp2,temp3,temp4,eta1;
	int* triang_ptr;
#ifdef VISCOSITY_CONTRAST
	struct point3D tempv[NMEM];
#endif
	cst = 2.0/(1.0+pp);
	cstk = 0.5*( pp-1.0);
	cstk2 = cstk /2/PI;
	temp1=1./3.;
	temp2=1./(24.0*PI*eta);
	eta1=3.*temp2;
	temp4=0.0625*RAD*RAD;

	fn = 0.0;
	for (i=0;i<NMEM;i++) fn += f_mem[i].x*n_mem[i].x + f_mem[i].y*n_mem[i].y + f_mem[i].z*n_mem[i].z;
	fn = fn/NMEM;
	for (i=0;i<NMEM;i++) {
		f_tmp[i].x = f_mem[i].x - fn*n_mem[i].x;
		f_tmp[i].y = f_mem[i].y - fn*n_mem[i].y;
		f_tmp[i].z = f_mem[i].z - fn*n_mem[i].z;
	}
	for(i=0;i<NTRIANG;i++){
		triang_ptr=triang_site[i];
		l0 = triang_ptr[0];
		l1 = triang_ptr[1];
		l2 = triang_ptr[2];
		tempr[i].x=(r_mem[l0].x+r_mem[l1].x+r_mem[l2].x)*temp1;
		tempr[i].y=(r_mem[l0].y+r_mem[l1].y+r_mem[l2].y)*temp1;
		tempr[i].z=(r_mem[l0].z+r_mem[l1].z+r_mem[l2].z)*temp1;
	}

	for (imem=0;imem<NMEM;imem++) {

#ifdef VISCOSITY_CONTRAST
		for (i=0;i<NMEM;i++) {
			v_tmp[i].x = v_mem[i].x - v_mem[imem].x;
			v_tmp[i].y = v_mem[i].y - v_mem[imem].y;
			v_tmp[i].z = v_mem[i].z - v_mem[imem].z;
		}
#endif

        	v_new[imem].x = v_new[imem].y = v_new[imem].z = 0.0;

/*
        tabulate_greg(r_mem,f_tmp,r_mem[imem],vg_tmp);
#ifdef VISCOSITY_CONTRAST
        tabulate_kreg(r_mem,n_mem,v_tmp,r_mem[imem],vk_tmp);
#endif*/
		tabulate_all(r_mem,n_mem,f_tmp,v_tmp,imem,vg_tmp,vk_tmp);
		temp5.x=temp5.y=temp5.z=0.0;
		for (i=0;i<NTRIANG;i++) {
			triang_ptr=triang_site[i];
//			tst=is_site(i,imem,triang_site);
			tst=is_site2(imem,triang_ptr);
			if ( tst < 3) {

				l1 = triang_ptr[(tst+1)%3];
				l2 = triang_ptr[(tst+2)%3];

				singular_mem(&v_new[imem],f_tmp[imem],f_tmp[l1],f_tmp[l2],r_mem[imem],r_mem[l1],r_mem[l2],n_mem[imem],eta,pp,shear,darea[i]);

            		}

			else {
				l0 = triang_ptr[0];
 				l1 = triang_ptr[1];
				l2 = triang_ptr[2];



            tmp.x = tempr[i].x - r_mem[imem].x;
				tmp.y = tempr[i].y - r_mem[imem].y;
				tmp.z = tempr[i].z - r_mem[imem].z;

				if (tmp.x*tmp.x+tmp.y*tmp.y+tmp.z*tmp.z<temp4) {
					regular_mem_new(&v_new[imem],f_tmp[l0],f_tmp[l1],f_tmp[l2],r_mem[l0],r_mem[l1],r_mem[l2],r_mem[imem],eta1,pp,shear);
				}
				else{ 
					temp5.x += (vg_tmp[l0].x+vg_tmp[l1].x+vg_tmp[l2].x)*darea[i];
					temp5.y += (vg_tmp[l0].y+vg_tmp[l1].y+vg_tmp[l2].y)*darea[i];
					temp5.z += (vg_tmp[l0].z+vg_tmp[l1].z+vg_tmp[l2].z)*darea[i];

				}

			}
#ifdef VISCOSITY_CONTRAST
			l0 = triang_ptr[0];
			l1 = triang_ptr[1];
			l2 = triang_ptr[2];
			v_new[imem].x += darea[i]*cstk2*(vk_tmp[l0].x+vk_tmp[l1].x+vk_tmp[l2].x);
			v_new[imem].y += darea[i]*cstk2*(vk_tmp[l0].y+vk_tmp[l1].y+vk_tmp[l2].y);
			v_new[imem].z += darea[i]*cstk2*(vk_tmp[l0].z+vk_tmp[l1].z+vk_tmp[l2].z);
#endif
		}
#ifdef VISCOSITY_CONTRAST
//		printf("%f\t%f\t%f\t%f\t%f\t%f\n",v_new[imem].x/cstk2,v_new[imem].y/cstk2,v_new[imem].z/cstk2,v_mem[imem].x,v_mem[imem].y,v_mem[imem].z);
		v_new[imem].x = (v_new[imem].x + temp2*temp5.x + cstk*v_mem[imem].x + xflow(r_mem[imem])*shear)*cst;
		v_new[imem].y = (v_new[imem].y + temp2*temp5.y + cstk*v_mem[imem].y + yflow(r_mem[imem])*shear)*cst;
		v_new[imem].z = (v_new[imem].z + temp2*temp5.z + cstk*v_mem[imem].z + zflow(r_mem[imem])*shear)*cst;
#else
		v_mem[imem].x = v_new[imem].x + temp2*temp5.x + xflow(r_mem[imem])*shear;
		v_mem[imem].y = v_new[imem].y + temp2*temp5.y + yflow(r_mem[imem])*shear;
		v_mem[imem].z = v_new[imem].z + temp2*temp5.z + zflow(r_mem[imem])*shear;
#endif
	}
#ifdef VISCOSITY_CONTRAST
	for(i=0;i<NMEM;i++){
		v_mem[i].x=v_new[i].x;
		v_mem[i].y=v_new[i].y;
		v_mem[i].z=v_new[i].z;
	}
#endif

}



void	green(int triang_site[NTRIANG][3], struct point3D pos, struct point3D *v, struct point3D v_mem[], struct point3D f_mem[], struct point3D r_mem[],
                    struct point3D n_mem[], double darea[], double eta, double pp, double shear)
{
    int			i, imem, tst, l0, l1, l2;
    double		cst, cstk, fn;
    struct point3D	sum, f_tmp[NMEM], vg_tmp[NMEM], vk_tmp[NMEM];

//  outside the vesicle

    cstk = pp-1.0;


    fn = 0.0;
    for (i=0;i<NMEM;i++) fn += f_mem[i].x*n_mem[i].x + f_mem[i].y*n_mem[i].y + f_mem[i].z*n_mem[i].z;
    fn = fn/NMEM;
    for (i=0;i<NMEM;i++) {
        f_tmp[i].x = f_mem[i].x - fn*n_mem[i].x;
        f_tmp[i].y = f_mem[i].y - fn*n_mem[i].y;
        f_tmp[i].z = f_mem[i].z - fn*n_mem[i].z;
    }

    sum.x = sum.y = sum.z = 0.0;

    tabulate_greg(r_mem,f_tmp,pos,vg_tmp);
    tabulate_kreg(r_mem,n_mem,v_mem,pos,vk_tmp);

    for (i=0;i<NTRIANG;i++) {

        l0 = triang_site[i][0];
        l1 = triang_site[i][1];
        l2 = triang_site[i][2];

        sum.x += darea[i]*(vg_tmp[l0].x+vg_tmp[l1].x+vg_tmp[l2].x)/(24.0*PI*eta);
        sum.y += darea[i]*(vg_tmp[l0].y+vg_tmp[l1].y+vg_tmp[l2].y)/(24.0*PI*eta);
        sum.z += darea[i]*(vg_tmp[l0].z+vg_tmp[l1].z+vg_tmp[l2].z)/(24.0*PI*eta);
        sum.x += darea[i]*cstk*(vk_tmp[l0].x+vk_tmp[l1].x+vk_tmp[l2].x)/(4.0*PI);
        sum.y += darea[i]*cstk*(vk_tmp[l0].y+vk_tmp[l1].y+vk_tmp[l2].y)/(4.0*PI);
        sum.z += darea[i]*cstk*(vk_tmp[l0].z+vk_tmp[l1].z+vk_tmp[l2].z)/(4.0*PI);

    }

    v->x = sum.x + xflow(pos);
    v->y = sum.y + yflow(pos);
    v->z = sum.z + zflow(pos);



}









void	singular_mem( struct point3D *sum, struct point3D f_mem0,
                                           struct point3D f_mem1,
                                           struct point3D f_mem2,
                                           struct point3D r_mem0,
                                           struct point3D r_mem1,
                                           struct point3D r_mem2, struct point3D n_mem,
                                           double eta, double pp, double shear, double dsurf)
{
    struct point3D		t12, r01, r02, rstar, tmp, f;
    double			rn12, rn12sq, rn01, rn02, scal01, scal02, scal;
    double			int1, int2, int3, int4, int5, sstar, st12;
    double			a0, a1, a2, a3, a4, a5;

    double			dum, rstarn;


    t12.x = r_mem2.x - r_mem1.x;
    t12.y = r_mem2.y - r_mem1.y;
    t12.z = r_mem2.z - r_mem1.z;

    rn12sq  = t12.x*t12.x + t12.y*t12.y + t12.z*t12.z;
    rn12    = sqrt(rn12sq);

    if (rn12<1.e-10) return;

    t12.x = t12.x / rn12;
    t12.y = t12.y / rn12;
    t12.z = t12.z / rn12;

    r01.x = r_mem1.x - r_mem0.x;
    r01.y = r_mem1.y - r_mem0.y;
    r01.z = r_mem1.z - r_mem0.z;

    rn01  = sqrt(r01.x*r01.x + r01.y*r01.y + r01.z*r01.z);
    if (rn01<1.e-10) return;

    r02.x = r_mem2.x - r_mem0.x;
    r02.y = r_mem2.y - r_mem0.y;
    r02.z = r_mem2.z - r_mem0.z;

    rn02  = sqrt(r02.x*r02.x + r02.y*r02.y + r02.z*r02.z);
    if (rn02<1.e-10) return;

    scal01 = r01.x*t12.x + r01.y*t12.y + r01.z*t12.z;
    scal02 = r02.x*t12.x + r02.y*t12.y + r02.z*t12.z;

    int1 = log((rn02+scal02)/(rn01+scal01));
    int2 = scal02/rn02 - scal01/rn01;
    int3 = 1.0/rn01-1.0/rn02;
    int4 = int1 - int2;
    int5 = (2.0*rn02*rn02 - scal02*scal02)/rn02 - (2.0*rn01*rn01 - scal01*scal01)/rn01;


    rstar.x = r01.x - scal01*t12.x;
    rstar.y = r01.y - scal01*t12.y;
    rstar.z = r01.z - scal01*t12.z;

//  point 0

    sstar   = rstar.x*f_mem0.x + rstar.y*f_mem0.y + rstar.z*f_mem0.z;
    st12    = t12.x*f_mem0.x + t12.y*f_mem0.y + t12.z*f_mem0.z;

    a0 = int1/rn12;
    a1 = (sstar*int2/(rn01*rn01-scal01*scal01) + st12*int3)/rn12;
    a2 = (sstar*int3 + st12*int4)/rn12;

    tmp.x = (f_mem0.x * a0 + rstar.x * a1 + t12.x * a2)/(8.0*PI);
    tmp.y = (f_mem0.y * a0 + rstar.y * a1 + t12.y * a2)/(8.0*PI);
    tmp.z = (f_mem0.z * a0 + rstar.z * a1 + t12.z * a2)/(8.0*PI);

//  point 1

    sstar   = rstar.x*f_mem1.x + rstar.y*f_mem1.y + rstar.z*f_mem1.z;
    st12    = t12.x*f_mem1.x + t12.y*f_mem1.y + t12.z*f_mem1.z;

    a0 = int1*scal02/rn12sq - (rn02-rn01)/rn12sq;
    a1 = (sstar*int2/(rn01*rn01-scal01*scal01) + st12*int3)*scal02/rn12sq - (sstar*int3+st12*int4)/rn12sq;
    a2 = (sstar*int3 + st12*int4)*scal02/rn12sq - (sstar*int4 + st12*int5)/rn12sq;

    tmp.x += (f_mem1.x * a0 + rstar.x * a1 + t12.x * a2)/(8.0*PI);
    tmp.y += (f_mem1.y * a0 + rstar.y * a1 + t12.y * a2)/(8.0*PI);
    tmp.z += (f_mem1.z * a0 + rstar.z * a1 + t12.z * a2)/(8.0*PI);


//  point 2

    sstar   = rstar.x*f_mem2.x + rstar.y*f_mem2.y + rstar.z*f_mem2.z;
    st12    = t12.x*f_mem2.x + t12.y*f_mem2.y + t12.z*f_mem2.z;

    a0 = - int1*scal01/rn12sq + (rn02-rn01)/rn12sq;
    a1 = - (sstar*int2/(rn01*rn01-scal01*scal01) + st12*int3)*scal01/rn12sq + (sstar*int3+st12*int4)/rn12sq;
    a2 = - (sstar*int3 + st12*int4)*scal01/rn12sq + (sstar*int4 + st12*int5)/rn12sq;

    tmp.x += (f_mem2.x * a0 + rstar.x * a1 + t12.x * a2)/(8.0*PI);
    tmp.y += (f_mem2.y * a0 + rstar.y * a1 + t12.y * a2)/(8.0*PI);
    tmp.z += (f_mem2.z * a0 + rstar.z * a1 + t12.z * a2)/(8.0*PI);

//  add contribution

    sum->x += dsurf*tmp.x/eta;
    sum->y += dsurf*tmp.y/eta;
    sum->z += dsurf*tmp.z/eta;

}



/*
void tabulate_greg( struct point3D r_mem[], struct point3D f[], struct point3D pos, struct point3D vg_tmp[])
{
    int			i;
    struct point3D	r;
    double 		rn, scal;


    for (i=0;i<NMEM;i++) {

        r.x = pos.x - r_mem[i].x;
        r.y = pos.y - r_mem[i].y;
        r.z = pos.z - r_mem[i].z;

        rn = sqrt(r.x*r.x + r.y*r.y + r.z*r.z);

        if (rn==0.0) vg_tmp[i].x = vg_tmp[i].y = vg_tmp[i].z = 0.0;
        else {

            scal = (f[i].x*r.x + f[i].y*r.y + f[i].z*r.z)/pow(rn,3.0);

            vg_tmp[i].x = f[i].x/rn + r.x*scal;
            vg_tmp[i].y = f[i].y/rn + r.y*scal;
            vg_tmp[i].z = f[i].z/rn + r.z*scal;

        }

    }


}
*/


void tabulate_greg( struct point3D r_mem[], struct point3D f[], struct point3D pos, struct point3D vg_tmp[])
{
    int			i;
    struct point3D	r;
    double 		rn, scal,tmp;


    for (i=0;i<NMEM;i++) {

        r.x = pos.x - r_mem[i].x;
        r.y = pos.y - r_mem[i].y;
        r.z = pos.z - r_mem[i].z;
		  tmp = r.x*r.x + r.y*r.y + r.z*r.z;

        if (tmp==0.0) vg_tmp[i].x = vg_tmp[i].y = vg_tmp[i].z = 0.0;
        else {
//				tmp=1.0/tmp;
	         rn = 1.0/sqrt(tmp);
            scal = (f[i].x*r.x + f[i].y*r.y + f[i].z*r.z)*rn*rn;

            vg_tmp[i].x = (f[i].x + r.x*scal)*rn;
            vg_tmp[i].y = (f[i].y + r.y*scal)*rn;
            vg_tmp[i].z = (f[i].z + r.z*scal)*rn;

        }

    }


}


void tabulate_kreg( struct point3D r_mem[], struct point3D n_mem[], struct point3D v[], struct point3D pos, struct point3D vk_tmp[])
{
    int			i;
    struct point3D	r;
    double 		rn, scal;


    for (i=0;i<NMEM;i++) {

        r.x = r_mem[i].x - pos.x;
        r.y = r_mem[i].y - pos.y;
        r.z = r_mem[i].z - pos.z;

        rn = sqrt(r.x*r.x + r.y*r.y + r.z*r.z);

        if (rn<1.e-6) vk_tmp[i].x = vk_tmp[i].y = vk_tmp[i].z = 0.0;
        else {

            scal = (v[i].x*r.x + v[i].y*r.y + v[i].z*r.z)*(n_mem[i].x*r.x + n_mem[i].y*r.y + n_mem[i].z*r.z)/pow(rn,5.0);

            vk_tmp[i].x =  r.x*scal;
            vk_tmp[i].y =  r.y*scal;
            vk_tmp[i].z =  r.z*scal;

        }

    }


}

void tabulate_all(struct point3D r_mem[NMEM],struct point3D n_mem[], struct point3D f[], struct point3D v[], int pos, struct point3D vg_tmp[], struct point3D vk_tmp[]){
	int i;
	struct point3D r;
	double rn,scal,tmp;


	for(i=0;i<NMEM;i++) {
		if(i==pos) {
#ifdef VISCOSITY_CONTRAST
		vk_tmp[i].x=vk_tmp[i].y=vk_tmp[i].z=0.0;
#endif
			

			continue;
		}
	   r.x = r_mem[i].x - r_mem[pos].x;
	   r.y = r_mem[i].y - r_mem[pos].y;
	   r.z = r_mem[i].z - r_mem[pos].z;
		tmp = r.x*r.x + r.y*r.y + r.z*r.z;
		tmp=1.0/tmp;
		rn = sqrt(tmp);
		scal = (f[i].x*r.x + f[i].y*r.y + f[i].z*r.z)*tmp;
		vg_tmp[i].x = (f[i].x + r.x*scal)*rn;
		vg_tmp[i].y = (f[i].y + r.y*scal)*rn;
		vg_tmp[i].z = (f[i].z + r.z*scal)*rn;
#ifdef VISCOSITY_CONTRAST
		scal = (v[i].x*r.x + v[i].y*r.y + v[i].z*r.z)*(n_mem[i].x*r.x + n_mem[i].y*r.y + n_mem[i].z*r.z)*tmp*tmp*rn;
		vk_tmp[i].x =  r.x*scal;
		vk_tmp[i].y =  r.y*scal;
		vk_tmp[i].z =  r.z*scal;
#endif
	}
}

int	is_site(int triang, int site, int triang_site[NTRIANG][3])
{
    if ( site==triang_site[triang][0] ) return 0;
    if ( site==triang_site[triang][1] ) return 1;
    if ( site==triang_site[triang][2] ) return 2;
    return 3;
}

int	is_site2(int site, int* triang)
{
    if ( site==triang[0] ) return 0;
    if ( site==triang[1] ) return 1;
    if ( site==triang[2] ) return 2;
    return 3;
}





void	singular_mem_contrib( struct point3D *sum, struct point3D f0,
                                           struct point3D r_mem0,
                                           struct point3D r_mem1,
                                           struct point3D r_mem2,
                                           struct point3D pos,double eta, double pp, double shear, double dsurf)
{

    struct point3D	r01, r12, ucm, zz, tmp;
    double		rn01sq, rn12sq, rncm, rncmsq, scal01, scal12, int1, int2, cst1, cst2, f0ucm, f0zz, f0r01, f0r12, fac;

//  surface computation plus normalization

    r01.x = r_mem1.x - r_mem0.x;
    r01.y = r_mem1.y - r_mem0.y;
    r01.z = r_mem1.z - r_mem0.z;

    r12.x = r_mem2.x - r_mem1.x;
    r12.y = r_mem2.y - r_mem1.y;
    r12.z = r_mem2.z - r_mem1.z;

    ucm.x = (r_mem0.x + r_mem1.x + r_mem2.x)/3.0 - pos.x;
    ucm.y = (r_mem0.y + r_mem1.y + r_mem2.y)/3.0 - pos.y;
    ucm.z = (r_mem0.z + r_mem1.z + r_mem2.z)/3.0 - pos.z;

    rncmsq = ucm.x*ucm.x + ucm.y*ucm.y + ucm.z*ucm.z;
    rncm   = sqrt(rncmsq);

    ucm.x = ucm.x / rncm;
    ucm.y = ucm.y / rncm;
    ucm.z = ucm.z / rncm;

    rn01sq = r01.x*r01.x + r01.y*r01.y + r01.z*r01.z;
    rn12sq = r12.x*r12.x + r12.y*r12.y + r12.z*r12.z;

    scal01 = r01.x*ucm.x + r01.y*ucm.y + r01.z*ucm.z;
    scal12 = r12.x*ucm.x + r12.y*ucm.y + r12.z*ucm.z;

    int1 = rn01sq + r01.x*r12.x + r01.y*r12.y + r01.z*r12.z + rn12sq;
    int2 = scal01*scal01 + scal01*scal12 + scal12*scal12;

    cst1 = -0.5*int1 + 1.5*int2;
    cst2 = -1.5*int1 + 7.5*int2;

    zz.x = r01.x * (scal01+0.5*scal12) + r12.x * (scal12+0.5*scal01);
    zz.y = r01.y * (scal01+0.5*scal12) + r12.y * (scal12+0.5*scal01);
    zz.z = r01.z * (scal01+0.5*scal12) + r12.z * (scal12+0.5*scal01);

    f0ucm = f0.x*ucm.x + f0.y*ucm.y + f0.z*ucm.z;
    f0zz  = f0.x*zz.x + f0.y*zz.y + f0.z*zz.z;
    f0r01 = f0.x*r01.x + f0.y*r01.y + f0.z*r01.z;
    f0r12 = f0.x*r12.x + f0.y*r12.y + f0.z*r12.z;

    tmp.x = cst1 * f0.x + (cst2*f0ucm - 3.0*f0zz) * ucm.x - 3.0*f0ucm * zz.x
          + (f0r01 + 0.5*f0r12) * r01.x + (f0r12 + 0.5*f0r01) * r12.x;
    tmp.y = cst1 * f0.y + (cst2*f0ucm - 3.0*f0zz) * ucm.y - 3.0*f0ucm * zz.y
          + (f0r01 + 0.5*f0r12) * r01.y + (f0r12 + 0.5*f0r01) * r12.y;
    tmp.z = cst1 * f0.z + (cst2*f0ucm - 3.0*f0zz) * ucm.z - 3.0*f0ucm * zz.z
          + (f0r01 + 0.5*f0r12) * r01.z + (f0r12 + 0.5*f0r01) * r12.z;

    fac = 1.0/(18.0*rncmsq);

    tmp.x = f0.x + f0ucm * ucm.x + tmp.x*fac;
    tmp.y = f0.y + f0ucm * ucm.y + tmp.y*fac;
    tmp.z = f0.z + f0ucm * ucm.z + tmp.z*fac;

//  add contribution

    fac = 1.0/(8.0*PI*rncm*eta);

    sum->x += dsurf*tmp.x*fac;
    sum->y += dsurf*tmp.y*fac;
    sum->z += dsurf*tmp.z*fac;

}

/*void	regular_mem_new(  struct point3D *sum, struct point3D f_mem0,
                                           struct point3D f_mem1,
                                           struct point3D f_mem2,
                                           struct point3D r_mem0,
                                           struct point3D r_mem1,
                                           struct point3D r_mem2,
                                           struct point3D pos,
                                           double eta, double pp, double shear)
{
#define	NGREEN	5


    int			i, j;
    double		rn, scal, dsurf, mu, umu, dmu, r0n, r0n2, r0n4, r3n, r3n2, r03n, r03n2, r03n3, r03n4, r03n5;
    double		cstet, cstet2, cstet3, cstet4, sntet2, sntet4;
    struct point3D	r, f, tmp, r01, r02, r12, r03, r0, r3, rstar;
    double		a0, a1, a2, b0, b1, b2, b3, b4, alp;
    double              aa0, aa1, aa2, bb0, bb1, bb2, bb3;
    double		sum0_0, sum0_1, sum0_2, sum0_3, sum0_4, sum0_5, sum0_6;
    double		sum1_0, sum1_1, sum1_2, sum1_3, sum1_4, sum1_5, sum1_6;
    double		sum2_0, sum2_1, sum2_2, sum2_3, sum2_4, sum2_5, sum2_6;
    double		scal0, scal01, scal12, trm0, trm1, trm2, r0scal, r3scal, coeff;


        dmu = 1.0/(NGREEN-1);
//  surface computation plus normalization

        r01.x = r_mem1.x - r_mem0.x;
        r01.y = r_mem1.y - r_mem0.y;
        r01.z = r_mem1.z - r_mem0.z;

        r02.x = r_mem2.x - r_mem0.x;
        r02.y = r_mem2.y - r_mem0.y;
        r02.z = r_mem2.z - r_mem0.z;

        rstar.x = r01.y*r02.z - r01.z*r02.y;
        rstar.y = r01.z*r02.x - r01.x*r02.z;
        rstar.z = r01.x*r02.y - r01.y*r02.x;

        dsurf = dmu*sqrt(rstar.x*rstar.x + rstar.y*rstar.y + rstar.z*rstar.z)/(8.0*PI*eta);

        if (dsurf<1.e-10) return;

        r12.x = r02.x - r01.x;
        r12.y = r02.y - r01.y;
        r12.z = r02.z - r01.z;

        r0.x = r_mem0.x - pos.x;
        r0.y = r_mem0.y - pos.y;
        r0.z = r_mem0.z - pos.z;

        r0n2 = (r0.x*r0.x + r0.y*r0.y + r0.z*r0.z);
        r0n4 = r0n2*r0n2;
        r0n  = sqrt(r0n2);

        sum0_0 = sum0_1 = sum0_2 = sum0_3 = sum0_4 = sum0_5 = sum0_6 = 0.0;
        sum1_0 = sum1_1 = sum1_2 = sum1_3 = sum1_4 = sum1_5 = sum1_6 = 0.0;
        sum2_0 = sum2_1 = sum2_2 = sum2_3 = sum2_4 = sum2_5 = sum2_6 = 0.0;

        for (j=0;j<NGREEN;j++) {

            mu   = j*dmu;
            umu   = 1.0-mu;

            r03.x = r01.x + mu*r12.x;
            r03.y = r01.y + mu*r12.y;
            r03.z = r01.z + mu*r12.z;

            r3.x = r0.x + r03.x;
            r3.y = r0.y + r03.y;
            r3.z = r0.z + r03.z;

            r3n2  = r3.x*r3.x + r3.y*r3.y + r3.z*r3.z;
            r3n   = sqrt(r3n2);
            r03n2 = (r03.x*r03.x + r03.y*r03.y + r03.z*r03.z);
            r03n  = sqrt(r03n2);
            r03n3 = r03n2*r03n;
            r03n4 = r03n3*r03n;
            r03n5 = r03n4*r03n;

            r0scal = (r0.x*r03.x + r0.y*r03.y + r0.z*r03.z)/r03n;
            r3scal = (r3.x*r03.x + r3.y*r03.y + r3.z*r03.z)/r03n;

            cstet  = r0scal/r0n;
            cstet2 = cstet*cstet;
            cstet3 = cstet2*cstet;
            cstet4 = cstet3*cstet;

            sntet2 = 1.0 - cstet2;
            sntet4 = sntet2*sntet2;

            a0 = log((r3scal+r3n)/(r0scal+r0n));
            a1 = r3n - r0n;
            a2 = 0.5*(r3scal*r3n - r0scal*r0n - r0n2*sntet2*a0);
            if (sntet2>1.e-3) b0 = (r3scal/r3n - r0scal/r0n)/(r0n2*sntet2);
            else b0 = (1.0/r0n2 - 1.0/r3n2)/(r3scal/r3n + r0scal/r0n);
            b1 = 1.0/r0n - 1.0/r3n ;
            b2 = r0scal/r0n - r3scal/r3n + a0;
            b3 = r3scal*r3scal/r3n - r0scal*r0scal/r0n - 2.0*r0n2*sntet2*b1;
            b4 = a2 + r0n2*sntet2*(a0 - 2.0*b2 - r0n2*sntet2*b0);

            alp = r0n*cstet;
            aa0 = (a1 - alp*a0)/r03n2;
            aa1 = (a2 - alp*(2.0*a1 - alp*a0))/r03n3;
            bb0 = (b1 - alp*b0)/r03n2;
            bb1 = (b2 - alp*(2.0*b1 - alp*b0))/r03n3;
            bb2 = (b3 - alp*(3.0*b2 - alp*(3.0*b1 - alp*b0)))/r03n4;
            bb3 = (b4 - alp*(4.0*b3 - alp*(6.0*b2 - alp*(4.0*b1 - alp*b0))))/r03n5;

            coeff = 1.0;
            if (j==0||j==NGREEN-1) coeff=0.5;

            sum0_0 += coeff*(aa0-aa1);
            sum0_1 += coeff*(bb0-bb1);
            sum0_2 += coeff*(bb1-bb2);
            sum0_3 += coeff*(mu*(bb1-bb2));
            sum0_4 += coeff*(bb2-bb3);
            sum0_5 += coeff*(mu*(bb2-bb3));
            sum0_6 += coeff*(mu*mu*(bb2-bb3));

            sum1_0 += coeff*(umu*aa1);
            sum1_1 += coeff*(umu*bb1);
            sum1_2 += coeff*(umu*bb2);
            sum1_3 += coeff*(mu*umu*bb2);
            sum1_4 += coeff*(umu*bb3);
            sum1_5 += coeff*(mu*umu*bb3);
            sum1_6 += coeff*(mu*mu*umu*bb3);

            sum2_0 += coeff*(mu*aa1);
            sum2_1 += coeff*(mu*bb1);
            sum2_2 += coeff*(mu*bb2);
            sum2_3 += coeff*(mu*mu*bb2);
            sum2_4 += coeff*(mu*bb3);
            sum2_5 += coeff*(mu*mu*bb3);
            sum2_6 += coeff*(mu*mu*mu*bb3);

        }


        scal0  = r0.x * f_mem0.x + r0.y * f_mem0.y + r0.z * f_mem0.z;
        scal01 = r01.x * f_mem0.x + r01.y * f_mem0.y + r01.z * f_mem0.z;
        scal12 = r12.x * f_mem0.x + r12.y * f_mem0.y + r12.z * f_mem0.z;

        trm0 = sum0_1*scal0 + sum0_2*scal01 + sum0_3*scal12;
        trm1 = sum0_2*scal0 + sum0_4*scal01 + sum0_5*scal12;
        trm2 = sum0_3*scal0 + sum0_5*scal01 + sum0_6*scal12;

        tmp.x = f_mem0.x * sum0_0 + r0.x  * trm0 + r01.x * trm1 + r12.x * trm2;
        tmp.y = f_mem0.y * sum0_0 + r0.y  * trm0 + r01.y * trm1 + r12.y * trm2;
        tmp.z = f_mem0.z * sum0_0 + r0.z  * trm0 + r01.z * trm1 + r12.z * trm2;


        scal0  = r0.x * f_mem1.x + r0.y * f_mem1.y + r0.z * f_mem1.z;
        scal01 = r01.x * f_mem1.x + r01.y * f_mem1.y + r01.z * f_mem1.z;
        scal12 = r12.x * f_mem1.x + r12.y * f_mem1.y + r12.z * f_mem1.z;

        trm0 = sum1_1*scal0 + sum1_2*scal01 + sum1_3*scal12;
        trm1 = sum1_2*scal0 + sum1_4*scal01 + sum1_5*scal12;
        trm2 = sum1_3*scal0 + sum1_5*scal01 + sum1_6*scal12;

        tmp.x += f_mem1.x * sum1_0 + r0.x  * trm0 + r01.x * trm1 + r12.x * trm2;
        tmp.y += f_mem1.y * sum1_0 + r0.y  * trm0 + r01.y * trm1 + r12.y * trm2;
        tmp.z += f_mem1.z * sum1_0 + r0.z  * trm0 + r01.z * trm1 + r12.z * trm2;


        scal0  = r0.x * f_mem2.x + r0.y * f_mem2.y + r0.z * f_mem2.z;
        scal01 = r01.x * f_mem2.x + r01.y * f_mem2.y + r01.z * f_mem2.z;
        scal12 = r12.x * f_mem2.x + r12.y * f_mem2.y + r12.z * f_mem2.z;

        trm0 = sum2_1*scal0 + sum2_2*scal01 + sum2_3*scal12;
        trm1 = sum2_2*scal0 + sum2_4*scal01 + sum2_5*scal12;
        trm2 = sum2_3*scal0 + sum2_5*scal01 + sum2_6*scal12;

        tmp.x += f_mem2.x * sum2_0 + r0.x  * trm0 + r01.x * trm1 + r12.x * trm2;
        tmp.y += f_mem2.y * sum2_0 + r0.y  * trm0 + r01.y * trm1 + r12.y * trm2;
        tmp.z += f_mem2.z * sum2_0 + r0.z  * trm0 + r01.z * trm1 + r12.z * trm2;



//  add contribution

    sum->x += dsurf*tmp.x;
    sum->y += dsurf*tmp.y;
    sum->z += dsurf*tmp.z;

}*/

void	regular_mem_new(  struct point3D *sum, struct point3D f_mem0,
                                           struct point3D f_mem1,
                                           struct point3D f_mem2,
                                           struct point3D r_mem0,
                                           struct point3D r_mem1,
                                           struct point3D r_mem2,
                                           struct point3D pos,
                                           double eta1, double pp, double shear)
{
#define	NGREEN	11
#define	dmu 0.1


    int			i, j;
    double		rn, scal, dsurf, mu, umu, r0n, r0n2, r0n4, r3n, r3n2, r03n, r03n2, r03n3, r03n4, r03n5;
    double		cstet, cstet2, cstet3, cstet4, sntet2, sntet4;
    struct point3D	r, f, tmp, r01, r02, r12, r03, r0, r3, rstar;
    double		a0, a1, a2, b0, b1, b2, b3, b4, alp;
    double              aa0, aa1, aa2, bb0, bb1, bb2, bb3;
    double		sum0_0, sum0_1, sum0_2, sum0_3, sum0_4, sum0_5, sum0_6;
    double		sum1_0, sum1_1, sum1_2, sum1_3, sum1_4, sum1_5, sum1_6;
    double		sum2_0, sum2_1, sum2_2, sum2_3, sum2_4, sum2_5, sum2_6;
    double		scal0, scal01, scal12, trm0, trm1, trm2, r0scal, r3scal, coeff;


//  surface computation plus normalization

        r01.x = r_mem1.x - r_mem0.x;
        r01.y = r_mem1.y - r_mem0.y;
        r01.z = r_mem1.z - r_mem0.z;

        r02.x = r_mem2.x - r_mem0.x;
        r02.y = r_mem2.y - r_mem0.y;
        r02.z = r_mem2.z - r_mem0.z;

        rstar.x = r01.y*r02.z - r01.z*r02.y;
        rstar.y = r01.z*r02.x - r01.x*r02.z;
        rstar.z = r01.x*r02.y - r01.y*r02.x;

        dsurf = dmu*sqrt(rstar.x*rstar.x + rstar.y*rstar.y + rstar.z*rstar.z)*eta1;

        if (dsurf<1.e-10) return;

        r12.x = r02.x - r01.x;
        r12.y = r02.y - r01.y;
        r12.z = r02.z - r01.z;

        r0.x = r_mem0.x - pos.x;
        r0.y = r_mem0.y - pos.y;
        r0.z = r_mem0.z - pos.z;

        r0n2 = (r0.x*r0.x + r0.y*r0.y + r0.z*r0.z);
        r0n4 = r0n2*r0n2;
        r0n  = sqrt(r0n2);

        sum0_0 = sum0_1 = sum0_2 = sum0_3 = sum0_4 = sum0_5 = sum0_6 = 0.0;
        sum1_0 = sum1_1 = sum1_2 = sum1_3 = sum1_4 = sum1_5 = sum1_6 = 0.0;
        sum2_0 = sum2_1 = sum2_2 = sum2_3 = sum2_4 = sum2_5 = sum2_6 = 0.0;

        for (j=0;j<NGREEN;j++) {

            mu   = j*dmu;
            umu   = 1.0-mu;

            r03.x = r01.x + mu*r12.x;
            r03.y = r01.y + mu*r12.y;
            r03.z = r01.z + mu*r12.z;

            r3.x = r0.x + r03.x;
            r3.y = r0.y + r03.y;
            r3.z = r0.z + r03.z;

            r3n2  = r3.x*r3.x + r3.y*r3.y + r3.z*r3.z;
            r3n   = sqrt(r3n2);
            r03n2 = 1.0/(r03.x*r03.x + r03.y*r03.y + r03.z*r03.z);
            r03n  = sqrt(r03n2);
            r03n3 = r03n2*r03n;
            r03n4 = r03n3*r03n;
            r03n5 = r03n4*r03n;

            r0scal = (r0.x*r03.x + r0.y*r03.y + r0.z*r03.z)*r03n;
            r3scal = (r3.x*r03.x + r3.y*r03.y + r3.z*r03.z)*r03n;

            cstet  = r0scal/r0n;
            cstet2 = cstet*cstet;
            cstet3 = cstet2*cstet;
            cstet4 = cstet3*cstet;

            sntet2 = 1.0 - cstet2;
            sntet4 = sntet2*sntet2;

            a0 = log((r3scal+r3n)/(r0scal+r0n));
            a1 = r3n - r0n;
            a2 = 0.5*(r3scal*r3n - r0scal*r0n - r0n2*sntet2*a0);
            if (sntet2>1.e-3) b0 = (r3scal/r3n - r0scal/r0n)/(r0n2*sntet2);
            else b0 = (1.0/r0n2 - 1.0/r3n2)/(r3scal/r3n + r0scal/r0n);
            b1 = 1.0/r0n - 1.0/r3n ;
            b2 = r0scal/r0n - r3scal/r3n + a0;
            b3 = r3scal*r3scal/r3n - r0scal*r0scal/r0n - 2.0*r0n2*sntet2*b1;
            b4 = a2 + r0n2*sntet2*(a0 - 2.0*b2 - r0n2*sntet2*b0);

            alp = r0n*cstet;
            aa0 = (a1 - alp*a0)*r03n2;
            aa1 = (a2 - alp*(2.0*a1 - alp*a0))*r03n3;
            bb0 = (b1 - alp*b0)*r03n2;
            bb1 = (b2 - alp*(2.0*b1 - alp*b0))*r03n3;
            bb2 = (b3 - alp*(3.0*b2 - alp*(3.0*b1 - alp*b0)))*r03n4;
            bb3 = (b4 - alp*(4.0*b3 - alp*(6.0*b2 - alp*(4.0*b1 - alp*b0))))*r03n5;

            coeff = 1.0;
            if (j==0||j==NGREEN-1) coeff=0.5;

            sum0_0 += coeff*(aa0-aa1);
            sum0_1 += coeff*(bb0-bb1);
            sum0_2 += coeff*(bb1-bb2);
            sum0_3 += coeff*(mu*(bb1-bb2));
            sum0_4 += coeff*(bb2-bb3);
            sum0_5 += coeff*(mu*(bb2-bb3));
            sum0_6 += coeff*(mu*mu*(bb2-bb3));

            sum1_0 += coeff*(umu*aa1);
            sum1_1 += coeff*(umu*bb1);
            sum1_2 += coeff*(umu*bb2);
            sum1_3 += coeff*(mu*umu*bb2);
            sum1_4 += coeff*(umu*bb3);
            sum1_5 += coeff*(mu*umu*bb3);
            sum1_6 += coeff*(mu*mu*umu*bb3);

            sum2_0 += coeff*(mu*aa1);
            sum2_1 += coeff*(mu*bb1);
            sum2_2 += coeff*(mu*bb2);
            sum2_3 += coeff*(mu*mu*bb2);
            sum2_4 += coeff*(mu*bb3);
            sum2_5 += coeff*(mu*mu*bb3);
            sum2_6 += coeff*(mu*mu*mu*bb3);

        }


        scal0  = r0.x * f_mem0.x + r0.y * f_mem0.y + r0.z * f_mem0.z;
        scal01 = r01.x * f_mem0.x + r01.y * f_mem0.y + r01.z * f_mem0.z;
        scal12 = r12.x * f_mem0.x + r12.y * f_mem0.y + r12.z * f_mem0.z;

        trm0 = sum0_1*scal0 + sum0_2*scal01 + sum0_3*scal12;
        trm1 = sum0_2*scal0 + sum0_4*scal01 + sum0_5*scal12;
        trm2 = sum0_3*scal0 + sum0_5*scal01 + sum0_6*scal12;

        tmp.x = f_mem0.x * sum0_0 + r0.x  * trm0 + r01.x * trm1 + r12.x * trm2;
        tmp.y = f_mem0.y * sum0_0 + r0.y  * trm0 + r01.y * trm1 + r12.y * trm2;
        tmp.z = f_mem0.z * sum0_0 + r0.z  * trm0 + r01.z * trm1 + r12.z * trm2;


        scal0  = r0.x * f_mem1.x + r0.y * f_mem1.y + r0.z * f_mem1.z;
        scal01 = r01.x * f_mem1.x + r01.y * f_mem1.y + r01.z * f_mem1.z;
        scal12 = r12.x * f_mem1.x + r12.y * f_mem1.y + r12.z * f_mem1.z;

        trm0 = sum1_1*scal0 + sum1_2*scal01 + sum1_3*scal12;
        trm1 = sum1_2*scal0 + sum1_4*scal01 + sum1_5*scal12;
        trm2 = sum1_3*scal0 + sum1_5*scal01 + sum1_6*scal12;

        tmp.x += f_mem1.x * sum1_0 + r0.x  * trm0 + r01.x * trm1 + r12.x * trm2;
        tmp.y += f_mem1.y * sum1_0 + r0.y  * trm0 + r01.y * trm1 + r12.y * trm2;
        tmp.z += f_mem1.z * sum1_0 + r0.z  * trm0 + r01.z * trm1 + r12.z * trm2;


        scal0  = r0.x * f_mem2.x + r0.y * f_mem2.y + r0.z * f_mem2.z;
        scal01 = r01.x * f_mem2.x + r01.y * f_mem2.y + r01.z * f_mem2.z;
        scal12 = r12.x * f_mem2.x + r12.y * f_mem2.y + r12.z * f_mem2.z;

        trm0 = sum2_1*scal0 + sum2_2*scal01 + sum2_3*scal12;
        trm1 = sum2_2*scal0 + sum2_4*scal01 + sum2_5*scal12;
        trm2 = sum2_3*scal0 + sum2_5*scal01 + sum2_6*scal12;

        tmp.x += f_mem2.x * sum2_0 + r0.x  * trm0 + r01.x * trm1 + r12.x * trm2;
        tmp.y += f_mem2.y * sum2_0 + r0.y  * trm0 + r01.y * trm1 + r12.y * trm2;
        tmp.z += f_mem2.z * sum2_0 + r0.z  * trm0 + r01.z * trm1 + r12.z * trm2;



//  add contribution

    sum->x += dsurf*tmp.x;
    sum->y += dsurf*tmp.y;
    sum->z += dsurf*tmp.z;

}

